"""
Tests for the two things a voice loop has to get right and this one did not:
record all of what you said, and play the answer without clicking.

Both were reported the same way -- "it isn't recording the full spoken thing"
and "I keep hearing clicks and static" -- and both turned out to be the same
kind of mistake: a Python function given an audio-driver deadline it cannot
meet on a busy machine.

    python -m pytest tests/test_capture_voice.py -q
"""
from __future__ import annotations

import queue
import threading
import time

import numpy as np
import pytest

from mem.voice.voice_loop import MIC_BLOCK, PTT_MIN_SAMPLES, PTT_TAIL_S, VoiceLoop


class FakeDash:
    def __init__(self):
        self.events: list[tuple] = []
        self.panes = None
        self.hub = self

    def emit(self, kind, payload):
        self.events.append((kind, payload))

    def send_threadsafe(self, msg):
        self.events.append(("raw", msg))


class FakeSpeaker:
    half_duplex = False
    ref = None
    busy = False

    def speak(self, text):
        pass

    def stop(self):
        pass

    def resume(self):
        pass

    def close(self):
        self.stop()


@pytest.fixture
def vl():
    loop = VoiceLoop(FakeDash())
    loop.speaker = FakeSpeaker()
    loop._alive = True
    return loop


def _block(n=MIC_BLOCK, value=0.2):
    return np.full(n, value, dtype=np.float32)


def _pump_in_thread(loop, q):
    t = threading.Thread(target=loop._pump, args=(q,), daemon=True)
    t.start()
    return t


def _wait(pred, timeout=2.0):
    deadline = time.time() + timeout
    while time.time() < deadline:
        if pred():
            return True
        time.sleep(0.01)
    return False


# ------------------------------------------------------- capturing the tail

def test_the_block_still_in_the_driver_is_kept(vl):
    """THE BUG. A 256ms capture block means that when you let go of the key,
    the block holding the last quarter-second of your sentence has not been
    handed over yet. Closing the recording at the keystroke threw it away, and
    what reached whisper was a sentence with its ending cut off."""
    sent = []
    vl._handle_utterance = lambda utt: sent.append(utt)

    q: queue.Queue = queue.Queue()
    _pump_in_thread(vl, q)

    vl.set_ptt(True)
    for _ in range(4):
        q.put(_block())
    assert _wait(lambda: len(vl._ptt_buf) == 4), "held audio was not recorded"

    vl.set_ptt(False)           # key up -- the last block has NOT arrived yet
    q.put(_block(value=0.9))    # ...and now the driver hands it over

    assert _wait(lambda: sent), "the recording never closed"
    vl._stop.set()

    got = sent[0]
    assert len(got) == 5 * MIC_BLOCK, \
        f"lost the tail: kept {len(got)} samples of {5 * MIC_BLOCK}"
    assert got[-1] == pytest.approx(0.9), "the last block is not the one at the end"


def test_the_recording_closes_even_if_nothing_more_arrives(vl):
    """The tail block is waited for, not waited on forever. Unplug the
    microphone between the last block and the keystroke and the turn still has
    to finish, or push-to-talk hangs with no way out."""
    sent = []
    vl._handle_utterance = lambda utt: sent.append(utt)

    q: queue.Queue = queue.Queue()
    _pump_in_thread(vl, q)

    vl.set_ptt(True)
    for _ in range(3):
        q.put(_block())
    assert _wait(lambda: len(vl._ptt_buf) == 3)

    t0 = time.time()
    vl.set_ptt(False)                     # and nothing ever arrives again
    assert _wait(lambda: sent, timeout=PTT_TAIL_S + 1.0), "push-to-talk hung"
    vl._stop.set()
    assert time.time() - t0 >= PTT_TAIL_S * 0.8, "gave up on the tail too early"


def test_audio_captured_before_the_key_went_down_is_not_recorded(vl):
    """The microphone is open the whole time; only the held part is a turn."""
    q: queue.Queue = queue.Queue()
    q.put(_block())                       # arrives before the key goes down
    _pump_in_thread(vl, q)
    time.sleep(0.15)
    assert vl._ptt_buf == []
    vl._stop.set()


def test_a_stray_tap_is_measured_in_samples_not_blocks(vl):
    """The length test used to be `len(buf) * 512`, which counted frames as if
    they were still 512 samples each. With a 4096-sample block that reads a
    single tap as eight times the audio it holds -- and the check that exists
    to ignore a stray keypress would pass one straight through."""
    sent = []
    vl._handle_utterance = lambda utt: sent.append(utt)
    vl.set_ptt(True)
    vl._ptt_buf = [np.zeros(200, dtype=np.float32)]     # far under the minimum
    vl.set_ptt(False)                                   # no mic thread: closes here
    assert sent == []
    assert vl._state == "listening"


def test_a_real_utterance_is_sent(vl):
    sent = []
    vl._handle_utterance = lambda utt: sent.append(utt)
    vl.set_ptt(True)
    vl._ptt_buf = [np.zeros(PTT_MIN_SAMPLES + 1, dtype=np.float32)]
    vl.set_ptt(False)
    assert _wait(lambda: sent), "a held sentence was dropped"


def test_dropped_capture_is_reported(vl):
    """It used to be silent. The driver threw audio away, whisper transcribed
    what was left, and half a sentence went to the session looking exactly like
    something you had chosen to say."""
    vl._handle_utterance = lambda utt: None
    vl.set_ptt(True)
    vl._dropped += 1                       # what the input callback records
    vl._ptt_buf = [np.zeros(PTT_MIN_SAMPLES + 1, dtype=np.float32)]
    vl.set_ptt(False)
    said = [m for k, m in vl.dash.events if k == "raw"]
    assert any("dropped" in (m.get("msg") or "") for m in said), \
        "audio was lost and nothing said so"


def test_the_capture_block_is_wide_enough_to_meet_its_deadline():
    """Measured: capturing for three seconds while eight compute-bound threads
    ran, a 512-sample block lost 58% of the audio and a 4096-sample block lost
    none. The block is the deadline; anything narrow brings the loss back."""
    from mem.voice.stt import SAMPLE_RATE
    assert MIC_BLOCK / SAMPLE_RATE >= 0.1, "under 100ms per callback is the bug"


# ------------------------------------------------------------- the speaker

def test_clip_edges_are_ramped():
    """A waveform that starts or ends away from zero is a step, and a step is
    a click -- at every sentence boundary, in every reply."""
    from mem.voice.tts import _shape
    x = np.ones(4800, dtype=np.float32)
    out = _shape(x, 24000)
    assert abs(out[0]) < 0.05 and abs(out[-1]) < 0.05, "an edge would click"
    assert out[len(out) // 2] == pytest.approx(1.0), "the middle was touched"


def test_a_clip_past_full_scale_is_brought_back():
    """Above full scale the device clips it into harsh broadband noise, which
    is what static is."""
    from mem.voice.tts import _shape
    out = _shape(np.full(4800, 3.0, dtype=np.float32), 24000)
    assert float(np.abs(out).max()) <= 1.0


def test_an_empty_clip_is_harmless():
    from mem.voice.tts import _shape
    assert len(_shape(np.zeros(0, dtype=np.float32), 24000)) == 0


def test_the_output_stream_is_not_reopened_per_sentence():
    """`sd.play` opens a device stream, plays one sentence, and closes it. The
    speakers run at 44100 and Kokoro produces 24000, so every sentence
    renegotiated the device format -- which is the click, dozens of times in
    one reply. One stream, opened once, replaced it."""
    import ast
    from pathlib import Path
    import mem.voice.tts as tts
    # The AST, not the text: this file's own docstrings explain what sd.play
    # did and why it went, and a substring search reads those as the code.
    tree = ast.parse(Path(tts.__file__).read_text(encoding="utf-8"))
    called = {ast.unparse(n.func) for n in ast.walk(tree) if isinstance(n, ast.Call)}
    assert "sd.play" not in called, "back to a stream per sentence"
    assert "sd.OutputStream" in called


def test_synthesis_runs_ahead_of_playback():
    """Synthesis and playback used to be serial -- speak a sentence, THEN start
    synthesizing the next one -- which measured 0.27-1.21s of silence dropped
    into the middle of every reply."""
    import mem.voice.tts as tts

    class SlowEngine:
        def __init__(self):
            self.synthesized: list[str] = []

        def synth(self, text):
            self.synthesized.append(text)
            return np.zeros(240, dtype=np.float32), 24000

    engine = SlowEngine()
    sp = tts.Speaker.__new__(tts.Speaker)      # no audio device in a test
    tts.Speaker.__init__(sp, engine)
    written: list = []
    sp._write = lambda samples, sr: (written.append(sr), time.sleep(0.3))

    for s in ("one.", "two.", "three."):
        sp.speak(s)
    time.sleep(0.35)                            # still inside the FIRST clip
    assert len(engine.synthesized) >= 2, \
        "the next sentence was not being synthesized while this one played"


def test_busy_covers_the_gap_while_a_sentence_is_synthesized():
    """`busy` is what the orb reads to decide it is still speaking. With the
    generator running ahead, a sentence taken off the text queue but not yet
    turned into audio belongs to neither queue -- and reporting silence there
    makes the orb twitch out of speaking mid-reply."""
    import mem.voice.tts as tts

    started = threading.Event()
    release = threading.Event()

    class BlockingEngine:
        def synth(self, text):
            started.set()
            release.wait(2.0)
            return np.zeros(240, dtype=np.float32), 24000

    sp = tts.Speaker.__new__(tts.Speaker)
    tts.Speaker.__init__(sp, BlockingEngine())
    sp._write = lambda samples, sr: None
    sp.speak("hello.")
    assert started.wait(2.0)
    assert sp.busy, "reported silence while the sentence was still being made"
    release.set()


def _speaker(engine):
    """A Speaker with no audio device behind it."""
    import mem.voice.tts as tts
    sp = tts.Speaker.__new__(tts.Speaker)
    tts.Speaker.__init__(sp, engine)
    return sp


class _NeverAnyRoom:
    """A device that is permanently full — what the real one looks like for
    the moment after an abort."""
    active = True
    write_available = 0

    def write(self, chunk):
        raise AssertionError("wrote to a full device")


def test_a_barge_in_cannot_wedge_the_writer():
    """THE HANG. `stream.write()` blocks until the device has room, and an
    abort landing while a write was parked inside it did not reliably come
    back: the worker hung, `playing` stayed set, and the voice went silent for
    the rest of the session while still reporting that it was speaking. Four
    interruptions in a row reproduced it every time."""
    sp = _speaker(object())
    sp._open = lambda sr: _NeverAnyRoom()

    done = threading.Event()

    def write():
        sp._write(np.zeros(24000, dtype=np.float32), 24000)
        done.set()

    threading.Thread(target=write, daemon=True).start()
    time.sleep(0.1)
    assert not done.is_set(), "the test's premise is wrong: it never blocked"
    sp.stop_flag.set()
    assert done.wait(1.0), "a barge-in could not get the writer out"


def test_the_writer_leaves_when_the_device_stops():
    """The stop flag is not the only way a write becomes impossible."""
    sp = _speaker(object())

    class Stopping(_NeverAnyRoom):
        active = False

    sp._open = lambda sr: Stopping()
    done = threading.Event()
    threading.Thread(
        target=lambda: (sp._write(np.zeros(24000, dtype=np.float32), 24000),
                        done.set()), daemon=True).start()
    assert done.wait(1.0), "kept writing at a stopped device"
