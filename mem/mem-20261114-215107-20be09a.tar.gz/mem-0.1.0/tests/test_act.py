"""mem do: fixed actions, honest one-line results, never sends."""
import subprocess

import pytest

from mem.voice import act
from mem.voice.pointer import ease, path_point


class FakeRun:
    """Records every command; answers osascript/open from a script."""

    def __init__(self, answers=None):
        self.calls, self.answers = [], answers or {}

    def __call__(self, args, **kw):
        self.calls.append(args)
        key = args[-1] if args[0] == "osascript" else " ".join(args[:2])
        for needle, (code, out, err) in self.answers.items():
            if needle in key:
                return subprocess.CompletedProcess(args, code, out, err)
        return subprocess.CompletedProcess(args, 0, "", "")


@pytest.fixture
def fake(monkeypatch):
    f = FakeRun()
    monkeypatch.setattr(act.subprocess, "run", f)
    monkeypatch.setattr(act.shutil, "which", lambda n: "/usr/bin/" + n)
    monkeypatch.setattr(act.time, "sleep", lambda s: None)
    return f


def test_escaping_cannot_break_out_of_the_string():
    assert act.esc('say "hi" \\ bye') == 'say \\"hi\\" \\\\ bye'


@pytest.mark.parametrize("err,needle", [
    ("execution error: Not authorized to send Apple events to Music. (-1743)", "Automation"),
    ("Music got an error: Application isn't running. (-600)", "not running"),
])
def test_macos_errors_become_the_fix(err, needle):
    assert needle in act.explain(err, "Music")


def test_mail_opens_a_draft_and_never_sends(fake):
    ok, msg = act.do_mail("a@b.com", "hi there", "line & more")
    assert ok and "press send" in msg
    (cmd,) = fake.calls
    assert cmd[0] == "open" and cmd[1].startswith("mailto:a@b.com?subject=hi%20there")
    assert "%26" in cmd[1]                         # & cannot end the body early
    assert not any(c[0] == "osascript" for c in fake.calls)


def test_open_unknown_app_fails_honestly(fake):
    fake.answers = {"open -a": (1, "", "Unable to find application named 'Nope'")}
    ok, msg = act.do_open("Nope")
    assert not ok and "no app called Nope" in msg


def test_open_waits_for_proof(fake):
    fake.answers = {"is running": (0, "true\n", "")}
    ok, msg = act.do_open("Safari")
    assert ok and msg == "Safari is open"


def test_open_url_and_path(fake, tmp_path):
    f = tmp_path / "notes.md"; f.write_text("x")
    assert act.do_open("https://example.com")[0]
    assert act.do_open(str(f)) == (True, "opened notes.md")


def test_play_that_does_not_start_is_not_reported_as_playing(fake):
    fake.answers = {"player state": (0, "paused\n", "")}
    ok, msg = act.do_music("play")
    assert not ok and "did not start playing" in msg


def test_play_from_library(fake):
    fake.answers = {"library playlist": (0, "Teardrop by Massive Attack\n", "")}
    assert act.do_music("play", "teardrop") == (True, "playing Teardrop by Massive Attack")


def test_not_in_library_opens_search_and_says_so(fake):
    fake.answers = {"library playlist": (0, "\n", "")}
    ok, msg = act.do_music("play", "some song")
    assert ok and "pick the one you want" in msg
    assert any(c[0] == "open" and "music.apple.com/search?term=some%20song" in c[1]
               for c in fake.calls)


def test_spotify_search_is_not_a_pretend_play(fake):
    fake.answers = {'application "Spotify" is running': (0, "true\n", "")}
    ok, msg = act.do_music("play", "lofi")
    assert ok and msg.startswith("opened Spotify's search")


def test_music_permission_error_surfaces(fake):
    fake.answers = {"library playlist": (1, "", "Not authorized to send Apple events (-1743)")}
    ok, msg = act.do_music("play", "x")
    assert not ok and "Automation" in msg


def test_volume_clamps_and_rejects_nonsense(fake):
    assert act.do_volume("250") == (True, "volume 100")
    assert act.do_volume("loud")[0] is False
    fake.answers = {"get volume settings": (0, "95\n", "")}
    assert act.do_volume("up") == (True, "volume 100")


def test_point_scales_screenshot_pixels(monkeypatch):
    seen = {}
    monkeypatch.setattr(act, "screen_scale", lambda: 2.0)
    monkeypatch.setattr(act.subprocess, "Popen", lambda args, **kw: seen.setdefault("a", args))
    ok, msg = act.do_point(800, 600, "here", shot=True)
    assert ok and msg == "pointing at 400,300 (here)"
    assert seen["a"][3:5] == ["400.0", "300.0"]


def test_cli_exit_codes(fake, capsys):
    assert act.main(["volume", "40"]) == 0
    assert capsys.readouterr().out.strip() == "volume 40"
    assert act.main(["volume", "loud"]) == 1
    assert act.main(["nonsense"]) == 2


def test_pointer_path_starts_and_ends_where_asked_and_bows():
    a, b = (0.0, 0.0), (400.0, 0.0)
    assert path_point(a, b, 0) == a and path_point(a, b, 1) == b
    assert abs(path_point(a, b, 0.5)[1]) > 20          # a reach, not a teleport
    assert ease(0) == 0 and ease(1) == 1 and ease(0.5) == 0.5


def test_navigator_prompt_uses_the_toolkit_by_absolute_path():
    from mem.voice.voice_prompt import build, do_command
    p = build("Ada")
    assert do_command() in p and "-m mem do" in p
    assert "never sends" in p.lower() or "It never sends" in p
