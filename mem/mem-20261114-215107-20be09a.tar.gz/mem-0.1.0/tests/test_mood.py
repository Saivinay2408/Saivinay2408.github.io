"""mood: every feeling has a cause, and every feeling fades."""
from mem.voice.mood import Mood, NAMES, palette


class Clock:
    def __init__(self):
        self.t = 0.0

    def __call__(self):
        return self.t


def make():
    clock, sent = Clock(), []
    return Mood(emit=sent.append, clock=clock), clock, sent


def test_palette_matches_names():
    assert [n for n, _ in palette()] == list(NAMES)
    assert dict(palette())["completeness"].lower() == "#fffaf0"


def test_calm_at_rest():
    m, _, _ = make()
    assert max(m.snapshot().values()) == 0


def test_prompt_brings_warmth():
    m, _, _ = make()
    m.on_event({"kind": "user", "text": "hey"})
    assert m.dominant()[0] == "warmth"


def test_reading_is_curiosity_editing_is_focus():
    m, _, _ = make()
    m.on_event({"kind": "tool", "name": "Grep", "input": {}, "id": "a"})
    m.on_event({"kind": "tool", "name": "Read", "input": {}, "id": "b"})
    assert m.dominant()[0] == "curiosity"
    m2, _, _ = make()
    m2.on_event({"kind": "tool", "name": "Edit", "input": {}, "id": "c"})
    m2.on_event({"kind": "tool", "name": "Write", "input": {}, "id": "d"})
    assert m2.dominant()[0] == "focus"


def test_errors_raise_concern_and_it_grows():
    m, _, _ = make()
    m.on_event({"kind": "tool_result", "ok": False, "id": "x"})
    one = m.snapshot()["concern"]
    m.on_event({"kind": "tool_result", "ok": False, "id": "y"})
    assert m.snapshot()["concern"] > one * 1.5


def test_passing_tests_bring_joy_and_clear_concern():
    m, _, _ = make()
    m.on_event({"kind": "tool_result", "ok": False, "id": "x"})
    m.on_event({"kind": "tool", "name": "Bash", "input": {"command": "python3 -m pytest -q"}, "id": "t"})
    before = m.snapshot()["concern"]
    m.on_event({"kind": "tool_result", "ok": True, "id": "t"})
    s = m.snapshot()
    assert s["joy"] >= 50 and s["concern"] < before


def test_a_failed_test_run_is_concern_not_joy():
    m, _, _ = make()
    m.on_event({"kind": "tool", "name": "Bash", "input": {"command": "npm test"}, "id": "t"})
    m.on_event({"kind": "tool_result", "ok": False, "id": "t"})
    s = m.snapshot()
    assert s["joy"] == 0 and s["concern"] > 0


def test_clean_finish_blazes_white_dirty_finish_does_not():
    clean, _, _ = make()
    for i in range(3):
        clean.on_event({"kind": "tool", "name": "Edit", "input": {}, "id": str(i)})
        clean.on_event({"kind": "tool_result", "ok": True, "id": str(i)})
    clean.on_event({"kind": "turn_end"})
    assert clean.dominant()[0] == "completeness"

    dirty, _, _ = make()
    dirty.on_event({"kind": "tool", "name": "Edit", "input": {}, "id": "1"})
    dirty.on_event({"kind": "tool_result", "ok": False, "id": "1"})
    dirty.on_event({"kind": "tool", "name": "Edit", "input": {}, "id": "2"})
    dirty.on_event({"kind": "turn_end"})
    assert dirty.snapshot()["completeness"] < clean.snapshot()["completeness"]


def test_a_chat_reply_alone_is_not_completeness():
    m, _, _ = make()
    m.on_event({"kind": "user", "text": "hi"})
    m.on_event({"kind": "assistant", "text": "hey"})
    m.on_event({"kind": "turn_end"})
    assert m.snapshot()["completeness"] == 0


def test_blocked_holds_urgency():
    m, clock, _ = make()
    m.set_blocked(True)
    for _ in range(10):
        clock.t += 1.0
        m.set_blocked(True)
    assert m.snapshot()["urgency"] >= 75


def test_everything_fades():
    m, clock, _ = make()
    m.on_event({"kind": "tool_result", "ok": False, "id": "x"})
    m.on_event({"kind": "user", "text": "hi"})
    clock.t += 60
    m.tick()
    assert max(m.snapshot().values()) <= 1


def test_emits_are_throttled_and_off_means_silent():
    m, clock, sent = make()
    m.on_event({"kind": "user", "text": "a"})
    m.on_event({"kind": "user", "text": "b"})       # same instant: throttled
    assert len(sent) == 1
    clock.t += 1
    m.enabled = False
    m.on_event({"kind": "tool_result", "ok": False, "id": "z"})
    assert len(sent) == 1
