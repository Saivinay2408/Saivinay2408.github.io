"""Phone calls (call.py) and the guard that keeps other websites out."""
import asyncio
import json
import threading
import time

import numpy as np
import pytest

from mem.voice import call as C


# ---- pure pieces ------------------------------------------------------------

def test_sentences_split_and_merge_short():
    out = C._sentences("Yes. OK. Your next meeting is the design review at four.\nWant the doc?")
    assert out[0].startswith("Yes. OK. Your next meeting")
    assert out[-1] == "Want the doc?"


def test_filler_is_ignored_but_short_answers_are_not():
    for f in ("Thank you.", "um", "Hmm...", "you"):
        assert C._filler(f), f
    for real in ("yes", "okay", "stop", "open the doc"):
        assert not C._filler(real), real


def test_resample_length():
    x = np.zeros(24000, dtype="float32")
    assert len(C._resample(x, 24000, 48000)) == 48000


def test_drain_keeps_shutdown_signal():
    import queue
    q = queue.Queue()
    for item in ("a", "b", None):
        q.put(item)
    C._drain(q)
    assert q.get_nowait() is None


# ---- a real call, both ends on this machine ---------------------------------

try:
    import aiortc  # noqa: F401
    HAVE_RTC = True
except ImportError:
    HAVE_RTC = False
needs_rtc = pytest.mark.skipif(not HAVE_RTC, reason="aiortc not installed")


class _FakeVAD:
    """Calls anything loud speech, and ends the utterance after quiet."""
    def __init__(self):
        self.buf, self.speaking, self.quiet = [], False, 0

    def feed(self, frame):
        loud = float(np.abs(frame).max()) > 0.05
        if loud:
            self.speaking, self.quiet = True, 0
            self.buf.append(frame)
            return None
        if self.speaking:
            self.quiet += 1
            if self.quiet > 8:
                utt = np.concatenate(self.buf)
                self.buf, self.speaking = [], False
                return utt
        return None


class _FakeSTT:
    def transcribe(self, audio):
        return "what is next", 0.0


class _Voice:
    def __init__(self):
        self.asked = []
        self.interrupted = 0

    def submit_remote(self, text, sink, speak_on_mac=False, progress=None, stream=None):
        self.asked.append((text, speak_on_mac))
        def go():
            stream("The design review at four.")
            sink("The design review at four.")
        threading.Thread(target=go, daemon=True).start()
        return True

    def _interrupt_turns(self):
        self.interrupted += 1


class _Dash:
    call = None


def _tone_track():
    """A phone saying something for 0.6 s, then silence."""
    import av
    import fractions
    from aiortc import MediaStreamTrack

    class Tone(MediaStreamTrack):
        kind = "audio"
        def __init__(self):
            super().__init__()
            self.pts = 0
            self.t0 = None
        async def recv(self):
            if self.t0 is None:
                self.t0 = time.monotonic()
            wait = self.t0 + self.pts / 48000 - time.monotonic()
            if wait > 0:
                await asyncio.sleep(wait)
            t = (np.arange(960) + self.pts) / 48000
            on = 0.3 <= self.pts / 48000 < 0.9
            x = (0.4 * np.sin(2 * np.pi * 300 * t) * on * 32767).astype("int16")
            f = av.AudioFrame.from_ndarray(x.reshape(1, -1), format="s16", layout="mono")
            f.sample_rate, f.pts, f.time_base = 48000, self.pts, fractions.Fraction(1, 48000)
            self.pts += 960
            return f
    return Tone()


@needs_rtc
def test_call_hears_asks_and_answers_out_loud():
    from aiortc import RTCConfiguration, RTCPeerConnection, RTCSessionDescription

    async def run():
        dash = _Dash()
        dash.voice = _Voice()
        spoken = []
        def synth(text):
            spoken.append(text)
            return np.full(4800, 0.2, dtype="float32"), 24000
        call = C.Call(dash, vad=_FakeVAD(), stt=_FakeSTT(), synth=synth)
        pc = RTCPeerConnection(RTCConfiguration(iceServers=[]))
        msgs = []
        ch = pc.createDataChannel("mem")
        ch.on("message", lambda m: msgs.append(json.loads(m)))
        pc.addTrack(_tone_track())
        got = []

        @pc.on("track")
        def _t(track):
            async def pull():
                while True:
                    try:
                        f = await track.recv()
                    except Exception:
                        return
                    got.append(float(np.abs(f.to_ndarray()).max()))
            asyncio.ensure_future(pull())

        await pc.setLocalDescription(await pc.createOffer())
        ans = await call.answer(pc.localDescription.sdp)
        await pc.setRemoteDescription(RTCSessionDescription(**ans))
        for _ in range(60):
            await asyncio.sleep(0.1)
            if spoken and any(g > 1000 for g in got[-20:]):
                break
        kinds = [m["t"] for m in msgs]
        await pc.close()
        await call.close()
        return dash, spoken, msgs, kinds, got

    dash, spoken, msgs, kinds, got = asyncio.run(run())
    assert dash.voice.asked == [("what is next", False)]   # the Mac stays quiet
    assert spoken == ["The design review at four."]
    assert {"t": "you", "v": "what is next"} in msgs
    assert "clone" in kinds and "state" in kinds
    assert any(g > 1000 for g in got), "the answer never reached the phone"


@needs_rtc
def test_barge_in_clears_the_answer():
    dash = _Dash()
    dash.voice = _Voice()

    async def make():
        return C.Call(dash, vad=_FakeVAD(), stt=_FakeSTT(), synth=lambda t: (None, 0))
    call = asyncio.run(make())
    call.out.push(np.full(48000 * 3, 0.2, dtype="float32"), 48000)
    assert call.out.playing
    loud = np.full(C.VAD_FRAME, 0.3, dtype="float32")
    t = threading.Thread(target=call._ears, daemon=True)
    t.start()
    for _ in range(int(C.BARGE_IN_S * C.IN_RATE / C.VAD_FRAME) + 3):
        call._frames.put(loud)
    deadline = time.time() + 2
    while call.out.playing and time.time() < deadline:
        time.sleep(0.02)
    assert not call.out.playing
    call._frames.put(None)


@needs_rtc
def test_stop_message_interrupts_the_work():
    dash = _Dash()
    dash.voice = _Voice()

    async def make():
        return C.Call(dash, vad=_FakeVAD(), stt=_FakeSTT(), synth=lambda t: (None, 0))
    call = asyncio.run(make())
    call.out.push(np.ones(48000, dtype="float32"), 48000)
    call._on_message(json.dumps({"t": "stop"}))
    assert not call.out.playing and dash.voice.interrupted == 1


# ---- the server -------------------------------------------------------------

def _client_for(dash):
    from aiohttp.test_utils import TestClient, TestServer
    return TestClient(TestServer(dash.app))


def test_other_websites_cannot_drive_mem(tmp_path, monkeypatch):
    pytest.importorskip("aiohttp")
    from mem.voice import phone
    from mem.voice.server import Dashboard
    monkeypatch.setattr(phone, "CONFIG", tmp_path / "phone.json")

    async def run():
        dash = Dashboard(model="sonnet", permission_mode="acceptEdits")
        async with _client_for(dash) as c:
            host = f"{c.server.host}:{c.server.port}"
            evil = await c.post("/phone/ask", json={"text": "rm -rf"},
                                headers={"Origin": "https://evil.example"})
            null = await c.get("/ws", headers={"Origin": "null"})
            same = await c.get("/phone", headers={"Origin": f"http://{host}"})
            plain = await c.get("/phone")
            return evil.status, null.status, same.status, plain.status
    assert asyncio.run(run()) == (403, 403, 200, 200)


def test_call_and_screen_need_the_phone_login(tmp_path, monkeypatch):
    pytest.importorskip("aiohttp")
    from mem.voice import phone
    from mem.voice.server import Dashboard
    monkeypatch.setattr(phone, "CONFIG", tmp_path / "phone.json")
    phone.update(enabled=True)
    R = {"Host": "mac.tailnet.ts.net"}

    async def run():
        dash = Dashboard(model="sonnet", permission_mode="acceptEdits")
        async with _client_for(dash) as c:
            a = await c.post("/phone/call", json={"sdp": "x", "type": "offer"}, headers=R)
            b = await c.get("/phone/screen.jpg", headers=R)
            bad = await c.post("/phone/call", data=b"nope",
                               headers={"Content-Type": "application/json"})
            return a.status, b.status, bad.status
    assert asyncio.run(run()) == (401, 401, 400)
