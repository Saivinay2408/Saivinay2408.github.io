"""Phone access: who gets in, what they reach, and that answers come back."""
from __future__ import annotations

import time

import pytest

from mem.voice import phone, telegram
from mem.voice.voice_loop import VoiceLoop

TOKEN = "123456789:" + "A" * 35


@pytest.fixture(autouse=True)
def isolated(tmp_path, monkeypatch):
    monkeypatch.setattr(phone, "CONFIG", tmp_path / "phone.json")
    monkeypatch.setenv("MEM_TELEGRAM_TOKEN", TOKEN)


# ---- pairing --------------------------------------------------------------------

def test_pairing_needs_the_right_fresh_code_once():
    code = phone.new_pair_code()
    assert not phone.try_pair(7, "000000" if code != "000000" else "111111")
    assert phone.try_pair(7, code, "Ada")
    assert phone.is_allowed(7)
    assert not phone.try_pair(8, code)                 # single use
    assert not phone.is_allowed(8)


def test_expired_code_fails(monkeypatch):
    code = phone.new_pair_code()
    later = time.time() + phone.PAIR_TTL_S + 5
    monkeypatch.setattr(phone.time, "time", lambda: later)
    assert not phone.try_pair(7, code)


def test_lock_blocks_and_rotates_the_web_token():
    phone.try_pair(7, phone.new_pair_code())
    tok = phone.web_token()
    assert phone.web_token_ok(tok)
    phone.lock()
    assert not phone.is_allowed(7)
    assert not phone.web_token_ok(tok)


def test_config_is_private():
    phone.update(enabled=True)
    assert oct(phone.CONFIG.stat().st_mode & 0o777) == "0o600"


def test_token_shape():
    assert phone.looks_like_token(TOKEN)
    assert not phone.looks_like_token("hello")


# ---- the bridge -----------------------------------------------------------------

class Pty:
    def __init__(self):
        self.alive, self.wrote = True, []

    def write(self, b):
        self.wrote.append(b)

    def scrollback(self):
        return b"\x1b[1mDo you want to proceed?\x1b[0m\r\n 1. Yes\r\n 2. No\r\n"


class Pane:
    def __init__(self, pid="p1", title="clone"):
        self.id, self.title, self.cwd, self.pty = pid, title, "/tmp/x", Pty()


class Panes:
    def __init__(self):
        self.p = Pane()
        self.target_set = None

    def target_pane(self):
        return self.p

    def info(self):
        return [{"id": "p1", "title": "clone", "shortCwd": "x", "state": "idle", "voice": True},
                {"id": "p2", "title": "api", "shortCwd": "api", "state": "blocked", "voice": False}]

    def set_voice_target(self, pid):
        self.target_set = pid


class Voice:
    def __init__(self):
        self.asked, self.on_blocked, self.state = [], [], "listening"

    def submit_remote(self, text, sink, speak_on_mac=False, progress=None):
        self.asked.append(text)
        sink(f"answer to {text}")
        return True

    def attach_target_pane(self):
        pass


class Hub:
    def send_threadsafe(self, m):
        pass


class Dash:
    def __init__(self):
        self.panes, self.voice, self.hub = Panes(), Voice(), Hub()
        self.phone_url = ""


@pytest.fixture
def bridge(monkeypatch):
    b = telegram.TelegramBridge(Dash(), token=TOKEN, api="http://fake")
    b.sent = []
    monkeypatch.setattr(b, "send", lambda chat, text, buttons=None: b.sent.append((chat, text, buttons)))
    monkeypatch.setattr(b, "typing", lambda chat: None)
    monkeypatch.setattr(telegram.threading, "Thread", Inline)
    return b


class Inline:
    """Run "threads" immediately, so the round trip is synchronous in tests."""

    def __init__(self, target=None, args=(), daemon=None, name=None):
        self.t, self.a = target, args

    def start(self):
        if getattr(self.t, "__name__", "") != "keep_typing":
            self.t(*self.a)


def msg(uid, text="", chat_type="private", **extra):
    return {"update_id": 1, "message": {"from": {"id": uid, "first_name": "Ada"},
                                        "chat": {"id": uid, "type": chat_type},
                                        "text": text, **extra}}


def test_strangers_get_silence(bridge):
    bridge.handle(msg(99, "hi"))
    bridge.handle(msg(99, "/start 123456"))
    assert bridge.sent == [] and bridge.ignored == 2
    assert bridge.dash.voice.asked == []


def test_groups_are_never_answered(bridge):
    phone.try_pair(7, phone.new_pair_code())
    bridge.handle(msg(7, "hi", chat_type="group"))
    assert bridge.sent == []


def test_pair_by_start_link_then_talk(bridge):
    code = phone.new_pair_code()
    bridge.handle(msg(7, f"/start {code}"))
    assert "Paired" in bridge.sent[-1][1]
    bridge.handle(msg(7, "what am I building?"))
    assert bridge.dash.voice.asked == ["what am I building?"]
    assert bridge.sent[-1][1] == "answer to what am I building?"


def test_voice_note_is_heard_and_answered_with_voice(bridge, monkeypatch, tmp_path):
    phone.try_pair(7, phone.new_pair_code())
    f = tmp_path / "n.ogg"; f.write_bytes(b"x")
    monkeypatch.setattr(bridge, "download", lambda fid, suf: str(f))
    import mem.voice.phone_audio as pa
    monkeypatch.setattr(pa, "hear", lambda path, voice=None: "open the plan")
    monkeypatch.setattr(pa, "speak", lambda text, voice=None, out_dir=None: "/tmp/r.m4a")
    voiced = []
    monkeypatch.setattr(bridge, "send_voice", lambda chat, path: voiced.append(path))
    bridge.handle(msg(7, voice={"file_id": "F"}))
    assert bridge.sent[0][1] == "heard: open the plan"
    assert bridge.dash.voice.asked == ["open the plan"]
    assert voiced == ["/tmp/r.m4a"]
    assert not f.exists()                             # the recording is not kept


def test_commands(bridge):
    phone.try_pair(7, phone.new_pair_code())
    bridge.handle(msg(7, "/sessions"))
    assert "2. api" in bridge.sent[-1][1] and "<- talking to" in bridge.sent[-1][1]
    bridge.handle(msg(7, "/use 2"))
    assert bridge.dash.panes.target_set == "p2"
    bridge.handle(msg(7, "/keys 1 enter"))
    assert bridge.dash.panes.p.pty.wrote == [b"1", b"\r"]
    bridge.handle(msg(7, "/keys rm"))
    assert "do not know the key" in bridge.sent[-1][1]
    bridge.handle(msg(7, "/screen"))
    assert "Do you want to proceed?" in bridge.sent[-1][1] and "\x1b" not in bridge.sent[-1][1]
    bridge.handle(msg(7, "/stop"))
    assert bridge.dash.panes.p.pty.wrote[-1] == b"\x1b"
    bridge.handle(msg(7, "/lock"))
    assert not phone.is_allowed(7)


def test_blocked_pushes_with_buttons(bridge):
    phone.try_pair(7, phone.new_pair_code())
    bridge.notify_blocked(["api"])
    chat, text, buttons = bridge.sent[-1]
    assert chat == 7 and text == "api needs you." and buttons


def test_buttons_from_a_stranger_do_nothing(bridge, monkeypatch):
    monkeypatch.setattr(bridge, "call", lambda *a, **k: None)
    bridge.handle({"callback_query": {"id": "q", "from": {"id": 99}, "data": "k:1",
                                      "message": {"chat": {"id": 99}}}})
    assert bridge.dash.panes.p.pty.wrote == []


def test_token_never_escapes():
    assert TOKEN not in telegram.scrub(f"https://api.telegram.org/bot{TOKEN}/x failed", TOKEN)


def test_long_answers_are_split():
    parts = telegram.chunks("line\n" * 2000)
    assert len(parts) > 1 and all(len(p) <= telegram.MAX_MSG for p in parts)


# ---- reply routing in the real voice loop -------------------------------------------

class VDash:
    def __init__(self):
        self.events, self.panes, self.hub = [], Panes(), self

    def emit(self, k, v):
        self.events.append((k, v))

    def send_threadsafe(self, m):
        self.events.append(("raw", m))


def test_remote_turn_collects_the_answer_and_keeps_the_mac_quiet(monkeypatch):
    loop = VoiceLoop(VDash())
    spoken = []
    monkeypatch.setattr(loop, "_say", lambda t: spoken.append(t))

    def fake_submit(text):
        loop._on_event("p1", {"kind": "user", "text": text})
        return True
    monkeypatch.setattr(loop, "submit_text", fake_submit)
    got = []
    assert loop.submit_remote("hi", got.append)
    loop._on_event("p1", {"kind": "assistant", "text": "First part."})
    loop._on_event("p1", {"kind": "assistant", "text": "Second part."})
    assert got == []
    loop._on_event("p1", {"kind": "turn_end"})
    assert got == ["First part.\n\nSecond part."]
    assert spoken == []                                   # nobody in the room to hear it


def test_remote_turn_that_never_lands_says_so(monkeypatch):
    loop = VoiceLoop(VDash())
    monkeypatch.setattr(loop, "submit_text", lambda text: False)
    got = []
    assert not loop.submit_remote("hi", got.append)
    assert "did not reach the session" in got[0]


def test_blocked_listeners_fire_once():
    loop = VoiceLoop(VDash())
    seen = []
    loop.on_blocked.append(seen.append)
    loop.set_blocked(["api"])
    loop.set_blocked(["api"])
    assert seen == [["api"]]
