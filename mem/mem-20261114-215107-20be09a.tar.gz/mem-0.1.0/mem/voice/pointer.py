"""
pointer — a glowing ring that flies to a place on screen, then fades.

Run as its own short-lived process by `mem do point` (see act.py), so a
pointing gesture can never block or crash the dashboard. It owns one
borderless, transparent, click-through window over the display that holds the
target, so it cannot steal a click or the keyboard from whatever you are using.

It starts at the mouse and travels on a slight curve, because a straight line
reads as a teleport and a curve reads as someone reaching. Then it holds and
breathes for a few seconds with an optional label, and fades out. It never
clicks anything: it shows you where, and you decide.

Coordinates: points, origin at the top-left of the MAIN display (the same
frame a screenshot from `mem do look` uses once divided by the scale factor).
"""
from __future__ import annotations

import argparse
import math
import sys
import time

FLY_S = 0.65
FADE_S = 0.45
RING = 26.0                      # radius in points
COLOR = (0.925, 0.843, 0.608)    # the dashboard's bone yellow, #ecd79b


def ease(t: float) -> float:
    """Ease-in-out cubic: leave gently, arrive gently."""
    t = max(0.0, min(1.0, t))
    return 4 * t * t * t if t < 0.5 else 1 - pow(-2 * t + 2, 3) / 2


def path_point(a: tuple[float, float], b: tuple[float, float], t: float) -> tuple[float, float]:
    """A point along a quadratic curve from a to b, bowed to one side."""
    (x0, y0), (x1, y1) = a, b
    mx, my = (x0 + x1) / 2, (y0 + y1) / 2
    dx, dy = x1 - x0, y1 - y0
    d = math.hypot(dx, dy) or 1.0
    bow = min(160.0, d * 0.25)
    cx, cy = mx - dy / d * bow, my + dx / d * bow       # perpendicular offset
    u = ease(t)
    x = (1 - u) ** 2 * x0 + 2 * (1 - u) * u * cx + u ** 2 * x1
    y = (1 - u) ** 2 * y0 + 2 * (1 - u) * u * cy + u ** 2 * y1
    return x, y


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="mem.voice.pointer")
    ap.add_argument("x", type=float)
    ap.add_argument("y", type=float)
    ap.add_argument("--label", default="")
    ap.add_argument("--hold", type=float, default=3.5)
    a = ap.parse_args(argv)

    try:
        import objc
        from AppKit import (NSApplication, NSApplicationActivationPolicyAccessory,
                            NSBackingStoreBuffered, NSBezierPath, NSColor, NSEvent,
                            NSFont, NSFontAttributeName, NSForegroundColorAttributeName,
                            NSScreen, NSScreenSaverWindowLevel, NSString, NSTimer,
                            NSView, NSWindow, NSWindowStyleMaskBorderless,
                            NSWindowCollectionBehaviorCanJoinAllSpaces,
                            NSWindowCollectionBehaviorStationary)
    except ImportError:
        print("pointing needs PyObjC (installed with the window extra)", file=sys.stderr)
        return 1

    # Cocoa's global frame has its origin at the bottom-left of the main screen.
    main_h = NSScreen.screens()[0].frame().size.height
    target = (a.x, main_h - a.y)
    m = NSEvent.mouseLocation()
    start = (m.x, m.y)
    screen = next((s for s in NSScreen.screens()
                   if s.frame().origin.x <= target[0] <= s.frame().origin.x + s.frame().size.width
                   and s.frame().origin.y <= target[1] <= s.frame().origin.y + s.frame().size.height),
                  NSScreen.mainScreen())
    sf = screen.frame()
    t0 = time.monotonic()
    total = FLY_S + a.hold + FADE_S

    class RingView(NSView):
        def isFlipped(self):
            return False

        def drawRect_(self, _rect):
            el = time.monotonic() - t0
            if el < FLY_S:
                gx, gy = path_point(start, target, el / FLY_S)
                alpha, grow = 1.0, 0.6 + 0.4 * ease(el / FLY_S)
            else:
                gx, gy = target
                after = el - FLY_S - a.hold
                alpha = 1.0 if after < 0 else max(0.0, 1 - after / FADE_S)
                grow = 1.0 + 0.08 * math.sin((el - FLY_S) * 4.2)   # it breathes
            x, y = gx - sf.origin.x, gy - sf.origin.y
            r = RING * grow
            for i, (w, al) in enumerate(((10.0, 0.10), (5.0, 0.22), (2.2, 0.95))):
                NSColor.colorWithCalibratedRed_green_blue_alpha_(*COLOR, al * alpha).set()
                p = NSBezierPath.bezierPathWithOvalInRect_(((x - r, y - r), (2 * r, 2 * r)))
                p.setLineWidth_(w)
                p.stroke()
            NSColor.colorWithCalibratedRed_green_blue_alpha_(*COLOR, 0.9 * alpha).set()
            NSBezierPath.bezierPathWithOvalInRect_(((x - 3, y - 3), (6, 6))).fill()
            if a.label and el >= FLY_S * 0.8:
                attrs = {NSFontAttributeName: NSFont.systemFontOfSize_weight_(13, 0.3),
                         NSForegroundColorAttributeName:
                             NSColor.colorWithCalibratedRed_green_blue_alpha_(*COLOR, alpha)}
                s = NSString.stringWithString_(a.label)
                size = s.sizeWithAttributes_(attrs)
                bx, by = x + r + 10, y - size.height / 2
                NSColor.colorWithCalibratedWhite_alpha_(0.03, 0.82 * alpha).set()
                NSBezierPath.bezierPathWithRoundedRect_xRadius_yRadius_(
                    ((bx - 8, by - 4), (size.width + 16, size.height + 8)), 4, 4).fill()
                s.drawAtPoint_withAttributes_((bx, by), attrs)

    class Ticker(objc.lookUpClass("NSObject")):
        def tick_(self, _timer):
            view.setNeedsDisplay_(True)
            if time.monotonic() - t0 > total:
                NSApplication.sharedApplication().terminate_(None)

    app = NSApplication.sharedApplication()
    app.setActivationPolicy_(NSApplicationActivationPolicyAccessory)   # no Dock icon
    win = NSWindow.alloc().initWithContentRect_styleMask_backing_defer_(
        sf, NSWindowStyleMaskBorderless, NSBackingStoreBuffered, False)
    win.setOpaque_(False)
    win.setBackgroundColor_(NSColor.clearColor())
    win.setIgnoresMouseEvents_(True)            # clicks fall straight through
    win.setHasShadow_(False)
    win.setLevel_(NSScreenSaverWindowLevel)
    win.setCollectionBehavior_(NSWindowCollectionBehaviorCanJoinAllSpaces
                               | NSWindowCollectionBehaviorStationary)
    view = RingView.alloc().initWithFrame_(((0, 0), sf.size))
    win.setContentView_(view)
    win.orderFrontRegardless()                  # shown without taking focus
    ticker = Ticker.alloc().init()
    NSTimer.scheduledTimerWithTimeInterval_target_selector_userInfo_repeats_(
        1 / 60, ticker, "tick:", None, True)
    app.run()
    return 0


if __name__ == "__main__":
    sys.exit(main())
