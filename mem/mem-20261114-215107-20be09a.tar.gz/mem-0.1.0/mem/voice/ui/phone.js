/*
  Mem on your phone.

  It speaks the same control protocol as the window on the Mac (/ws), so the
  conversation, the sessions, the orb's state and its feelings are the Mac's
  own, live. What it adds is a way IN that works from a phone:

    typing        POST /phone/ask {text}      the answer arrives in the chat
    hold the mic  record -> POST /phone/ask   heard on the Mac, answer spoken back
    call          a live WebRTC call straight to the Mac: talk, it answers out
                  loud, talk over it and it stops (call.py)
    screen        watch the Mac's screen, view-only

  Your words are transcribed on the Mac, not by a cloud service; the only thing
  that leaves your network is nothing, because the link is your own tailnet.
*/
(function () {
  "use strict";
  const $ = (id) => document.getElementById(id);

  const orb = new window.Orb($("orb"));
  const mesh = window.Mesh ? window.Mesh(orb, $("stage")) : null;
  const feel = window.Feel ? window.Feel(orb, mesh) : null;
  const STATE_LABEL = { idle: "idle", starting: "starting", listening: "listening", hearing: "hearing you",
                        thinking: "thinking", working: "working", speaking: "speaking", blocked: "needs you" };

  let panes = [], sock = null, retry = 0, orbState = "idle", status = "";

  // ---------------------------------------------------------------- socket
  function connect() {
    const proto = location.protocol === "https:" ? "wss:" : "ws:";
    sock = new WebSocket(`${proto}//${location.host}/ws`);
    sock.onopen = () => { retry = 0; $("dot").classList.add("live"); };
    sock.onmessage = (ev) => { try { handle(JSON.parse(ev.data)); } catch (e) { /* not ours */ } };
    sock.onclose = () => {
      $("dot").classList.remove("live");
      if (!callOn) setState("idle");      // a call has its own channel; it is still up
      retry = Math.min(retry + 1, 6);
      setTimeout(connect, 300 * Math.pow(1.7, retry));
    };
  }
  function send(m) { if (sock && sock.readyState === 1) sock.send(JSON.stringify(m)); }

  function handle(m) {
    switch (m.t) {
      case "panes": paintPanes(m.panes || []); break;
      // On a call, the call's own channel owns the orb (it knows about you
      // talking, which the Mac's room does not).
      case "state": if (!callOn) setState(m.v); break;
      case "status": if (!callOn) { status = m.v || ""; paintState(); } break;
      case "level": if (!callOn) orb.setLevel(m.v); break;
      case "you": chat("you", m.v, true); break;
      case "clone": chat("clone", m.v); break;
      case "feel.palette": if (feel) feel.palette(m.v, m.on); break;
      case "feel": if (feel) feel.set(m.v); break;
      case "error": note(m.msg || "Something went wrong."); break;
      case "toast": if (m.v) note(m.v); break;
    }
  }

  function setState(s) { orbState = s; orb.setState(s === "starting" ? "idle" : s); paintState(); }
  function paintState() {
    const el = $("orb-state");
    el.textContent = orbState === "working" && status ? status : (STATE_LABEL[orbState] || orbState);
    el.className = "orb-state " + orbState;
  }

  // ---------------------------------------------------------------- chat
  let lastYou = null;
  function chat(who, text, replaceLast) {
    text = (text || "").trim();
    if (!text) return;
    $("chat-empty").hidden = true;
    const list = $("chat");
    if (who === "you" && replaceLast && lastYou && lastYou.isConnected && Date.now() - lastYou._t < 4000) {
      lastYou.textContent = text;
    } else {
      const li = document.createElement("li");
      li.className = who;
      li.textContent = text;
      li._t = Date.now();
      list.appendChild(li);
      if (who === "you") lastYou = li;
      while (list.children.length > 200) list.removeChild(list.children[1]);
    }
    list.scrollTop = list.scrollHeight;
  }
  function note(text) { chat("note", text); }

  // ---------------------------------------------------------------- sessions
  function paintPanes(list) {
    panes = list;
    const t = list.find((p) => p.voice);
    $("target-v").textContent = t ? `${t.title} · ${t.shortCwd}` : "no session";
    const blocked = list.filter((p) => p.state === "blocked" && p.alive);
    $("keys").hidden = !blocked.length;
    if (blocked.length) $("keys-k").textContent = `${blocked[0].title} needs you`;
    if ($("sessions").open) paintSessionRows();
  }
  function paintSessionRows() {
    const ul = $("sess-rows");
    ul.textContent = "";
    if (!panes.length) { ul.innerHTML = '<li><span class="meta">No sessions are open on the Mac.</span></li>'; return; }
    for (const p of panes) {
      const li = document.createElement("li");
      li.className = p.voice ? "on" : "";
      li.innerHTML = `<div class="meta"><div class="t"></div><div class="s"></div></div>
                      <button type="button" data-a="talk">talk</button><button type="button" data-a="view">view</button>`;
      li.querySelector(".t").textContent = p.title;
      const s = li.querySelector(".s");
      s.textContent = `${p.shortCwd} · ${p.alive ? p.state : "ended"}`;
      s.classList.add(p.state);
      li.querySelector('[data-a="talk"]').onclick = () => { send({ t: "voice.target", id: p.id }); $("sessions").close(); };
      li.querySelector('[data-a="view"]').onclick = () => { $("sessions").close(); openTerm(p); };
      ul.appendChild(li);
    }
  }
  $("target").onclick = () => { paintSessionRows(); $("sessions").showModal(); };
  $("sess-close").onclick = () => $("sessions").close();

  // keys for whichever session is asking (or the one you talk to)
  function pressKeys(keys, paneId) { send({ t: "pane.keys", id: paneId || "", keys }); }
  $("keys").addEventListener("click", (e) => {
    const b = e.target.closest("button");
    if (!b) return;
    const blocked = panes.find((p) => p.state === "blocked" && p.alive);
    if (b.dataset.view) { const p = blocked || panes.find((x) => x.voice); if (p) openTerm(p); return; }
    pressKeys(b.dataset.k, blocked ? blocked.id : "");
  });
  $("stop").onclick = () => { pressKeys("esc"); note("interrupted"); };

  // ---------------------------------------------------------------- live terminal
  let term = null, termSock = null, termPane = null;
  const KEY = { esc: "\x1b", enter: "\r", up: "\x1b[A", down: "\x1b[B", tab: "\t" };
  function openTerm(p) {
    closeTerm();
    termPane = p;
    $("term-title").textContent = `${p.title} · ${p.shortCwd}`;
    $("term-dlg").showModal();
    $("term").textContent = "";
    // Deliberately NO resize messages: resizing the pty to phone width would
    // squash the same session in the window on the Mac. The phone reads it at
    // the Mac's width, small, and scrolls sideways if it must.
    term = new window.Terminal({ fontSize: 9, cols: 120, rows: 48, convertEol: false, scrollback: 2000,
      theme: { background: "#000000", foreground: "#e4e0d8", cursor: "#ecd79b" },
      fontFamily: '"SF Mono", Menlo, monospace' });
    term.open($("term"));
    const proto = location.protocol === "https:" ? "wss:" : "ws:";
    termSock = new WebSocket(`${proto}//${location.host}/pty/${p.id}`);
    termSock.binaryType = "arraybuffer";
    termSock.onmessage = (ev) => term.write(typeof ev.data === "string" ? ev.data : new Uint8Array(ev.data));
    term.onData((d) => termSock && termSock.readyState === 1 && termSock.send(new TextEncoder().encode(d)));
  }
  function closeTerm() {
    if (termSock) { try { termSock.close(); } catch (e) {} termSock = null; }
    if (term) { term.dispose(); term = null; }
  }
  $("term-close").onclick = () => { $("term-dlg").close(); };
  $("term-dlg").addEventListener("close", closeTerm);
  document.querySelector(".keys.inline").addEventListener("click", (e) => {
    const b = e.target.closest("button");
    if (!b || !termSock || termSock.readyState !== 1) return;
    termSock.send(new TextEncoder().encode(KEY[b.dataset.k] || b.dataset.k));
  });

  // ---------------------------------------------------------------- asking
  const player = $("player");
  let audioUnlocked = false;
  function unlockAudio() {
    // iOS only lets a page play sound after a touch. Spend the first touch on
    // a silent play so the first real answer is not swallowed.
    if (audioUnlocked) return;
    audioUnlocked = true;
    player.src = "data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQAAAAA=";
    player.play().catch(() => {});
  }
  document.addEventListener("touchstart", unlockAudio, { once: true, passive: true });
  document.addEventListener("mousedown", unlockAudio, { once: true });

  async function ask(body, isAudio) {
    const opts = isAudio
      ? { method: "POST", body, headers: { "Content-Type": body.type || "application/octet-stream" } }
      : { method: "POST", body: JSON.stringify(body), headers: { "Content-Type": "application/json" } };
    let res;
    try {
      res = await fetch("/phone/ask" + (isAudio ? "?voice=1" : ""), opts);
    } catch (e) { note("Lost the Mac. Is Mem open there?"); return null; }
    if (res.status === 401) { note("Logged out. Send /app to your Mem bot for a fresh link."); return null; }
    let j = {};
    try { j = await res.json(); } catch (e) {}
    if (j.error && !j.answer) note(j.error);
    return j;
  }
  function play(url) {
    return new Promise((resolve) => {
      if (!url) return resolve();
      player.src = url;
      player.onended = player.onerror = () => resolve();
      player.play().catch(() => resolve());
    });
  }

  $("form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const text = $("input").value.trim();
    if (!text) return;
    $("input").value = "";
    $("hint").textContent = "sent";
    await ask({ text });
    $("hint").textContent = callOn ? "on a call" : "hold to talk";
  });

  // ---------------------------------------------------------------- recording
  function pickMime() {
    for (const m of ["audio/webm;codecs=opus", "audio/mp4", "audio/ogg;codecs=opus", "audio/webm"]) {
      if (window.MediaRecorder && MediaRecorder.isTypeSupported(m)) return m;
    }
    return "";
  }
  let stream = null;
  async function mic() {
    if (stream) return stream;
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      note("This browser will not give the page a microphone. It needs the https link from your bot.");
      throw new Error("no mic");
    }
    stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } });
    return stream;
  }
  function recorder(s) {
    const mime = pickMime();
    const rec = new MediaRecorder(s, mime ? { mimeType: mime } : undefined);
    const parts = [];
    rec.ondataavailable = (e) => e.data && e.data.size && parts.push(e.data);
    rec.done = new Promise((r) => { rec.onstop = () => r(new Blob(parts, { type: rec.mimeType || mime })); });
    return rec;
  }

  let busy = false;
  async function sendRecording(blob) {
    if (blob.size < 2000) return;                 // a tap, not a sentence
    busy = true;
    $("mic").classList.add("busy");
    $("hint").textContent = "hearing you on the Mac";
    const j = await ask(blob, true);
    if (j && j.answer) { $("hint").textContent = "answering"; await play(j.audio); }
    busy = false;
    $("mic").classList.remove("busy");
    $("hint").textContent = callOn ? "on a call" : "hold to talk";
  }

  // hold to talk
  let rec = null;
  async function down(e) {
    e.preventDefault();
    if (busy || callOn) return;
    try { rec = recorder(await mic()); } catch (err) { return; }
    rec.start();
    $("mic").classList.add("on");
    $("hint").textContent = "listening";
    player.pause();
  }
  async function up() {
    if (!rec) return;
    const r = rec; rec = null;
    $("mic").classList.remove("on");
    r.stop();
    sendRecording(await r.done);
  }
  $("mic").addEventListener("pointerdown", down);
  $("mic").addEventListener("pointerup", up);
  $("mic").addEventListener("pointercancel", up);
  $("mic").addEventListener("pointerleave", up);

  // ---------------------------------------------------------------- call
  /* A real call: one WebRTC connection straight to the Mac (call.py). Your
     voice streams there live, the clone's voice streams back. The phone's own
     echo cancellation keeps it from hearing itself, so you can talk over it
     and it stops, the way a person would. No phone network, no server in the
     middle: over Tailscale it is your devices and nothing else. */
  let callOn = false, pc = null, dc = null, callStream = null, wake = null, tick = 0, callStart = 0;

  function gathered(conn, ms) {
    // The Mac does not trickle candidates, so send the offer complete.
    return new Promise((resolve) => {
      if (conn.iceGatheringState === "complete") return resolve();
      const done = () => { if (conn.iceGatheringState === "complete") { conn.removeEventListener("icegatheringstatechange", done); resolve(); } };
      conn.addEventListener("icegatheringstatechange", done);
      setTimeout(resolve, ms);
    });
  }
  async function keepAwake() {
    try { if (navigator.wakeLock && callOn) wake = await navigator.wakeLock.request("screen"); } catch (e) { wake = null; }
  }
  document.addEventListener("visibilitychange", () => { if (document.visibilityState === "visible" && callOn) keepAwake(); });

  function callMsg(m) {
    switch (m.t) {
      case "state": setState(m.v); if (m.v === "listening") { status = ""; paintState(); } break;
      case "level": orb.setLevel(m.v); break;
      case "status": status = m.v || ""; paintState(); break;
      case "you": $("cap-you").textContent = m.v; $("cap-clone").textContent = ""; break;
      case "clone": $("cap-clone").textContent = m.v; break;
      case "note": $("cap-clone").textContent = m.v; break;
      case "ready": $("cap-clone").textContent = "Go ahead, I'm listening."; break;
    }
  }
  function callSend(m) { if (dc && dc.readyState === "open") dc.send(JSON.stringify(m)); }

  async function startCall() {
    if (callOn) return;
    if (!window.RTCPeerConnection || !navigator.mediaDevices) {
      note("This browser cannot make calls. Open the https link from your bot in Safari.");
      return;
    }
    const remote = $("remote");
    remote.play().catch(() => {});          // spend the tap: iOS needs a gesture for sound
    callOn = true;
    document.body.classList.add("oncall");
    $("cap-you").textContent = ""; $("cap-clone").textContent = "Calling your Mac…";
    try {
      callStream = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true } });
      pc = new RTCPeerConnection({ iceServers: [] });
      callStream.getTracks().forEach((t) => pc.addTrack(t, callStream));
      dc = pc.createDataChannel("mem");
      dc.onmessage = (e) => { try { callMsg(JSON.parse(e.data)); } catch (err) {} };
      pc.ontrack = (e) => { remote.srcObject = e.streams[0] || new MediaStream([e.track]); remote.play().catch(() => {}); };
      pc.onconnectionstatechange = () => {
        const st = pc && pc.connectionState;
        if (st === "connected") { callStart = Date.now(); $("cap-clone").textContent = "Connected."; }
        if (st === "failed" || st === "disconnected" || st === "closed") endCall(st === "closed" ? "" : "The call dropped.");
      };
      await pc.setLocalDescription(await pc.createOffer());
      await gathered(pc, 2500);
      const r = await fetch("/phone/call", { method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sdp: pc.localDescription.sdp, type: pc.localDescription.type }) });
      const j = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(r.status === 401 ? "Logged out. Send /app to your Mem bot for a fresh link." : (j.error || `The Mac said ${r.status}.`));
      await pc.setRemoteDescription(j);
    } catch (e) {
      endCall(e && e.name === "NotAllowedError" ? "Mem needs the microphone for a call. Allow it in Safari's settings for this site."
                                                 : (e && e.message) || "Could not reach the Mac.");
      return;
    }
    keepAwake();
    callStart = Date.now();
    tick = setInterval(() => {
      const s = Math.floor((Date.now() - callStart) / 1000);
      $("call-time").textContent = `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
    }, 500);
  }
  function endCall(why) {
    if (!callOn) return;
    callOn = false;
    callSend({ t: "hangup" });
    clearInterval(tick);
    if (dc) { try { dc.close(); } catch (e) {} dc = null; }
    if (pc) { const p = pc; pc = null; try { p.close(); } catch (e) {} }
    if (callStream) { callStream.getTracks().forEach((t) => t.stop()); callStream = null; }
    if (wake) { wake.release().catch(() => {}); wake = null; }
    $("remote").srcObject = null;
    $("c-mute").setAttribute("aria-pressed", "false");
    document.body.classList.remove("oncall");
    orb.setLevel(0);
    $("hint").textContent = "hold to talk";
    if (why) note(why);
  }
  $("call").onclick = startCall;
  $("c-end").onclick = () => endCall("");
  $("c-stop").onclick = () => { callSend({ t: "stop" }); $("cap-clone").textContent = "Stopped."; };
  $("c-mute").onclick = () => {
    const on = $("c-mute").getAttribute("aria-pressed") !== "true";
    $("c-mute").setAttribute("aria-pressed", String(on));
    if (callStream) callStream.getAudioTracks().forEach((t) => { t.enabled = !on; });
    callSend({ t: "mute", on });
  };
  $("c-screen").onclick = () => openScreen();

  // ---------------------------------------------------------------- screen
  /* Watching the Mac, view-only: a fresh still every half second while this is
     open, nothing while it is closed. Double-tap to zoom in. */
  let shotTimer = 0, shotUrl = "", shotBusy = false;
  async function shot() {
    if (shotBusy || !$("screen-dlg").open) return;
    shotBusy = true;
    try {
      const zoom = $("screen-wrap").classList.contains("zoom");
      const r = await fetch(`/phone/screen.jpg?w=${zoom ? 2000 : 1280}&_=${Date.now()}`);
      if (r.ok) {
        const url = URL.createObjectURL(await r.blob());
        $("screen-img").src = url;
        if (shotUrl) URL.revokeObjectURL(shotUrl);
        shotUrl = url;
        $("screen-msg").textContent = "";
      } else {
        const j = await r.json().catch(() => ({}));
        $("screen-msg").textContent = j.error || (r.status === 401 ? "Logged out. Send /app to your bot." : `The Mac said ${r.status}.`);
      }
    } catch (e) {
      $("screen-msg").textContent = "Lost the Mac. Is Mem open there?";
    }
    shotBusy = false;
  }
  function openScreen() {
    $("screen-msg").textContent = "connecting…";
    $("screen-dlg").showModal();
    shot();
    clearInterval(shotTimer);
    shotTimer = setInterval(shot, 500);
  }
  $("screen-btn").onclick = openScreen;
  $("screen-close").onclick = () => $("screen-dlg").close();
  $("screen-dlg").addEventListener("close", () => { clearInterval(shotTimer); });
  $("screen-wrap").addEventListener("dblclick", () => $("screen-wrap").classList.toggle("zoom"));

  paintState();
  connect();
})();
