/*
  mesh — the field of soft dots behind the orb. Ported from the short film.

  It never touches the orb. It READS the orb (its eased colour, glow and level)
  and answers it: dots near the orb catch its light and colour, and while it
  speaks or listens, circular waves run outward from its centre through the
  field, lifting and brightening the dots they pass.

  Differences from the film, all deliberate:
    * it lives inside the voice column, not across the whole window: the
      terminals are where you read, and dots behind text are noise;
    * the resting field is much dimmer, so the conversation under the orb
      stays legible at 6:1 or better;
    * it throttles to ~8fps when nothing is moving and stops entirely when the
      window is hidden, the same battery rule the orb follows.
*/
(function () {
  "use strict";

  const SPACING = 20;
  const SPRITE = 32;

  function Mesh(orb, host) {
    const orbEl = document.getElementById("orb");
    if (!host || !orbEl) return null;
    const cv = document.createElement("canvas");
    cv.className = "mesh";
    cv.setAttribute("aria-hidden", "true");
    host.prepend(cv);
    const ctx = cv.getContext("2d");
    const reduced = matchMedia("(prefers-reduced-motion: reduce)").matches;

    // one blurry white dot, tinted per frame by compositing
    const sprite = document.createElement("canvas");
    sprite.width = sprite.height = SPRITE;
    const sctx = sprite.getContext("2d");
    const g = sctx.createRadialGradient(SPRITE / 2, SPRITE / 2, 0, SPRITE / 2, SPRITE / 2, SPRITE / 2);
    g.addColorStop(0, "rgba(255,255,255,1)");
    g.addColorStop(0.25, "rgba(255,255,255,0.6)");
    g.addColorStop(0.6, "rgba(255,255,255,0.18)");
    g.addColorStop(1, "rgba(255,255,255,0)");
    sctx.fillStyle = g;
    sctx.fillRect(0, 0, SPRITE, SPRITE);

    const tinted = document.createElement("canvas");
    tinted.width = tinted.height = SPRITE;
    const tctx = tinted.getContext("2d");
    let lastTint = "";
    function tint(r, g2, b) {
      const key = `${r},${g2},${b}`;
      if (key === lastTint) return;
      lastTint = key;
      tctx.clearRect(0, 0, SPRITE, SPRITE);
      tctx.globalCompositeOperation = "source-over";
      tctx.drawImage(sprite, 0, 0);
      tctx.globalCompositeOperation = "source-in";
      tctx.fillStyle = `rgb(${key})`;
      tctx.fillRect(0, 0, SPRITE, SPRITE);
    }

    let dots = [], W = 0, H = 0;
    function layout() {
      const dpr = Math.min(devicePixelRatio || 1, 2);
      const box = host.getBoundingClientRect();
      W = Math.max(1, Math.round(box.width)); H = Math.max(1, Math.round(box.height));
      cv.width = W * dpr; cv.height = H * dpr;
      cv.style.width = W + "px"; cv.style.height = H + "px";
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      dots = [];
      const ox = (W % SPACING) / 2, oy = (H % SPACING) / 2;
      for (let y = oy; y <= H; y += SPACING) {
        for (let x = ox; x <= W; x += SPACING) {
          dots.push({ x, y,
            sx: 0.75 + Math.random() * 0.5,       // not quite round
            sy: 0.75 + Math.random() * 0.5,
            ph: Math.random() * Math.PI * 2 });   // its own faint shimmer
        }
      }
    }
    layout();
    if (typeof ResizeObserver === "function") new ResizeObserver(layout).observe(host);
    else addEventListener("resize", layout);

    let t = 0, last = performance.now(), energy = 0, lastDraw = 0;
    const api = { on: true };

    (function frame(now) {
      requestAnimationFrame(frame);
      if (document.hidden) { last = now; return; }
      const glow = orb.glow || 0;
      const lvl = orb.smooth || 0;
      const lively = !reduced && (lvl > 0.01 || energy > 0.01 || glow > 0.03);
      if (!lively && now - lastDraw < 120) return;
      lastDraw = now;
      const dt = Math.min(0.05, (now - last) / 1000); last = now;
      if (!reduced) t += dt;

      ctx.clearRect(0, 0, W, H);
      if (!api.on) return;

      const hb = host.getBoundingClientRect(), ob = orbEl.getBoundingClientRect();
      const cx = ob.left - hb.left + ob.width / 2, cy = ob.top - hb.top + ob.height / 2;
      const R = Math.min(ob.width, ob.height) * 0.30;      // the orb draws its ring at 0.30
      const [r, g2, b] = (orb.tint || [110, 116, 124]).map(Math.round);
      energy += ((lvl > energy ? lvl : energy * 0.985) - energy) * (lvl > energy ? 0.3 : 1);
      tint(r, g2, b);

      ctx.globalCompositeOperation = "lighter";
      const reach = Math.max(W, H) * 0.55;
      const K = 0.05, SPEED = 5.5;
      for (const d of dots) {
        const dx = d.x - cx, dy = d.y - cy;
        const dist = Math.sqrt(dx * dx + dy * dy) || 1;
        const fade = Math.max(0, 1 - dist / reach);
        if (fade <= 0 && energy < 0.01) continue;
        const wave = Math.sin((dist - R) * K - t * SPEED);
        const crest = Math.max(0, wave) * energy * fade;
        const push = wave * energy * 6 * fade;
        const px = d.x + (dx / dist) * push, py = d.y + (dy / dist) * push;
        const light = fade * fade * (0.18 + glow * 0.8);
        const shimmer = 0.5 + 0.5 * Math.sin(t * 0.6 + d.ph);
        let a = Math.min(0.85, 0.025 + shimmer * 0.025 + light * 0.45 + crest * 0.8);
        if (dist < R * 1.15) a *= Math.max(0, dist / (R * 1.15) - 0.4);   // the orb owns its centre
        const size = 4 + light * 3 + crest * 5;
        ctx.globalAlpha = a;
        ctx.drawImage(tinted, px - size * d.sx / 2, py - size * d.sy / 2, size * d.sx, size * d.sy);
      }
      ctx.globalAlpha = 1;
      ctx.globalCompositeOperation = "source-over";
    })(performance.now());

    return api;
  }

  window.Mesh = Mesh;
})();
