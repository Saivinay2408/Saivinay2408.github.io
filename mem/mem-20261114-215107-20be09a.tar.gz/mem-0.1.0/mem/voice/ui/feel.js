/*
  feel — the emotions box, and the colour the orb takes from it.
  Ported from the short film (ui/feel.js there), where it was the performance.

  The numbers come from the server (mood.py), and every one of them is caused by
  something real: a failing tool raises concern, a session waiting on you holds
  urgency, a clean finish blazes white. This file only draws them.

  Colour rules, unchanged from the film because they were right:
    * the dominant feeling paints the orb, and the stronger it is the more light
      the orb throws;
    * exactly two feelings leading: mix those two, and only those two, in OKLCH,
      so two lights make a third vivid colour instead of RGB's grey sludge;
    * three or more up together: the dominant colour stays on its own;
    * completeness is white and is the only feeling allowed to truly blaze.
*/
(function () {
  "use strict";

  const WHITE = [255, 250, 240];
  const LIT = 15;                         // below this, the state colour shows instead

  function hex(h) {
    const n = parseInt(String(h).replace("#", ""), 16);
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  }

  // ---- OKLCH mixing (Björn Ottosson's OKLab, polar form)
  const lin = (c) => (c /= 255) <= 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
  const gam = (c) => 255 * (c <= 0.0031308 ? 12.92 * c : 1.055 * Math.pow(c, 1 / 2.4) - 0.055);
  function toOklch([r, g, b]) {
    r = lin(r); g = lin(g); b = lin(b);
    const l = Math.cbrt(0.4122214708 * r + 0.5363325363 * g + 0.0514459929 * b);
    const m = Math.cbrt(0.2119034982 * r + 0.6806995451 * g + 0.1073969566 * b);
    const s = Math.cbrt(0.0883024619 * r + 0.2817188376 * g + 0.6299787005 * b);
    const L = 0.2104542553 * l + 0.7936177850 * m - 0.0040720468 * s;
    const A = 1.9779984951 * l - 2.4285922050 * m + 0.4505937099 * s;
    const B = 0.0259040371 * l + 0.7827717662 * m - 0.8086757660 * s;
    return [L, Math.hypot(A, B), Math.atan2(B, A)];
  }
  function fromOklch([L, C, H]) {
    const A = C * Math.cos(H), B = C * Math.sin(H);
    const l = Math.pow(L + 0.3963377774 * A + 0.2158037573 * B, 3);
    const m = Math.pow(L - 0.1055613458 * A - 0.0638541728 * B, 3);
    const s = Math.pow(L - 0.0894841775 * A - 1.2914855480 * B, 3);
    return [
      +4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s,
      -1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s,
      -0.0041960863 * l - 0.7034186147 * m + 1.7076147010 * s,
    ].map((c) => Math.max(0, Math.min(255, gam(Math.max(0, c)))));
  }
  // w = share of the second colour, 0..1
  function mix(c1, c2, w) {
    const a = toOklch(c1), b = toOklch(c2);
    const L = a[0] + (b[0] - a[0]) * w;
    if (a[1] < 0.03 || b[1] < 0.03) {            // one side is white: no hue to blend
      const hued = a[1] >= b[1] ? a : b;
      return fromOklch([L, hued[1] * (a[1] >= b[1] ? 1 - w : w), hued[2]]);
    }
    let dh = b[2] - a[2];
    if (dh > Math.PI) dh -= 2 * Math.PI;
    if (dh < -Math.PI) dh += 2 * Math.PI;       // the short way round the wheel
    return fromOklch([L, Math.max(a[1], b[1]), a[2] + dh * w]);
  }

  function Feel(orb, mesh) {
    const rows = document.getElementById("emo-rows");
    const box = document.getElementById("feel-box");
    const tag = document.getElementById("feel-now");
    const emo = {};
    let on = true;

    function build(list) {
      rows.textContent = "";
      for (const k in emo) delete emo[k];
      for (const [key, color] of list) {
        const li = document.createElement("li");
        li.className = "emo";
        li.style.setProperty("--c", color);
        li.innerHTML = `<span class="emo-k"></span><span class="emo-bar"><i></i></span><span class="emo-v">0</span>`;
        li.querySelector(".emo-k").textContent = key;
        rows.appendChild(li);
        emo[key] = { cur: 0, target: 0, rgb: key === "completeness" ? WHITE : hex(color),
                     row: li, fill: li.querySelector(".emo-bar > i"), val: li.querySelector(".emo-v") };
      }
    }

    const api = {
      palette(list, enabled) {
        if (Array.isArray(list) && list.length && Object.keys(emo).length !== list.length) build(list);
        on = enabled !== false;
        if (box) box.hidden = !on;
        if (mesh) mesh.on = on;
        if (!on) { orb.setTint(null, 0); document.body.dataset.feel = ""; }
      },
      set(snap) {
        for (const [k, v] of Object.entries(snap || {})) {
          if (emo[k]) emo[k].target = Math.max(0, Math.min(100, Number(v) || 0));
        }
      },
      get on() { return on; },
      get keys() { return Object.keys(emo); },
    };

    let lastPaint = 0;
    (function tick(now) {
      requestAnimationFrame(tick);
      if (!on || document.hidden) return;
      if (now - lastPaint < 33) return;          // 30fps is plenty for bars
      lastPaint = now;
      const keys = Object.keys(emo);
      if (!keys.length) return;
      for (const k of keys) {
        const e = emo[k];
        e.cur += (e.target - e.cur) * 0.12;
        e.fill.style.width = e.cur.toFixed(1) + "%";
        e.val.textContent = Math.round(e.cur);
      }
      const ranked = keys.slice().sort((a, b) => emo[b].cur - emo[a].cur);
      const [k1, k2, k3] = ranked;
      const v1 = emo[k1].cur, v2 = k2 ? emo[k2].cur : 0, v3 = k3 ? emo[k3].cur : 0;
      const lit = v1 > LIT;
      let rgb = null, glow = 0;
      if (lit) {
        rgb = emo[k1].rgb;
        glow = k1 === "completeness" ? 0.35 + 0.6 * (v1 / 100) : 0.1 + 0.35 * (v1 / 100);
      }
      const pair = lit && v2 >= 35 && v2 >= v1 * 0.5 && v3 < v2 * 0.6;
      if (pair) rgb = mix(emo[k1].rgb, emo[k2].rgb, v2 / (v1 + v2));
      for (const k of keys) {
        emo[k].row.classList.toggle("top", lit && k === k1);
        emo[k].row.classList.toggle("pair", pair && k === k2);
      }
      orb.setTint(rgb, glow);
      document.body.dataset.feel = lit ? k1 : "";
      if (tag) tag.textContent = lit ? (pair ? `${k1} + ${k2}` : k1) : "calm";
      // the light the orb throws into its column, read back EASED from the orb
      const c = (orb.tint || [110, 116, 124]).map(Math.round);
      const st = document.documentElement.style;
      st.setProperty("--orb-rgb", `${c[0]},${c[1]},${c[2]}`);
      st.setProperty("--orb-glow", (orb.glow || 0).toFixed(3));
    })(performance.now());

    return api;
  }

  window.Feel = Feel;
  window.FeelMix = mix;     // exposed for the look-dev check in verify
})();
