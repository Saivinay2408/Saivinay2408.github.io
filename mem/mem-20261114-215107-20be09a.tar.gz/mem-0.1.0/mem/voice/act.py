"""
mem do — hands for the clone. Opening apps, music, volume, mail, looking at
the screen, and pointing at something on it.

WHY THIS EXISTS
---------------
"Play some music" used to mean the agent improvising AppleScript: a different
script every time, a silent failure when macOS had not granted Automation, and
a confident "done" either way. That is the false-alarm problem: the voice says
it worked because a command exited 0, not because music is playing.

So each action here is ONE fixed, tested command that:
  * does the thing the same way every time,
  * checks the result where it can be checked (is the app frontmost, is the
    player actually in the playing state) and says so honestly,
  * prints exactly one line, which is what the agent reads back to you,
  * turns macOS's numeric errors into the sentence that fixes them
    (-1743 is "System Settings > Privacy & Security > Automation", not a code).

Nothing here sends anything on your behalf. `mail` opens a filled-in draft and
stops; you press send. That line is deliberate and is not a missing feature.

Exit codes: 0 done, 1 failed (the line says why), 2 bad arguments.
"""
from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from urllib.parse import quote

TIMEOUT = 8

# macOS Apple Event errors worth a sentence. Anything else is reported raw.
_AE_ERRORS = {
    "-1743": ("macOS has not allowed this app to control {app}. Open System Settings > "
              "Privacy & Security > Automation, find the terminal or Mem, and turn on {app}."),
    "-1728": "{app} did not have what was asked for (nothing matched).",
    "-600":  "{app} is not running.",
    "-1712": "{app} did not answer in time (it may be showing a dialog).",
    "-10810": "macOS could not launch {app}.",
}


def esc(s: str) -> str:
    """A Python string as an AppleScript string literal's contents."""
    return str(s).replace("\\", "\\\\").replace('"', '\\"')


def explain(err: str, app: str = "the app") -> str:
    for code, msg in _AE_ERRORS.items():
        if code in err:
            return msg.format(app=app)
    err = " ".join(err.split())
    return err[:200] or "it failed without saying why"


def osa(script: str, app: str = "the app") -> tuple[bool, str]:
    """Run AppleScript. (ok, stdout-or-explained-error)."""
    if not shutil.which("osascript"):
        return False, "this needs macOS (osascript is not here)"
    try:
        p = subprocess.run(["osascript", "-e", script], capture_output=True,
                           text=True, timeout=TIMEOUT)
    except subprocess.TimeoutExpired:
        return False, explain("-1712", app)
    if p.returncode != 0:
        return False, explain(p.stderr or p.stdout, app)
    return True, p.stdout.strip()


def _run(args: list[str]) -> tuple[bool, str]:
    try:
        p = subprocess.run(args, capture_output=True, text=True, timeout=TIMEOUT)
    except (OSError, subprocess.TimeoutExpired) as e:
        return False, str(e)
    return p.returncode == 0, (p.stderr or p.stdout).strip()


def frontmost() -> str:
    """The frontmost app's name. Needs no permission (unlike window titles)."""
    ok, out = osa('tell application "System Events" to get name of first process '
                  'whose frontmost is true', "System Events")
    return out if ok else ""


def running(app: str) -> bool:
    ok, out = osa(f'application "{esc(app)}" is running', app)
    return ok and out == "true"


# ---- actions ---------------------------------------------------------------

def do_open(target: str) -> tuple[bool, str]:
    """An app by name, or a path, or a URL. Verifies an app actually came up."""
    t = target.strip()
    if not t:
        return False, "open what?"
    if "://" in t or t.startswith("mailto:"):
        ok, err = _run(["open", t])
        return ok, f"opened {t}" if ok else f"could not open {t}: {err}"
    p = Path(os.path.expanduser(t))
    if p.exists():
        ok, err = _run(["open", str(p)])
        return ok, f"opened {p.name}" if ok else f"could not open {p}: {err}"
    ok, err = _run(["open", "-a", t])
    if not ok:
        return False, f"there is no app called {t} on this Mac"
    # `open -a` returns before the app is up. Wait briefly for proof.
    for _ in range(20):
        if running(t):
            return True, f"{t} is open"
        time.sleep(0.15)
    return True, f"asked {t} to open; it has not reported in yet"


_MUSIC_STATE = 'tell application "{app}" to get player state as string'


def _player() -> str:
    """Spotify if it is running, else Music. One choice, made the same way."""
    if running("Spotify"):
        return "Spotify"
    return "Music"


def do_music(verb: str, query: str = "") -> tuple[bool, str]:
    app = _player()
    simple = {"play": "play", "pause": "pause", "toggle": "playpause",
              "next": "next track", "previous": "previous track", "prev": "previous track"}
    if verb == "now":
        if not running(app):
            return True, "nothing is playing"
        ok, out = osa(f'tell application "{app}" to if player state is playing then '
                      f'return (name of current track) & " by " & (artist of current track)', app)
        return ok, (out or "nothing is playing") if ok else out
    if verb == "play" and query:
        return _music_search(app, query)
    if verb not in simple:
        return False, f"music can play, pause, toggle, next, previous or now, not {verb}"
    ok, out = osa(f'tell application "{app}" to {simple[verb]}', app)
    if not ok:
        return False, out
    if verb in ("play", "next", "previous", "prev"):
        time.sleep(0.6)
        ok2, state = osa(_MUSIC_STATE.format(app=app), app)
        if ok2 and state != "playing":
            return False, f"{app} did not start playing (it says {state}); is anything queued?"
    return True, {"play": f"playing in {app}", "pause": f"paused {app}",
                  "toggle": f"toggled {app}", "next": "skipped", "previous": "went back",
                  "prev": "went back"}[verb]


def _music_search(app: str, query: str) -> tuple[bool, str]:
    q = esc(query)
    if app == "Music":
        # Your own library first: that is the one place a name can be played
        # without a guess.
        ok, out = osa(
            f'tell application "Music"\n'
            f'  set hits to (every track of library playlist 1 whose name contains "{q}" '
            f'or artist contains "{q}" or album contains "{q}")\n'
            f'  if (count of hits) is 0 then return ""\n'
            f'  play item 1 of hits\n'
            f'  return (name of current track) & " by " & (artist of current track)\n'
            f'end tell', "Music")
        if ok and out:
            return True, f"playing {out}"
        if not ok:
            # "not in the library" comes back ok-and-empty. A failure is a real
            # problem (usually permission) and must not be papered over with a search.
            return False, out
        _run(["open", f"music://music.apple.com/search?term={quote(query)}"])
        return True, (f"{query} is not in your library, so I opened Apple Music's search "
                      f"for it; pick the one you want")
    # Spotify's AppleScript can only play a URI it is given; it has no search.
    # Opening the search is the honest version, not a pretend "playing".
    _run(["open", f"spotify:search:{quote(query)}"])
    return True, f"opened Spotify's search for {query}; pick the one you want"


def do_volume(level: str) -> tuple[bool, str]:
    lv = level.strip().lower()
    if lv in ("mute", "unmute"):
        ok, out = osa(f"set volume output muted {'true' if lv == 'mute' else 'false'}")
        return ok, (f"{lv}d" if ok else out)
    if lv in ("up", "down"):
        ok, cur = osa("output volume of (get volume settings)")
        if not ok:
            return False, cur
        n = max(0, min(100, int(cur or 50) + (12 if lv == "up" else -12)))
    else:
        try:
            n = max(0, min(100, int(float(lv))))
        except ValueError:
            return False, "volume takes 0-100, up, down, mute or unmute"
    ok, out = osa(f"set volume output volume {n}")
    return ok, (f"volume {n}" if ok else out)


def do_mail(to: str, subject: str, body: str) -> tuple[bool, str]:
    """A filled-in draft in your mail app. Never sends: you press send."""
    url = (f"mailto:{quote(to, safe='@,')}?subject={quote(subject)}&body={quote(body)}")
    ok, err = _run(["open", url])
    who = to or "nobody yet"
    return ok, (f"draft to {who} is open; check it and press send" if ok
                else f"could not open a draft: {err}")


def do_notify(text: str, title: str = "Mem") -> tuple[bool, str]:
    ok, out = osa(f'display notification "{esc(text)}" with title "{esc(title)}"')
    return ok, ("notified" if ok else out)


def screen_scale() -> float:
    """Pixels per point on the main display (2.0 on Retina)."""
    try:
        from AppKit import NSScreen
        return float(NSScreen.mainScreen().backingScaleFactor())
    except Exception:                                   # noqa: BLE001
        return 2.0


def do_look(out: str = "") -> tuple[bool, str]:
    """Screenshot the main display, and say how to turn pixels into points."""
    path = out or os.path.join(tempfile.gettempdir(), "mem-screen.png")
    ok, err = _run(["screencapture", "-x", "-m", path])
    if not ok or not os.path.exists(path):
        return False, ("could not take a screenshot. macOS needs Screen Recording for "
                       "this: System Settings > Privacy & Security > Screen Recording")
    s = screen_scale()
    return True, (f"{path} (front app: {frontmost() or 'unknown'}). Pixel coordinates in it "
                  f"are {s:g}x screen points: to point at pixel X,Y run "
                  f"`mem do point X Y --shot`")


def do_point(x: float, y: float, label: str = "", shot: bool = False,
             hold: float = 3.5) -> tuple[bool, str]:
    """Fly a glowing ring to a place on screen, the way a person points.

    x, y are screen points from the top-left of the main display, or pixels in
    a `mem do look` screenshot when shot=True. It never clicks: pointing shows
    you where; you decide whether to press.
    """
    if shot:
        s = screen_scale()
        x, y = x / s, y / s
    args = [sys.executable, "-m", "mem.voice.pointer", str(x), str(y),
            "--hold", str(hold)]
    if label:
        args += ["--label", label]
    try:
        subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                         start_new_session=True)
    except OSError as e:
        return False, f"could not draw the pointer: {e}"
    return True, f"pointing at {int(x)},{int(y)}" + (f" ({label})" if label else "")


def do_check() -> tuple[bool, str]:
    """Which of the permissions these actions need are actually granted."""
    lines, all_ok = [], True
    ok, out = osa('tell application "System Events" to get name of first process', "System Events")
    lines.append(f"automation (System Events): {'ok' if ok else out}")
    all_ok &= ok
    if running("Music") or not running("Spotify"):
        ok, out = osa('tell application "Music" to get player state as string', "Music")
        lines.append(f"automation (Music): {'ok' if ok else out}")
        all_ok &= ok
    path = os.path.join(tempfile.gettempdir(), "mem-check.png")
    ok, _ = _run(["screencapture", "-x", "-m", path])
    lines.append("screen recording: " + ("ok" if ok and os.path.getsize(path) > 0
                                          else "not granted (needed for look)"))
    return all_ok, "; ".join(lines)


# ---- cli -------------------------------------------------------------------

def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="mem do", description=__doc__.split("\n\n")[0])
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("open", help="an app, a file or a URL"); p.add_argument("target", nargs="+")
    p = sub.add_parser("music", help="play [what] | pause | toggle | next | previous | now")
    p.add_argument("verb"); p.add_argument("query", nargs="*")
    p = sub.add_parser("volume", help="0-100 | up | down | mute | unmute"); p.add_argument("level")
    p = sub.add_parser("mail", help="open a filled-in draft (never sends)")
    p.add_argument("--to", default=""); p.add_argument("--subject", default="")
    p.add_argument("--body", default="")
    p = sub.add_parser("notify", help="a macOS notification"); p.add_argument("text", nargs="+")
    p = sub.add_parser("look", help="screenshot the main display"); p.add_argument("--out", default="")
    p = sub.add_parser("point", help="point at a place on screen (never clicks)")
    p.add_argument("x", type=float); p.add_argument("y", type=float)
    p.add_argument("--label", default=""); p.add_argument("--hold", type=float, default=3.5)
    p.add_argument("--shot", action="store_true",
                   help="x,y are pixels in a `mem do look` screenshot")
    sub.add_parser("front", help="the frontmost app")
    sub.add_parser("check", help="which permissions these actions have")
    try:
        a = ap.parse_args(argv)
    except SystemExit as e:
        return 2 if e.code else 0

    if a.cmd == "open":
        ok, msg = do_open(" ".join(a.target))
    elif a.cmd == "music":
        ok, msg = do_music(a.verb.lower(), " ".join(a.query))
    elif a.cmd == "volume":
        ok, msg = do_volume(a.level)
    elif a.cmd == "mail":
        ok, msg = do_mail(a.to, a.subject, a.body)
    elif a.cmd == "notify":
        ok, msg = do_notify(" ".join(a.text))
    elif a.cmd == "look":
        ok, msg = do_look(a.out)
    elif a.cmd == "point":
        ok, msg = do_point(a.x, a.y, a.label, a.shot, a.hold)
    elif a.cmd == "front":
        name = frontmost()
        ok, msg = bool(name), name or "could not tell (Automation for System Events?)"
    else:
        ok, msg = do_check()
    print(msg)
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
