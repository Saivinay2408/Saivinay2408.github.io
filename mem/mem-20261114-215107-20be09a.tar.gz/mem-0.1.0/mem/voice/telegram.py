"""
telegram — talk to Mem from your phone, by text or voice note.

A long-polling thread inside the dashboard. It is not a second assistant: a
message from your phone goes into the SAME clone session the orb talks to,
with the same memory, and the answer comes back from that session's own
transcript (VoiceLoop.submit_remote). So what you said on the phone is in the
window when you sit back down, and the other way round.

    text            -> the clone; the written answer comes back
    voice note      -> heard on the Mac (whisper) -> the clone; the answer comes
                       back as text AND a voice note (Kokoro)
    /sessions       every session, which one you are talking to
    /use 2          talk to session 2 instead
    /new <task>     ask the clone to start a background session for it
    /stop           interrupt what the current session is doing (Esc)
    /screen         a rough text view of the current session
    /keys 1         press keys in the current session (1-9, esc, enter, up,
                    down, tab, y, n) -- for answering its questions
    /status         usage, memory, how it feels
    /app            the link to the phone app
    /mac            toggle: also say phone answers out loud on the Mac
    /lock           turn all phone access off until you turn it on at the Mac

When a session starts waiting on you, your phone is told, with buttons to
answer it. Unpaired senders get no reply at all.

Standard library only (urllib), so the bridge adds no dependency.
"""
from __future__ import annotations

import json
import os
import re
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.request
import uuid

from . import phone

API = "https://api.telegram.org"
POLL_S = 25
MAX_MSG = 3900                     # Telegram's limit is 4096; leave room

KEYS = {"esc": b"\x1b", "enter": b"\r", "up": b"\x1b[A", "down": b"\x1b[B",
        "tab": b"\t", "y": b"y", "n": b"n", "space": b" ",
        **{str(i): str(i).encode() for i in range(10)}}

_ANSI = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]|\x1b\][^\x07\x1b]*(?:\x07|\x1b\\)|\x1b[@-Z\\-_]")

HELP = ("Talk to me by text or voice note. Commands: /sessions, /use N, /new <task>, "
        "/stop, /screen, /keys 1|esc|enter, /status, /app, /mac, /lock")


def _ssl():
    try:
        from .models import _ssl_context
        return _ssl_context()
    except Exception:                                       # noqa: BLE001
        return None


def scrub(text: str, token: str) -> str:
    """Never let the token reach a log, an exception message, or a reply."""
    return text.replace(token, "<token>") if token else text


def screen_text(raw: bytes, lines: int = 28) -> str:
    """A rough plain-text view of a terminal's recent output.

    Not a terminal emulator: a TUI repaints in place, so this is the tail of
    what was drawn with the escape codes removed. Good enough to read a
    question and its numbered options, which is what it is for.
    """
    text = _ANSI.sub("", raw.decode("utf-8", "replace")).replace("\r", "\n")
    out = [ln.rstrip() for ln in text.split("\n")]
    out = [ln for ln in out if ln.strip()]
    return "\n".join(out[-lines:]) or "(nothing on screen)"


def chunks(text: str, n: int = MAX_MSG) -> list[str]:
    text = text.strip() or "(no answer)"
    parts = []
    while len(text) > n:
        cut = text.rfind("\n", 0, n)
        cut = cut if cut > n // 2 else n
        parts.append(text[:cut])
        text = text[cut:].lstrip()
    parts.append(text)
    return parts


class TelegramBridge:
    def __init__(self, dash, token: str = "", api: str = API):
        self.dash = dash
        self.token = token or phone.get_token()
        self.api = api.rstrip("/")
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._offset = 0
        self.ignored = 0                 # messages from people who are not you
        self.me: dict = {}
        self.last_error = ""
        self._last_chat: int | None = None

    # ---- http ---------------------------------------------------------------

    def _url(self, method: str) -> str:
        return f"{self.api}/bot{self.token}/{method}"

    def call(self, method: str, timeout: float = 15, **params):
        data = json.dumps(params).encode()
        req = urllib.request.Request(self._url(method), data=data,
                                     headers={"Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=timeout, context=_ssl()) as r:
                body = json.loads(r.read().decode())
        except urllib.error.HTTPError as e:
            try:
                body = json.loads(e.read().decode())
            except Exception:                               # noqa: BLE001
                raise RuntimeError(scrub(f"{method}: HTTP {e.code}", self.token)) from None
        except Exception as e:                              # noqa: BLE001
            raise RuntimeError(scrub(f"{method}: {e}", self.token)) from None
        if not body.get("ok"):
            raise RuntimeError(scrub(f"{method}: {body.get('description', 'failed')}",
                                     self.token))
        return body.get("result")

    def upload(self, method: str, field: str, path: str, **params):
        """multipart/form-data by hand, to stay inside the standard library."""
        boundary = uuid.uuid4().hex
        parts = []
        for k, v in params.items():
            parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{k}"'
                         f"\r\n\r\n{v}\r\n".encode())
        name = os.path.basename(path)
        with open(path, "rb") as f:
            blob = f.read()
        parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{field}"; '
                     f'filename="{name}"\r\nContent-Type: application/octet-stream\r\n\r\n'
                     .encode() + blob + b"\r\n")
        parts.append(f"--{boundary}--\r\n".encode())
        req = urllib.request.Request(
            self._url(method), data=b"".join(parts),
            headers={"Content-Type": f"multipart/form-data; boundary={boundary}"})
        try:
            with urllib.request.urlopen(req, timeout=60, context=_ssl()) as r:
                return json.loads(r.read().decode()).get("result")
        except Exception as e:                              # noqa: BLE001
            raise RuntimeError(scrub(f"{method}: {e}", self.token)) from None

    def download(self, file_id: str, suffix: str) -> str:
        info = self.call("getFile", file_id=file_id)
        url = f"{self.api}/file/bot{self.token}/{info['file_path']}"
        fd, path = tempfile.mkstemp(prefix="mem-tg-", suffix=suffix)
        try:
            with urllib.request.urlopen(url, timeout=60, context=_ssl()) as r, \
                    os.fdopen(fd, "wb") as f:
                f.write(r.read())
        except Exception as e:                              # noqa: BLE001
            raise RuntimeError(scrub(f"download: {e}", self.token)) from None
        return path

    # ---- sending ----------------------------------------------------------------

    def send(self, chat: int, text: str, buttons: list[list[tuple[str, str]]] | None = None):
        for i, part in enumerate(chunks(text)):
            kw = {"chat_id": chat, "text": part, "disable_web_page_preview": True}
            if buttons and i == 0:
                kw["reply_markup"] = {"inline_keyboard": [
                    [{"text": t, "callback_data": d} for t, d in row] for row in buttons]}
            try:
                self.call("sendMessage", **kw)
            except RuntimeError as e:
                self.last_error = str(e)

    def typing(self, chat: int) -> None:
        try:
            self.call("sendChatAction", chat_id=chat, action="typing", timeout=5)
        except RuntimeError:
            pass

    def send_voice(self, chat: int, path: str) -> None:
        try:
            self.upload("sendVoice", "voice", path, chat_id=chat)
        except RuntimeError as e:
            self.last_error = str(e)

    # ---- lifecycle --------------------------------------------------------------

    def start(self) -> bool:
        if not self.token:
            self.last_error = "no bot token (run: mem phone setup)"
            return False
        try:
            self.me = self.call("getMe") or {}
        except RuntimeError as e:
            self.last_error = str(e)
            print(f"[phone] telegram: {e}", file=sys.stderr)
            return False
        if self.me.get("username") and phone.load().get("bot") != self.me["username"]:
            phone.update(bot=self.me["username"])
        voice = getattr(self.dash, "voice", None)
        if voice is not None and hasattr(voice, "on_blocked"):
            voice.on_blocked.append(self.notify_blocked)
        self._thread = threading.Thread(target=self._run, name="telegram", daemon=True)
        self._thread.start()
        print(f"[phone] telegram bridge up as @{self.me.get('username', '?')}", file=sys.stderr)
        return True

    def stop(self) -> None:
        self._stop.set()

    def _run(self) -> None:
        backoff = 1.0
        while not self._stop.is_set():
            try:
                ups = self._poll()
                backoff = 1.0
            except RuntimeError as e:
                self.last_error = str(e)
                time.sleep(backoff)
                backoff = min(backoff * 2, 60)
                continue
            for up in ups or []:
                self._offset = max(self._offset, up.get("update_id", 0) + 1)
                try:
                    self.handle(up)
                except Exception as e:                      # noqa: BLE001
                    print(scrub(f"[phone] update failed: {e}", self.token), file=sys.stderr)

    def _poll(self):
        # `timeout` is both Telegram's long-poll wait and our socket timeout,
        # so they are passed separately: the socket must outlast the poll.
        data = json.dumps({"offset": self._offset, "timeout": POLL_S,
                           "allowed_updates": ["message", "callback_query"]}).encode()
        req = urllib.request.Request(self._url("getUpdates"), data=data,
                                     headers={"Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=POLL_S + 10, context=_ssl()) as r:
                body = json.loads(r.read().decode())
        except Exception as e:                              # noqa: BLE001
            raise RuntimeError(scrub(f"getUpdates: {e}", self.token)) from None
        if not body.get("ok"):
            raise RuntimeError(scrub(f"getUpdates: {body.get('description')}", self.token))
        return body.get("result") or []

    # ---- inbound ------------------------------------------------------------------

    def handle(self, up: dict) -> None:
        if "callback_query" in up:
            return self._callback(up["callback_query"])
        msg = up.get("message") or {}
        chat = (msg.get("chat") or {})
        user = (msg.get("from") or {})
        uid, cid = user.get("id"), chat.get("id")
        if chat.get("type") != "private" or uid is None:
            self.ignored += 1
            return                                   # never in groups
        text = (msg.get("text") or "").strip()

        if text.startswith("/start") or text.startswith("/pair"):
            code = text.split(maxsplit=1)[1] if " " in text else ""
            if code and phone.try_pair(uid, code, user.get("first_name", "")):
                self.send(cid, "Paired. This is your clone, with your memory. " + HELP)
            elif phone.is_allowed(uid):
                self.send(cid, HELP)
            else:
                self.ignored += 1                    # silence: do not confirm we exist
            return
        if not phone.is_allowed(uid):
            self.ignored += 1
            return
        self._last_chat = cid

        if msg.get("voice") or msg.get("audio"):
            return self._voice_note(cid, msg.get("voice") or msg.get("audio"))
        if not text:
            self.send(cid, "Text or voice notes only, for now.")
            return
        if text.startswith("/"):
            return self._command(cid, uid, text)
        self._ask(cid, text, voice_reply=False)

    def _ask(self, cid: int, text: str, voice_reply: bool) -> None:
        voice = getattr(self.dash, "voice", None)
        if voice is None:
            self.send(cid, "The voice loop is off on the Mac, so I cannot reach the session.")
            return
        stop_typing = threading.Event()

        def keep_typing():
            while not stop_typing.wait(4.0):
                self.typing(cid)

        def sink(answer: str) -> None:
            stop_typing.set()
            self.send(cid, answer)
            if voice_reply:
                from .phone_audio import speak
                path = speak(answer, voice)
                if path:
                    self.send_voice(cid, path)

        self.typing(cid)
        threading.Thread(target=keep_typing, daemon=True).start()
        speak_mac = bool(phone.load().get("speak_on_mac"))
        threading.Thread(target=voice.submit_remote, daemon=True,
                         args=(text, sink, speak_mac)).start()

    def _voice_note(self, cid: int, media: dict) -> None:
        self.typing(cid)
        path = ""
        try:
            path = self.download(media["file_id"], ".ogg")
            from .phone_audio import hear
            text = hear(path, getattr(self.dash, "voice", None))
        except Exception as e:                              # noqa: BLE001
            self.send(cid, scrub(f"I could not hear that one: {e}", self.token))
            return
        finally:
            if path:
                try:
                    os.unlink(path)
                except OSError:
                    pass
        if not text:
            self.send(cid, "I could not make out any words in that.")
            return
        self.send(cid, f"heard: {text}")
        self._ask(cid, text, voice_reply=True)

    # ---- commands ----------------------------------------------------------------

    def _target(self):
        return self.dash.panes.target_pane()

    def _command(self, cid: int, uid: int, text: str) -> None:
        cmd, _, arg = text.partition(" ")
        cmd = cmd.split("@")[0].lower()
        arg = arg.strip()
        if cmd == "/sessions":
            rows = self.dash.panes.info()
            if not rows:
                return self.send(cid, "No sessions are open.")
            lines = [f"{i}. {r['title']} ({r['shortCwd']}, {r['state']})"
                     f"{'  <- talking to' if r.get('voice') else ''}"
                     for i, r in enumerate(rows, 1)]
            return self.send(cid, "\n".join(lines) + "\n\n/use N to switch.")
        if cmd == "/use":
            rows = self.dash.panes.info()
            try:
                row = rows[int(arg) - 1]
            except (ValueError, IndexError):
                return self.send(cid, "Which one? /sessions lists them.")
            self.dash.panes.set_voice_target(row["id"])
            voice = getattr(self.dash, "voice", None)
            if voice is not None:
                voice.attach_target_pane()
            self.dash.hub.send_threadsafe({"t": "panes", "panes": self.dash.panes.info()})
            return self.send(cid, f"Now talking to {row['title']}.")
        if cmd == "/new":
            if not arg:
                return self.send(cid, "/new what? Say the task after it.")
            return self._ask(cid, "Start a background session for this task, then tell me "
                                  f"in one line that it is running: {arg}", voice_reply=False)
        if cmd == "/stop":
            pane = self._target()
            if pane is None or not pane.pty.alive:
                return self.send(cid, "Nothing is running.")
            pane.pty.write(b"\x1b")
            return self.send(cid, f"Interrupted {pane.title}.")
        if cmd == "/screen":
            pane = self._target()
            if pane is None:
                return self.send(cid, "No session to look at.")
            return self.send(cid, screen_text(pane.pty.scrollback()), self._key_buttons())
        if cmd == "/keys":
            return self._keys(cid, arg)
        if cmd == "/status":
            return self.send(cid, self._status())
        if cmd == "/app":
            url = getattr(self.dash, "phone_url", "")
            return self.send(cid, f"{url}/phone?k={phone.web_token()}" if url else
                             "The phone app is not reachable yet. On the Mac run: mem phone tunnel")
        if cmd == "/mac":
            on = not phone.load().get("speak_on_mac")
            phone.update(speak_on_mac=on)
            return self.send(cid, "Answers will also be spoken on the Mac." if on
                             else "The Mac stays quiet for phone answers.")
        if cmd == "/lock":
            phone.lock()
            return self.send(cid, "Locked. Nothing from this phone works until you run "
                                  "`mem phone on` at the Mac.")
        if cmd == "/help":
            return self.send(cid, HELP)
        self.send(cid, f"I do not know {cmd}. " + HELP)

    def _keys(self, cid: int, arg: str) -> None:
        pane = self._target()
        if pane is None or not pane.pty.alive:
            return self.send(cid, "No session to press keys in.")
        seq = []
        for tok in arg.split() or []:
            k = KEYS.get(tok.lower())
            if k is None:
                return self.send(cid, f"I do not know the key {tok}. Use 1-9, esc, enter, "
                                      "up, down, tab, y, n.")
            seq.append(k)
        if not seq:
            return self.send(cid, "Which keys? e.g. /keys 1  or  /keys down enter")
        for k in seq:
            pane.pty.write(k)
            time.sleep(0.08)
        self.send(cid, f"Pressed {arg} in {pane.title}.")

    def _key_buttons(self):
        return [[("1", "k:1"), ("2", "k:2"), ("3", "k:3"), ("Esc", "k:esc"),
                 ("Enter", "k:enter")], [("Show screen", "screen")]]

    def _callback(self, q: dict) -> None:
        uid = (q.get("from") or {}).get("id")
        cid = ((q.get("message") or {}).get("chat") or {}).get("id")
        try:
            self.call("answerCallbackQuery", callback_query_id=q.get("id"))
        except RuntimeError:
            pass
        if not phone.is_allowed(uid) or cid is None:
            self.ignored += 1
            return
        data = q.get("data") or ""
        if data.startswith("k:"):
            self._keys(cid, data[2:])
        elif data == "screen":
            self._command(cid, uid, "/screen")

    def _status(self) -> str:
        lines = []
        voice = getattr(self.dash, "voice", None)
        if voice is not None:
            k, v = voice.mood.dominant()
            lines.append(f"state: {voice.state}, feeling {k if v > 15 else 'calm'}")
        pane = self._target()
        if pane is not None:
            lines.append(f"talking to: {pane.title} in {pane.cwd}")
        mem = getattr(getattr(self.dash, "memory", None), "last", None) or {}
        if mem:
            notes = mem.get("notes") or mem.get("total")
            if notes:
                lines.append(f"memory: {notes} notes")
        use = getattr(getattr(self.dash, "usage", None), "last", None) or {}
        for key in ("session", "week"):
            val = use.get(key)
            if isinstance(val, dict) and val.get("pct") is not None:
                lines.append(f"{key} usage: {val['pct']}%")
        lines.append(f"sessions open: {len(self.dash.panes.info())}")
        return "\n".join(lines)

    # ---- outbound pushes -----------------------------------------------------------

    def notify_blocked(self, names: list[str]) -> None:
        """A session started waiting on you. Tell every paired phone, once."""
        cfg = phone.load()
        if not cfg["enabled"]:
            return
        who = names[0] if len(names) == 1 else f"{len(names)} sessions"
        for uid in cfg["allowed"]:
            self.send(uid, f"{who} needs you.", self._key_buttons())
