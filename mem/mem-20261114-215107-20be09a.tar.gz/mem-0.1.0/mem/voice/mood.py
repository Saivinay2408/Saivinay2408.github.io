"""
mood — what the clone feels, from what is actually happening.

Ported from the short film's emotion engine, with one deliberate change. In the
film the model tagged its own feelings (`<<anger=80>>`), which is right for a
character and wrong for a tool: a colour you cannot trust is decoration. Here
every feeling is caused by a typed event the dashboard already receives, so
the orb turning ember means a session really is waiting on you, and the white
blaze means a turn really did finish with its tests green.

  event                                  feeling
  -------------------------------------  ---------------------------
  you start talking / a prompt arrives   warmth
  Read, Grep, Glob, search, look         curiosity
  Edit, Write, build, commit             focus
  a tool result comes back as an error   concern  (grows on repeats)
  a session is blocked on your answer    urgency
  tests or a build pass, a push lands    joy
  a turn ends after real, clean work     completeness (white)

Costs nothing: no model call, no token. Feelings decay back to calm on their
own, so a colour never outlives its cause by more than a few seconds.
"""
from __future__ import annotations

import re
import threading
import time
from typing import Callable

# name, colour. Order is the order the emotions box draws them in.
# The colours sit in the dashboard's own palette (brass, oxide, patina, ember)
# rather than the film's saturated set, so the window still reads as one thing.
EMOTIONS: tuple[tuple[str, str], ...] = (
    ("warmth",       "#e0bb43"),   # brass, brighter: you are here
    ("curiosity",    "#4fb3a9"),   # teal: looking, reading, searching
    ("focus",        "#6f8fb8"),   # steel blue: making changes
    ("concern",      "#9b6fd0"),   # violet: something failed
    ("urgency",      "#f0913a"),   # ember: it needs you (the blocked colour)
    ("joy",          "#7fc97a"),   # patina, lifted: it worked
    ("completeness", "#fffaf0"),   # white: the only feeling that makes the orb blaze
)
NAMES = tuple(n for n, _ in EMOTIONS)

# Per second, the fraction of a feeling that fades. Urgency is slow on purpose:
# it is re-asserted every tick while a session is blocked, and should not
# flicker between ticks. Completeness is quick: it is a moment, not a mood.
_DECAY = {"warmth": 0.18, "curiosity": 0.22, "focus": 0.15, "concern": 0.10,
          "urgency": 0.30, "joy": 0.14, "completeness": 0.25}

_TOOL_FEEL = {
    "Read": ("curiosity", 22), "Grep": ("curiosity", 22), "Glob": ("curiosity", 18),
    "WebSearch": ("curiosity", 30), "WebFetch": ("curiosity", 26),
    "Edit": ("focus", 26), "MultiEdit": ("focus", 30), "Write": ("focus", 30),
    "NotebookEdit": ("focus", 26), "Task": ("focus", 20), "Agent": ("focus", 20),
}
_TESTY = re.compile(r"\b(pytest|jest|vitest|go test|cargo test|npm (run )?test|verify\.py|"
                    r"npm run build|cargo build|make\b|tsc\b)", re.I)
_SHIPPY = re.compile(r"\bgit\s+(commit|push)\b", re.I)
_LOOKY = re.compile(r"\b(mdfind|find|grep|rg|ls|cat|head|tail|screencapture|curl)\b", re.I)

EMIT_MIN_S = 0.25          # at most four updates a second reach the window
EMIT_DELTA = 2.0           # and only when something moved by this much


class Mood:
    """Seven numbers between 0 and 100, pushed by events, pulled back by time.

    Thread-safe: events arrive on the transcript watcher's thread, the blocked
    signal on the server's, the tick on the voice loop's.
    """

    def __init__(self, emit: Callable[[dict], None] | None = None,
                 clock: Callable[[], float] = time.monotonic):
        self._emit = emit
        self._clock = clock
        self._v = {n: 0.0 for n in NAMES}
        self._lock = threading.Lock()
        self._t = clock()
        self._pending: dict[str, str] = {}    # tool_use id -> "test" | "ship"
        self._turn_tools = 0
        self._turn_errors = 0
        self._sent: dict[str, int] = {}
        self._sent_at = float("-inf")
        self._held = False                     # a session is blocked on you
        self.enabled = True

    # ---- inputs ------------------------------------------------------------

    def bump(self, name: str, amount: float, cap: float = 100.0) -> None:
        with self._lock:
            self._v[name] = min(cap, self._v[name] + amount)

    def on_event(self, ev: dict) -> None:
        """One typed transcript event (see transcript.parse_line)."""
        kind = ev.get("kind")
        if kind == "user":
            self._turn_tools = self._turn_errors = 0
            self.bump("warmth", 45)
            with self._lock:                   # a new turn clears the old verdict
                self._v["completeness"] *= 0.3
                self._v["joy"] *= 0.5
        elif kind == "tool":
            self._turn_tools += 1
            name = ev.get("name", "")
            if name == "Bash":
                cmd = str((ev.get("input") or {}).get("command", ""))
                if _TESTY.search(cmd):
                    self._pending[ev.get("id", "")] = "test"
                    self.bump("focus", 24)
                elif _SHIPPY.search(cmd):
                    self._pending[ev.get("id", "")] = "ship"
                    self.bump("focus", 18)
                elif _LOOKY.search(cmd):
                    self.bump("curiosity", 18)
                else:
                    self.bump("focus", 12)
            elif name in _TOOL_FEEL:
                feel, amt = _TOOL_FEEL[name]
                self.bump(feel, amt, cap=85)
        elif kind == "tool_result":
            what = self._pending.pop(ev.get("id", ""), None)
            if ev.get("ok", True):
                if what == "test":
                    self.bump("joy", 55)
                    with self._lock:
                        self._v["concern"] *= 0.4   # it was broken, now it is not
                elif what == "ship":
                    self.bump("joy", 40)
            else:
                self._turn_errors += 1
                # the third failure in a row worries more than the first
                self.bump("concern", 22 + 10 * min(self._turn_errors, 4))
        elif kind == "assistant":
            self.bump("warmth", 8, cap=60)
        elif kind == "turn_end":
            if self._turn_tools >= 2:
                with self._lock:               # the work is over; the verdict leads
                    for n in ("focus", "curiosity"):
                        self._v[n] *= 0.4
            if self._turn_tools >= 2 and self._turn_errors == 0:
                self.bump("completeness", 70)
            elif self._turn_tools >= 2:
                # finished, but through failures: relief, not a blaze
                self.bump("completeness", 30)
            self._turn_tools = self._turn_errors = 0
        self.tick()

    def set_blocked(self, blocked: bool) -> None:
        """Held, not bumped: while a session waits on you, urgency stays up."""
        self._held = bool(blocked)
        self.tick()

    def hearing(self) -> None:
        """You are holding space. Attention turns to you."""
        self.bump("warmth", 6, cap=70)

    # ---- output ------------------------------------------------------------

    def tick(self) -> dict[str, int]:
        """Apply decay, and push to the window if anything visibly moved."""
        now = self._clock()
        with self._lock:
            dt = max(0.0, now - self._t)
            self._t = now
            for n in NAMES:
                self._v[n] *= (1.0 - _DECAY[n]) ** dt
            if self._held:
                self._v["urgency"] = max(self._v["urgency"], 75.0)
            snap = {n: int(round(v)) for n, v in self._v.items()}
        if self._emit and self.enabled and now - self._sent_at >= EMIT_MIN_S:
            moved = any(abs(snap[n] - self._sent.get(n, -99)) >= EMIT_DELTA for n in NAMES)
            if moved:
                self._sent, self._sent_at = snap, now
                self._emit(snap)
        return snap

    def snapshot(self) -> dict[str, int]:
        with self._lock:
            return {n: int(round(v)) for n, v in self._v.items()}

    def dominant(self) -> tuple[str, int]:
        s = self.snapshot()
        k = max(s, key=s.get)
        return k, s[k]


def palette() -> list[list[str]]:
    """What the window needs to draw the emotions box: [[name, colour], ...]."""
    return [[n, c] for n, c in EMOTIONS]
