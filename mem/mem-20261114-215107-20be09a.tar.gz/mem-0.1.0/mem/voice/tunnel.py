"""
tunnel — your phone reaching this Mac, through Tailscale.

Why Tailscale and not a public tunnel: `tailscale serve` publishes the window
ONLY to devices signed into your own tailnet, with a real HTTPS certificate.
A phone's microphone only works on an HTTPS page, so the certificate is
needed, and "only my own devices can even see it" is the right default for
something that can run commands on this machine. It is free for personal use.

The app still asks for its own token on top (phone.py): the tailnet is the
wall, the token is the lock on the door.
"""
from __future__ import annotations

import json
import shutil
import subprocess

_APP_CLI = "/Applications/Tailscale.app/Contents/MacOS/Tailscale"


def cli() -> str:
    found = shutil.which("tailscale")
    if found:
        return found
    import os
    return _APP_CLI if os.path.exists(_APP_CLI) else ""


def _run(args: list[str], timeout: int = 15) -> tuple[int, str]:
    exe = cli()
    if not exe:
        return 127, "Tailscale is not installed (https://tailscale.com/download)"
    try:
        p = subprocess.run([exe, *args], capture_output=True, text=True, timeout=timeout)
    except (OSError, subprocess.TimeoutExpired) as e:
        return 1, str(e)
    return p.returncode, (p.stdout or "") + (p.stderr or "")


def status() -> dict:
    """{'installed', 'running', 'host'}: host is this Mac's tailnet name."""
    code, out = _run(["status", "--json"])
    if code == 127:
        return {"installed": False, "running": False, "host": ""}
    try:
        st = json.loads(out)
    except ValueError:
        return {"installed": True, "running": False, "host": ""}
    host = ((st.get("Self") or {}).get("DNSName") or "").rstrip(".")
    return {"installed": True, "running": st.get("BackendState") == "Running", "host": host}


def serving(port: int) -> bool:
    code, out = _run(["serve", "status", "--json"])
    if code != 0:
        return False
    return f"127.0.0.1:{port}" in out or f"localhost:{port}" in out


def public_url(port: int) -> str:
    """The phone app's address, or "" if it is not being served right now."""
    st = status()
    if st["running"] and st["host"] and serving(port):
        return f"https://{st['host']}"
    return ""


def serve(port: int) -> tuple[bool, str]:
    st = status()
    if not st["installed"]:
        return False, "Install Tailscale on this Mac and your phone: https://tailscale.com/download"
    if not st["running"]:
        return False, ("Tailscale is installed but not connected. Open the Tailscale app, "
                       "sign in, then run this again.")
    code, out = _serve_bg(port)
    if code != 0:
        return False, out.strip() or "tailscale serve failed"
    return True, f"https://{st['host']}"


def _serve_bg(port: int, wait: float = 12.0) -> tuple[int, str]:
    """`tailscale serve --bg`, without hanging.

    On a tailnet where Serve has never been switched on, the command prints an
    enable link and then waits, forever, for someone to click it. Read what it
    says; if it is that, stop it and hand the link back instead."""
    import re
    import time
    exe = cli()
    if not exe:
        return 127, "Tailscale is not installed (https://tailscale.com/download)"
    import os
    p = subprocess.Popen([exe, "serve", "--bg", f"http://127.0.0.1:{port}"],
                         stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    os.set_blocking(p.stdout.fileno(), False)
    out, deadline = "", time.time() + wait
    while time.time() < deadline:
        try:
            chunk = os.read(p.stdout.fileno(), 4096)
        except BlockingIOError:
            chunk = None
        if chunk:
            out += chunk.decode("utf-8", "replace")
            m = re.search(r"https://login\.tailscale\.com/\S+", out)
            if "not enabled" in out and m:
                p.kill()
                return 1, ("Serve is switched off for your tailnet. Turn it on once "
                           f"(it is free) by opening this link, then run this again:\n\n    {m.group(0)}")
        elif chunk == b"" or p.poll() is not None:
            if p.poll() is not None:
                break
        time.sleep(0.1)
    if p.poll() is None:
        p.kill()
        return 1, out.strip() or "tailscale serve did not finish"
    try:
        out += (os.read(p.stdout.fileno(), 65536) or b"").decode("utf-8", "replace")
    except BlockingIOError:
        pass
    return p.returncode, out


def unserve(port: int) -> tuple[bool, str]:
    """Stop publishing Mem, and only Mem. `serve reset` would also tear down
    anything else this Mac shares on the tailnet, which is not ours to touch."""
    if not serving(port):
        return True, "was not being served"
    code, out = _run(["serve", "--https=443", "off"])
    return code == 0, out.strip() or "stopped"
