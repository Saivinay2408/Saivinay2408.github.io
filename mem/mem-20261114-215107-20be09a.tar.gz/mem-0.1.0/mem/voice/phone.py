"""
phone — reaching Mem from your phone: who is allowed, and the secrets that prove it.

Everything a remote turn can do, a session running with full permissions can
do to this Mac. So this file is mostly about saying no:

  * The Telegram bot token lives in the macOS Keychain, never in a file or a
    log. `mem phone setup` asks for it with getpass, so it is not even in your
    shell history.
  * Only paired Telegram accounts are answered, by user id (a chat id alone
    would admit anyone added to a group with the bot). Pairing needs a
    six-digit code, valid for ten minutes, printed on the Mac itself, so
    knowing the bot's name gets a stranger nothing.
  * The phone web app (through Tailscale) needs a long random token, stored
    here with 0600 permissions, which becomes an HttpOnly cookie.
  * `mem phone off` turns all of it off at once; so does /lock from the phone.

This is deliberately a separate bot from any other assistant on the machine:
a Telegram bot can only be read by one program at a time, and sharing one
would silently break the other.
"""
from __future__ import annotations

import json
import os
import secrets
import shutil
import subprocess
import time
from pathlib import Path

from .paths import STATE

CONFIG = STATE / "phone.json"
KEYCHAIN_SERVICE = "mem-telegram"
PAIR_TTL_S = 600
DEFAULT_PORT = 47821


# ---- config ----------------------------------------------------------------

def load() -> dict:
    try:
        cfg = json.loads(CONFIG.read_text())
    except (OSError, ValueError):
        cfg = {}
    cfg.setdefault("enabled", False)
    cfg.setdefault("allowed", [])           # Telegram user ids
    cfg.setdefault("names", {})             # user id -> first name, for status
    cfg.setdefault("port", DEFAULT_PORT)
    cfg.setdefault("speak_on_mac", False)
    cfg.setdefault("bot", "")               # bot username, for the pairing link
    return cfg


def save(cfg: dict) -> dict:
    CONFIG.parent.mkdir(parents=True, exist_ok=True)
    tmp = CONFIG.with_suffix(".tmp")
    tmp.write_text(json.dumps(cfg, indent=2) + "\n")
    os.chmod(tmp, 0o600)
    os.replace(tmp, CONFIG)
    return cfg


def update(**patch) -> dict:
    cfg = load()
    cfg.update(patch)
    return save(cfg)


# ---- the bot token (Keychain) -----------------------------------------------

def _security() -> str | None:
    return shutil.which("security")


def get_token() -> str:
    """The bot token, or "" if none is stored. MEM_TELEGRAM_TOKEN overrides,
    for machines without a Keychain (Linux, CI)."""
    env = os.environ.get("MEM_TELEGRAM_TOKEN", "").strip()
    if env:
        return env
    sec = _security()
    if not sec:
        return ""
    p = subprocess.run([sec, "find-generic-password", "-s", KEYCHAIN_SERVICE, "-w"],
                       capture_output=True, text=True)
    return p.stdout.strip() if p.returncode == 0 else ""


def set_token(token: str) -> bool:
    sec = _security()
    if not sec:
        return False
    # -U updates in place. The token goes in as an argument to a child process,
    # never through a shell and never printed.
    p = subprocess.run([sec, "add-generic-password", "-s", KEYCHAIN_SERVICE,
                        "-a", "bot", "-w", token.strip(), "-U"],
                       capture_output=True, text=True)
    return p.returncode == 0


def delete_token() -> None:
    sec = _security()
    if sec:
        subprocess.run([sec, "delete-generic-password", "-s", KEYCHAIN_SERVICE],
                       capture_output=True)


def looks_like_token(t: str) -> bool:
    head, _, tail = t.strip().partition(":")
    return head.isdigit() and len(tail) >= 30


# ---- pairing ------------------------------------------------------------------

def new_pair_code() -> str:
    code = f"{secrets.randbelow(10**6):06d}"
    update(pair_code=code, pair_expires=time.time() + PAIR_TTL_S)
    return code


def try_pair(user_id: int, code: str, name: str = "") -> bool:
    """Consume a pairing code. Single use, time limited, constant-time compare."""
    cfg = load()
    want = cfg.get("pair_code") or ""
    if not want or time.time() > float(cfg.get("pair_expires") or 0):
        return False
    if not secrets.compare_digest(want, (code or "").strip()):
        return False
    allowed = [u for u in cfg["allowed"] if u != user_id] + [user_id]
    names = dict(cfg["names"]); names[str(user_id)] = name
    update(allowed=allowed, names=names, pair_code="", pair_expires=0, enabled=True)
    return True


def is_allowed(user_id) -> bool:
    cfg = load()
    return bool(cfg["enabled"]) and user_id in cfg["allowed"]


def pair_link(code: str) -> str:
    bot = load().get("bot") or ""
    return f"https://t.me/{bot}?start={code}" if bot else ""


# ---- the phone web app ------------------------------------------------------

def web_token() -> str:
    cfg = load()
    tok = cfg.get("web_token") or ""
    if not tok:
        tok = secrets.token_urlsafe(32)
        update(web_token=tok)
    return tok


def rotate_web_token() -> str:
    tok = secrets.token_urlsafe(32)
    update(web_token=tok)
    return tok


def web_token_ok(candidate: str) -> bool:
    tok = load().get("web_token") or ""
    return bool(tok) and secrets.compare_digest(tok, candidate or "")


def lock() -> None:
    """Everything off, now: from the phone (/lock) or the Mac (`mem phone off`).
    Pairings are kept, so turning it back on does not mean pairing again, but
    the web token is rotated so any open phone session is logged out."""
    update(enabled=False)
    rotate_web_token()


def config_path() -> Path:
    return CONFIG
