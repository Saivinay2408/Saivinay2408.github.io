"""
screen — a still of this Mac's screen, small enough to send to your phone.

View-only by design: the phone watches, the clone does. Your hands on the Mac
from a phone would be a second, unsupervised way to drive it; the clone already
has hands (act.py), so the phone only needs eyes.

Uses Quartz directly (already installed for the pointer overlay): one call to
grab the main display, one to scale it, one to encode a JPEG. No subprocess,
no temporary file, about 0.1 s on Apple Silicon.

macOS asks once for Screen Recording permission. Until it is granted the
capture still "works" but shows only the wallpaper, so `allowed()` is checked
first and the phone is told what to do instead of being shown a blank desk.
"""
from __future__ import annotations

_asked = False


def allowed() -> bool:
    try:
        import Quartz
        return bool(Quartz.CGPreflightScreenCaptureAccess())
    except Exception:                                       # noqa: BLE001
        return False


def ask() -> None:
    """Show macOS's permission prompt on the Mac, once per run."""
    global _asked
    if _asked:
        return
    _asked = True
    try:
        import Quartz
        Quartz.CGRequestScreenCaptureAccess()
    except Exception:                                       # noqa: BLE001
        pass


def grab_jpeg(max_w: int = 1280, quality: float = 0.6) -> bytes | None:
    import Quartz
    img = Quartz.CGDisplayCreateImage(Quartz.CGMainDisplayID())
    if img is None:
        return None
    w, h = Quartz.CGImageGetWidth(img), Quartz.CGImageGetHeight(img)
    scale = min(1.0, max_w / float(w))
    nw, nh = max(1, int(w * scale)), max(1, int(h * scale))
    cs = Quartz.CGColorSpaceCreateDeviceRGB()
    ctx = Quartz.CGBitmapContextCreate(None, nw, nh, 8, 0, cs,
                                       Quartz.kCGImageAlphaNoneSkipLast)
    Quartz.CGContextSetInterpolationQuality(ctx, Quartz.kCGInterpolationMedium)
    Quartz.CGContextDrawImage(ctx, Quartz.CGRectMake(0, 0, nw, nh), img)
    # Where the mouse is, as a ring: the Mac's own cursor is not in the capture,
    # and "what is it doing" is mostly "where is it pointing".
    try:
        loc = Quartz.CGEventGetLocation(Quartz.CGEventCreate(None))
        b = Quartz.CGDisplayBounds(Quartz.CGMainDisplayID())
        px = (loc.x - b.origin.x) / b.size.width * nw
        py = nh - (loc.y - b.origin.y) / b.size.height * nh
        Quartz.CGContextSetRGBStrokeColor(ctx, 0.94, 0.57, 0.23, 0.95)
        Quartz.CGContextSetLineWidth(ctx, 2.5)
        Quartz.CGContextStrokeEllipseInRect(ctx, Quartz.CGRectMake(px - 9, py - 9, 18, 18))
    except Exception:                                       # noqa: BLE001
        pass
    scaled = Quartz.CGBitmapContextCreateImage(ctx)
    data = Quartz.CFDataCreateMutable(None, 0)
    dest = Quartz.CGImageDestinationCreateWithData(data, "public.jpeg", 1, None)
    Quartz.CGImageDestinationAddImage(
        dest, scaled, {Quartz.kCGImageDestinationLossyCompressionQuality: quality})
    if not Quartz.CGImageDestinationFinalize(dest):
        return None
    return bytes(data)
