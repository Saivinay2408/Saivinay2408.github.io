"""
phone_audio — turning a phone's voice note into words, and an answer into one.

Both directions stay on this Mac, like the rest of the voice stack: whisper
hears it, Kokoro (or the system voice) says it. Nothing is uploaded anywhere
except the finished reply, to the phone that asked for it.

  hear(path)     any audio a phone records (Telegram's OGG/Opus, Safari's MP4,
                 Chrome's WebM) -> text. PyAV, which faster-whisper already
                 depends on, decodes all of them.
  speak(text)    -> a .m4a file. Telegram accepts M4A as a voice note, and
                 every phone browser plays it. `afconvert` ships with macOS.
"""
from __future__ import annotations

import os
import shutil
import subprocess
import tempfile
import threading
import wave
from pathlib import Path

_lock = threading.Lock()
_transcriber = None


def _stt(voice=None):
    """Reuse the voice loop's whisper if it has one loaded; load our own if not."""
    global _transcriber
    if voice is not None and getattr(voice, "stt", None) is not None:
        return voice.stt
    with _lock:
        if _transcriber is None:
            from .stt import Transcriber
            size = getattr(voice, "whisper_size", "small") if voice else "small"
            _transcriber = Transcriber(size)
        return _transcriber


def hear(path: str | Path, voice=None) -> str:
    from faster_whisper import decode_audio
    audio = decode_audio(str(path), sampling_rate=16000)
    if len(audio) < 1600:            # under a tenth of a second: nothing said
        return ""
    text, _ = _stt(voice).transcribe(audio)
    return text.strip()


def _write_wav(path: str, samples, sr: int) -> None:
    import numpy as np
    pcm = (np.clip(samples, -1.0, 1.0) * 32767).astype("<i2")
    with wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(sr)
        w.writeframes(pcm.tobytes())


def speak(text: str, voice=None, out_dir: str | None = None) -> str:
    """Synthesize `text` to an .m4a and return its path, or "" if it cannot."""
    text = (text or "").strip()
    if not text:
        return ""
    from .speakable import to_speech
    said = to_speech(text) or text
    out_dir = out_dir or tempfile.mkdtemp(prefix="mem-phone-")
    import uuid
    base = os.path.join(out_dir, f"reply-{uuid.uuid4().hex}")
    wav, m4a = base + ".wav", base + ".m4a"

    engine = getattr(getattr(voice, "speaker", None), "engine", None)
    try:
        samples, sr = engine.synth(said) if engine is not None else (said, -1)
    except Exception:                                       # noqa: BLE001
        samples, sr = said, -1
    if sr == -1:
        # The system voice: robotic, but always there.
        if not shutil.which("say"):
            return ""
        aiff = base + ".aiff"
        if subprocess.run(["say", "-o", aiff, said], capture_output=True).returncode:
            return ""
        src = aiff
    else:
        _write_wav(wav, samples, sr)
        src = wav
    if shutil.which("afconvert"):
        p = subprocess.run(["afconvert", "-f", "m4af", "-d", "aac", src, m4a],
                           capture_output=True)
        if p.returncode == 0 and os.path.exists(m4a):
            return m4a
    return src if src.endswith(".wav") else ""


_engine = None


def synth(text: str, voice=None):
    """`text` -> (float32 mono samples, sample rate), or (None, 0).

    For a live call, which needs the audio itself rather than a file. Uses the
    same voice the room uses; falls back to the system voice."""
    global _engine
    text = (text or "").strip()
    if not text:
        return None, 0
    engine = getattr(getattr(voice, "speaker", None), "engine", None)
    if engine is None:
        with _lock:
            if _engine is None:
                try:
                    from .paths import MODELS, VOICE_CONFIG
                    from .tts import KokoroTTS
                    _engine = KokoroTTS(models_dir=MODELS, config_path=VOICE_CONFIG)
                except Exception:                           # noqa: BLE001
                    _engine = False
        engine = _engine or None
    if engine is not None:
        try:
            samples, sr = engine.synth(text)
            if sr and sr > 0:
                import numpy as np
                return np.asarray(samples, dtype="float32").reshape(-1), int(sr)
        except Exception:                                   # noqa: BLE001
            pass
    if not shutil.which("say"):
        return None, 0
    fd, aiff = tempfile.mkstemp(prefix="mem-call-", suffix=".aiff")
    os.close(fd)
    try:
        if subprocess.run(["say", "-o", aiff, text], capture_output=True).returncode:
            return None, 0
        from faster_whisper import decode_audio
        return decode_audio(aiff, sampling_rate=24000), 24000
    finally:
        try:
            os.unlink(aiff)
        except OSError:
            pass
