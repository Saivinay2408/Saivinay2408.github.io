# Mem

**A model of you that any agent can read**, stored as plain markdown files in a
git repository — plus one window to talk to them all.

Works with **Claude Code, Codex, and Gemini CLI**. One vault behind all three,
so what you tell one, the others know.

```bash
pip install "mem[voice]"
mem backfill --apply    # learn from sessions you have already had
mem init                # wire the agents you have
mem voice               # one window. hold space to talk.
```

## What you actually get

**It is still your coding agent.** Same model, same tools, same intelligence,
all of it intact — this does not wrap it, replace it, or route around it. What
changes is that it also knows how *you* think.

You get both halves, and they are genuinely different things:

- **Its own intelligence.** It still reasons about problems it has never seen,
  writes code you never taught it, and tells you when you are wrong. None of
  that is traded away for the memory.
- **Your judgement.** It knows what you are building and why, who your people
  are, what you decided last month and what has changed since, how you write,
  and what you would never ship. So on the close calls it makes *your* call
  instead of the median one.

The practical difference is that you stop re-explaining your life at the start
of every session. Point it at a project and the context you would have spent ten
minutes pasting in is already there.

**It is a file, not a product.** The model of you is markdown in a git
repository you own, and every fact in it can show you the sentence you actually
said that made it believe that. Swap Claude for something else later and the
model of you stays put. No database, no vector store, no service, no
dependencies outside the Python standard library.

**And there is a window.** `mem voice` opens one dark window with an orb you
hold space to talk to, and your real sessions tiled underneath it. Each pane is
a genuine `claude` process on a real PTY — actual permission prompts, actual
slash commands — rendered with xterm.js, not a chat client pretending to be one.
Spoken progress comes from the agent's own typed transcript, so "running the
tests" is said because a `Bash` call really started, not because a regex matched
a repainting terminal.

The window is optional. `pip install mem` on its own gets you the memory, which
works in the agents you already use, with no window at all.

**And "off" means off.** Not every task wants an agent that knows you — a work
repo, a screen share, somebody else's problem:

```bash
mem memory off      # a plain agent: nothing injected, nothing recorded
mem memory on       # your clone again
```

Requires Python 3.10 or later. Your data stays on your disk, with one exception
you should know about before you start: see [SECURITY.md](SECURITY.md).

### Installing

| Command | What you get |
|---|---|
| `pip install mem` | the memory. Zero dependencies. Works in the agents you already use |
| `pip install "mem[window]"` | the dashboard, driven by typing |
| `pip install "mem[voice]"` | the dashboard, driven by voice |
| `pip install "mem[all]"` | the above plus a native desktop window |

Each extra degrades rather than breaks: without `[gui]` the window opens in your
browser, without `[voice]` you type into the same sessions, and if the speech
weights are missing it falls back to your system voice. Nobody who wants a
session manager should have to download model weights to get one.

## Setting it up

**Start with the part that asks you nothing.** If you have used Claude Code
before, months of your own real decisions are already sitting on disk:

```bash
mem backfill              # what's there; writes nothing
mem backfill --apply      # capture it
mem consolidate           # distil it into facts
```

That is a better source than any interview, because it is what you actually did
rather than what you say you do when someone asks.

**Then answer ten questions** — for the things transcripts cannot show you: who
your people are, what it must never do, how you want to be written as. About
twenty minutes, every question is optional, and the first three sections are
enough on their own.

Easiest in the window: `mem voice`, then **Setup → Answer ten questions**. It
asks them one at a time, out loud, and you answer by holding space or by
typing. Every answer is saved as you give it, so it survives closing the
window, and the last step runs exactly the command below on your behalf.

The same thing from a terminal, if you would rather write it in your own
editor — [`docs/QUICKSTART.md`](docs/QUICKSTART.md) is the same ten questions:

```bash
cp docs/QUICKSTART.md my-answers.md                  # ...answer it...
mem check-extractor                  # confirm setup before you spend time
mem onboard my-answers.md            # dry run, writes nothing
mem onboard my-answers.md --apply    # file, extract, gate, seed
mem onboard --approve-identity       # after you read the drafts
```

**If you want the deep version**, `docs/INTERVIEW.md` is 137 questions across 15
sections and produces a noticeably better clone. It is there when you want it.
Almost nobody finishes it in one sitting, and nothing here requires you to.

**Then wire it into whichever agents you use.** One command, and it only touches
the ones you actually have:

```bash
mem init --dry-run    # show exactly what would change
mem init              # wire them
```

### Which agent gets which version

They do not offer the same hooks, so they do not all get the same thing. Rather
than average that away, here is the difference:

| | identity at start | recall per message | capture at end |
|---|---|---|---|
| **Claude Code** | SessionStart hook | UserPromptSubmit hook | Stop hook |
| **Codex** | `AGENTS.md` | `recall` tool | `remember` tool |
| **Gemini CLI** | `GEMINI.md` | `recall` tool | `remember` tool |

Claude Code is the only one of the three with lifecycle hooks, and hooks are
strictly better: they fire on their own, so the self-model loads whether or not
the model thought to ask, and every message is scored against the vault without
anything having to cooperate.

On Codex and Gemini, identity still arrives involuntarily — it goes in the
context file, which is read every session, that being what context files are
for. What changes is that per-message recall becomes a tool the model *elects*
to call, prompted by an instruction in that same file. So on those two, "it
didn't remember" has a different cause: not a broken vault, but a model that
didn't reach for it. Worth knowing before you blame the memory.

The vault underneath is the same one. Tell Claude Code something on Monday and
Codex knows it on Tuesday.

**A caveat worth stating plainly:** neither Codex nor Gemini CLI was installed
on the machine these adapters were written on, so they are built from each
project's documented config format rather than a live round trip. Everything
writes with `--dry-run` available, merges instead of clobbering, backs up first,
and reads the file back to confirm it still parses — but until somebody runs
this against a real install, treat those two rows as *believed correct* rather
than *observed*. Please open an issue if yours behaves differently.

### What it costs

Measured on a real vault, not estimated: roughly **2.5–4¢ per session on
Sonnet**, most of which is the fixed `CLAUDE.md` floor you would pay anyway.
Recall deduplicates per session, so a conversation that stays on one subject
pays for a fact once rather than on every turn — 74% cheaper on the shape where
the clone is most useful. Narration, retrieval, speech, and the usage meters
cost zero tokens.

```bash
mem tokens    # measures against your own vault, not mine
```

Full breakdown: [`docs/TOKENS.md`](docs/TOKENS.md).

**Before you answer 137 questions, make sure extraction can actually run.**
`--apply` turns your answers into facts by shelling out to an extractor command
(default `claude -p`, i.e. the Claude Code CLI, installed and authenticated).
If that command is missing, `--apply` used to complete with exit code 0 having
written zero facts, no error, no hint anything was wrong. It no longer does:
a run that processes real sources and extracts nothing at all now exits
non-zero with the exact fix. Check it first with
`mem check-extractor`, and if you'd rather use something else,
point `MEM_EXTRACTOR_CMD` at any command that takes a prompt as its final
argument and prints JSON with a `"candidates"` key on stdout:

```bash
export MEM_EXTRACTOR_CMD="my-llm-cli --json"
```

See `docs/HOOKS.md#extractor-configuration` for the full contract.

What `--apply` does:

| Step | Result |
|---|---|
| splits your answers by section | one capture per section in `episodic/inbox/`, unconsolidated |
| runs the ordinary consolidation pipeline | every candidate must quote your own words verbatim and clear the REJECT gate |
| writes what survives | entity nodes in `people/`, `projects/`, `goals/`, `concepts/`, each fact provenanced back to the answer that produced it |
| assembles `identity.md` and `now.md` | as **drafts** in `proposals/`, verbatim from your text, never installed |
| converts the decision-calibration section | one eval golden case per scenario, in `eval/cases/` |

Onboarding gets no privileges. It does not have its own extractor, its own gate,
or its own writer: it files captures and calls the same pipeline every later
session goes through, so a fact learned at setup is checked exactly as hard as a
fact learned in month six. And it cannot write `identity.md` or `now.md`, because
nothing scripted can. It drafts them and stops. Installing a draft is a separate
command that backs the old file up first, and the file stays locked against
scripts afterwards. Checks 24 to 29 exist to prove all of that.

Try the whole path with no model configured and no interview answered:

```bash
mem onboard tools/example_answers.md \
  --apply --fixture tools/example_onboard_fixture.json
```

### GUI setup (optional)

Everything above also runs as a small pywebview wizard, if you would rather click
through it than type commands:

```bash
pip install pywebview        # or: pip install 'mem[gui]'
mem setup-gui
```

It is the same four steps as the terminal path, as screens in one window:
prereq check, pick your answered interview file (native file picker) or the
bundled example, run `onboard --apply` with the real output streamed into an
action-feed panel, review the `identity.md`/`now.md` drafts with
Approve/Edit/Reject per file, then run `init-hooks`. It calls the exact same
`onboard.py`/`hooks.py` functions the terminal commands call; it is not a second
implementation of onboarding, and the terminal path above is equally supported
and requires none of this dependency.

## Then wire it in, and forget about it

The interview is how you seed the vault once. Hooks are how it stays alive after
that.

```bash
mem init                  # every agent this machine has
```

From then on, in that project, on Claude Code:

| Event | What the agent gets | Cost |
|---|---|---|
| session starts | `identity.md` + `now.md` + pending proposals, loaded involuntarily | one file read |
| you send a message | a capped, relevance-gated block of whatever the vault knows about it, or nothing | lexical, no model call |
| session ends | the transcript written to `episodic/sessions/`, unconsolidated | one file write |

On Codex and Gemini the same three things happen, by a weaker mechanism — see
[Which agent gets which version](#which-agent-gets-which-version) above.

Then something runs `consolidate` and `maintain` off the live path, and today's
conversation becomes graph facts with your own words as provenance. That loop is
the product: it is how a vault seeded in one sitting keeps up with you for a year
without you ever curating it. `mem voice` runs that pass itself on an interval
you choose; without the window, run `mem consolidate` from cron or by hand.

## The window

```bash
mem voice                 # a real desktop window
mem voice --browser       # serve only, open the URL yourself
mem voice --no-voice      # no microphone; type into the same sessions
mem doctor                # what is wired, what is broken, how to fix it
```

**Push to talk, and only that.** Hold space, the mic button, or the orb. There
is no always-listening mode, deliberately: voice activity detection could not
reliably tell the clone's own reply from yours — text-to-speech output *is*
speech — so it interrupted itself. Holding a key silences the speaker before a
frame is captured, which deletes the problem rather than managing it.

**Speech comes from typed events, not from the screen.** Progress narration is
driven by `tool_use` / `tool_result` / `assistant` entries in the agent's own
transcript. It is structurally incapable of reading your prompt back to you or
narrating a file's contents, because those are different event types and it
never speaks them. `verify.py` fails the build if anything reintroduces
terminal scraping.

**An orb that tells the truth.** One function computes the state from recorded
facts in one ordered pass — `hearing > thinking > speaking > working > blocked >
listening` — and nothing else may assign it. That is a checked invariant, not a
convention: when four threads each set it directly, the last writer won and the
orb lied.

Everything is local. Microphone, voice activity detection, speech recognition
and speech synthesis never leave the machine, and the window authenticates
nothing — it sits on top of the CLI you are already logged into.

Machine-local state (window preferences, chosen voice, model sizes, the
consolidation log) lives in `~/.mem-voice`, deliberately **not** in the vault:
the vault is a git repository you may sync between machines, and a chosen
whisper size should not follow you across them or turn up in a diff.

`mem doctor` is worth running first. It checks the nine things that fail
silently — missing binary, expired extractor, unsound graph, unauthenticated MCP
server, no input device — and every failure comes with the command that fixes
it. A red dot that does not tell you what to do is just anxiety.

## Honest gaps

- **The microphone path is the least tested thing here.** Everything downstream
  of it is verified through typed input; live speech through whisper has no
  automated test, because a test that needs somebody to talk into it does not
  run in CI.
- **Codex and Gemini get memory, not panes.** `mem init` wires the vault into
  all three, but the session grid is a client of Claude Code's session daemon,
  which the other two do not have.
- **The Codex and Gemini adapters have not met a live CLI.** Neither was
  installed on the machine they were written on, so they follow each project's
  documented config format. Every write is merge-not-clobber, backs up first,
  offers `--dry-run`, and re-parses the file afterwards to confirm it still
  loads — but please open an issue if yours behaves differently.
- **Linux is unverified.** The PTY and websocket layers are POSIX and should be
  fine; the system-voice fallback and the Spotlight helpers in the voice prompt
  are macOS-specific.

**Why there are still no embeddings in here, measured rather than argued.**
Mem's retrieval is lexical, and measured alone it drops from 92.6% to 48.1%
when questions are paraphrased away from the vault's vocabulary. The instinct was
that a language model sitting downstream of the injected block would bridge most
of that gap, since bridging paraphrase is a thing models are good at. Measured
directly (`eval/benchmark_agent.py`, a real model reading the real injected
block), that instinct is only partly right: the model does bridge individual
paraphrases when it sees the evidence, but for about half the paraphrased
questions the lexical gate never retrieves anything to bridge, and that failure
sits upstream of any agent. The honest number is under
[Measured performance](#measured-performance). Adding an embedding index is still
not this repo's answer to that gap — it would fix retrieval, which is where the
gap actually lives, but it is a dependency, an index to keep warm, and a second
thing that can go stale, and it hasn't been built or measured here. The gap is
reported plainly instead of closed by claim.

`init-hooks` merges: your existing permissions and hooks survive it, re-running
is a no-op, and the old settings file is backed up first. `--dry-run` shows you
the command it would add.

## The demo vault is a test fixture, not a persona to adopt

```bash
python3 tools/seed_persona.py --reset                          # rebuild examples/vault/
MEM_DIR=examples/vault mem recall "why did the demo slip"
```

`examples/vault/` ships holding a fictional freelance game developer, fifteen synthetic
sessions across seven months, and the graph those sessions produce. It is there
so you can evaluate the architecture in two minutes without answering 137
questions first, and so the verifier has a corpus with real temporal structure to
assert against. It is **not** the intended way to use this. Nobody should ship an
agent that believes it is a fictional game developer. Real setup is the interview
above; the persona is a fixture, and `docs/PERSONA.md` documents what each part
of it was built to test.

## The idea in one paragraph

Most agent memory systems treat remembering as a retrieval problem: embed
everything the user says, search it later. That works until the user changes
their mind. An embedding store asked "what is the ship date" cheerfully returns
April's answer and July's answer with no way to tell which one is true, because
"true" is not a property it stores. Mem treats remembering as a
**bookkeeping** problem instead. Facts are typed, attached to entities, stamped
with the window in which they were true, and linked to the conversation that
produced them. New information does not overwrite old information, it closes it.

## Architecture

```
  live session                      off the live path
 +------------+                   +--------------------+
 |  capture   | -- raw markdown-> |    consolidate     |
 | (stop hook)|                   |  extract           |
 +------------+                   |  GROUND check      |
        ^                         |  REJECT gate       |
        |                         |  write + supersede |
 +------------+                   +---------+----------+
 |   recall   | <-- index.json -------+     |
 | (injection)|                       |     v
 +------------+                   +---------------------+
        |   access.jsonl          |   markdown vault    |
        +-----------------------> |  (source of truth)  |
                   reinforcement  +---------+-----------+
                                            |
                                  +---------v-----------+
                                  |      maintain       |
                                  | links, dedup,       |
                                  | decay, proposals    |
                                  +---------------------+
```

Four processes, and only one of them runs while the user is waiting.

**capture** and **recall** are the entire live-path cost, and `hooks.py` is what
puts them there. Capture takes the transcript your agent harness already has,
strips tool noise, and writes a markdown file: no model call, no extraction, no
latency, and if everything downstream is broken the conversation is still saved.
Recall reads an index and scores strings. Neither calls a model, because the
model is the thing on the other side of them.

**consolidate** is the sleep pass. It runs on a timer or by hand, asks a model to
propose candidate facts from unconsolidated captures, and then refuses most of
them. Survivors are written by deterministic code.

**recall** scores the index and returns either a small block of relevant facts or
nothing at all.

**maintain** is the janitor: repair links, find duplicates, decay unused notes,
strengthen used ones, and draft proposals for the files it is not allowed to
edit.

## The five design decisions

### 1. Facts are bi-temporal, and contradictions close windows

Every fact carries `valid_from`, optionally `valid_to`, and a `provenance` link.
When a contradicting fact arrives, the old one is stamped, tagged `[superseded]`,
and moved to a `## History` section. It is never edited in place and never
deleted.

```markdown
## Current facts
- target:: demo build for the October Next Fest window (valid_from: 2026-07-05, provenance: [[2026-07-05-e3d1c8b7]])

## History
- target:: demo build for the June Next Fest window (valid_to: 2026-07-05, valid_from: 2026-04-08, provenance: [[2026-04-08-9b0d34fe]]) [superseded]
```

That is four questions answered from one entity file: what is true now, what was
true before, when it changed, and which conversation changed it. A store that
keeps only the latest value answers one of the four. A store that keeps both
values without windows answers none of them reliably, because it cannot tell you
which is current.

### 2. Every generator gets a checker

Exactly one component is allowed to be a language model: the extractor that reads
a transcript and proposes candidate facts. It has no write access. Two
independent checkers sit between it and the vault, and both run inside the write
path rather than in the prompt.

**The REJECT gate** drops candidates that are junk: salience below 3, a junk
category, a junk pattern (meals, weather, greetings, "as an AI"), a fact with no
entity, an event with no linked entity. This is what keeps a memory store from
degenerating into a landfill of "the user said hello" after a few hundred
sessions. Precision matters more than recall here, because a false memory is
retrieved with exactly the same confidence as a true one.

**The GROUND check** is stricter and catches the more dangerous failure. Every
candidate must carry a `quote`: a verbatim span from the source. Before anything
is written, that quote is searched for in the actual transcript. If it is not
there, the candidate is discarded, no matter how plausible it sounds.

The demo corpus exercises both. Two of its candidates are planted failures, one
mundane and one fabricated, and the seeder reports them being caught:

```
REJECT 'made coffee before starting': salience 2 < 3
UNGROUNDED (quote not found in source): 'signed a two-game publishing deal'
```

An invented fact carrying a provenance link is worse than no memory at all,
because the provenance makes it look verified.

### 3. A typed graph, not a vector store

Facts hang off typed entities (`person`, `project`, `concept`, `skill`, `goal`,
`artifact`, `organization`) connected by typed wikilinks. Retrieval scores nodes,
then walks one hop out from the top hits.

That hop is the point. Ask "what does the publisher want" and lexical scoring
finds the publisher's node; expansion pulls in the project it links to, where the
answer about the ship date actually lives. Chunk similarity does not do this,
because the chunk that mentions the publisher and the chunk that holds the date
are not similar to each other. They are *connected*, which is a different
relation, and only a graph stores it.

Retrieval itself is IDF-weighted lexical overlap with three components (recency,
importance, relevance) in the Generative Agents shape, plus field weighting so
that matching a note's name beats matching its prose. No embeddings. At the scale
a personal vault reaches, lexical retrieval over a curated vocabulary is accurate,
instant, free, and auditable: you can see exactly why a note ranked, which you
cannot do with a cosine distance. Swapping in embeddings is a contained change to
one function when a vault outgrows this, and not before.

### 4. Silence beats noise

`recall.context_block()` returns an empty string when nothing clears the bar, and
the bar is two independent gates on raw (not normalized) signals: the top hit
needs enough IDF mass, and the query needs to be mostly made of words the vault
knows.

The second gate exists because of a real bug. Min-max normalizing an all-zero
relevance vector produces all ones, so a query that matched nothing looked
maximally relevant and floated junk into the context window. Normalized scores
are relative, and the top hit is always 1.0 no matter how bad it is. Gate on the
raw signal.

An irrelevant memory block does not merely waste tokens. It actively misleads the
model reading it, which has no way to know the memory was a bad match.

### 5. No destructive operation on an ambiguous signal

The maintenance pass can merge duplicate entities, and merging is effectively
irreversible even though the file is archived, because every inbound link has
already been rewritten. So it merges automatically only on an **exact shared name
or alias**, which is the precise fingerprint of extractor fragmentation.

Everything weaker is reported and left alone. A token subset is not evidence of
sameness: `tidewright` is a strict subset of `tidewright-artbook`, and those are
two different things. The same rule gates fact-key collapsing behind an explicit
flag, because `degree` and `degree_correction` look like the same slot and are
not. When the signal is ambiguous, the system reports and a human decides.

The corollary: `identity.md` and `now.md` are human-curated and the write
function raises `PermissionError` on them, by filename and by frontmatter type.
The system is allowed to notice that `now.md` has gone stale and to draft the
update into `proposals/`. It is not allowed to apply it.

## How it compares

This is an architectural comparison, not a benchmark. Mem has **not** been
run on LongMemEval or LoCoMo proper, so nothing in this table is a performance
claim. Its own measured numbers, on its own corpus, are in
[`eval/REPORT-2026-07-26.md`](eval/REPORT-2026-07-26.md).

| | Mem | Mem0 | Zep / Graphiti | Letta (MemGPT) |
|---|---|---|---|---|
| Store | markdown files in git | vector plus optional graph store | temporal knowledge graph in a database | database-backed memory blocks |
| Unit | typed fact on a typed entity | extracted memory string | episode plus extracted entities and edges | text block plus archival passages |
| Contradictions | window closed, old fact kept in History | newer memory updates or replaces | edges invalidated over time | agent rewrites its own blocks |
| Anti-junk | REJECT gate plus GROUND check, both outside the model | extraction prompt | extraction pipeline | agent judgement |
| Retrieval | lexical IDF plus salience plus recency, one graph hop | vector similarity | graph plus semantic search | paging blocks in and out of context |
| Runs | local, no service, no dependencies | service or SDK | service | service |
| Inspect a memory | open the file | query the API | query the API | query the API |

Where the ideas come from: bi-temporal edge invalidation is the property Zep's
Graphiti gets right and is the direct ancestor of the supersession rule here. The
recency plus importance plus relevance score is from the Generative Agents paper.
The self-editing memory idea is MemGPT's.

Where Mem deliberately differs:

- **The checkers live outside the model.** Systems that rely on the extraction
  prompt for quality inherit every bad day the model has. A gate in code does not
  have bad days. Nothing here trusts a model's own claim about the importance or
  the truth of what it just extracted.
- **Files, not a service.** The vault is greppable, diffable, reviewable in a pull
  request, and openable in any markdown editor. When a memory is wrong you fix it
  with a text editor and the fix is a commit with an author and a timestamp. Git
  gives you a second, coarser temporal axis for free.
- **Provenance is mandatory, not decorative.** Verifier check 35 fails the build
  if any assertion in the vault lacks a link to its source.
- **The system knows what it may not touch.** Human-curated files are enforced in
  code, and machine suggestions for them land in a proposals folder.

What Mem does not do, honestly: no embeddings, so a query phrased entirely
in synonyms will miss. That is measured, not hedged: 92.6% strict pass when a
question uses the vault's vocabulary, 48.1% when it is paraphrased away from it. No multi-user or multi-tenant story. No server, no API, no
concurrency control beyond what a filesystem gives you. It is built for one
person's agent, running on one machine, remembering one life.

## Measured performance

```bash
python3 eval/benchmark.py --verbose
```

60 questions over the demo corpus, following the LongMemEval and LoCoMo task
taxonomies, scoring the exact string `context_block()` hands an agent. Full
writeup, including the two defects the benchmark found in the injection gates and
the honest comparison against Mem0's and Zep's published figures, is in
[`eval/REPORT-2026-07-26.md`](eval/REPORT-2026-07-26.md).

| | |
|---|---|
| strict evidence pass, 56 answerable questions | 69.6% |
| lexical phrasing / paraphrased phrasing | 92.6% / 48.1% |
| superseded values leaked as current | 0 of 8 |
| correct silence on unanswerable questions | 75% |
| context size against pasting the whole corpus | 97.0% smaller |

The paraphrase gap is the headline limitation and it has not been tuned around.
Loosening the gates that cause it would trade correct silences for confident
noise.

**Does putting a real agent on top of the block close that gap?** Tested directly,
not assumed: `eval/benchmark_agent.py` injects through the real hook path
(`hooks.prompt_submit`, the exact `UserPromptSubmit` handler) and has a model
answer using only what it received, opt-in because it costs one model call per
question. It does not. Full writeup, including why, is in
[`eval/REPORT-2026-07-28-AGENT.md`](eval/REPORT-2026-07-28-AGENT.md).

| | retrieval alone | agent-in-the-loop |
|---|---|---|
| strict pass, answerable | 69.6% | 60.7% |
| paraphrase phrasing | 48.1% | 37.0% |
| correct abstention | 75.0% | 100% |

For roughly half the paraphrased questions the coverage gate never retrieves any
evidence at all; an agent reading nothing cannot bridge anything, so the dominant
failure is upstream of the agent, not downstream. Where evidence did reach the
model, some of the strict-substring misses were the model answering correctly in
its own words rather than quoting the note, which the fixed-string grader cannot
credit. The fix for the paraphrase gap, if it is worth closing, is still on the
retrieval side (a better scorer behind `score()`), not the agent. Deferred, as
before, and not attempted this run.

## Layout

```
mem/
  config.py        vault location, entity folders
  core.py          gates, frontmatter I/O, entity resolution, bi-temporal writes
  indexer.py       markdown -> index.json projection
  recall.py        scoring, graph expansion, injection block, salience decay
  capture.py       transcript cleaning and session notes
  hooks.py         the live path: three handlers plus the settings installer
  consolidate.py   the sleep pass, extractor prompt, end-to-end pipeline
  maintain.py      links, key drift, duplicates, reinforcement, proposals
  onboard.py       the interview to vault path, drafts, eval cases
  backfill.py      seed from coding sessions you have already had
  agents.py        wiring for Claude Code, Codex and Gemini CLI
  mcp.py           the vault as an MCP server, for agents without hooks
  switch.py        on / learn-only / off
  injected.py      per-session dedup, so a fact is paid for once
  lint.py          check a draft against how you write
  tokens.py        measure the live path against your own vault
  verify.py        37 numbered checks
  voice/           the window. Optional; nothing above imports it
    cli.py         `mem voice` and `mem doctor`
    server.py      local aiohttp: static files, control socket, PTY channel
    pty_pane.py    one PTY per pane -- a real `claude`, not a chat client
    panes.py       the pane roster; supervisor.py the session daemon client
    transcript.py  tails the agent's JSONL into typed events
    narrate.py     typed event -> one spoken line, from templates
    speakable.py   assistant markdown -> speech-safe text
    voice_loop.py  mic -> whisper -> pane -> narration -> speakers
    stt.py, tts.py Silero VAD, faster-whisper, Kokoro
    health.py      the nine things that fail silently
    ui/            the page, and vendored xterm.js
docs/
  INTERVIEW.md     the 137-question setup interview
  SCHEMA.md        the data contract
  HOOKS.md         the hooks, the installer, and wiring other harnesses
  PERSONA.md       the fictional demo persona and what it tests
tools/
  seed_persona.py  the fictional demo corpus
  example_answers.md            a short filled-in interview
  example_onboard_fixture.json  candidates, so onboarding runs with no model
examples/vault/    the demo vault, checked in, evaluated by `verify` and `eval/`
vault/             your real vault (gitignored, empty on a fresh clone; onboarding
                   writes here by default so it never collides with the demo)
eval/              benchmark harness and reports
```

## Commands

```bash
mem backfill       # seed from sessions you have already had; --apply to write
mem onboard a.md   # --apply to write; --fixture; --approve-identity
mem init           # wire claude / codex / gemini; --dry-run to preview
mem voice          # the window; --browser, --no-voice, --port
mem doctor         # what is wired, what is broken, how to fix it

mem memory off     # on / capture-only / off
mem recall "..."   # --context for bodies, --block for injection, --decay
mem consolidate    # extract, gate, write; --dry-run, --fixture, --commit
mem lint draft.md  # check a draft against your `lint::` rules
mem tokens         # what the live path costs against your own vault

mem hook           # the live-path handler the hooks call
mem mcp            # serve the vault over MCP on stdio
mem capture        # stdin JSON from your harness stop hook
mem index          # rebuild index.json
mem maintain       # dry run by default; --apply, --merge-dupes, --merge-keys
mem verify         # exit non-zero on any failed check
```

`MEM_DIR` points the whole system at a different vault (defaults to `vault/`
beside the library, which is empty until you onboard or write to it; the demo
fixture lives at `examples/vault/` and is never the default).
`MEM_EXTRACTOR_CMD` sets the extractor subprocess (anything that takes a
prompt as its last argument and prints JSON).

## Verification

`mem verify` runs 37 checks. Checks 1 to 23 build a throwaway
vault in a temp directory and exercise the machinery directly: supersession,
history preservation, both gates, the identity guard, entity resolution and
fuzzy matching, event immutability, index round-tripping of `valid_to`, ranking,
injection silence, key drift, duplicate merging and its refusal to merge subsets,
link repair, decay, reinforcement, proposals, and the full consolidation
pipeline. Checks 24 to 29 cover onboarding, running against the example answers
and fixture in `tools/`: the parser's refusal to shred an in-answer list into
fake questions, one verbatim capture per section, entities seeded through the
real gates with a planted junk candidate and a planted ungrounded one, drafts
that never touch `identity.md`, approval that backs up the previous file and
leaves it locked, and golden cases that point back at the capture they came from.
Checks 30 to 33 cover the live path, driven through the real hook dispatcher
with the JSON a harness actually sends: SessionStart carrying identity core and
pending proposals, UserPromptSubmit injecting byte-for-byte what `recall` would
and staying silent on short, slash and junk prompts, Stop round-tripping a
transcript into `episodic/`, and `init-hooks` merging into a populated
`settings.json` idempotently without writing a machine-specific path. Checks 34
to 36 assert properties of whichever vault is configured: no dangling links,
every assertion provenanced, identity-core present and guarded. Check 37 covers
the failure that used to be silent: a missing extractor now exits non-zero and
leaves the capture unconsolidated so the run is retryable, rather than reporting
success over an empty vault.

Two more suites cover the window:

```bash
python3 verify.py          # 16 structural checks, no hardware needed
python3 -m pytest tests    # 72 behavioural tests
```

`verify.py` runs on a machine with no microphone, no weights, no vault and no
agent installed — which is what a CI runner is, and what a new user's laptop is
five seconds before they install anything. It is mostly a static resolver: it
walks every module's AST and confirms that every import and every `module.attr`
names something real. The bug that motivated it was a call to a function that
had never been defined anywhere — valid Python, invisible to `py_compile`, fatal
the moment that line ran. The rest pin the invariants that were each once a real
bug: one function decides the orb state, nothing scrapes a terminal, the
settings panel writes the file the TTS engine watches, and nothing personal to
any one author is baked into the package.

The suite is the specification. If a claim in this README is not covered by a
numbered check, treat it as marketing.

## Licence

MIT. See `LICENSE`.
