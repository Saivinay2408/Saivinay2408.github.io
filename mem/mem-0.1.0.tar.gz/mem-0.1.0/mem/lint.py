"""
lint — does this draft sound like you, or like a language model?

    mem lint draft.md
    mem lint --stdin < draft.md

Run it on anything a third party will read before it leaves. Exit 0 clean,
exit 1 with numbered findings.

WHY THIS IS PART OF A MEMORY TOOL
---------------------------------
The vault already knows how you write — it is one of the things onboarding asks
about and consolidation records. But a preference sitting in a note only shapes
output when a model happens to read that note and happens to follow it. Prose is
not a mechanism. This is the mechanism: the same rules, checked mechanically,
on the artifact itself.

WHY THE RULES COME FROM THE VAULT
---------------------------------
The version this grew from hardcoded one person's register — no em dashes, a
specific list of banned phrases. That is a real preference and a completely
wrong default, because the next user may write em dashes on purpose. So:

  * SLOP is shipped as a default, because "delve", "in today's fast-paced" and
    "I hope this email finds you well" are not a style, they are a model's
    fingerprint, and nobody adopts them deliberately.
  * everything else is read out of the vault, and an empty vault means those
    rules simply do not fire.

Vault rules live in a note with `lint::` assertions, so they are edited the same
way every other fact about you is:

    - lint:: no em dashes
    - lint:: never say "utilize"
    - lint:: no emoji
"""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

from .config import vault_path

# Phrases that are a model's fingerprint rather than anyone's voice. Shipped on
# by default; `--no-slop` turns them off for someone who disagrees.
SLOP_PHRASES = [
    "delve", "tapestry", "in today's fast-paced", "in the ever-evolving",
    "it's important to note", "it is important to note", "furthermore,",
    "moreover,", "in conclusion,", "unlock the power", "game-changer",
    "revolutionize", "seamlessly", "leverage the", "dive deep into",
    "i hope this email finds you well", "as an ai", "navigating the",
    "in the realm of", "testament to", "meticulous",
]

EMOJI_RE = re.compile("[\U0001F300-\U0001FAFF✅❌✨⚡\U0001F680]")
DASH_RE = re.compile("[—–]")

# `- lint:: no em dashes` anywhere in the vault.
RULE_RE = re.compile(r"^\s*-?\s*lint::\s*(.+?)\s*$", re.M | re.I)


def vault_rules(vault: Path | None = None) -> list[str]:
    """Every `lint::` assertion in the vault, lowercased.

    Reads the markdown directly rather than the index, so a rule works the
    moment it is written and does not wait for the next `mem index`. A lint
    rule you just added and that does not fire reads as a broken feature.
    """
    root = Path(vault) if vault else vault_path()
    rules: list[str] = []
    if not root.is_dir():
        return rules
    for path in root.rglob("*.md"):
        try:
            rules += RULE_RE.findall(path.read_text(encoding="utf-8"))
        except OSError:
            continue
    return [r.lower().strip() for r in rules]


def _banned_words(rules: list[str]) -> list[str]:
    """Pull quoted terms out of rules like `never say "utilize"`."""
    out = []
    for rule in rules:
        out += [w.lower() for w in re.findall(r"[\"'“”‘’]([^\"'“”‘’]{2,40})[\"'“”‘’]", rule)]
    return out


def lint(text: str, name: str = "<stdin>", rules: list[str] | None = None,
         slop: bool = True) -> list[str]:
    """Findings, one string each. Empty list means clean.

    Fenced code is skipped entirely. A code block is not prose and never was:
    flagging an em dash inside a shell snippet trains people to ignore the tool.
    """
    rules = rules or []
    no_dashes = any("em dash" in r or "em-dash" in r for r in rules)
    no_emoji = any("emoji" in r for r in rules)
    banned = _banned_words(rules)

    findings, in_code = [], False
    for i, line in enumerate(text.splitlines(), 1):
        if line.strip().startswith("```"):
            in_code = not in_code
            continue
        if in_code:
            continue
        low = line.lower()
        if no_dashes and DASH_RE.search(line):
            findings.append(f"{name}:{i}: em/en dash — rewrite as comma, colon "
                            f"or full stop (your rule)")
        if no_emoji and EMOJI_RE.search(line):
            findings.append(f"{name}:{i}: emoji (your rule)")
        for word in banned:
            if word in low:
                findings.append(f"{name}:{i}: {word!r} (your rule)")
        if slop:
            for phrase in SLOP_PHRASES:
                if phrase in low:
                    findings.append(f"{name}:{i}: {phrase!r} reads as model boilerplate")
    return findings


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(
        prog="mem lint",
        description="check a draft against how you actually write")
    parser.add_argument("files", nargs="*", help="files to check")
    parser.add_argument("--stdin", action="store_true", help="read from stdin")
    parser.add_argument("--vault", help="vault location (default: $MEM_DIR)")
    parser.add_argument("--no-slop", action="store_true",
                        help="skip the built-in model-boilerplate list")
    args = parser.parse_args(list(sys.argv[1:] if argv is None else argv))

    if not args.files and not args.stdin:
        parser.error("give a file, or --stdin")

    rules = vault_rules(Path(args.vault) if args.vault else None)
    findings = []
    if args.stdin:
        findings += lint(sys.stdin.read(), "<stdin>", rules, not args.no_slop)
    for name in args.files:
        path = Path(name)
        try:
            body = path.read_text(encoding="utf-8")
        except OSError as e:
            print(f"cannot read {name}: {e}", file=sys.stderr)
            return 2
        findings += lint(body, path.name, rules, not args.no_slop)

    if not findings:
        print(f"clean ({len(rules)} rule(s) from your vault)")
        return 0
    print(f"{len(findings)} finding(s):")
    for n, f in enumerate(findings, 1):
        print(f"  {n}. {f}")
    if not rules:
        print("\nOnly the built-in list ran: your vault has no `lint::` rules "
              "yet.\nAdd them to any note, e.g. `- lint:: no em dashes`.")
    return 1


if __name__ == "__main__":
    sys.exit(main())
