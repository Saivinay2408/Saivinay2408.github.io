"""The checker for the memory system. Every generator gets a checker, including
the memory system itself.

Checks 1-33 run against throwaway vaults built in a temp directory, so the suite
never touches real memory and never depends on what happens to be in it. Checks
34-36 run against the vault currently configured, because some properties (no
dangling links, every fact provenanced) are properties of the *corpus*, not the
code.

Checks 24-29 cover the onboarding path, and they run against the example answers
and fixture that ship in `tools/`, so the setup a new user is told to run is the
one actually under test.

Checks 30-33 cover the live path: the three hooks, driven through the real
dispatcher with the JSON a harness actually sends, plus the installer that wires
them in. That code runs inside somebody's conversation, so it is the code with
the least room to be wrong.

Each check prints PASS or FAIL with a reason. Exit code is non-zero if any check
fails.

    python3 -m mem verify
"""
from __future__ import annotations

import datetime
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

from . import consolidate as cs
from . import core as lm
from . import indexer as ix
from . import maintain as mt
from . import onboard as ob
from . import hooks as hk
from . import recall as rc
from .config import REPO_ROOT

RESULTS: list[tuple[int, bool]] = []


def check(n: int, name: str, ok: bool, detail: str = "") -> None:
    RESULTS.append((n, bool(ok)))
    print(f"[{'PASS' if ok else 'FAIL'}] {n}. {name}" + (f"  : {detail}" if detail else ""))


def make_vault(tmp: Path) -> Path:
    vault = tmp / "vault"
    for sub in ("people", "projects", "concepts", "goals", "episodic/inbox",
                "episodic/sessions", "episodic/2026"):
        (vault / sub).mkdir(parents=True, exist_ok=True)
    return vault


def fact(entity: str, key: str, content: str, **kw) -> dict:
    base = {"kind": "fact", "entity": entity, "entity_type": kw.pop("entity_type", "project"),
            "key": key, "content": content, "salience": kw.pop("salience", 7),
            "category": kw.pop("category", "fact"), "provenance": kw.pop("provenance", "s1")}
    base.update(kw)
    return base


def run() -> int:
    tmp = Path(tempfile.mkdtemp())
    vault = make_vault(tmp)
    today = datetime.date.today().isoformat()

    # ---------------------------------------------------------------- capture
    transcript = tmp / "transcript.jsonl"
    transcript.write_text("\n".join(json.dumps(o) for o in [
        {"type": "user", "message": {"content": "the demo slips to october"}},
        {"type": "assistant", "message": {"content": [{"type": "text", "text": "noted"}]}},
        {"type": "tool_result", "message": {"content": "noise that must not survive"}},
    ]), encoding="utf-8")

    env = {**os.environ, "MEM_DIR": str(vault)}
    subprocess.run([sys.executable, "-m", "mem", "capture"],
                   input=json.dumps({"transcript_path": str(transcript), "cwd": "/tmp/demo-project",
                                     "session_id": "abcd1234"}),
                   capture_output=True, text=True, env=env, cwd=str(REPO_ROOT))
    sessions = list((vault / "episodic" / "sessions").glob("*.md"))
    session_text = sessions[0].read_text(encoding="utf-8") if sessions else ""
    ok = (len(sessions) == 1 and "october" in session_text
          and "noise that must not survive" not in session_text
          and "consolidated: false" in session_text)
    check(1, "capture hook writes a cleaned session note, tool noise stripped", ok,
          sessions[0].name if sessions else "no session written")

    subprocess.run([sys.executable, "-m", "mem", "capture"],
                   input=json.dumps({"summary": "decided to cut co-op"}),
                   capture_output=True, text=True, env=env, cwd=str(REPO_ROOT))
    inbox = vault / "episodic" / "inbox" / f"{today}.md"
    ok = inbox.exists() and "decided to cut co-op" in inbox.read_text(encoding="utf-8")
    check(2, "capture hook falls back to an inbox note when there is no transcript", ok,
          inbox.name if ok else "no inbox file")

    # ------------------------------------------------------------ bi-temporal
    lm.apply_fact(vault, fact("Harbourlight", "status", "status active",
                              valid_from="2026-05-01", provenance="s1"))
    lm.apply_fact(vault, fact("Harbourlight", "status", "status paused",
                              valid_from="2026-07-10", provenance="s2"))
    _, body = lm.read_note(vault / "projects" / "harbourlight.md")
    current = "\n".join(lm.section(body, "## Current facts")[0])
    history = "\n".join(lm.section(body, "## History")[0])
    ok = "status paused" in current and "status active" not in current
    check(3, "contradiction supersedes rather than overwrites", ok,
          "current holds paused only" if ok else f"current=[{current.strip()}]")
    ok = "status active" in history and "valid_to: 2026-07-10" in history and "[superseded]" in history
    check(4, "superseded fact preserved in History with valid_to", ok,
          "history holds the closed window" if ok else f"history=[{history.strip()}]")

    lm.apply_fact(vault, fact("harbourlight", "target", "delivery in week 33", provenance="s3"))
    n_projects = len(list((vault / "projects").glob("*.md")))
    check(5, "alias resolves to the existing node, no duplicate created", n_projects == 1,
          f"{n_projects} project file(s)")

    # -------------------------------------------------------------- the gates
    junk_keep, junk_reason = lm.reject_gate(
        {"kind": "fact", "entity": "coffee", "content": "drank coffee at 8am",
         "salience": 1, "category": "mundane"})
    orphan_keep, _ = lm.reject_gate(
        {"kind": "fact", "content": "something true about nothing", "salience": 8, "category": "fact"})
    signal_keep, _ = lm.reject_gate(
        {"kind": "event", "title": "Cut co-op from the demo", "entities": ["Tidewright"],
         "salience": 8, "category": "decision"})
    ok = junk_keep is False and orphan_keep is False and signal_keep is True
    check(6, "REJECT gate: junk and subject-less facts out, decisions in", ok,
          f"junk rejected ({junk_reason}); decision kept" if ok else "gate misclassified")

    source = "she said the demo slips to october. also we grabbed lunch."
    grounded, dropped = lm.ground_check([
        {"kind": "fact", "entity": "Tidewright", "key": "target", "content": "demo slips to october",
         "salience": 8, "quote": "the demo slips to october"},
        {"kind": "fact", "entity": "Tidewright", "key": "status", "content": "she cancelled the project",
         "salience": 9, "quote": "decided to cancel the project"},
        {"kind": "fact", "entity": "Tidewright", "key": "team", "content": "no quote at all",
         "salience": 7},
    ], source)
    ok = len(grounded) == 1 and grounded[0]["key"] == "target" and len(dropped) == 2
    check(7, "GROUND check: unquoted and fabricated candidates discarded", ok,
          "1 grounded kept, fiction and quoteless dropped" if ok
          else f"kept={[c['key'] for c in grounded]}")

    guarded = False
    try:
        lm.write_note(vault / "identity.md", {"type": "identity-core"}, "overwritten")
    except PermissionError:
        guarded = True
    guarded_by_type = False
    try:
        lm.write_note(vault / "projects" / "sneaky.md", {"type": "identity-core"}, "x")
    except PermissionError:
        guarded_by_type = True
    check(8, "identity-core is unwritable by scripts, by filename and by type",
          guarded and guarded_by_type,
          "write_note refused both" if guarded and guarded_by_type else "identity was writable")

    # ------------------------------------------------------ entity resolution
    lm.apply_fact(vault, fact("Ines Barros", "role", "audio designer", entity_type="person"))
    lm.apply_fact(vault, fact("ines barros", "note", "same person, lowercase", entity_type="person"))
    ok = ((vault / "people" / "ines-barros.md").exists()
          and not (vault / "persons").exists()
          and len(list((vault / "people").glob("*.md"))) == 1)
    check(9, "person entities land in people/ as a singleton (irregular plural)", ok,
          "resolved to people/" if ok else "wrong folder or duplicate")

    lm.get_or_create_entity(vault, "Mo Adeyemi Okafor", "person", ["Mo"], 6)
    hit = lm.resolve_entity(vault, "Mo Okafor", "person")
    miss = lm.resolve_entity(vault, "Radek Novak", "person")
    ok = hit is not None and hit.stem == "mo-adeyemi-okafor" and miss is None
    check(10, "fuzzy resolution links superset names but not unrelated ones", ok,
          "'Mo Okafor' matched, 'Radek Novak' did not" if ok else "fuzzy match wrong")

    # ---------------------------------------------------------------- events
    event = {"kind": "event", "subtype": "decision", "title": "Cut co-op from the demo",
             "entities": ["Harbourlight", "Ines Barros", "Nonexistent Thing"],
             "rationale": "netcode was eating the art budget", "salience": 8,
             "category": "decision", "date": "2026-06-18", "provenance": "s2"}
    first = lm.apply_event(vault, event)
    second = lm.apply_event(vault, event)
    event_path = vault / "episodic" / "2026" / "2026-06-18-cut-co-op-from-the-demo.md"
    efm, _ = lm.read_note(event_path)
    entities = efm.get("entities") or []
    _, ines_body = lm.read_note(vault / "people" / "ines-barros.md")
    ok = ("[[harbourlight]]" in entities and "[[ines-barros]]" in entities
          and "Nonexistent Thing" in entities
          and "[[2026-06-18-cut-co-op-from-the-demo]]" in ines_body
          and "skipped" in second and "->" in first)
    check(11, "events are immutable, resolve links by stem, and backlink entities", ok,
          "re-apply skipped; unresolvable name kept as plain text, not a dead link" if ok
          else f"entities={entities} second={second!r}")

    # ------------------------------------------------------------------ index
    for sid in ("s1", "s2", "s3"):
        (vault / "episodic" / "sessions" / f"{sid}.md").write_text(
            f"---\nid: {sid}\ntype: session\ndate: 2026-05-01\nconsolidated: true\n---\n"
            f"# session {sid}\n", encoding="utf-8")
    index = ix.build(vault)
    dangling = [e for e in index["edges"] if not e.get("resolved")]
    ok = index["counts"]["nodes"] > 0 and not dangling
    check(12, "index rebuilds from markdown with zero dangling internal edges", ok,
          f"{index['counts']['nodes']} nodes, {index['counts']['edges']} edges"
          if ok else f"dangling: {[e['src'] + '->' + e['dst'] for e in dangling][:5]}")

    closed = [f for n in index["nodes"] for f in n["history"] if f.get("valid_to")]
    ok = any(f["valid_to"] == "2026-07-10" and f["provenance"] == "s1" for f in closed)
    check(13, "index round-trips superseded facts with valid_to and provenance intact",
          ok, f"{len(closed)} closed fact(s) indexed" if ok else "valid_to lost in the index")

    captures = [n for n in index["nodes"] if n["type"] == "capture"]
    ok = bool(captures) and all("tokens" not in n and not n["facts"] for n in captures)
    check(14, "raw captures carry no tokens or facts, so they cannot swamp scoring", ok,
          f"{len(captures)} capture node(s) excluded from scoring")

    # -------------------------------------------------------------- retrieval
    lm.apply_fact(vault, fact("Tidewright", "genre", "roguelike deckbuilder", salience=9))
    lm.apply_fact(vault, fact("Pipeworks", "note", "a tool used while building Tidewright",
                              salience=5))
    index = ix.build(vault)
    hits = rc.score(index, "what is tidewright", k=3)
    ok = bool(hits) and hits[0]["stem"] == "tidewright"
    check(15, "retrieval ranks the named entity above notes that merely mention it", ok,
          f"top hit = {hits[0]['stem']}" if ok else f"top = {[h['stem'] for h in hits]}")

    ix.write_index(vault)
    block = rc.context_block(vault, "what is the status of harbourlight")
    quiet = rc.context_block(vault, "zzz qqq xxyy nothing matches this")
    ok = "harbourlight" in block.lower() and quiet == ""
    check(16, "injection returns a block for a real query and silence for a junk one", ok,
          "block injected; junk query silent" if ok else f"block={block[:60]!r} quiet={quiet[:40]!r}")

    # -------------------------------------------------------------- key drift
    lm.apply_fact(vault, fact("Kelp Atlas", "target", "ship in June", valid_from="2026-01-01"))
    lm.apply_fact(vault, fact("Kelp Atlas", "launch_target", "ship in August",
                              valid_from="2026-06-01"))
    report = mt.fix_key_drift(vault, apply=True)                 # no merge: review only
    _, drift_body = lm.read_note(vault / "projects" / "kelp-atlas.md")
    current = " ".join(lm.section(drift_body, "## Current facts")[0])
    safe = (len(report["review"]) >= 1 and not report["merged"]
            and "June" in current and "August" in current)

    mt.fix_key_drift(vault, apply=True, merge=True)               # explicit opt-in
    _, drift_body = lm.read_note(vault / "projects" / "kelp-atlas.md")
    current = " ".join(lm.section(drift_body, "## Current facts")[0])
    history = " ".join(lm.section(drift_body, "## History")[0])
    merged_ok = ("August" in current and "June" not in current
                 and "June" in history and "valid_to" in history)
    check(17, "key drift is review-only by default; opt-in collapses and keeps history",
          safe and merged_ok,
          "default kept both and flagged; opt-in merged, older closed into History"
          if safe and merged_ok else f"safe={safe} merged={merged_ok} current={current!r}")

    # ------------------------------------------------------------- duplicates
    lm.apply_fact(vault, fact("Tidewright", "status", "vertical slice done", salience=9))
    lm.write_note(vault / "projects" / "tidewright-game.md",
                  {"id": "project-tidewright-game", "type": "project", "aliases": ["Tidewright"],
                   "salience": 5, "created": "2026-01-01", "updated": "2026-01-01"},
                  "# Tidewright\n\n## Current facts\n\n"
                  "- engine:: built in Godot (valid_from: 2026-01-01, provenance: [[s1]])\n\n"
                  "## History\n\n## Links\n")
    lm.get_or_create_entity(vault, "Tidewright Artbook", "project", ["Tidewright Artbook"], 6)

    auto, review = mt.find_duplicates(vault)
    for canon, dup in auto:
        mt.merge_entities(vault, canon, dup, apply=True)
    tide = sorted(p.stem for p in (vault / "projects").glob("tidewright*.md"))
    archived = any((vault / "archive" / "merged").glob("tidewright*.md"))
    carried = "engine::" in (vault / "projects" / "tidewright.md").read_text(encoding="utf-8")
    ok = tide == ["tidewright", "tidewright-artbook"] and archived and carried
    check(18, "shared-alias duplicate merges and is archived; token subset never auto-merges",
          ok, "alias dupe folded in, artbook left intact" if ok
          else f"files={tide} archived={archived} carried={carried}")

    # ------------------------------------------------------------ link repair
    (vault / "projects" / "linky.md").write_text(
        "---\nid: project-linky\ntype: project\nsalience: 5\n---\n# Linky\n\n## Current facts\n\n"
        "- ref:: sees [[project-kelp-atlas]] and [[SCHEMA]] (valid_from: 2026-07-01, "
        "provenance: [[s1]])\n\n## History\n\n## Links\n", encoding="utf-8")
    mt.repair_links(vault, apply=True)
    text = (vault / "projects" / "linky.md").read_text(encoding="utf-8")
    ok = "[[kelp-atlas]]" in text and "[[SCHEMA]]" in text
    check(19, "link repair rewrites id-style links and leaves external refs alone", ok,
          "[[project-kelp-atlas]] -> [[kelp-atlas]], [[SCHEMA]] untouched" if ok else text[:120])

    # ------------------------------------------------- decay and reinforcement
    stale_path = lm.get_or_create_entity(vault, "Abandoned Idea", "concept", ["Abandoned Idea"], 1)
    sfm, sbody = lm.read_note(stale_path)
    sfm["updated"], sfm["salience"] = "2020-01-01", 1
    lm.write_note(stale_path, sfm, sbody)
    n_events_before = len(list((vault / "episodic").rglob("*.md")))
    moved = rc.decay_pass(vault, ix.build(vault), apply=True)
    ok = ((vault / "archive" / "cold" / "abandoned-idea.md").exists()
          and not stale_path.exists()
          and len(list((vault / "episodic").rglob("*.md"))) == n_events_before
          and len(moved) >= 1)
    check(20, "salience decay archives cold notes instead of deleting; episodic exempt", ok,
          "moved to archive/cold/, episodic untouched" if ok else f"moved={moved}")

    # pipeworks sits below the cap, and tidewright sits at it: one must rise by
    # exactly one, the other must not move at all.
    with (vault / "access.jsonl").open("w", encoding="utf-8") as f:
        for _ in range(3):
            f.write(json.dumps({"hits": ["pipeworks", "tidewright"]}) + "\n")
    before = int(lm.read_note(vault / "projects" / "pipeworks.md")[0]["salience"])
    capped_before = int(lm.read_note(vault / "projects" / "tidewright.md")[0]["salience"])
    mt.reinforce(vault, apply=True)
    after = int(lm.read_note(vault / "projects" / "pipeworks.md")[0]["salience"])
    capped_after = int(lm.read_note(vault / "projects" / "tidewright.md")[0]["salience"])
    ok = (before < mt.SALIENCE_CAP and after == before + 1
          and capped_before == mt.SALIENCE_CAP and capped_after == mt.SALIENCE_CAP
          and not (vault / "access.jsonl").exists())
    check(21, "used memories strengthen, the cap holds, and the access log is consumed", ok,
          f"salience {before} -> {after}, capped note stayed {capped_after}, log cleared"
          if ok else f"{before} -> {after}, capped {capped_before} -> {capped_after}")

    # ------------------------------------------------------------- proposals
    (vault / "now.md").write_text(
        "---\nid: now\ntype: identity-core\nupdated: 2026-01-01\n---\n"
        "# Now\n\n- **Tidewright** is the active project\n", encoding="utf-8")
    now_before = (vault / "now.md").read_text(encoding="utf-8")
    stale_lines = mt.propose_now(vault, apply=True)
    proposals = list((vault / "proposals").glob("now-*.md"))
    ok = (any("tidewright" in line.lower() for line in stale_lines) and proposals
          and (vault / "now.md").read_text(encoding="utf-8") == now_before)
    check(22, "now.md drift becomes a proposal file and now.md is left untouched", ok,
          f"{len(stale_lines)} stale line(s), proposal written" if ok
          else f"stale={stale_lines[:2]} files={proposals}")

    # -------------------------------------------- consolidation, end to end
    fixture = tmp / "fixture.json"
    fixture.write_text(json.dumps({
        "source": "radek said the publisher call moved to august 3. we also talked about the weather.",
        "candidates": [
            {"kind": "fact", "entity": "Harbourlight", "entity_type": "project", "key": "status",
             "content": "publisher call moved to august 3", "salience": 8, "category": "state",
             "valid_from": "2026-07-20", "provenance": "s3",
             "quote": "the publisher call moved to august 3"},
            {"kind": "fact", "entity": "Harbourlight", "entity_type": "project", "key": "mood",
             "content": "talked about the weather", "salience": 2, "category": "smalltalk",
             "provenance": "s3", "quote": "we also talked about the weather"},
            {"kind": "fact", "entity": "Harbourlight", "entity_type": "project", "key": "deal",
             "content": "the deal was signed", "salience": 9, "category": "fact",
             "provenance": "s3", "quote": "the deal was signed yesterday"},
        ],
    }), encoding="utf-8")
    report = cs.run(vault, fixture=fixture)
    _, hb_body = lm.read_note(vault / "projects" / "harbourlight.md")
    hb_current = " ".join(lm.section(hb_body, "## Current facts")[0])
    hb_history = " ".join(lm.section(hb_body, "## History")[0])
    ok = (len(report["kept"]) == 1 and len(report["rejected"]) == 1
          and len(report["ungrounded"]) == 1
          and "august 3" in hb_current and "status paused" in hb_history
          and "the deal was signed" not in hb_body)
    check(23, "consolidation end to end: ground, gate, supersede, write", ok,
          "1 written, 1 rejected as junk, 1 dropped as ungrounded" if ok
          else f"kept={report['kept']} rejected={len(report['rejected'])} "
               f"ungrounded={len(report['ungrounded'])}")

    # ------------------------------------------------------------- onboarding
    # The shipped example files are the input here on purpose: the setup path a
    # new user is told to run is the one under test, not a synthetic stand-in.
    example_answers = REPO_ROOT / "tools" / "example_answers.md"
    example_fixture = REPO_ROOT / "tools" / "example_onboard_fixture.json"

    parsed = ob.parse_answers(
        "preamble text that belongs to no section\n\n"
        "## 1. Origins and context (feeds: people/, identity)\n\n"
        "1. Where are you from?\n\nnorth coast, fishing town.\n\n"
        "2. Who raised you?\n\nmy mother. my three rules from her were\n"
        "1. show up\n2. do not explain\n3. finish it\n\n"
        "## 12. Decision calibration (feeds: eval/)\n\n"
        "101. Kill or continue at hour 22?\n\nkill it.\n\n"
        "102. Do their work for them?\n\nn/a\n"
    )
    origins = parsed[0] if parsed else {"questions": [], "feeds": []}
    calibration = parsed[1] if len(parsed) > 1 else {"questions": [], "feeds": []}
    ok = (len(parsed) == 2 and len(origins["questions"]) == 2
          and "1. show up" in origins["questions"][1]["answer"]
          and origins["feeds"] == ["people", "identity"]
          and ob.feeds(calibration, "eval")
          and [q["answered"] for q in calibration["questions"]] == [True, False])
    check(24, "interview parser: sections, feeds, in-answer lists, skipped answers", ok,
          "nested list stayed inside the answer, 'n/a' counted as skipped" if ok
          else f"sections={len(parsed)} qs={[len(s['questions']) for s in parsed]}")

    ob_vault = make_vault(tmp / "onboarding")
    result = ob.run(ob_vault, example_answers, apply=True, fixture=example_fixture)
    captures = sorted((ob_vault / "episodic" / "inbox").glob("interview-*.md"))
    cap_fm, cap_body = lm.read_note(captures[1]) if len(captures) > 1 else ({}, "")
    all_bodies = "\n".join(p.read_text(encoding="utf-8") for p in captures)
    ok = (len(captures) == result["stats"]["sections"]
          and cap_fm.get("type") == "capture" and cap_fm.get("subtype") == "interview"
          and "Ines Barros does audio. she joined Tidewright in may" in all_bodies
          and cap_fm.get("source") == example_answers.name)
    check(25, "onboarding files one capture per answered section, answers verbatim", ok,
          f"{len(captures)} captures, quotable text preserved" if ok
          else f"{len(captures)} captures, fm={cap_fm}")

    report = result["report"]
    _, ines_body = lm.read_note(ob_vault / "people" / "ines-barros.md")
    seeded = result["seeded"]
    ok = (len(report["kept"]) == 4 and len(report["rejected"]) == 1
          and len(report["ungrounded"]) == 1
          and "provenance: [[interview-02-your-people]]" in ines_body
          and set(seeded) == {"people", "projects", "concepts", "goals"}
          and not (ob_vault / "projects" / "tidewright.md").read_text(
              encoding="utf-8").count("signed with a publisher"))
    check(26, "onboarding seeds entities through the real gates, not around them", ok,
          "4 written with provenance, 1 junk rejected, 1 ungrounded dropped" if ok
          else f"kept={len(report['kept'])} rejected={len(report['rejected'])} "
               f"ungrounded={len(report['ungrounded'])} seeded={sorted(seeded)}")

    drafted = (result["identity_draft"].exists() and result["now_draft"].exists()
               and result["identity_draft"].parent.name == "proposals")
    untouched = not (ob_vault / "identity.md").exists() and not (ob_vault / "now.md").exists()
    dfm, dbody = lm.read_note(result["identity_draft"])
    quotes_user = "north coast" in dbody and dfm.get("type") == "proposal"
    check(27, "onboarding drafts identity into proposals and never writes identity.md",
          drafted and untouched and quotes_user,
          "drafts written, identity-core absent until approved" if drafted and untouched
          else f"drafted={drafted} untouched={untouched} quotes_user={quotes_user}")

    (ob_vault / "identity.md").write_text(
        "---\nid: identity\ntype: identity-core\n---\n# Identity\n\nthe old one\n",
        encoding="utf-8")
    ob.approve_identity(ob_vault)
    installed = (ob_vault / "identity.md").read_text(encoding="utf-8")
    backups = list((ob_vault / "archive" / "identity").glob("identity-*.md"))
    still_guarded = False
    try:
        lm.write_note(ob_vault / "identity.md", {"type": "identity-core"}, "x")
    except PermissionError:
        still_guarded = True
    ok = ("type: identity-core" in installed and "north coast" in installed
          and "the old one" not in installed
          and len(backups) == 1 and "the old one" in backups[0].read_text(encoding="utf-8")
          and still_guarded)
    check(28, "approving a draft installs it, backs up the old one, and re-locks the file",
          ok, "previous identity archived, scripted writes still refused" if ok
          else f"backups={len(backups)} guarded={still_guarded}")

    cases = sorted((ob_vault / "eval" / "cases").glob("*.json"))
    case = json.loads(cases[0].read_text(encoding="utf-8")) if cases else {}
    ok = (len(cases) == 3 and case.get("kind") == "decision-calibration"
          and case.get("provenance") == "interview-12-decision-calibration"
          and case["reference_behavior"].strip()
          and (ob_vault / "episodic" / "inbox"
               / f"{case['provenance']}.md").exists())
    check(29, "decision-calibration answers become golden cases with live provenance", ok,
          f"{len(cases)} cases, each pointing at the capture it came from" if ok
          else f"{len(cases)} cases, first={case.get('id')}")

    # ------------------------------------------------------------ the live path
    # These four cover the hooks, which are the only Mem code that runs
    # inside somebody's actual conversation. They go through the real dispatcher
    # with the real JSON a harness sends, not the handler functions directly,
    # because the thing that breaks in practice is the wiring.
    (vault / "identity.md").write_text(
        "---\nid: identity\ntype: identity-core\n---\n# Identity\n\n"
        "a fictional solo developer who ships small and often\n", encoding="utf-8")
    (vault / "proposals").mkdir(exist_ok=True)
    ix.write_index(vault)

    start = hk.session_start(vault)
    ok = ("ships small and often" in start and "Tidewright" in start
          and "identity.md" in start and "now.md" in start
          and any("proposals/" in line for line in start.splitlines()))
    check(30, "SessionStart loads identity core and surfaces pending proposals", ok,
          "identity.md, now.md and the proposal list all in the block" if ok
          else f"start={start[:120]!r}")

    query = "what is the status of harbourlight"
    hook_out = subprocess.run(
        [sys.executable, "-m", "mem", "hook"],
        input=json.dumps({"hook_event_name": "UserPromptSubmit", "prompt": query}),
        capture_output=True, text=True, env=env, cwd=str(REPO_ROOT)).stdout.strip()
    direct = rc.context_block(vault, query).strip()
    quiet = [subprocess.run(
        [sys.executable, "-m", "mem", "hook"],
        input=json.dumps({"hook_event_name": "UserPromptSubmit", "prompt": p}),
        capture_output=True, text=True, env=env, cwd=str(REPO_ROOT)).stdout.strip()
        for p in ("okay", "/verify the vault please", "zzz qqq xxyy nothing matches this")]
    ok = bool(hook_out) and hook_out == direct and not any(quiet)
    check(31, "UserPromptSubmit injects exactly what recall would, and stays silent "
              "on short, slash and junk prompts", ok,
          f"{len(hook_out)} chars injected, 3 non-queries silent" if ok
          else f"hook=={direct[:60]!r} vs {hook_out[:60]!r} quiet={[q[:20] for q in quiet]}")

    stop_transcript = tmp / "stop.jsonl"
    stop_transcript.write_text(json.dumps(
        {"type": "user", "message": {"content": "longshore wants a build by september"}}),
        encoding="utf-8")
    subprocess.run([sys.executable, "-m", "mem", "hook"],
                   input=json.dumps({"hook_event_name": "Stop", "cwd": "/tmp/demo-project",
                                     "session_id": "beef4321",
                                     "transcript_path": str(stop_transcript)}),
                   capture_output=True, text=True, env=env, cwd=str(REPO_ROOT))
    captured = [p for p in (vault / "episodic" / "sessions").glob("*beef4321*.md")]
    text = captured[0].read_text(encoding="utf-8") if captured else ""
    ok = (len(captured) == 1 and "build by september" in text
          and "consolidated: false" in text)
    check(32, "Stop hook round-trips a session into episodic/, unconsolidated", ok,
          captured[0].name if ok else "nothing captured")

    proj = tmp / "someones-project"
    (proj / ".claude").mkdir(parents=True)
    (proj / "vault").mkdir()
    prior = {"permissions": {"allow": ["Read", "Bash(git status:*)"]},
             "hooks": {"Stop": [{"hooks": [{"type": "command", "command": "make fmt"}]}]}}
    (proj / ".claude" / "settings.json").write_text(json.dumps(prior, indent=2),
                                                    encoding="utf-8")
    hk.init_hooks(proj, REPO_ROOT, proj / "vault")
    first = json.loads((proj / ".claude" / "settings.json").read_text(encoding="utf-8"))
    hk.init_hooks(proj, REPO_ROOT, proj / "vault")                    # idempotence
    second = json.loads((proj / ".claude" / "settings.json").read_text(encoding="utf-8"))
    commands = [h["command"] for matchers in second["hooks"].values()
                for m in matchers for h in m["hooks"]]
    mine = [c for c in commands if hk.HOOK_MARKER in c]
    ok = (first == second
          and second["permissions"] == prior["permissions"]
          and "make fmt" in commands
          and len(mine) == 3
          and all('"$CLAUDE_PROJECT_DIR"' in c and str(tmp) not in c for c in mine)
          and list(second["hooks"]) >= ["Stop"])
    check(33, "init-hooks merges into an existing settings.json, is idempotent, and "
              "writes no machine-specific path", ok,
          "existing permissions and Stop hook survived, 3 mem hooks, all relative"
          if ok else f"idempotent={first == second} mine={mine}")

    # ----------------------------------------- properties of the live corpus
    # `examples/vault/`, not `vault_path()`: the default vault is deliberately
    # empty on a fresh clone (a real user's onboarding writes there), so what
    # "ships" and what these checks assert against is the example fixture.
    live = REPO_ROOT / "examples" / "vault"
    live_index = ix.build(live) if live.exists() else {"nodes": [], "edges": [], "counts": {}}
    dangling = [e for e in live_index["edges"] if not e.get("resolved")]
    ok = live.exists() and not dangling
    check(34, "configured vault has no dangling links",
          ok, f"{live_index['counts'].get('nodes', 0)} nodes, 0 dangling"
          if ok else f"dangling: {[e['src'] + '->' + e['dst'] for e in dangling][:5]}")

    unsourced = [f"{n['stem']}.{f['key']}"
                 for n in live_index["nodes"] if n["type"] not in ("capture", "identity-core")
                 for f in n["facts"] + n["history"] if not f.get("provenance")]
    n_assertions = sum(len(n["facts"]) + len(n["history"])
                       for n in live_index["nodes"] if n["type"] != "capture")
    ok = n_assertions > 0 and not unsourced
    check(35, "every assertion in the configured vault carries provenance", ok,
          f"{n_assertions} assertions, 0 unsourced" if ok else f"unsourced={unsourced[:5]}")

    identity_ok = (live / "identity.md").exists() and (live / "now.md").exists()
    guard_ok = False
    if identity_ok:
        try:
            fm, body = lm.read_note(live / "identity.md")
            lm.write_note(live / "identity.md", fm, body)
        except PermissionError:
            guard_ok = True
    check(36, "configured vault has identity-core present and guarded",
          identity_ok and guard_ok,
          "identity.md and now.md present, writes refused" if identity_ok and guard_ok
          else f"present={identity_ok} guarded={guard_ok}")

    # --------------------------------------------------- missing extractor is loud
    # The bug this closes: a brand-new user without the default extractor
    # (`claude -p`) installed used to get exit code 0 and an empty vault, with
    # the only trace a stderr line nobody sees during onboarding. It must now
    # (a) report failure in the returned report, not just stderr, (b) leave the
    # source unconsolidated so a fixed extractor retries it, and (c) make both
    # `consolidate` and `check-extractor` exit non-zero over the CLI.
    fail_vault = make_vault(tmp / "extractor-fail")
    pending = fail_vault / "episodic" / "inbox" / "s1.md"
    pending.write_text(
        "---\nid: s1\ntype: capture\nconsolidated: false\n---\n"
        "# note\n\nthe demo slips to october\n", encoding="utf-8")
    bogus_cmd = "definitely-not-a-real-mem-extractor"

    old_extractor_env = os.environ.get("MEM_EXTRACTOR_CMD")
    os.environ["MEM_EXTRACTOR_CMD"] = bogus_cmd
    try:
        fail_report = cs.run(fail_vault)
        probe_ok, probe_msg = cs.check_extractor()
    finally:
        if old_extractor_env is None:
            os.environ.pop("MEM_EXTRACTOR_CMD", None)
        else:
            os.environ["MEM_EXTRACTOR_CMD"] = old_extractor_env

    still_fm, _ = lm.read_note(pending)
    still_pending = still_fm.get("consolidated") is not True
    extractor_env = {**os.environ, "MEM_EXTRACTOR_CMD": bogus_cmd}
    cli_consolidate = subprocess.run(
        [sys.executable, "-m", "mem", "consolidate"],
        env={**extractor_env, "MEM_DIR": str(fail_vault)},
        capture_output=True, text=True, cwd=str(REPO_ROOT))
    cli_check = subprocess.run(
        [sys.executable, "-m", "mem", "check-extractor"],
        env=extractor_env, capture_output=True, text=True, cwd=str(REPO_ROOT))

    ok = (fail_report.get("extractor_failed") is True
          and "not found on PATH" in fail_report.get("extractor_message", "")
          and still_pending
          and probe_ok is False and "not found on PATH" in probe_msg
          and cli_consolidate.returncode != 0 and "FAIL" in cli_consolidate.stderr
          and cli_check.returncode != 0 and cli_check.stdout.startswith("FAIL:"))
    check(37, "missing extractor fails loud and leaves the source retryable, "
              "not a silent empty vault", ok,
          "report + check-extractor + `consolidate` CLI all report failure, "
          "capture stayed unconsolidated" if ok
          else f"report={fail_report.get('extractor_failed')} "
               f"still_pending={still_pending} "
               f"probe_ok={probe_ok} cli_rc={cli_consolidate.returncode} "
               f"check_rc={cli_check.returncode}")

    print()
    passed = sum(1 for _, ok in RESULTS if ok)
    print(f"RESULT: {passed}/{len(RESULTS)} checks passed")
    return 0 if passed == len(RESULTS) else 1


def main(argv=None) -> int:
    """`mem verify`.

    The suite drives the real onboarding path against the example answers and
    the demo corpus, which live in `tools/` and `examples/` — beside the
    package in a checkout, and nowhere at all in an installed wheel. Rather
    than crash three hundred lines in with a FileNotFoundError that reads like
    a bug in the library, say plainly that this command needs the repository.

    `mem doctor` is the one to run against an installation.
    """
    missing = [p for p in (REPO_ROOT / "tools" / "example_answers.md",
                           REPO_ROOT / "examples" / "vault")
               if not p.exists()]
    if missing:
        print("`mem verify` runs against the example corpus in the repository, "
              "which is not part of the installed package.\n\n"
              "  git clone https://github.com/Saivinay24/mem && cd mem\n"
              "  python3 -m mem verify\n\n"
              "To check an installation instead:\n\n"
              "  mem doctor\n", file=sys.stderr)
        return 2
    return run()


if __name__ == "__main__":
    sys.exit(run())
