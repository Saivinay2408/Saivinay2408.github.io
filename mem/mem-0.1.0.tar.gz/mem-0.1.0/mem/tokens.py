"""What the live path costs, measured against your own vault.

`docs/TOKENS.md` publishes figures from one machine. Those are honest but they
are not yours: cost scales with how much you have told the vault and how much
of it any given question touches. This runs the same measurement locally so the
numbers you plan against are your own.

It measures the two things that actually get billed, which are not the same
number:

  WRITTEN   tokens of memory text injected across the session
  CARRIED   tokens actually read, counting the re-read of every earlier block
            on every later turn. An injected block is appended to the
            conversation and stays there, so a block written on turn 3 is paid
            for again on turns 4..N. This is the figure people are surprised by.

Nothing here calls a model, so measuring costs nothing.
"""
from __future__ import annotations

import argparse
import sys
import uuid
from pathlib import Path

from .config import vault_path

# Measured on the shape of an injected block (fact lines, short values, note
# titles) rather than on English prose, which runs closer to 4.0.
CHARS_PER_TOKEN = 3.7

# Cache write is 1.25x input at the 5-minute TTL; a re-read is 0.1x.
WRITE_MULT, READ_MULT = 1.25, 0.10
PRICES = {"Sonnet 5": 3.00, "Opus 5": 5.00}      # USD per Mtok input

# A person does not ask about five unrelated things. They stay on one job and
# circle it, which is exactly the shape deduplication helps — so a default
# probe that jumped subjects every turn would flatter the stateless path.
DEFAULT_PROBES = [
    "what did we decide about the launch plan",
    "who is helping with this project besides me",
    "what was the deadline we set for it",
    "does it depend on anything else shipping first",
    "remind me what the win condition actually was",
    "write the announcement for it in my voice",
]


def _toks(text: str) -> int:
    return round(len(text) / CHARS_PER_TOKEN)


def _run(vault: Path, prompts: list[str], dedup: bool) -> tuple[list[int], int, int]:
    from .recall import context_block

    session = uuid.uuid4().hex if dedup else ""
    per_turn = [_toks(context_block(vault, p, session_id=session) or "")
                for p in prompts]
    written = sum(per_turn)
    n = len(per_turn)
    carried = sum(t * (n - i) for i, t in enumerate(per_turn))
    return per_turn, written, carried


def _fixed(vault: Path) -> int:
    """The once-per-session floor: identity core, plus any CLAUDE.md beside it."""
    from .hooks import session_start

    total = _toks(session_start(vault))
    for name in ("CLAUDE.md", "AGENTS.md"):
        candidate = vault.parent / name
        if candidate.is_file():
            try:
                total += _toks(candidate.read_text(encoding="utf-8"))
            except OSError:
                pass
    return total


def _cost(price: float, fixed: int, written: int, carried: int) -> float:
    return ((written + fixed) * WRITE_MULT + carried * READ_MULT) * price / 1_000_000


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(
        prog="mem tokens",
        description="measure what the live path costs against your own vault")
    parser.add_argument("prompts", nargs="*",
                        help="messages to simulate (default: a realistic "
                             "single-subject session)")
    parser.add_argument("--vault")
    args = parser.parse_args(list(sys.argv[1:] if argv is None else argv))

    vault = vault_path(args.vault)
    prompts = args.prompts or DEFAULT_PROBES

    from . import injected
    stateless, w_a, c_a = _run(vault, prompts, dedup=False)
    deduped, w_b, c_b = _run(vault, prompts, dedup=True)
    fixed = _fixed(vault)

    print(f"vault: {vault}")
    print(f"{len(prompts)} messages · {CHARS_PER_TOKEN} chars/token\n")

    print("per-turn recall (tokens)")
    print(f"  stateless  {stateless}")
    print(f"  deduped    {deduped}")

    saved = (1 - w_b / w_a) * 100 if w_a else 0.0
    saved_c = (1 - c_b / c_a) * 100 if c_a else 0.0
    print(f"\n{'':<12}{'stateless':>10}{'deduped':>10}{'saved':>8}")
    print(f"{'written':<12}{w_a:>10,}{w_b:>10,}{saved:>7.0f}%")
    print(f"{'carried':<12}{c_a:>10,}{c_b:>10,}{saved_c:>7.0f}%")
    print(f"\nfixed floor (identity core + CLAUDE.md): {fixed:,} tokens/session")

    print(f"\n{'model':<12}{'stateless':>11}{'deduped':>11}")
    for name, price in PRICES.items():
        a = _cost(price, fixed, w_a, c_a)
        b = _cost(price, fixed, w_b, c_b)
        print(f"{name:<12}{'$%.4f' % a:>11}{'$%.4f' % b:>11}")

    if not w_a:
        print("\nNothing cleared the relevance bar. Either the vault is still "
              "thin, or these probes are not about anything it knows —\n"
              "pass your own messages as arguments to measure a real session.")

    injected.prune(0)          # this run's simulated sessions are not real
    return 0
