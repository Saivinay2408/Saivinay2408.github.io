"""The live path: Mem as a memory backend for a coding agent.

This is the piece that makes the rest of the library worth having. Everything
else runs off the clock, on a timer or by hand. These three handlers run inside
somebody's actual conversation, so they are cheap, they are lexical, and they
never call a model.

One entry point, three events, dispatched on ``hook_event_name`` in the JSON the
harness writes to stdin:

  SessionStart      identity.md + now.md + pending proposals, printed into the
                    agent's context. The self-model is loaded involuntarily,
                    not by an instruction the agent may or may not follow.
  UserPromptSubmit  score the message against the vault and print a capped,
                    relevance-gated block. Silence when nothing clears the bar.
  Stop              hand the transcript to ``capture``. No extraction here: the
                    session is written down, and consolidation reads it later.

**Why there are no embeddings behind any of this.** The retrieval score is
lexical and the Phase 2B benchmark measured what that costs: 92.6% on questions
phrased in the vault's own vocabulary against 48.1% on the same questions
paraphrased away from it. That number is the score of the scorer *alone*, with
nothing downstream of it. It is not the score of the system as used, because the
system is never used that way. What sits downstream of this block is a language
model, in the loop, reading the retrieved candidates and reasoning over them.
Measured directly (`eval/benchmark_agent.py`, Phase 3B): the model does bridge
individual paraphrases it can see, but for roughly half of the paraphrased
questions the coverage gate never retrieves anything to bridge, so agent-in-the-
loop paraphrase accuracy (37.0%) did not surpass retrieval alone (48.1%) — the
gap is upstream of the agent. See `eval/REPORT-2026-07-28-AGENT.md`. Buying an
embedding index to do a job the agent already does, and is already paid for, adds
a dependency, an index to keep warm, and a second thing that can be stale.

The division of labour, stated once: the library grounds, gates, stores,
retrieves and injects. The agent does semantics.

Hook stdout on exit 0 is added to the model's context, so this module must never
crash the harness. Every handler degrades to printing nothing.
"""
from __future__ import annotations

import argparse
import copy
import json
import sys
from pathlib import Path

from .config import ENV_VAR, REPO_ROOT, vault_path

# Prompts shorter than this are almost never worth a retrieval pass. "okay",
# "yes do that", "nono" carry no query terms, and a block injected against them
# is noise attached to a message that did not ask for anything.
MIN_PROMPT_WORDS = 4
PENDING_CAPTURE_NOTICE = 5

IDENTITY_CORE = ("identity.md", "now.md")


def _body(path: Path) -> str:
    """Note text with the frontmatter stripped, or empty if unreadable."""
    try:
        text = path.read_text(encoding="utf-8")
    except OSError:
        return ""
    return text.split("---", 2)[-1].strip() if text.startswith("---") else text.strip()


def session_start(vault: Path | None = None) -> str:
    """Identity core, pending proposals, and the state of the inbox.

    Returned as a string rather than printed so the verifier can assert on it
    without capturing stdout.
    """
    vault = Path(vault) if vault else vault_path()
    parts = []
    for name in IDENTITY_CORE:
        body = _body(vault / name)
        if body:
            parts.append(f"<!-- {name} (identity core, always loaded) -->\n{body}")

    proposals = sorted((vault / "proposals").glob("*.md"))
    if proposals:
        parts.append(
            "PENDING PROPOSALS (a consolidation pass thinks the identity core has "
            "drifted; read them, apply by hand, then delete the file):\n"
            + "\n".join(f"- proposals/{p.name}" for p in proposals)
        )

    pending = []
    for folder in ("sessions", "inbox"):
        for path in (vault / "episodic" / folder).glob("*.md"):
            try:
                head = path.read_text(encoding="utf-8")[:400]
            except OSError:
                continue
            if "consolidated: false" in head:
                pending.append(path)
    if len(pending) > PENDING_CAPTURE_NOTICE:
        parts.append(f"(memory note: {len(pending)} captures await consolidation; "
                     "the scheduled pass will pick them up)")

    return "\n\n".join(parts)


def prompt_submit(prompt: str, vault: Path | None = None,
                  session_id: str = "") -> str:
    """Relevance-gated recall block for one user message, or an empty string.

    ``session_id`` is passed straight through to retrieval, which uses it to
    avoid re-sending facts this conversation already has. It is the difference
    between paying for a memory block once and paying for it on every turn.
    """
    text = (prompt or "").strip()
    if not text or text.startswith("/") or len(text.split()) < MIN_PROMPT_WORDS:
        return ""
    from .recall import context_block
    try:
        return context_block(vault or vault_path(), text,
                             session_id=session_id) or ""
    except Exception:                                    # noqa: BLE001
        # Retrieval failing is a bad turn. Retrieval taking the harness down with
        # it is a bad afternoon.
        return ""


def stop(data: dict, vault: Path | None = None) -> Path | None:
    """Write the finished session down. No model, no extraction, no judgement."""
    from . import capture

    vault = Path(vault) if vault else vault_path()
    transcript = data.get("transcript_path")
    if transcript and Path(transcript).exists():
        return capture.write_session(
            vault, transcript,
            project=Path(data.get("cwd") or "").name,
            session_id=str(data.get("session_id") or ""),
        )
    summary = data.get("summary")
    if summary:
        return capture.write_manual_summary(vault, summary)
    return None


def dispatch(data: dict, vault: Path | None = None) -> str:
    """Route one hook event, subject to the memory switch.

    The switch is checked HERE, at the single point every event passes through,
    rather than inside each handler. That is what makes "off" mean off: there
    is one place to read, and no event can grow a path around it.

    Off is not a quieter on. Nothing is read into the session and nothing is
    written down, so the agent behaves exactly as it would if Mem were not
    installed — which is the entire point of having the switch.
    """
    from . import switch

    event = data.get("hook_event_name", "")
    if event == "SessionStart":
        return session_start(vault) if switch.injects() else ""
    if event == "UserPromptSubmit":
        if not switch.injects():
            return ""
        return prompt_submit(data.get("prompt", ""), vault,
                             session_id=str(data.get("session_id") or ""))
    if event == "Stop":
        if switch.captures():
            stop(data, vault)
        return ""
    return ""


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(prog="mem hook")
    parser.add_argument("--event", help="override hook_event_name (for testing)")
    args = parser.parse_args(list(sys.argv[1:] if argv is None else argv))

    raw = "" if sys.stdin.isatty() else sys.stdin.read()
    try:
        data = json.loads(raw)
    except (json.JSONDecodeError, ValueError):
        data = {}
    if args.event:
        data["hook_event_name"] = args.event

    out = dispatch(data)
    if out:
        print(out)
    return 0


# --------------------------------------------------------------------- install

HOOK_MARKER = "mem hook"
SETTINGS_REL = Path(".claude") / "settings.json"
HOOK_TIMEOUT = 10


def hook_command(mem_home: Path, vault: Path, project: Path) -> str:
    """The shell command a harness runs for every Mem hook.

    Two environment variables and nothing else, so the same string works for all
    three events and there is one place to look when it misbehaves.

    ``$CLAUDE_PROJECT_DIR`` is used wherever the path is the project being worked
    in, so the settings file stays portable across machines and checkouts. An
    absolute path only appears when the library genuinely lives somewhere else
    than the project, which is a real fact about that install and cannot be
    expressed relatively.
    """
    def rel(path: Path) -> str:
        try:
            inside = path.relative_to(project)
        except ValueError:
            return str(path)
        return '"$CLAUDE_PROJECT_DIR"' + (f"/{inside.as_posix()}" if inside.parts else "")

    parts = [f"{ENV_VAR}={rel(vault)}"]
    if mem_home != project:
        parts.append(f"PYTHONPATH={rel(mem_home)}")
    return " ".join(parts) + " python3 -m mem hook"


def _entry(command: str, timeout: int | None = HOOK_TIMEOUT) -> dict:
    hook = {"type": "command", "command": command}
    if timeout:
        hook["timeout"] = timeout
    return {"hooks": [hook]}


def merge_hooks(settings: dict, command: str) -> tuple[dict, list[str]]:
    """Add the three Mem hooks to a settings dict, touching nothing else.

    Merge, never clobber. Somebody's existing formatter-on-save hook and their
    permission list survive this untouched, and re-running replaces Mem's
    own entries rather than stacking a second copy of them. That idempotence is
    the property that makes the command safe to put in a README.
    """
    changed = []
    hooks = settings.setdefault("hooks", {})
    for event in ("SessionStart", "UserPromptSubmit", "Stop"):
        # Stop can be slow on a long transcript, and unlike the other two nothing
        # is waiting on its output.
        entry = _entry(command, None if event == "Stop" else HOOK_TIMEOUT)
        matchers = hooks.setdefault(event, [])
        if not isinstance(matchers, list):
            matchers = hooks[event] = [matchers]

        existing = [m for m in matchers
                    if any(HOOK_MARKER in (h.get("command") or "")
                           for h in (m.get("hooks") or []) if isinstance(h, dict))]
        if not existing:
            matchers.append(entry)
            changed.append(f"{event}: added")
            continue
        # Replace only Mem's own command, leaving any co-located hook alone.
        replaced = False
        for matcher in existing:
            for hook in matcher.get("hooks") or []:
                if isinstance(hook, dict) and HOOK_MARKER in (hook.get("command") or ""):
                    if hook.get("command") != command:
                        hook["command"] = command
                        replaced = True
        changed.append(f"{event}: updated" if replaced else f"{event}: already wired")
    return settings, changed


def init_hooks(project: Path, mem_home: Path, vault: Path, apply: bool = True) -> dict:
    project, mem_home, vault = (Path(p).expanduser().resolve()
                                     for p in (project, mem_home, vault))
    path = project / SETTINGS_REL
    settings = {}
    if path.exists():
        try:
            settings = json.loads(path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            raise SystemExit(f"{path} is not valid JSON ({exc}); fix or move it first")

    command = hook_command(mem_home, vault, project)
    before = json.dumps(settings, indent=2)
    settings, changed = merge_hooks(copy.deepcopy(settings), command)
    after = json.dumps(settings, indent=2)

    backup = None
    if apply and after != before:
        if path.exists():
            backup = path.with_suffix(f".json.bak-{_stamp()}")
            backup.write_text(path.read_text(encoding="utf-8"), encoding="utf-8")
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(after + "\n", encoding="utf-8")

    return {"path": path, "command": command, "changed": changed,
            "backup": backup, "settings": settings, "wrote": apply and after != before}


def _stamp() -> str:
    import datetime
    return datetime.datetime.now().strftime("%Y%m%dT%H%M%S")


def main_init(argv=None) -> int:
    parser = argparse.ArgumentParser(
        prog="mem init-hooks",
        description="wire Mem into a Claude Code project's .claude/settings.json")
    parser.add_argument("project", nargs="?", default=".",
                        help="project directory to wire up (default: cwd)")
    parser.add_argument("--vault", help=f"vault location (default: ${ENV_VAR} or the "
                                        "vault/ beside the library)")
    parser.add_argument("--mem-home", default=str(REPO_ROOT),
                        help="directory containing the mem package")
    parser.add_argument("--dry-run", action="store_true", help="print, write nothing")
    args = parser.parse_args(list(sys.argv[1:] if argv is None else argv))

    result = init_hooks(Path(args.project), Path(args.mem_home),
                        vault_path(args.vault), apply=not args.dry_run)

    print(f"settings : {result['path']}")
    print(f"command  : {result['command']}")
    for line in result["changed"]:
        print(f"  {line}")
    if args.dry_run:
        print("\n(dry run, nothing written; drop --dry-run to apply)")
    elif result["wrote"]:
        if result["backup"]:
            print(f"backed up: {result['backup'].name}")
        print("\nwired. Open this project in Claude Code and the vault is on the live path:")
        print("  identity + now load at session start, recall is injected per message, "
              "the session is captured on stop.")
    else:
        print("\nalready wired, nothing to change.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
