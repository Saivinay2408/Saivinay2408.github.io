"""Retrieval: score = recency + importance + relevance, plus one hop of graph
expansion.

The scoring shape is the Generative Agents formula, with three deliberate
changes made after watching it fail on a real vault:

1. **Field weighting.** Matching a note's *name* counts more than matching its
   prose, or a note that merely mentions an entity outranks the entity's own file.
2. **Gate on raw relevance, before normalization.** Min-max normalizing an
   all-zero relevance vector produces all ones, which made a query matching
   nothing look maximally relevant and floated junk into the context window.
3. **Query coverage.** A junk query can still accidentally hit one token. A real
   question is mostly made of words the vault already knows, so the fraction of
   query tokens present in the vocabulary is a second, independent gate.

Relevance is IDF-weighted lexical overlap, not embeddings. At the scale a
personal vault actually reaches, lexical retrieval over a curated vocabulary is
accurate, has zero dependencies, zero model calls, and zero latency, and it is
auditable: you can see exactly why a note ranked. Swap in embeddings when the
vault outgrows it, not before.
"""
from __future__ import annotations

import argparse
import datetime
import json
import math
import shutil
from pathlib import Path

from .config import vault_path
from .core import read_note, write_note
from .indexer import load_index, tokenize

DECAY_PER_DAY = 0.995
NAME_WEIGHT = 2.0
ARCHIVE_BELOW = 2.0
MIN_RAW_RELEVANCE = 1.5      # IDF mass the best hit must clear to be injected
MIN_QUERY_COVERAGE = 0.6     # fraction of query CONTENT tokens the vault must recognise

# Interrogatives and auxiliaries. Coverage asks "is this query about something the
# vault has never heard of", and these words cannot answer that: every question
# contains them and no note does. Counting them made a five-word question fail the
# gate for the crime of starting with "what". Found by the Phase 2 benchmark, where
# it silenced sixteen answerable questions. Content words that the vault genuinely
# does not know still count against coverage, which is the whole point of the gate.
# Set to True to restore the pre-benchmark gating (read the relevance floor off
# rank 1 instead of off the best hit). It exists so `eval/benchmark.py
# --legacy-gate` can reproduce the baseline number rather than ask a reader to
# take a before-and-after on trust. Nothing in the library sets it.
GATE_ON_TOP_HIT_ONLY = False

FUNCTION_WORDS = {
    "what", "who", "whom", "whose", "when", "where", "why", "how", "which",
    "are", "am", "do", "does", "did", "can", "could", "would", "should", "will",
    "there", "here", "any", "many", "much", "some", "about", "tell", "know",
    "still", "now", "actually", "really", "going", "get", "got", "have", "has",
    "had", "been", "being", "be", "if", "or", "than", "then", "from", "into",
}
NEVER_ARCHIVE = {"identity-core", "event", "capture", "proposal"}
ACCESS_LOG = "access.jsonl"


def days_since(datestr: str) -> float:
    if not datestr:
        return 365.0
    for fmt, width in (("%Y-%m-%d", 10), ("%Y-%m", 7), ("%Y", 4)):
        try:
            parsed = datetime.datetime.strptime(datestr[:width], fmt).date()
            return max(0.0, (datetime.date.today() - parsed).days)
        except ValueError:
            continue
    return 365.0


def _minmax(values: list[float]) -> list[float]:
    lo, hi = min(values), max(values)
    if hi - lo < 1e-9:
        return [1.0 for _ in values]
    return [(v - lo) / (hi - lo) for v in values]


def score(index: dict, query: str, k: int = 8) -> list[dict]:
    nodes = [n for n in index["nodes"] if "tokens" in n and n["type"] != "identity-core"]
    if not nodes:
        return []
    query_tokens = set(tokenize(query))

    total = len(nodes)
    doc_freq: dict[str, int] = {}
    for node in nodes:
        for token in set(node["tokens"]):
            doc_freq[token] = doc_freq.get(token, 0) + 1

    relevance, recency, importance = [], [], []
    for node in nodes:
        body_tokens = set(node["tokens"])
        hits = query_tokens & body_tokens
        rel = sum(math.log(1 + total / doc_freq.get(t, 1)) for t in hits)
        rel /= math.sqrt(len(body_tokens) or 1)

        name_tokens = set(node.get("name_tokens") or [])
        if name_tokens:
            name_hits = query_tokens & name_tokens
            rel += NAME_WEIGHT * sum(
                math.log(1 + total / doc_freq.get(t, 1)) for t in name_hits
            ) / math.sqrt(len(name_tokens))

        relevance.append(rel)
        recency.append(DECAY_PER_DAY ** days_since(node.get("updated") or node.get("created")))
        importance.append(int(node.get("salience", 5)) / 10.0)

    raw_relevance = relevance[:]
    if query_tokens and max(raw_relevance, default=0.0) <= 0.0:
        return []
    content_tokens = query_tokens - FUNCTION_WORDS
    coverage = (
        sum(1 for t in content_tokens if doc_freq.get(t)) / len(content_tokens)
        if content_tokens else 1.0
    )

    relevance = _minmax(relevance)
    recency = _minmax(recency)
    importance = _minmax(importance)

    out = []
    for i, node in enumerate(nodes):
        if query_tokens and raw_relevance[i] <= 0:
            continue
        out.append({
            **node,
            "score": relevance[i] + recency[i] + importance[i],
            "_rel": relevance[i],
            "_rec": recency[i],
            "_imp": importance[i],
            "_raw_rel": raw_relevance[i],
            "_coverage": coverage,
        })
    out.sort(key=lambda n: -n["score"])
    return out[:k]


def expand(index: dict, hits: list[dict], per_hit: int = 3, from_top: int = 3) -> list[dict]:
    """One hop of graph expansion over the top hits.

    This is what answers multi-hop questions. Lexical scoring finds the person a
    question names; expansion brings in the project she leads, which is where the
    answer actually lives. Neighbours are ordered by salience and appended after
    the direct hits, so expansion can add context but never displace a real match.
    """
    by_stem = {n["stem"]: n for n in index["nodes"]}
    seen = {h["stem"] for h in hits}
    extra = []
    for hit in hits[:from_top]:
        neighbours = []
        for edge in index["edges"]:
            if not edge.get("resolved") or edge.get("external"):
                continue
            other = None
            if edge["src"] == hit["stem"]:
                other = edge["dst"]
            elif edge["dst"] == hit["stem"]:
                other = edge["src"]
            if other and other not in seen and other in by_stem:
                node = by_stem[other]
                # An edge recorded from both ends surfaces the same neighbour
                # twice, which put the same note in the injection block twice and
                # charged the budget for it. Found by reading a live hook block.
                if (node["type"] not in ("capture", "identity-core")
                        and all(n["stem"] != other for n in neighbours)):
                    neighbours.append(node)
        neighbours.sort(key=lambda n: -int(n.get("salience", 5)))
        for node in neighbours[:per_hit]:
            seen.add(node["stem"])
            extra.append({**node, "score": 0.0, "via": hit["stem"]})
    return extra


def log_access(vault: Path, query: str, hits: list[dict]) -> None:
    """Append which notes a query touched.

    The vault is never written mid-conversation. The maintenance pass turns this
    log into salience reinforcement later, so memories that get used strengthen,
    mirroring the decay that runs the other way. Logging failures are swallowed:
    telemetry must never break retrieval.
    """
    record = {
        "ts": datetime.datetime.now().isoformat(timespec="seconds"),
        "query": query[:200],
        "hits": [h["stem"] for h in hits[:8]],
        "top_score": round(hits[0]["score"], 3) if hits else 0.0,
    }
    try:
        with (Path(vault) / ACCESS_LOG).open("a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")
    except OSError:
        pass


def context_block(vault: Path | None = None, query: str = "", k: int = 5,
                  budget: int = 6000, session_id: str = "") -> str:
    """Paste-ready memory block for live prompt injection.

    Returns an empty string when nothing clears the bar. Silence beats noise: an
    irrelevant memory block does not merely waste tokens, it actively misleads
    the model that reads it.

    ``session_id`` enables per-session deduplication: facts this conversation
    has already been given are dropped, and a block left with nothing new in it
    is not sent at all. Retrieval is stateless and per-message, so without this
    a conversation that stays on one subject re-injects the same notes on every
    single turn — the largest avoidable cost in the system, and one the model
    gains nothing from, because it is still looking at the first copy. See
    ``injected.py``. Omit the argument and the behaviour is exactly as before.
    """
    vault = Path(vault) if vault else vault_path()
    index = load_index(vault)
    hits = score(index, query, k)
    log_access(vault, query, hits)

    if not hits:
        return ""
    # Gate on the BEST raw relevance in the result set, not on hits[0].
    #
    # `score` sorts by the blended figure (relevance + recency + importance), so
    # hits[0] is routinely a recent, high-salience note that merely brushes the
    # query, while the note that actually answers it sits at rank 2 with ten times
    # the raw relevance. Reading the gate off position zero therefore threw away
    # whole answers because something else was newer. The Phase 2 benchmark caught
    # this on "what licence is Pipeworks under": pipeworks scored 5.96 raw at rank
    # 2, tidewright scored 0.24 at rank 1, and the block came back empty.
    best_relevance = hits[0]["_raw_rel"] if GATE_ON_TOP_HIT_ONLY else max(
        hit["_raw_rel"] for hit in hits)
    if best_relevance < MIN_RAW_RELEVANCE or hits[0]["_coverage"] < MIN_QUERY_COVERAGE:
        return ""

    from . import injected
    already = injected.load(session_id) if session_id else set()

    blocks, used, fresh = [], 0, []
    for hit in hits + expand(index, hits):
        lines, ids = [], []
        for fact in (hit.get("facts") or [])[:6]:
            if fact.get("superseded"):
                continue
            fid = injected.fact_id(hit["stem"], fact["key"], fact["value"])
            if fid in already:
                continue            # this conversation already has it
            lines.append(f"- {fact['key']}:: {fact['value']}")
            ids.append(fid)
        if not lines:
            # Either the note carries no live facts, or every one of them has
            # already been sent. Both mean there is nothing here worth paying
            # for, and a header with no content under it is pure overhead.
            continue
        via = f" (linked from {hit['via']})" if hit.get("via") else ""
        chunk = f"[{hit['type']}] {hit['title']}{via}\n" + "\n".join(lines)
        if used + len(chunk) > budget:
            break
        blocks.append(chunk)
        fresh.extend(ids)
        used += len(chunk)

    if not blocks:
        return ""
    injected.record(session_id, fresh)
    return ("[recalled memory for this message, from the vault; "
            "trust it over training data]\n\n" + "\n\n".join(blocks))


def decay_pass(vault: Path, index: dict, apply: bool = False) -> list[str]:
    """Salience decays with disuse. Nothing is deleted.

    Cold notes move to ``archive/cold/`` and stay in git history. Identity-core,
    episodic events, and captures are exempt: history does not get less true
    because nobody asked about it lately.
    """
    vault = Path(vault)
    moved = []
    for node in index["nodes"]:
        if node["type"] in NEVER_ARCHIVE or node.get("n_facts", 0) > 0:
            continue
        age = days_since(node.get("updated") or node.get("created"))
        effective = int(node.get("salience", 5)) * (DECAY_PER_DAY ** age)
        if effective >= ARCHIVE_BELOW:
            continue
        moved.append(f"{node['path']} (salience {node['salience']} -> {effective:.2f} after {age:.0f}d)")
        if apply:
            src = vault / node["path"]
            dst = vault / "archive" / "cold" / src.name
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(src), str(dst))
    return moved


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(prog="mem recall")
    parser.add_argument("query", nargs="?", default="")
    parser.add_argument("-k", type=int, default=8)
    parser.add_argument("--context", action="store_true", help="print full note bodies")
    parser.add_argument("--block", action="store_true", help="print the injection block")
    parser.add_argument("--decay", action="store_true", help="run the salience decay pass")
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args(argv)

    vault = vault_path()
    index = load_index(vault)

    if args.decay:
        moved = decay_pass(vault, index, args.apply)
        suffix = " -> archive/cold/" if args.apply else " (dry run)"
        print(f"decay: {len(moved)} note(s) below salience floor {ARCHIVE_BELOW}{suffix}")
        for line in moved:
            print(f"  {line}")
        return 0

    if not args.query:
        parser.error("give a query, or --decay")

    if args.block:
        print(context_block(vault, args.query) or "(nothing cleared the relevance bar)")
        return 0

    hits = score(index, args.query, args.k)
    if not hits:
        print("no lexical match. (identity.md and now.md are always loaded anyway)")
        return 0

    if args.context:
        for hit in hits:
            body = (vault / hit["path"]).read_text(encoding="utf-8")
            print(f"--- {hit['path']} (score {hit['score']:.2f})\n{body}")
        return 0

    print(f"query: {args.query!r}\n")
    print(f"{'score':>6} {'rel':>5} {'rec':>5} {'imp':>5}  {'type':<12} note")
    for hit in hits:
        print(f"{hit['score']:6.2f} {hit['_rel']:5.2f} {hit['_rec']:5.2f} {hit['_imp']:5.2f}  "
              f"{hit['type']:<12} {hit['stem']}")
    return 0
