"""Session capture: the only thing that runs on the live path.

This is a stop-hook for an agent harness. It reads the harness's JSON on stdin,
pulls the conversation transcript, strips tool noise, and writes a cleaned
markdown record into ``episodic/sessions/``. No model call, no extraction, no
judgement, so it costs the user nothing in latency and cannot fail in a way that
loses the conversation.

Everything expensive happens later, off the live path, in ``consolidate``.

Contract, in order of preference:
  1. stdin JSON with ``transcript_path`` (and optionally ``cwd``, ``session_id``)
  2. stdin JSON with ``summary``
  3. plain text on stdin or argv, stored as a manual inbox note

See ``docs/HOOKS.md`` for wiring instructions.
"""
from __future__ import annotations

import datetime
import json
import sys
from pathlib import Path

from .config import vault_path

MAX_TURN_CHARS = 4000


def extract_turns(transcript_path: str) -> list[tuple[str, str]]:
    """Read a JSONL transcript into ``(role, text)`` pairs, tool calls dropped.

    Malformed lines are skipped rather than fatal. A capture hook that crashes on
    one bad line loses the entire session, which is the worst possible trade.
    """
    turns: list[tuple[str, str]] = []
    try:
        lines = Path(transcript_path).read_text(encoding="utf-8").splitlines()
    except OSError:
        return turns

    for line in lines:
        try:
            obj = json.loads(line)
        except json.JSONDecodeError:
            continue
        if obj.get("type") not in ("user", "assistant"):
            continue
        content = obj.get("message", {}).get("content")
        if isinstance(content, str):
            text = content
        elif isinstance(content, list):
            text = "\n".join(
                block.get("text", "") for block in content
                if isinstance(block, dict) and block.get("type") == "text"
            )
        else:
            text = ""
        text = text.strip()
        if not text or text.startswith("<"):
            continue      # system reminders and meta blocks are not conversation
        turns.append((obj["type"], text[:MAX_TURN_CHARS]))
    return turns


def write_session(vault: Path, transcript_path: str, project: str = "", session_id: str = "") -> Path | None:
    turns = extract_turns(transcript_path)
    if not turns:
        return None
    sid = (session_id or Path(transcript_path).stem)[:8]
    date = datetime.date.today().isoformat()
    out = Path(vault) / "episodic" / "sessions" / f"{date}-{sid}.md"
    out.parent.mkdir(parents=True, exist_ok=True)

    frontmatter = [
        "---",
        "type: session",
        f"date: {date}",
        f"session_id: {sid}",
        f"source: {transcript_path}",
        f"project: {project or 'unknown'}",
        f"turns: {len(turns)}",
        "consolidated: false",
        "---",
        "",
    ]
    body = [f"\n### {role}\n\n{text}" for role, text in turns]
    out.write_text("\n".join(frontmatter) + "\n".join(body) + "\n", encoding="utf-8")
    return out


def write_manual_summary(vault: Path, summary: str) -> Path:
    """Append a free-text note to today's inbox file, creating it if needed."""
    date = datetime.date.today().isoformat()
    inbox = Path(vault) / "episodic" / "inbox" / f"{date}.md"
    inbox.parent.mkdir(parents=True, exist_ok=True)
    if not inbox.exists():
        inbox.write_text(
            f"---\ntype: session\ndate: {date}\nconsolidated: false\n---\n\n", encoding="utf-8"
        )
    stamp = datetime.datetime.now().isoformat(timespec="seconds")
    with inbox.open("a", encoding="utf-8") as f:
        f.write(f"\n## capture {stamp}\n- summary:: {summary}\n")
    return inbox


def main(argv=None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    raw = ""
    if not sys.stdin.isatty():
        raw = sys.stdin.read()
    if argv:
        raw = " ".join(argv)

    transcript = summary = None
    project = session_id = ""
    try:
        data = json.loads(raw)
        transcript = data.get("transcript_path")
        summary = data.get("summary")
        session_id = str(data.get("session_id") or "")
        cwd = data.get("cwd") or ""
        if cwd:
            project = Path(cwd).name
    except (json.JSONDecodeError, TypeError):
        summary = raw.strip() or None

    vault = vault_path()
    if transcript and Path(transcript).exists():
        write_session(vault, transcript, project, session_id)
    elif summary:
        write_manual_summary(vault, summary)
    return 0
