"""Consolidation: the scheduled "sleep" pass.

Runs off the live path, on a timer or by hand, never during a conversation.

    inbox + unconsolidated sessions
      -> extract candidates (model, prompted with the entity catalog)
      -> GROUND check   (quote must exist verbatim in the source)
      -> REJECT gate    (junk, low salience, no durable subject)
      -> deterministic write with bi-temporal supersession
      -> mark sources consolidated
      -> git commit

The model's only job is proposing candidates. It never writes. Both checkers run
inside the write path, so an extractor that ignores every instruction in its
prompt still cannot put junk or fiction into the vault.

The extractor is invoked as a subprocess so Mem stays dependency-free and
provider-agnostic. Set ``MEM_EXTRACTOR_CMD`` to any command that reads a
prompt as its final argument and prints JSON on stdout.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import shlex
import shutil
import subprocess
import sys
from pathlib import Path

from . import core
from .config import REPO_ROOT, vault_path

DEFAULT_EXTRACTOR_CMD = "claude -p"
EXTRACTOR_TIMEOUT = 240

# One message, three call sites (extract() failure log, the loud end-of-run
# error, and `check-extractor`), so a user never sees three different stories
# about the same broken command.
EXTRACTOR_FIX_MSG = (
    "extractor command {cmd!r} is unavailable ({reason}).\n"
    "  Fix: install/authenticate it (the default is the Claude Code CLI, "
    "`claude -p`), or point MEM_EXTRACTOR_CMD at your own extractor -- "
    "any command that takes a prompt as its final argument and prints JSON "
    "with a \"candidates\" key on stdout:\n"
    "    export MEM_EXTRACTOR_CMD=\"my-llm-cli --json\"\n"
    "  Check it before onboarding with: python3 -m mem check-extractor\n"
    "  See docs/HOOKS.md#extractor-configuration."
)

EXTRACT_PROMPT = """You extract durable memory from a conversation log for a personal knowledge graph. Output STRICT JSON only, no prose.

Return: {"candidates": [ ... ]}. Each candidate is either

  a FACT:  {"kind":"fact","entity_type":"person|project|concept|artifact|skill|goal","entity":"<name>","aliases":[...],"key":"<short_stable_key>","content":"<the fact>","salience":1-10,"category":"decision|fact|preference|state|relationship","valid_from":"YYYY-MM-DD","provenance":"<source id>","quote":"<verbatim words from the log that state this>"}

  an EVENT: {"kind":"event","subtype":"decision|milestone|note","title":"<title>","entities":["<name>",...],"rationale":"<why>","outcome":"<optional>","salience":1-10,"category":"decision|milestone","date":"YYYY-MM-DD","provenance":"<source id>","quote":"<verbatim words from the log>"}

GROUNDING (non-negotiable): every candidate carries "quote", a short VERBATIM span copied character for character out of the log below. A checker searches the source for that quote; a candidate whose quote is not found is discarded. Never paraphrase inside "quote". Watch polarity: if the user REJECTED an idea, the fact is that they rejected it, not that they chose it.

REJECT (do not emit) anything mundane or transient: meals, greetings, weather, smalltalk, or anything with salience below 3. Only durable facts about people, projects, concepts, goals, decisions, and lasting preferences. A smaller true set beats a bigger noisy one.

KEY DISCIPLINE (this is what stops duplicate memory):
- Reuse canonical short keys. A person's relation is "relationship". A project's state is "status". A ship date is "target". The entity is already the subject, so never prefix the entity name into the key.
- CRITICAL: if an entity below lists [existing keys: ...] and your fact updates one of those slots, reuse that EXACT key. Emitting a new key for an existing slot reads as a new fact instead of a correction, and leaves two contradictory current truths in the graph. Only invent a key for a genuinely new attribute.
- Do not create nodes for tooling, meta-work, or documents. Only real people, projects, concepts, and goals in the user's life.
- Set every provenance to SOURCE_ID below.
- EVENTS: only for something that happened or was decided in THIS session. Do not create events for past milestones being recounted from memory.

SOURCE_ID: %s

EXISTING ENTITIES (if something matches one of these, use its EXACT name as "entity"; only emit a new entity if it is genuinely absent):
%s

CONVERSATION LOG:
%s
"""

KEY_IN_BULLET = re.compile(r"^- ([\w-]+)::")


def build_catalog(vault: Path) -> str:
    """Compact catalog of existing entities and their fact keys.

    Showing the keys is the upstream fix for key drift. If a project already
    carries a ``target`` fact, the extractor must reuse ``target`` rather than
    inventing ``launch_target``. Fixing drift at generation time is safe; fixing
    it afterwards by merging similar-looking keys is not, because two keys that
    look alike are not reliably the same slot.
    """
    from .config import ENTITY_FOLDERS

    lines = []
    for folder in ENTITY_FOLDERS:
        directory = Path(vault) / folder
        if not directory.exists():
            continue
        for path in sorted(directory.glob("*.md")):
            frontmatter, body = core.read_note(path)
            name = body.splitlines()[0].lstrip("# ").strip() if body.strip() else path.stem
            aliases = ", ".join(str(a) for a in (frontmatter.get("aliases") or []))
            current, _, _ = core.section(body, "## Current facts")
            keys: list[str] = []
            for bullet in current:
                match = KEY_IN_BULLET.match(bullet.strip())
                if match and match.group(1) not in keys:
                    keys.append(match.group(1))
            line = f"- {name}" + (f" (aka: {aliases})" if aliases else "")
            if keys:
                line += f" [existing keys: {', '.join(keys[:12])}]"
            lines.append(line)
    return "\n".join(lines) or "(vault is empty)"


def extract(text: str, source_id: str, catalog: str) -> tuple[list[dict], bool]:
    """Ask the configured extractor for candidates. Failures degrade to [].

    A consolidation run that finds no extractor should be a no-op, not a crash:
    the captures stay marked unconsolidated and the next run picks them up.

    Returns ``(candidates, failed)``. ``failed`` is True only when the
    extractor itself is broken (missing binary, timeout, no JSON, malformed
    JSON) -- never when it ran fine and genuinely found nothing durable. That
    distinction is what lets the caller fail loud on "the extractor never ran"
    without also failing loud on "this session had nothing worth keeping".
    """
    cmd = shlex.split(os.environ.get("MEM_EXTRACTOR_CMD", DEFAULT_EXTRACTOR_CMD))
    prompt = EXTRACT_PROMPT % (source_id, catalog, text)
    try:
        completed = subprocess.run(
            cmd + [prompt], capture_output=True, text=True, timeout=EXTRACTOR_TIMEOUT
        )
    except (subprocess.TimeoutExpired, FileNotFoundError) as exc:
        print(f"  ! extractor unavailable ({exc}); skipping {source_id}", file=sys.stderr)
        return [], True

    out = completed.stdout
    start, end = out.find("{"), out.rfind("}")
    if start == -1 or end == -1:
        print(f"  ! extractor returned no JSON for {source_id}", file=sys.stderr)
        return [], True
    try:
        candidates = json.loads(out[start:end + 1]).get("candidates", [])
    except json.JSONDecodeError:
        print(f"  ! extractor JSON malformed for {source_id}", file=sys.stderr)
        return [], True
    for candidate in candidates:
        candidate.setdefault("provenance", source_id)
    return candidates, False


def check_extractor(cmd: list[str] | None = None, timeout: int = EXTRACTOR_TIMEOUT) -> tuple[bool, str]:
    """Preflight: does the configured extractor actually run?

    Used both by `python3 -m mem check-extractor` (run before onboarding)
    and by the loud end-of-run failure in `run()` (run after the fact, once a
    whole pass has come back with zero facts). Same probe, same message, so
    the two surfaces never disagree about what is wrong.
    """
    cmd = cmd or shlex.split(os.environ.get("MEM_EXTRACTOR_CMD", DEFAULT_EXTRACTOR_CMD))
    if not cmd:
        return False, "MEM_EXTRACTOR_CMD is set to an empty command."
    if shutil.which(cmd[0]) is None:
        return False, EXTRACTOR_FIX_MSG.format(
            cmd=" ".join(cmd), reason=f"{cmd[0]!r} not found on PATH")

    probe = 'Reply with exactly this JSON and nothing else: {"candidates": []}'
    try:
        completed = subprocess.run(cmd + [probe], capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        return False, EXTRACTOR_FIX_MSG.format(
            cmd=" ".join(cmd), reason=f"timed out after {timeout}s")
    except FileNotFoundError as exc:
        return False, EXTRACTOR_FIX_MSG.format(cmd=" ".join(cmd), reason=str(exc))

    out = completed.stdout
    if "{" not in out or "}" not in out:
        detail = (completed.stderr or out or "no output").strip()[:200]
        return False, EXTRACTOR_FIX_MSG.format(
            cmd=" ".join(cmd), reason=f"ran but produced no JSON ({detail!r})")
    return True, f"extractor {' '.join(cmd)!r} is configured and responds with JSON."


def main_check_extractor(argv=None) -> int:
    ok, message = check_extractor()
    print(("OK: " if ok else "FAIL: ") + message)
    return 0 if ok else 1


def pending_sources(vault: Path) -> list[tuple[Path, str]]:
    vault = Path(vault)
    sources = sorted((vault / "episodic" / "inbox").glob("*.md"))
    sources += sorted((vault / "episodic" / "sessions").glob("*.md"))
    out = []
    for path in sources:
        frontmatter, body = core.read_note(path)
        if frontmatter.get("consolidated") is True:
            continue
        out.append((path, body))
    return out


def mark_consolidated(path: Path) -> None:
    frontmatter, body = core.read_note(path)
    if frontmatter.get("consolidated") is True:
        return
    frontmatter["consolidated"] = True
    lines = ["---"] + [f"{k}: {core._dump_scalar(v)}" for k, v in frontmatter.items()] + ["---", ""]
    path.write_text("\n".join(lines) + body.rstrip("\n") + "\n", encoding="utf-8")


def git_commit(message: str, root: Path = REPO_ROOT) -> None:
    if not (Path(root) / ".git").exists():
        return
    subprocess.run(["git", "-C", str(root), "add", "vault"], capture_output=True)
    subprocess.run(["git", "-C", str(root), "commit", "-m", message], capture_output=True)


def run(vault: Path, fixture: Path | None = None, dry_run: bool = False, commit: bool = False) -> dict:
    vault = Path(vault)
    candidates: list[dict] = []
    discarded: list[dict] = []
    sources: list[Path] = []

    if fixture:
        payload = json.loads(Path(fixture).read_text(encoding="utf-8"))
        raw = payload.get("candidates", [])
        source_text = payload.get("source")
        if source_text:
            raw, dropped = core.ground_check(raw, source_text)
            discarded += dropped
        candidates = raw
    any_processed = False
    any_extractor_failure = False
    if not fixture:
        catalog = build_catalog(vault)
        for path, body in pending_sources(vault):
            print(f"extracting: {path.name}")
            raw, failed = extract(body, path.stem, catalog)
            any_processed = True
            any_extractor_failure = any_extractor_failure or failed
            grounded, dropped = core.ground_check(raw, body)
            for item in dropped:
                print(f"  UNGROUNDED ({item['_reason']}): "
                      f"{str(item.get('content') or item.get('title'))[:70]!r}", file=sys.stderr)
            candidates += grounded
            discarded += dropped
            # Only a source the extractor actually ran on gets marked
            # consolidated. One that failed (missing binary, timeout, bad
            # output) stays unconsolidated so a fixed extractor picks it up on
            # the next run instead of it being silently lost the moment the
            # dependency comes back.
            if not failed:
                sources.append(path)

    report = core.apply_candidates(vault, candidates) if not dry_run else {
        "kept": [], "rejected": [], "log": ["(dry run: nothing written)"]
    }
    report["ungrounded"] = discarded

    # Loud failure: sources were actually processed, at least one extraction
    # call failed (missing binary, timeout, unparsable output), and NOTHING
    # came out of the extraction step at all -- not one grounded candidate,
    # not one ungrounded drop. That combination can only mean the extractor
    # never produced usable output; it is not the "this session had nothing
    # durable" case, since a working extractor that legitimately finds nothing
    # still returns a clean `candidates: []` without ever setting `failed`.
    # (Checked against raw extraction output, not `report["kept"]`/
    # `"rejected"`, because those are hardcoded empty on --dry-run.)
    report["extractor_failed"] = False
    if any_processed and any_extractor_failure and not candidates and not discarded:
        _, message = check_extractor()
        report["extractor_failed"] = True
        report["extractor_message"] = message

    if not dry_run:
        for path in sources:
            mark_consolidated(path)
        if commit:
            git_commit(
                f"memory: consolidate: +{len(report['kept'])} facts, "
                f"{len(report['rejected'])} rejected, {len(discarded)} ungrounded"
            )
    return report


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(prog="mem consolidate")
    parser.add_argument("--fixture", help="JSON file of candidates; skips the model")
    parser.add_argument("--dry-run", action="store_true", help="report only, write nothing")
    parser.add_argument("--commit", action="store_true", help="git commit the vault afterwards")
    args = parser.parse_args(argv)

    report = run(
        vault_path(),
        Path(args.fixture) if args.fixture else None,
        dry_run=args.dry_run,
        commit=args.commit,
    )

    print(f"\nkept {len(report['kept'])}, rejected {len(report['rejected'])}, "
          f"ungrounded {len(report['ungrounded'])}")
    for item in report["rejected"]:
        print(f"  REJECT: {item['content']!r}: {item['reason']}")
    for line in report["log"]:
        print(f"  wrote: {line}")

    if report.get("extractor_failed"):
        print(f"\nFAIL: {report['extractor_message']}", file=sys.stderr)
        return 1
    return 0
