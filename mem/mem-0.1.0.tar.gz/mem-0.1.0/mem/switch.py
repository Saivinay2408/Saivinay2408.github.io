"""Memory on, memory off.

The switch exists because "an agent that knows you" is not always what you want
from an agent. Sometimes you want plain Claude Code — on a work repo, in a
screen share, on somebody else's problem — and having to uninstall a memory
system to get that is not a real off switch.

Off means off, in both directions:

    on            identity core loads at session start, recall is injected per
                  message, and the finished session is captured for the vault
    off           nothing is read into the session and nothing is written down.
                  The agent behaves exactly as it would with Mem absent
    capture-only  nothing is injected, but sessions are still captured. For
                  "keep learning, don't influence me yet" — which is what you
                  want for the first week, while the vault is still thin

Two places can set it, and the narrower one wins:

    MEM_MEMORY=off claude        this session only
    mem memory off               until you change it back

The setting is machine-local (``~/.mem/settings.json``) and deliberately
NOT stored in the vault. The vault is a git repository you may sync between
machines or publish; whether your laptop currently injects memory is not a fact
about your memory, and committing it would mean pushing a private preference to
whoever you share the vault with.

Nothing in here can raise. A switch that crashes the harness is worse than any
setting it could hold, so every reader degrades to ``on`` — the state the user
chose by installing this in the first place.
"""
from __future__ import annotations

import json
import os
from pathlib import Path

ENV_VAR = "MEM_MEMORY"
SETTINGS = Path.home() / ".mem" / "settings.json"

ON = "on"
OFF = "off"
CAPTURE_ONLY = "capture-only"
MODES = (ON, OFF, CAPTURE_ONLY)

# Words people actually type, mapped to the three real states. `1`/`0` and
# `true`/`false` are here because an env var is a place where those get used.
_ALIASES = {
    "on": ON, "1": ON, "true": ON, "yes": ON, "enabled": ON, "clone": ON,
    "off": OFF, "0": OFF, "false": OFF, "no": OFF, "disabled": OFF,
    "capture-only": CAPTURE_ONLY, "capture": CAPTURE_ONLY,
    "capture_only": CAPTURE_ONLY, "silent": CAPTURE_ONLY, "learn": CAPTURE_ONLY,
}

DESCRIPTION = {
    ON: "on — the agent loads your identity, recalls what is relevant, "
        "and captures this session",
    OFF: "off — nothing is injected and nothing is recorded. "
         "This is plain Claude Code",
    CAPTURE_ONLY: "capture-only — nothing is injected, but sessions are still "
                  "written down for the vault to learn from later",
}


def normalize(value: str | None) -> str | None:
    if value is None:
        return None
    return _ALIASES.get(str(value).strip().lower())


def _load() -> dict:
    try:
        data = json.loads(SETTINGS.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def mode() -> str:
    """The effective mode: environment first, then the saved setting, then on.

    The environment override is per-process, which is what makes
    ``MEM_MEMORY=off claude`` mean this one session and nothing else.
    """
    from_env = normalize(os.environ.get(ENV_VAR))
    if from_env:
        return from_env
    return normalize(_load().get("memory")) or ON


def set_mode(value: str) -> str:
    """Persist a mode. Raises ValueError on anything not in MODES."""
    resolved = normalize(value)
    if resolved is None:
        raise ValueError(f"unknown mode {value!r}; use one of {', '.join(MODES)}")
    data = _load()
    data["memory"] = resolved
    SETTINGS.parent.mkdir(parents=True, exist_ok=True)
    SETTINGS.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
    return resolved


def injects() -> bool:
    """Should anything be read INTO a session right now?"""
    return mode() == ON


def captures() -> bool:
    """Should a finished session be written down?"""
    return mode() in (ON, CAPTURE_ONLY)


def overridden_by_env() -> bool:
    """True when the current mode comes from the environment rather than the
    saved setting — worth saying out loud, because otherwise `mem memory
    status` and the running session can disagree and both be right."""
    return normalize(os.environ.get(ENV_VAR)) is not None


def status() -> dict:
    current = mode()
    return {
        "mode": current,
        "description": DESCRIPTION[current],
        "injects": injects(),
        "captures": captures(),
        "fromEnv": overridden_by_env(),
        "settings": str(SETTINGS),
    }


# ------------------------------------------------------------------------ cli

USAGE = """usage: python3 -m mem memory [on|off|capture-only]

  on            load your identity, recall what is relevant, capture sessions
  off           inject nothing, record nothing. Plain Claude Code
  capture-only  record sessions but inject nothing, so the vault keeps learning
                while it is still too thin to be worth reading

With no argument, prints the current state.

  MEM_MEMORY=off claude     one session only, without changing the setting
"""


def main(argv=None) -> int:
    import sys
    args = list(sys.argv[1:] if argv is None else argv)
    if args and args[0] in ("-h", "--help"):
        print(USAGE)
        return 0

    if args:
        try:
            set_mode(args[0])
        except ValueError as exc:
            print(f"{exc}\n\n{USAGE}", file=sys.stderr)
            return 2

    state = status()
    print(f"memory is {state['description']}.")
    if state["fromEnv"]:
        # Otherwise `memory status` and the running session can disagree and
        # both be right, which is a confusing five minutes.
        print(f"  (from {ENV_VAR} in this shell, overriding the saved setting)")
    if args and not state["fromEnv"]:
        print(f"  saved to {state['settings']}")
    return 0
