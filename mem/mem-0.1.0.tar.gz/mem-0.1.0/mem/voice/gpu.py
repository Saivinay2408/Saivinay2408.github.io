"""
gpu — the speech models on the Mac's GPU, through Apple's MLX.

Measured on an M4 (16 GB), a three-second sentence in, a one-sentence reply out:

    whisper small   CPU int8 (faster-whisper)   1146 ms     MLX GPU   270 ms
    Kokoro          CPU (onnxruntime)            ~700 ms    MLX GPU   ~200 ms

On the CPU both models sat on four cores while the GPU did nothing; more
threads did not help (8 threads: the same 1.15 s), and onnxruntime's CoreML
provider was no faster because most of Kokoro falls back to the CPU anyway.
MLX runs the whole graph on the GPU. For a phone call that is about 1.4 s off
every reply.

Two choices here are deliberate:

  * Kokoro keeps kokoro-onnx's own phonemizer, splitter, trimming and pauses.
    Only the network itself moves to the GPU, by standing in for the one
    method that runs it. So a word is pronounced exactly as it was before;
    mlx-audio's own pipeline would bring a different G2P (misaki, plus spaCy)
    and a different accent with it.

  * Nothing here downloads during a conversation. The GPU weights are fetched
    in the background the first time the app starts; until they are on disk,
    and on any error after that, the CPU path answers as it always has.

Apple Silicon only. Set MEM_GPU=0 to force the CPU path.
"""
from __future__ import annotations

import os
import platform
import sys
import threading
from pathlib import Path

WHISPER_REPO = {
    "tiny":  "mlx-community/whisper-tiny-mlx",
    "base":  "mlx-community/whisper-base-mlx",
    "small": "mlx-community/whisper-small-mlx",
    "medium": "mlx-community/whisper-medium-mlx",
}
KOKORO_REPO = "mlx-community/Kokoro-82M-bf16"
KOKORO_FILES = ["config.json", "kokoro-v1_0.safetensors"]

# MLX is safe from several threads, but the GPU only does one of these at a
# time anyway, and a lock makes "one at a time" a fact rather than a hope.
LOCK = threading.Lock()

_avail: bool | None = None
_fetching = threading.Lock()


def available() -> bool:
    """Apple Silicon, MLX importable, and not switched off."""
    global _avail
    if os.environ.get("MEM_GPU", "").strip().lower() in ("0", "off", "no", "false"):
        return False
    if _avail is None:
        ok = sys.platform == "darwin" and platform.machine() == "arm64"
        if ok:
            try:
                import mlx.core  # noqa: F401
            except Exception:                           # noqa: BLE001
                ok = False
        _avail = ok
    return _avail


def _has(module: str) -> bool:
    import importlib.util
    try:
        return importlib.util.find_spec(module) is not None
    except (ImportError, ValueError):
        return False


def _local(repo: str, files: list[str] | None = None) -> str:
    """The snapshot folder if the repo (or the named files) is already
    downloaded, else "". Never touches the network."""
    try:
        from huggingface_hub import snapshot_download
        path = snapshot_download(repo_id=repo, allow_patterns=files,
                                 local_files_only=True)
    except Exception:                                   # noqa: BLE001
        return ""
    p = Path(path)
    if files and not all((p / f).exists() for f in files):
        return ""
    return str(p) if p.is_dir() else ""


def whisper_path(size: str = "small") -> str:
    repo = WHISPER_REPO.get(size)
    return _local(repo) if repo else ""


def kokoro_path() -> str:
    return _local(KOKORO_REPO, KOKORO_FILES)


_waiting: list = []


def prefetch(size: str = "small", on_done=None) -> None:
    """Download the GPU weights in the background, once. Every caller's
    on_done() runs after, so the engines can switch over mid-session."""
    if not available():
        return
    if on_done:
        _waiting.append(on_done)
    if not _fetching.acquire(blocking=False):
        return                                  # already downloading

    def run():
        try:
            from huggingface_hub import snapshot_download
            repo = WHISPER_REPO.get(size)
            if repo and _has("mlx_whisper") and not whisper_path(size):
                snapshot_download(repo_id=repo)
            if _has("mlx_audio") and not kokoro_path():
                snapshot_download(repo_id=KOKORO_REPO, allow_patterns=KOKORO_FILES)
        except Exception as e:                          # noqa: BLE001
            print(f"[gpu] could not fetch the GPU speech models ({e}); "
                  f"staying on the CPU", file=sys.stderr)
        finally:
            _fetching.release()
        while _waiting:
            try:
                _waiting.pop(0)()
            except Exception:                           # noqa: BLE001
                pass

    threading.Thread(target=run, daemon=True, name="gpu-prefetch").start()


# ---- whisper ----------------------------------------------------------------

class Whisper:
    """mlx-whisper with the weights already on disk. transcribe() matches
    faster-whisper's settings in stt.Transcriber: English, greedy, no
    carry-over between utterances."""

    def __init__(self, path: str):
        import mlx_whisper
        self._mw = mlx_whisper
        self.path = path
        import numpy as np
        # Load and compile now, not on the first thing you say.
        self.transcribe(np.zeros(16000, dtype=np.float32))

    def transcribe(self, audio) -> str:
        import numpy as np
        with LOCK:
            r = self._mw.transcribe(
                np.asarray(audio, dtype=np.float32), path_or_hf_repo=self.path,
                language="en", temperature=0.0, condition_on_previous_text=False,
                verbose=None)
        return (r.get("text") or "").strip()


# ---- Kokoro -----------------------------------------------------------------

def _load_kokoro(path: str):
    import json
    import mlx.core as mx
    from mlx_audio.tts.models.kokoro.kokoro import Model, ModelConfig
    cfg = json.loads((Path(path) / "config.json").read_text())
    make = getattr(ModelConfig, "from_dict", None)
    model = Model(make(cfg) if make else ModelConfig(**cfg))
    weights = mx.load(str(Path(path) / "kokoro-v1_0.safetensors"))
    model.load_weights(list(model.sanitize(weights).items()))
    mx.eval(model.parameters())
    return model, cfg


def accelerate_kokoro(k, path: str | None = None) -> bool:
    """Run a kokoro_onnx.Kokoro's network on the GPU, keeping everything else.

    kokoro-onnx turns text into token ids (its espeak phonemizer and
    vocabulary), runs the network once per batch in `_infer(tokens, style,
    speed)`, then trims and joins. Only `_infer` is replaced. The MLX model
    looks tokens up through its own vocabulary, which is the same table
    (checked below); giving it the identity table lets the ids pass straight
    through.

    Returns False, and leaves `k` untouched, if anything does not line up.
    Any error at synthesis time falls back to the original `_infer` for good.
    """
    if not available():
        return False
    orig = getattr(k, "_infer", None)
    if orig is None or getattr(orig, "_mem_gpu", False):
        return bool(orig)
    import inspect
    try:
        if list(inspect.signature(orig).parameters)[:3] != ["tokens", "style", "speed"]:
            return False
    except (TypeError, ValueError):
        return False
    path = path or kokoro_path()
    if not path:
        return False
    try:
        model, cfg = _load_kokoro(path)
        vocab = getattr(getattr(k, "tokenizer", None), "vocab", None)
        if vocab is not None and dict(vocab) != dict(cfg.get("vocab") or {}):
            print("[gpu] Kokoro vocabularies differ; staying on the CPU", file=sys.stderr)
            return False
        model.vocab = {i: i for i in range(int(cfg["n_token"]))}
    except Exception as e:                              # noqa: BLE001
        print(f"[gpu] Kokoro on the GPU unavailable ({e}); staying on the CPU",
              file=sys.stderr)
        return False

    import numpy as np
    import mlx.core as mx
    timed = bool(getattr(k, "has_timings", False))
    broken = []

    def infer(tokens, style, speed, *a, **kw):
        if broken or a or kw:
            return orig(tokens, style, speed, *a, **kw)
        try:
            ref = mx.array(np.asarray(style, dtype=np.float32)).reshape(1, -1)
            with LOCK:
                out = model(list(tokens), ref, float(speed), return_output=True)
                audio = np.array(out.audio.astype(mx.float32)).ravel()
                dur = np.array(out.pred_dur).astype(np.int64).ravel() if timed else None
            return audio, dur
        except Exception as e:                          # noqa: BLE001
            # Too long for the context window, a driver hiccup, an API change:
            # this sentence and every later one go to the CPU.
            broken.append(e)
            print(f"[gpu] Kokoro GPU failed ({e}); using the CPU from now on",
                  file=sys.stderr)
            return orig(tokens, style, speed)

    infer._mem_gpu = True
    k._infer = infer
    # Compile the graph now rather than on the first reply.
    try:
        k.create("Ready.", voice=next(iter(k.voices)), speed=1.0, lang="en-us")
    except Exception:                                   # noqa: BLE001
        pass
    return not broken
