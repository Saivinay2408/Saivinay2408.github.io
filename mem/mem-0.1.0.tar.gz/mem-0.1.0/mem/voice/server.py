"""
server — the local transport between the Python side and the one window.

aiohttp on 127.0.0.1 with a random port. Two socket types:

  /ws            control channel, JSON. Panes, roster, orb state, actions.
  /pty/<id>      one per pane, binary. Raw terminal bytes both directions.

Terminal bytes get their own socket on purpose. A TUI repainting at speed is a
different traffic shape from "a pane changed state", and putting them on one
channel means either base64-ing every frame or letting a burst of screen paint
delay a state update. Two sockets, no coupling.

Serving over HTTP rather than pushing HTML into a webview also means the exact
same dashboard opens in a browser — useful for development, and for anyone who
would rather not install a native shell.
"""
from __future__ import annotations

import asyncio
import json
import socket
from pathlib import Path

from aiohttp import WSMsgType, web

from . import supervisor
from .panes import PaneManager
from .paths import LAUNCH_CWD

UI_DIR = Path(__file__).parent / "ui"
ROSTER_INTERVAL = 2.0


def free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


class Hub:
    """Fan-out to every connected control socket."""

    def __init__(self) -> None:
        self._sockets: set[web.WebSocketResponse] = set()
        self.loop: asyncio.AbstractEventLoop | None = None

    def add(self, ws: web.WebSocketResponse) -> None:
        self._sockets.add(ws)

    def discard(self, ws: web.WebSocketResponse) -> None:
        self._sockets.discard(ws)

    async def send(self, msg: dict) -> None:
        dead = []
        for ws in list(self._sockets):
            try:
                await ws.send_json(msg)
            except (ConnectionResetError, RuntimeError):
                dead.append(ws)
        for ws in dead:
            self._sockets.discard(ws)

    def send_threadsafe(self, msg: dict) -> None:
        """Broadcast from a non-async thread (the voice loop lives on one)."""
        if self.loop is None:
            return
        try:
            asyncio.run_coroutine_threadsafe(self.send(msg), self.loop)
        except RuntimeError:
            pass


class Dashboard:
    def __init__(self, model: str = "sonnet",
                 permission_mode: str = "bypassPermissions") -> None:
        self.hub = Hub()
        self.model = model
        self.permission_mode = permission_mode
        # Which agent a new terminal starts with. Read from the saved defaults
        # at startup (see _on_start) so the header picker comes back where you
        # left it.
        self.agent = "claude"
        self.panes = PaneManager(on_change=self._panes_changed)
        self.app = web.Application()
        self._routes()
        self.app.on_startup.append(self._on_start)
        self.app.on_cleanup.append(self._on_stop)
        self._roster_task: asyncio.Task | None = None
        self._health_task: asyncio.Task | None = None
        self._health_last: dict | None = None
        # set by __main__ once these exist, so UI actions can reach them
        self.voice = None
        self.usage = None
        self.downloader = None
        self.memory = None
        # Built on first use: onboarding is a thing most users touch once, and
        # nobody should pay for its import on every launch.
        self.setup = None
        # Something the first window to connect should be told once — set by
        # cli.py before the server starts. Shown once and cleared, so a reload
        # does not repeat it at someone who has already read it.
        self.first_run_note = ""
        # The interview, on the other hand, is built eagerly: the voice loop
        # asks it on every utterance whether it wants the text, and a `None`
        # that becomes an object halfway through a session is a race nobody
        # needs. It holds no resources until it is started.
        from .interview import Interview
        self.interview = Interview(self)

    # ---- wiring ---------------------------------------------------------

    def _routes(self) -> None:
        self.app.middlewares.append(self._no_cache)
        self.app.router.add_get("/", self._index)
        self.app.router.add_get("/ws", self._control_ws)
        self.app.router.add_get("/pty/{pane_id}", self._pty_ws)
        self.app.router.add_static("/ui/", UI_DIR)

    @staticmethod
    @web.middleware
    async def _no_cache(request, handler):
        """Never cache the interface.

        The assets are served from disk over loopback, so caching buys nothing
        and costs correctness: after an edit or an update the browser keeps
        showing the old CSS against the new markup, which looks like a layout
        bug and isn't one. (It presented as a permanently-open menu drawer.)
        """
        response = await handler(request)
        if not isinstance(response, web.WebSocketResponse):
            response.headers["Cache-Control"] = "no-store, must-revalidate"
        return response

    async def _on_start(self, _app) -> None:
        self.hub.loop = asyncio.get_running_loop()
        try:
            from .settings import load_defaults
            self.agent = load_defaults().get("agent", self.agent)
        except Exception:                              # noqa: BLE001
            pass                                       # the default is fine
        self._roster_task = asyncio.create_task(self._roster_loop())
        self._health_task = asyncio.create_task(self._health_loop())

    async def _health_loop(self) -> None:
        """Run the checks in the background so a silent breakage can raise a
        flag on the closed menu. Nobody opens a Health tab speculatively —
        the whole point is being told without asking."""
        from .health import run_all
        loop = asyncio.get_running_loop()
        while True:
            try:
                self._health_last = await loop.run_in_executor(None, run_all)
                await self.hub.send({"t": "health", "v": self._health_last})
            except asyncio.CancelledError:
                raise
            except Exception:                          # noqa: BLE001
                pass
            await asyncio.sleep(300)

    async def _on_stop(self, _app) -> None:
        for task in (self._roster_task, self._health_task):
            if task:
                task.cancel()
        self.panes.close_all()

    def _panes_changed(self) -> None:
        # The voice session can be replaced (you close its pane and open a new
        # one). The watcher has to follow it, or the dashboard keeps tailing a
        # transcript nothing writes to any more and quietly goes deaf.
        if self.voice is not None:
            self.voice.attach_target_pane()
        self.hub.send_threadsafe({"t": "panes", "panes": self.panes.info()})
        # A pane opening or closing can change which repo you are in — the
        # focused one may have just gone away — so the rail has to be told.
        self.hub.send_threadsafe({"t": "git", "v": self.git_snapshot()})

    # ---- http -----------------------------------------------------------

    async def _index(self, _req) -> web.FileResponse:
        return web.FileResponse(UI_DIR / "index.html")

    # ---- control socket -------------------------------------------------

    async def _control_ws(self, req) -> web.WebSocketResponse:
        ws = web.WebSocketResponse(heartbeat=30)
        await ws.prepare(req)
        self.hub.add(ws)
        try:
            await self._snapshot(ws)
            async for msg in ws:
                if msg.type is not WSMsgType.TEXT:
                    continue
                try:
                    await self._command(json.loads(msg.data), ws)
                except ConnectionResetError:
                    # The client left while we were answering. Some handlers
                    # take seconds -- `agents` shells out once per agent -- and
                    # a reload during one is completely ordinary. Writing to
                    # the closed socket raised, the error reply raised again on
                    # the same socket, and aiohttp logged both: ~180 lines of
                    # traceback in ~/Library/Logs/Mem.log for a page refresh.
                    break
                except Exception as e:                     # noqa: BLE001
                    if not await self._say_error(ws, f"{type(e).__name__}: {e}"):
                        break
        except ConnectionResetError:
            pass                                           # disconnected mid-snapshot
        finally:
            self.hub.discard(ws)
        return ws

    @staticmethod
    async def _say_error(ws: web.WebSocketResponse, msg: str) -> bool:
        """Tell the client something went wrong. False if it is not there to
        be told, which is a disconnection and not a second failure."""
        if ws.closed:
            return False
        try:
            await ws.send_json({"t": "error", "msg": msg})
            return True
        except (ConnectionResetError, RuntimeError):
            return False

    async def _snapshot(self, ws: web.WebSocketResponse) -> None:
        """Everything a freshly connected client needs to draw a correct page.

        Without this, a reload — or the automatic reconnect after the server
        restarts — left the meters blank and the orb on "idle" until whatever
        timer happened to own each value came round again: 20s for usage, 60s
        for memory, 300s for health, and for the orb state, never. The page
        was not stale, it was empty, and it looked exactly like a dead backend.
        """
        await ws.send_json({"t": "panes", "panes": self.panes.info()})
        if self.voice is not None:
            await ws.send_json({"t": "state", "v": self.voice.state})
        if self.usage is not None and self.usage.last:
            await ws.send_json({"t": "usage", "v": self.usage.last})
        if self.memory is not None and self.memory.last:
            await ws.send_json({"t": "memory", "v": self.memory.last})
        if self._health_last is not None:
            await ws.send_json({"t": "health", "v": self._health_last})
        await ws.send_json({"t": "interview", "v": self.interview.status()})
        from .settings import load_voice
        await ws.send_json({"t": "muted",
                            "v": bool(load_voice().get("muted"))})
        await ws.send_json({"t": "git", "v": self.git_snapshot()})
        if self.first_run_note:
            await ws.send_json({"t": "toast", "v": self.first_run_note})
            self.first_run_note = ""

    # ---- the repo you are in --------------------------------------------

    def focused_cwd(self) -> str:
        """The working directory of the pane you are looking at.

        Everything about "which project am I in" resolves through here, so the
        left rail and the git panel can never disagree about it. It follows
        what you are LOOKING at, which is not the same as where your voice is
        pointed — you read one session while talking to another all the time.
        """
        pane = self.panes.focused_pane()
        return pane.project_cwd if pane else str(LAUNCH_CWD)

    def git_snapshot(self) -> dict:
        """Git state for the focused repo. Never raises: the panel degrades to
        an error string, because a dashboard that dies on an odd repository is
        worse than one that says it could not read it."""
        from . import git as gitmod
        cwd = self.focused_cwd()
        try:
            snap = gitmod.snapshot(cwd)
        except Exception as e:                             # noqa: BLE001
            snap = {"repo": False, "error": f"{type(e).__name__}: {e}",
                    "label": "git unavailable", "files": []}
        snap["cwd"] = cwd
        snap["project"] = Path(cwd).name or cwd
        return snap

    def push_git(self) -> None:
        self.emit_raw({"t": "git", "v": self.git_snapshot()})

    async def _command(self, m: dict, ws: web.WebSocketResponse) -> None:
        """Handle one UI action. Anything that shells out goes to a thread —
        `claude --bg` can take seconds and must not stall the event loop."""
        t = m.get("t")
        run = asyncio.get_running_loop().run_in_executor

        if t == "pane.open":
            kind = m.get("kind", "plain")
            if kind == "voice":
                self.panes.open_voice(self.model, self.permission_mode)
            else:
                cwd = m.get("cwd") or LAUNCH_CWD
                # The header picker is the authority when it names one, and the
                # saved default otherwise. Before this the agent was chosen in
                # the page and then dropped on the floor here, so selecting
                # Codex or Gemini and pressing + still opened Claude — the one
                # control in the window that did nothing at all.
                agent = m.get("agent") or self.agent
                self.panes.open_plain(cwd, m.get("model") or "", agent=agent)
                # Opening a project IS visiting it; that is what "Most visited"
                # counts. Recorded off the event loop because it writes a file.
                from . import registry
                await run(None, lambda: registry.visit(cwd))

        elif t == "pane.close":
            self.panes.close(m["id"], stop_session=bool(m.get("stop")),
                             delete_session=bool(m.get("delete")))

        elif t == "pane.compact":
            pane = self.panes.get(m.get("id", ""))
            if pane is None or not pane.pty.alive:
                await ws.send_json({"t": "error", "msg": "That session isn't running."})
            else:
                # Ctrl-U first, for the same reason voice input does it: the box
                # may hold a pre-filled prompt suggestion, and typing into that
                # would submit "<suggestion>/compact" — which is a prompt, not a
                # command. See voice_loop.submit_text.
                pane.pty.write(b"\x15")
                await asyncio.sleep(0.05)
                pane.pty.write(b"/compact")
                await asyncio.sleep(0.12)
                pane.pty.write(b"\r")

        elif t == "dispatch":
            prompt = (m.get("prompt") or "").strip()
            if prompt:
                await self._dispatch(m, prompt, ws, run)

        elif t == "say":
            # typed input routed to the voice pane, so the dashboard is usable
            # with the mic off (and so voice can be tested without speaking)
            if self.voice is not None:
                await run(None, lambda: self.voice.submit_text(m.get("text", "")))

        elif t == "voice.ptt":
            # Hot path: this is a key going down. Anything slow here shows up as
            # the orb lagging the press, so it must stay a plain flag set.
            if self.voice is not None:
                self.voice.set_ptt(bool(m.get("down")))

        elif t == "memory.consolidate":
            if self.memory is not None and not self.memory.consolidator.run_now():
                await ws.send_json({"t": "error", "msg": "A consolidation pass is already running."})

        elif t == "memory.mode":
            # The clone on or off. Off is not a quieter on: nothing is injected
            # and nothing is recorded, so a session behaves exactly as it would
            # without any of this installed.
            from .memory_ctl import memory_switch, snapshot
            try:
                await run(None, lambda: memory_switch().set_mode(m.get("mode", "on")))
            except ValueError as e:
                await ws.send_json({"t": "error", "msg": str(e)})
            else:
                await self.hub.send({"t": "memory", "v": await run(None, snapshot)})

        elif t == "memory.cadence":
            if self.memory is not None:
                from .memory_ctl import save_config, snapshot
                await run(None, lambda: save_config({
                    "cadence": m.get("cadence"),
                    "autoConsolidate": m.get("cadence") != "off"}))
                await self.hub.send({"t": "memory", "v": await run(None, snapshot)})

        elif t == "usage.refresh":
            if self.usage is not None:
                self.usage.refresh_limits_now()

        # ---- menu ----------------------------------------------------
        # All of these touch the filesystem or shell out, so they go to a
        # thread. The menu opening must never stall the event loop that is
        # streaming terminal output behind it.

        elif t == "menu.projects":
            await ws.send_json({"t": "projects", "v": await run(None, self.projects)})

        elif t == "setup":
            from . import setup_ctl
            await ws.send_json({"t": "setup", "v": await run(None, setup_ctl.status)})

        elif t == "setup.run":
            from . import setup_ctl
            if self.setup is None:
                self.setup = setup_ctl.Runner(self)
            step = m.get("step") or ""
            res = (self.setup.start_all() if step == "all"
                   else self.setup.start(step, bool(m.get("dry"))))
            if not res["ok"]:
                await ws.send_json({"t": "error", "msg": res["error"]})

        elif t == "models":
            from . import models as models_mod
            await ws.send_json({"t": "models", "v": {
                **await run(None, models_mod.status),
                "whisper": await run(None, models_mod.whisper_status),
                "freeBytes": await run(None, models_mod.free_space),
            }})

        elif t == "models.fetch":
            from .models import Downloader
            if self.downloader is None:
                self.downloader = Downloader(self)
            res = self.downloader.start(bool(m.get("whisper", True)))
            if not res["ok"]:
                await ws.send_json({"t": "error", "msg": res["error"]})

        elif t == "models.cancel":
            if self.downloader is not None:
                self.downloader.cancel()

        elif t.startswith("interview."):
            await self._interview_cmd(t, m, ws, run)

        elif t == "setup.dismiss":
            from . import setup_ctl
            await ws.send_json({"t": "setup",
                                "v": await run(None, lambda: (
                                    setup_ctl.dismiss(bool(m.get("value", True))),
                                    setup_ctl.status())[1])})

        elif t == "agents":
            # Probing versions shells out once per agent, so this is asked for
            # rather than pushed on a timer.
            from . import agents_ui
            cwd = m.get("cwd") or self.focused_cwd()
            snap = await run(None, lambda: agents_ui.snapshot(cwd))
            # The picker's own state travels with the list it paints. It used
            # to be restored from the settings snapshot, which is only sent
            # when that menu is opened -- so a reload showed Claude selected
            # while new terminals correctly opened Codex, which is a worse bug
            # than the one it was fixing.
            snap["chosen"] = self.agent
            await ws.send_json({"t": "agents", "v": snap})

        elif t == "agent.install":
            """Install an agent, in a terminal you can watch.

            Not a hidden subprocess with a spinner: this runs `npm i -g ...`
            on somebody's machine, and the honest way to do that is in a pane
            where the output, the prompts and any failure are visible and can
            be answered. It is the same thing they would have typed, typed for
            them.
            """
            from . import agents_ui
            spec = agents_ui.AGENTS.get(m.get("name") or "")
            cmd = (spec or {}).get("installCmd") or ""
            if not cmd:
                await ws.send_json({"t": "error",
                                    "msg": "That one has to be installed from "
                                           "its own site."})
            else:
                pane = self.panes.open_shell(cmd, title=f"install {m['name']}")
                await ws.send_json({"t": "toast",
                                    "v": f"Installing in a terminal: {cmd}"})
                del pane

        elif t == "injected":
            from . import injected
            cwd = m.get("cwd") or self.focused_cwd()
            await ws.send_json({"t": "injected",
                                "v": await run(None, lambda: injected.snapshot(cwd))})

        elif t == "injected.preview":
            # Runs real retrieval against the real vault, so what it shows is
            # what a session would get -- including nothing, which is the
            # answer people least expect and most need to see.
            from . import injected
            await ws.send_json({"t": "injected.preview",
                                "v": await run(None,
                                               lambda: injected.preview(m.get("text") or ""))})

        elif t == "rules.read":
            from . import agents_ui
            await ws.send_json({"t": "rules.read",
                                "v": await run(None,
                                               lambda: agents_ui.read_rules(m.get("path") or ""))})

        elif t in ("project.add", "project.remove", "project.rename",
                   "project.pin", "project.sort", "project.branch",
                   "project.scan", "project.import"):
            await self._project_cmd(t, m, ws, run)

        elif t == "menu.sessions":
            # Two questions, one handler. `project` is "what was I doing here";
            # `recent` is "what was I doing", which is the one you ask when the
            # session you want is in a repo you have not opened in days. The
            # scope comes back with the answer so a slow reply cannot paint
            # itself into a list you have since switched away from.
            from .projects import list_sessions, recent_sessions
            scope = m.get("scope") or "project"
            cwd = m.get("cwd") or str(LAUNCH_CWD)
            live = {s["sessionId"] for s in await run(None, supervisor.roster)}
            rows = await run(None, lambda: (
                recent_sessions(live_ids=live) if scope == "recent"
                else list_sessions(cwd, live_ids=live)))
            await ws.send_json({"t": "sessions", "scope": scope,
                                "cwd": cwd, "v": rows})

        elif t == "menu.health":
            from .health import run_all
            self._health_last = await run(None, run_all)
            await ws.send_json({"t": "health", "v": self._health_last})

        elif t == "menu.settings":
            from .settings import snapshot
            await ws.send_json({"t": "settings", "v": await run(None, snapshot)})

        elif t == "settings.voice":
            from .settings import save_voice, snapshot
            await run(None, lambda: save_voice(m.get("patch") or {}))
            await ws.send_json({"t": "settings", "v": await run(None, snapshot)})

        elif t == "voice.mute":
            # Persisted, then applied. A room you cannot talk out loud in is
            # not a per-session condition, and having to re-mute every launch
            # is how a mute button becomes a thing people stop trusting.
            from .settings import save_voice
            muted = bool(m.get("muted"))
            await run(None, lambda: save_voice({"muted": muted}))
            if self.voice is not None:
                self.voice.set_muted(muted)
            await self.hub.send({"t": "muted", "v": muted})

        elif t == "voice.test":
            # Hearing it is the only way to judge it. Silently doing nothing
            # when the mic is off would make the button look broken, so say so.
            if self.voice is None:
                await ws.send_json({"t": "error",
                                    "msg": "Voice is off in this window "
                                           "(started with --no-voice)."})
            else:
                await run(None, self.voice.say_sample)

        elif t == "settings.defaults":
            from .settings import save_defaults, snapshot
            saved = await run(None, lambda: save_defaults(m.get("patch") or {}))
            # New panes should use the new defaults immediately rather than
            # after a restart, which is the whole point of a settings screen.
            self.model = saved.get("model", self.model)
            self.permission_mode = saved.get("permissionMode", self.permission_mode)
            self.agent = saved.get("agent", self.agent)
            await ws.send_json({"t": "settings", "v": await run(None, snapshot)})

        elif t == "pane.resume":
            sid = (m.get("sessionId") or "").strip()
            if sid:
                self.panes.open_resume(sid, m.get("cwd") or LAUNCH_CWD,
                                       m.get("title") or "", self.model)

        elif t == "pane.focus":
            # Selecting a session moves the repo the rail names, the tree the
            # git panel acts on, and the keyboard. It deliberately does NOT
            # move your voice — see PaneManager.target_pane.
            if self.panes.focus(m.get("id") or ""):
                self.emit_raw({"t": "panes", "panes": self.panes.info()})
                await run(None, self.push_git)

        elif t == "voice.target":
            # The one gesture that moves your voice, and it is a toggle: press
            # it on the pane that has the voice and it goes back to the clone.
            pane = self.panes.set_voice_target(m.get("id") or "")
            if self.voice is not None:
                self.voice.attach_target_pane()
            self.emit_raw({"t": "panes", "panes": self.panes.info()})
            if pane is None:
                await ws.send_json({"t": "error",
                                    "msg": "There is no session to talk to. Open one."})
            else:
                where = "your clone" if pane.kind == "voice" else pane.title
                # Say what pointing the voice at a non-Claude session actually
                # buys you, rather than letting it look broken. Dictation works
                # — the words are typed into the pane exactly as they are into
                # a Claude one — but Codex and Gemini keep their transcripts in
                # their own stores and formats, so there is nothing to read
                # back and the reply is not narrated.
                if pane.agent != "claude":
                    await ws.send_json({
                        "t": "toast",
                        "v": f"Dictating to {where}. {pane.agent.title()} "
                             f"replies on screen, not out loud."})
                else:
                    await ws.send_json({"t": "toast", "v": f"Talking to {where}."})

        elif t == "git.refresh":
            await run(None, self.push_git)

        elif t == "git.diff":
            from . import git as gitmod
            cwd = m.get("cwd") or self.focused_cwd()
            out = await run(None, lambda: gitmod.diff(
                cwd, m.get("path") or "", bool(m.get("staged"))))
            await ws.send_json({"t": "git.diff", "path": m.get("path") or "",
                                "staged": bool(m.get("staged")), "v": out})

        elif t == "git.review":
            # Everything this branch changed, not just what is uncommitted. An
            # agent that ran for an hour and made nine commits shows nothing
            # under `git diff`, and reporting that as "no changes" is the most
            # misleading answer the panel could give.
            from . import git as gitmod
            cwd = m.get("cwd") or self.focused_cwd()
            out = await run(None, lambda: gitmod.diff_vs_base(cwd, m.get("base") or ""))
            await ws.send_json({"t": "git.review", "v": out})

        elif t == "git.worktree.remove":
            from . import git as gitmod
            cwd = m.get("cwd") or self.focused_cwd()
            res = await run(None, lambda: gitmod.remove_worktree(
                cwd, m.get("path") or "", bool(m.get("deleteBranch"))))
            await ws.send_json({"t": "git.result", "op": t, "v": res})
            await run(None, self.push_git)

        elif t in ("git.stage", "git.unstage", "git.commit", "git.push",
                   "git.branch", "git.worktree"):
            await self._git_write(t, m, ws, run)

        elif t == "ping":
            await ws.send_json({"t": "pong"})

    async def _interview_cmd(self, t: str, m: dict, ws, run) -> None:
        """The onboarding conversation.

        Every one of these returns the whole status and the Interview
        broadcasts it too, so a second window watching the same interview
        stays in step rather than showing a question you already answered.
        """
        iv = self.interview
        if t == "interview.start":
            iv.start(m.get("at"))
        elif t == "interview.stop":
            iv.stop()
        elif t == "interview.go":
            iv.go(int(m.get("at") or 0))
        elif t == "interview.answer":
            # From the text box: what it holds IS the answer, and moving on is
            # a separate decision from writing one down.
            iv.replace(m.get("text") or "")
            if m.get("next"):
                iv.next()
        elif t == "interview.skip":
            iv.skip()
        elif t == "interview.repeat":
            iv.speak_current()
        elif t == "interview.finish":
            # Write the file, then run the same command the CLI documents.
            # `--apply` is the step that spends tokens and sends the text to
            # an extractor, so it is only ever reached from this click.
            path = await run(None, iv.write)
            from . import setup_ctl
            if self.setup is None:
                self.setup = setup_ctl.Runner(self)
            res = self.setup.start_args(
                "onboard", ["onboard", str(path), "--apply"],
                note=f"$ mem onboard {path} --apply")
            if not res["ok"]:
                await ws.send_json({"t": "error", "msg": res["error"]})
        await ws.send_json({"t": "interview", "v": iv.status()})

    def projects(self) -> dict:
        """Discovered ∪ registered, in the user's chosen order."""
        from . import registry
        from .projects import list_projects
        live = {s["cwd"] for s in supervisor.roster() if s.get("cwd")}
        return registry.merged(list_projects(live), live)

    async def _project_cmd(self, t: str, m: dict, ws, run) -> None:
        """Add, rename, pin, remove, sort, scan, import.

        `remove` forgets a project and never touches the folder — see
        registry.py. Nothing in this handler deletes anything from disk, and
        that is a property worth keeping when adding to it.
        """
        from . import registry
        path = m.get("cwd") or ""

        if t == "project.add":
            res = registry.add(path, m.get("name") or "")
        elif t == "project.remove":
            res = registry.remove(path)
        elif t == "project.rename":
            res = registry.rename(path, m.get("name") or "")
        elif t == "project.pin":
            res = registry.pin(path, bool(m.get("pinned", True)))
        elif t == "project.branch":
            res = registry.set_default_branch(path, m.get("branch") or "")
        elif t == "project.sort":
            res = {"ok": True, "error": "", "sort": registry.set_sort(m.get("sort") or "")}
        elif t == "project.scan":
            res = await run(None, lambda: registry.scan(m.get("path") or ""))
            await ws.send_json({"t": "project.scan", "v": res})
            return
        else:                                              # project.import
            paths = [p for p in (m.get("paths") or []) if isinstance(p, str)]
            res = await run(None, lambda: registry.import_many(paths))

        await ws.send_json({"t": "project.result", "op": t, "v": res})
        await ws.send_json({"t": "projects", "v": await run(None, self.projects)})

    async def _dispatch(self, m: dict, prompt: str, ws, run) -> None:
        """Start a background session, in its own working tree by default.

        This is the part that makes running several agents at once safe rather
        than merely possible. Two sessions in one checkout interleave edits and
        the loser's work is gone with no conflict marker to show for it, so the
        default is isolation and sharing the tree is the thing you opt into.

        Falling back to the shared tree when a worktree cannot be made is
        deliberate, and it is reported rather than silent: a directory that is
        not a git repository is a perfectly normal place to want an agent, and
        refusing the dispatch outright would be worse than doing it in place.
        """
        from . import git as gitmod
        cwd = m.get("cwd") or self.focused_cwd()
        name = (m.get("name") or "").strip()
        isolate = m.get("isolate", True)
        note = ""

        if isolate:
            branch = gitmod.session_branch(name or prompt)
            made = await run(None, lambda: gitmod.add_worktree(cwd, branch))
            if made["ok"]:
                cwd = made["path"]
                note = f"in a worktree on {branch}"
            else:
                note = f"in the shared tree ({made['error']})"

        res = await run(None, lambda: supervisor.dispatch(
            prompt, cwd, name, m.get("model") or "",
            m.get("permissionMode") or ""))
        if not res["ok"]:
            await ws.send_json({"t": "error", "msg": res["error"]})
            return
        await ws.send_json({"t": "dispatched", "v": {**res, "cwd": cwd, "note": note}})
        await run(None, self.push_git)

    async def _git_write(self, t: str, m: dict, ws, run) -> None:
        """Every operation that changes the repository.

        Grouped in one place on purpose. These are the only calls in the whole
        dashboard that can alter somebody's history, and they run exclusively
        from an explicit click — there is no timer, no agent hook and no retry
        that can reach them. See git.py, rule 1.
        """
        from . import git as gitmod
        cwd = m.get("cwd") or self.focused_cwd()
        paths = [p for p in (m.get("paths") or []) if isinstance(p, str)]

        if t == "git.stage":
            res = await run(None, lambda: gitmod.stage(cwd, paths))
        elif t == "git.unstage":
            res = await run(None, lambda: gitmod.unstage(cwd, paths))
        elif t == "git.commit":
            res = await run(None, lambda: gitmod.commit(
                cwd, m.get("message") or "", bool(m.get("all"))))
        elif t == "git.push":
            res = await run(None, lambda: gitmod.push(cwd))
        elif t == "git.branch":
            res = await run(None, lambda: gitmod.switch_branch(
                cwd, m.get("name") or "", bool(m.get("create"))))
        else:                                              # git.worktree
            res = await run(None, lambda: gitmod.add_worktree(
                cwd, m.get("name") or ""))
            if res.get("ok") and res.get("path"):
                # A worktree exists to be worked in, so open it. Dispatching a
                # second agent into the tree a first one is editing is how two
                # sessions silently overwrite each other.
                self.panes.open_plain(res["path"], self.model, agent=self.agent)

        await ws.send_json({"t": "git.result", "op": t, "v": res})
        await run(None, self.push_git)

    # ---- pty socket -----------------------------------------------------

    async def _pty_ws(self, req) -> web.WebSocketResponse:
        pane = self.panes.get(req.match_info["pane_id"])
        ws = web.WebSocketResponse(heartbeat=30, max_msg_size=8 * 1024 * 1024)
        await ws.prepare(req)
        if pane is None:
            await ws.close(code=4404, message=b"no such pane")
            return ws

        loop = asyncio.get_running_loop()
        out: asyncio.Queue[bytes] = asyncio.Queue(maxsize=1024)

        # NOTHING RUNS UNTIL THE VIEWER HAS SAID HOW BIG IT IS.
        #
        # A TUI reads its size once, at boot. Claude Code fixes the width of
        # its banner and its tips panel there and never recomputes them, so a
        # session started at a guessed 80 columns and resized to 49 a moment
        # later draws a layout for a pane it is not in, permanently — wrapped
        # box borders, a rule repeated down the side, text broken at the wrong
        # column. Every resize after boot only re-runs the same wrong layout.
        #
        # So the process is held (PtyPane(defer=True)) until the first resize
        # arrives, and started at THAT size. Its first frame is correct, which
        # is the only version of this that is actually fixed rather than
        # cleaned up afterwards.
        #
        # `showing` still exists for the resizes that come later — a pane that
        # is already running and gets re-tiled — where dropping frames while it
        # redraws is what stops the stranded ones being seen.
        showing = False

        def on_bytes(data: bytes) -> None:
            # reader thread -> event loop. put_nowait on a full queue would raise
            # inside the PTY reader; dropping is correct here because the TUI
            # repaints, so a dropped frame during a burst self-heals.
            if not showing:
                return
            try:
                loop.call_soon_threadsafe(out.put_nowait, data)
            except RuntimeError:
                pass

        unsubscribe = pane.pty.subscribe(on_bytes)
        # How a reconnecting viewer catches up depends on whether anything is
        # still able to paint.
        #
        # A live TUI owns the screen. Replaying its raw scrollback into a fresh
        # xterm.js does NOT reproduce it — cursor moves, alternate-screen
        # switches and clears all replay out of context, and the result is
        # visibly shredded (overlapping lines, half-drawn boxes). The correct
        # move is to show nothing, then ask the program itself to repaint.
        #
        # A dead pane has no one left to ask, so its scrollback is all there is
        # and replaying it is exactly right.
        #
        # The repaint is NOT triggered here. A freshly opened xterm.js measures
        # itself and sends its real geometry a moment later; asking for a
        # repaint before that arrives means the repaint is drawn at the wrong
        # size and then immediately invalidated by the client's own resize.
        # That race is what shredded reattached panes. The redraw is triggered
        # by the first resize message instead — see below.
        if pane.pty.alive:
            await ws.send_bytes(b"\x1b[H\x1b[2J\x1b[3J")   # home, clear, drop scrollback
        else:
            # Nothing is left to ask for a repaint, so the scrollback is all
            # there is — and replaying it is exactly right.
            showing = True
            back = pane.pty.scrollback()
            if back:
                await ws.send_bytes(back)

        async def pump() -> None:
            while True:
                data = await out.get()
                try:
                    await ws.send_bytes(data)
                except (ConnectionResetError, RuntimeError):
                    return

        async def start_showing(settle: float = 0.35) -> None:
            """Start the program at the settled size, then show it.

            WAIT FOR THE WIDTH TO STOP MOVING FIRST. A new pane is resized more
            than once before it comes to rest: the browser measures it, and
            then the grid re-tiles because this very pane just joined it — a
            third session turns two columns into three and every pane, this one
            included, changes width again within a few hundred milliseconds.
            Starting on the FIRST resize would boot the TUI at the two-column
            width and leave it there, which is the same bug one step earlier.

            So this is debounced on resize quiescence, and every resize while
            still hidden restarts it. Then, in order: let bytes through, clear
            whatever a reconnecting viewer had, and start the process — which
            for a pane that is already running (a reload, a reattach) becomes
            a repaint instead, since `start` is a no-op the second time.
            """
            nonlocal showing
            try:
                await asyncio.sleep(settle)
            except asyncio.CancelledError:
                return
            if showing or not pane.pty.alive:
                return
            try:
                await ws.send_bytes(b"\x1b[H\x1b[2J\x1b[3J")
            except (ConnectionResetError, RuntimeError):
                return
            showing = True
            # First viewer: this is where the program is actually born, at the
            # size it will be read at. Later viewers: already started, so ask
            # the running program for a fresh frame instead.
            if not pane.pty.start(pane.pty.cols, pane.pty.rows):
                pane.pty.repaint()

        async def settle_repaint() -> None:
            """One more paint, after a width change has stopped moving.

            Claude Code erases its previous frame by counting the lines that
            frame occupied, and that count depends on the width it wrapped at.
            Change the width — which happens every time a session is added and
            the grid re-tiles — and the count is wrong, so the old input box
            survives, its borders broken across the narrower pane. That stack
            of stray rules down a reflowed pane is exactly this.

            A paint whose frame is both drawn and erased at ONE width has
            arithmetic that holds, so asking for one after the dust settles
            replaces the wreckage with a correct frame. Debounced, because a
            drag across the window edge is a hundred resizes and the repaint is
            only worth doing at the end of one.
            """
            nonlocal showing
            try:
                await asyncio.sleep(0.25)
            except asyncio.CancelledError:
                return
            if not pane.pty.alive:
                return

            # Provoke a redraw the only way this program answers to — a real
            # change of width — but do it with the client deaf, so the frame
            # that gets stranded by the wrong erase count is stranded into
            # nothing. Then clear, listen again, and go back to the true width:
            # THAT redraw lands on an empty screen, and its erase sequences are
            # harmless there because there is nothing above to erase.
            cols, rows = pane.pty.cols, pane.pty.rows
            showing = False
            pane.pty.force_size(max(20, cols - 1), rows)
            await asyncio.sleep(0.12)
            try:
                await ws.send_bytes(b"\x1b[H\x1b[2J\x1b[3J")
            except (ConnectionResetError, RuntimeError):
                showing = True
                return
            showing = True
            pane.pty.force_size(cols, rows)

        # If a viewer never reports a size — an old client, a socket that opens
        # and stalls — the pane must not stay blank forever. The guess is worse
        # than the truth and better than nothing.
        async def fallback() -> None:
            await asyncio.sleep(2.0)
            await start_showing(settle=0.0)

        pump_task = asyncio.create_task(pump())
        fallback_task = asyncio.create_task(fallback())
        repaint_task: asyncio.Task | None = None
        show_task: asyncio.Task | None = None
        try:
            async for msg in ws:
                if msg.type is WSMsgType.BINARY:
                    pane.pty.write(msg.data)
                elif msg.type is WSMsgType.TEXT:
                    # only control frames on this socket: geometry
                    try:
                        c = json.loads(msg.data)
                    except ValueError:
                        continue
                    if c.get("t") == "resize":
                        was = pane.pty.cols
                        pane.pty.resize(int(c.get("cols", 80)), int(c.get("rows", 24)))
                        if not showing:
                            # Every resize while hidden restarts the wait: the
                            # pane is not settled until they stop arriving.
                            if show_task and not show_task.done():
                                show_task.cancel()
                            show_task = asyncio.create_task(start_showing())
                        elif pane.pty.cols != was:
                            if repaint_task and not repaint_task.done():
                                repaint_task.cancel()
                            repaint_task = asyncio.create_task(settle_repaint())
        finally:
            pump_task.cancel()
            fallback_task.cancel()
            for t in (repaint_task, show_task):
                if t:
                    t.cancel()
            unsubscribe()
        return ws

    # ---- roster ---------------------------------------------------------

    async def _roster_loop(self) -> None:
        """Poll the daemon and keep the pane set in step with reality."""
        loop = asyncio.get_running_loop()
        while True:
            try:
                sessions = await loop.run_in_executor(None, supervisor.roster)
                changed = await loop.run_in_executor(
                    None, lambda: self.panes.sync_roster(sessions))
                # "Needs you" is a roster fact, and the roster poll is the only
                # thing that sees it. Handing it to the voice loop is what makes
                # the orb's blocked state reachable at all — it was in the
                # palette from the first version and nothing ever set it.
                if self.voice is not None:
                    self.voice.set_blocked([p.title for p in self.panes.all()
                                            if p.state == "blocked"])
                await self.hub.send({"t": "roster", "sessions": sessions})
                if changed:
                    await self.hub.send({"t": "panes", "panes": self.panes.info()})
            except asyncio.CancelledError:
                raise
            except Exception:                              # noqa: BLE001
                pass                                       # a poll failure is not fatal
            await asyncio.sleep(ROSTER_INTERVAL)

    # ---- state broadcast used by the background monitors ----------------

    def emit(self, kind: str, payload) -> None:
        self.hub.send_threadsafe({"t": kind, "v": payload})

    def emit_raw(self, msg: dict) -> None:
        self.hub.send_threadsafe(msg)
