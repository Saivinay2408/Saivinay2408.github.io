"""
hands_broker — "Can I click Send in Mail?", asked everywhere you might be,
answered from wherever you are.

The hands gate (hands.py, a hook inside the voice session) POSTs here and
waits. The question goes out at once to every place you could be:

    the window      a card with Allow / Deny / Allow for 10 minutes
    the phone app   the same card, and on a call the question is SPOKEN
    the Mac         spoken, when you are at the Mac and not on a call

and the first answer from any of them wins: a tap, or a spoken yes/no (the
voice loop and the call hand every utterance to take_spoken() first, so "yes"
is an answer here rather than a new message to the session).

Nobody answers in two minutes -> no. Silence is never consent.
"""
from __future__ import annotations

import asyncio
import threading
import time
import uuid

TIMEOUT_S = 120
TRUST_MINUTES = 10


class Broker:
    def __init__(self, dash):
        self.dash = dash
        self.loop: asyncio.AbstractEventLoop | None = None
        self.pending: dict[str, dict] = {}
        self._lock = threading.Lock()
        self.trust_until = 0.0          # "allow for 10 minutes" (never risky ones)

    # ---- state ---------------------------------------------------------

    def snapshot(self) -> dict:
        from . import hands
        with self._lock:
            items = [{"id": k, "what": v["what"], "risky": v["risky"]}
                     for k, v in self.pending.items()]
        left = max(0, int(self.trust_until - time.time()))
        return {"level": hands.level(), "pending": items, "trustLeft": left}

    def push(self) -> None:
        snap = self.snapshot()
        self.dash.emit("hands", snap)
        call = self._call()
        if call is not None:
            call.send({"t": "hands", "v": snap})

    def set_level(self, lvl: str) -> str:
        from . import hands
        v = hands.set_level(lvl)
        if v != "free":
            self.trust_until = 0.0
        self.push()
        return v

    def _call(self):
        c = getattr(self.dash, "call", None)
        return c if c is not None and not getattr(c, "closed", True) else None

    # ---- asking --------------------------------------------------------

    async def ask(self, what: str, tool: str = "", risky: bool = False) -> dict:
        if not risky and time.time() < self.trust_until:
            return {"allow": True, "by": "trusted"}
        self.loop = asyncio.get_running_loop()
        fut = self.loop.create_future()
        qid = uuid.uuid4().hex[:10]
        with self._lock:
            self.pending[qid] = {"what": what, "risky": risky, "fut": fut,
                                 "tool": tool, "at": time.time()}
        self.push()
        self._speak(f"Can I {what}?")
        try:
            return await asyncio.wait_for(asyncio.shield(fut), TIMEOUT_S)
        except asyncio.TimeoutError:
            return {"allow": False, "reason": "Nobody answered in two minutes, so it "
                    "was not done. Ask again when they are back."}
        finally:
            with self._lock:
                self.pending.pop(qid, None)
            self.push()

    def _speak(self, line: str) -> None:
        call = self._call()
        if call is not None:
            try:
                call.send({"t": "clone", "v": line})
                call._say(line)
            except Exception:                           # noqa: BLE001
                pass
            return
        voice = getattr(self.dash, "voice", None)
        if voice is not None:
            try:
                voice._enqueue(line, "reply")
            except Exception:                           # noqa: BLE001
                pass

    # ---- answering -----------------------------------------------------

    def answer(self, qid: str | None, allow: bool, minutes: int = 0,
               by: str = "window") -> bool:
        """Resolve one question (the oldest if qid is None). Thread-safe."""
        with self._lock:
            if not self.pending:
                return False
            if qid is None or qid not in self.pending:
                qid = min(self.pending, key=lambda k: self.pending[k]["at"])
            item = self.pending.get(qid)
        if item is None:
            return False
        if allow and minutes:
            self.trust_until = time.time() + 60 * min(int(minutes), 60)
        res = {"allow": bool(allow), "by": by}
        if not allow:
            res["reason"] = ("They said no. Do not do it, and do not try another way "
                             "around it; ask what they want instead.")
        fut = item["fut"]

        def settle():
            if not fut.done():
                fut.set_result(res)
        loop = self.loop
        if loop is not None and loop.is_running():
            loop.call_soon_threadsafe(settle)
        else:
            settle()
        return True

    def take_spoken(self, text: str, by: str = "voice") -> bool:
        """If a question is open and this is a yes or a no, it is the answer."""
        with self._lock:
            if not self.pending:
                return False
        from .hands import spoken_answer
        a = spoken_answer(text)
        if a is None:
            return False
        return self.answer(None, a, by=by)
