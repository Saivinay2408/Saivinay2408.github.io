"""
projects — everywhere you have worked, and what you were doing there.

Claude Code keeps one directory per project under ~/.claude/projects, named by
replacing every "/" in the path with "-". That name is **lossy and cannot be
reversed**: `-Users-you-Desktop-my-project` is as consistent with
`.../my/project` as with `.../my-project`, and guessing wrong means opening a
terminal in a directory that does not exist. The real path is read from the
`cwd` field inside a transcript instead, which is present on every record.

Sized against a real machine rather than a hypothetical one. On the laptop this
was written on there were ~2,700 transcripts and ~96% of them belonged to a
single project. Reading every file to build a menu takes about three seconds,
which is not a menu; reading the most recent handful per project takes about
twenty milliseconds, and beyond that nobody is scrolling. So the project list
reads one file per directory, and session lists are capped and sorted by
modification time.
"""
from __future__ import annotations

import json
import time
from datetime import datetime, timezone
from pathlib import Path

from .paths import PROJECTS

RECENT_SESSIONS = 40          # per project, newest first
HEAD_LINES = 400              # enough to reach a title; a transcript can be huge


def _head(path: Path, limit: int = HEAD_LINES):
    """Yield parsed records from the start of a transcript, bounded."""
    try:
        with path.open("r", encoding="utf-8", errors="replace") as f:
            for i, line in enumerate(f):
                if i >= limit:
                    return
                line = line.strip()
                if not line:
                    continue
                try:
                    yield json.loads(line)
                except ValueError:
                    continue
    except OSError:
        return


def _digest(path: Path) -> dict:
    """cwd, branch and a human label for one session, from its opening records."""
    cwd = branch = title = prompt = None
    for obj in _head(path):
        if cwd is None and obj.get("cwd"):
            cwd, branch = obj["cwd"], obj.get("gitBranch")
        if title is None and obj.get("type") in ("ai-title", "custom-title"):
            title = obj.get("aiTitle") or obj.get("customTitle")
        if prompt is None and obj.get("type") == "user":
            c = (obj.get("message") or {}).get("content")
            if isinstance(c, str) and c.strip() and not obj.get("isMeta"):
                prompt = " ".join(c.split())[:80]
        if cwd and title and prompt:
            break
    # Claude Code only names substantial sessions — about 3% of the whole
    # archive here, though most *recent* ones do have one. The first thing you
    # asked is a good label for the rest, and better than a UUID.
    return {"cwd": cwd, "branch": branch, "title": title or prompt or ""}


def _mtime(path: Path) -> float:
    try:
        return path.stat().st_mtime
    except OSError:
        return 0.0


def _iso(ts: float) -> str:
    return datetime.fromtimestamp(ts, timezone.utc).isoformat() if ts else ""


def list_projects(live_cwds: set[str] | None = None) -> list[dict]:
    """Every project with at least one transcript, most recently used first."""
    live = live_cwds or set()
    out = []
    try:
        dirs = [d for d in PROJECTS.iterdir() if d.is_dir()]
    except OSError:
        return []

    for d in dirs:
        files = list(d.glob("*.jsonl"))
        if not files:
            continue                      # a directory with no history is not a project
        newest = max(files, key=_mtime)
        info = _digest(newest)
        cwd = info["cwd"]
        if not cwd:
            continue
        exists = Path(cwd).is_dir()
        out.append({
            "slug": d.name,
            "cwd": cwd,
            "name": Path(cwd).name or cwd,
            "parent": str(Path(cwd).parent),
            "sessions": len(files),
            "lastActive": _iso(_mtime(newest)),
            "lastActiveTs": _mtime(newest),
            "branch": info["branch"] or "",
            "live": cwd in live,
            # A project can outlive its directory — moved, renamed, deleted.
            # Listing it and letting you click it would open a terminal that
            # immediately fails, so say so instead.
            "missing": not exists,
        })
    out.sort(key=lambda p: p["lastActiveTs"], reverse=True)
    return out


def list_sessions(cwd: str, limit: int = RECENT_SESSIONS,
                  live_ids: set[str] | None = None) -> list[dict]:
    """Recent sessions for one project, newest first, ready to resume."""
    from .paths import project_slug
    live = live_ids or set()
    d = PROJECTS / project_slug(cwd)
    try:
        files = sorted(d.glob("*.jsonl"), key=_mtime, reverse=True)[:limit]
    except OSError:
        return []

    now = time.time()
    out = []
    for f in files:
        info = _digest(f)
        ts = _mtime(f)
        out.append({
            "id": f.stem,
            "title": info["title"] or "(no messages)",
            "branch": info["branch"] or "",
            "lastActive": _iso(ts),
            "ago": _ago(now - ts),
            "live": f.stem in live,
            "empty": not info["title"],
        })
    return out


def recent_sessions(limit: int = 14, live_ids: set[str] | None = None) -> list[dict]:
    """The last sessions you had ANYWHERE, newest first.

    The per-project list answers "what was I doing here"; this one answers
    "what was I doing", which is the question you ask when the thing you want
    to reopen is in a repo you have not thought about since Tuesday.

    Only the newest `limit` transcripts are opened. Listing every directory and
    stat-ing its files is a few hundred syscalls even on a large archive;
    reading them is seconds, and this runs behind a click.
    """
    live = live_ids or set()
    files: list[Path] = []
    try:
        for d in PROJECTS.iterdir():
            if d.is_dir():
                files.extend(d.glob("*.jsonl"))
    except OSError:
        return []

    files.sort(key=_mtime, reverse=True)
    now = time.time()
    out = []
    for f in files[:limit]:
        info = _digest(f)
        cwd = info["cwd"]
        if not cwd:
            continue
        ts = _mtime(f)
        out.append({
            "id": f.stem,
            "title": info["title"] or "(no messages)",
            "cwd": cwd,
            "project": Path(cwd).name or cwd,
            "branch": info["branch"] or "",
            "lastActive": _iso(ts),
            "ago": _ago(now - ts),
            "live": f.stem in live,
            "empty": not info["title"],
        })
    return out


def _ago(seconds: float) -> str:
    """Short relative time. Menus are scanned, not read."""
    s = int(max(0, seconds))
    if s < 60:
        return "just now"
    if s < 3600:
        return f"{s // 60}m ago"
    if s < 86400:
        return f"{s // 3600}h ago"
    if s < 86400 * 7:
        return f"{s // 86400}d ago"
    return f"{s // (86400 * 7)}w ago"
