"""
`mem models` — the speech weights, from a terminal.

The window has a button for this and that is where most people will press it.
This exists for the two places a button cannot reach:

  the installer   a shell script has just created a virtualenv on a stranger's
                  machine and needs 365 MB of weights on disk BEFORE the app
                  opens, so the first thing they ever do is hold the space bar
                  and have it work.

  a headless box  `mem voice --no-voice`, a remote machine, someone who lives
                  in tmux. The weights are not a GUI concern.

Progress is drawn as a bar rather than printed per chunk, because this runs in
an installer whose whole output is meant to be four readable lines and not
thirteen hundred.
"""
from __future__ import annotations

import argparse
import shutil
import sys


def _bar(done: int, total: int, width: int = 28) -> str:
    filled = 0 if not total else min(width, int(width * done / total))
    return "[" + "#" * filled + "." * (width - filled) + "]"


def _mb(n: float) -> str:
    return f"{n / 1e6:.0f} MB"


def main(argv=None) -> int:
    from . import models

    p = argparse.ArgumentParser(
        prog="mem models",
        description="download the speech models, or say what is missing")
    p.add_argument("--fetch", action="store_true",
                   help="download whatever is missing")
    p.add_argument("--whisper", action="store_true",
                   help="also pre-fetch the transcriber (~480 MB), so the "
                        "first thing you say does not trigger it")
    p.add_argument("--quiet", action="store_true", help="no progress bar")
    args = p.parse_args(argv)

    st = models.status()

    if not args.fetch:
        print(f"models in {st['dir']}\n")
        for i in st["items"]:
            mark = "ok " if i["present"] else "-- "
            size = "present" if i["present"] else _mb(i["size"])
            print(f"  {mark} {i['what']:<44} {size:>9}")
        w = models.whisper_status()
        print(f"  {'ok ' if w['present'] else '-- '} "
              f"{'turning what you said into words':<44} "
              f"{'present' if w['present'] else '~' + str(w['mb']) + ' MB':>9}")
        if st["ready"]:
            print("\neverything the voice needs is here.")
            return 0
        # Exit 1 so a script can branch on it, and say the command rather than
        # describing it -- this is read by someone who wants to fix it now.
        print(f"\n{st['missing']} missing ({_mb(st['missingBytes'])}).\n"
              f"    mem models --fetch")
        return 1

    if st["ready"] and not (args.whisper and not models.whisper_status()["present"]):
        print("everything the voice needs is already here.")
        return 0

    room = models.free_space()
    if room and room < st["missingBytes"] * 1.1:
        print(f"not enough disk space: this needs about "
              f"{_mb(st['missingBytes'])} and there is {_mb(room)} free.",
              file=sys.stderr)
        return 1

    width = min(shutil.get_terminal_size((80, 24)).columns, 100)
    show = not args.quiet and sys.stderr.isatty()
    state = {"file": ""}

    def progress(name: str, done: int, total: int) -> None:
        if not show:
            return
        if name != state["file"]:
            # One line per file, finished lines left on screen. A single
            # rewritten line makes a ten-minute download look like nothing
            # happened four separate times.
            if state["file"]:
                sys.stderr.write("\n")
            state["file"] = name
        have = sum(i["size"] for i in models.status()["items"] if i["present"])
        line = (f"  {_bar(done, total)} {name[:26]:<26} "
                f"{_mb(have + done)} / {_mb(models.TOTAL_BYTES)}")
        sys.stderr.write("\r" + line[:width].ljust(min(width, len(line))))
        sys.stderr.flush()

    print(f"downloading {_mb(st['missingBytes'])} into {st['dir']}")
    report = models.fetch(on_progress=progress)
    if show and state["file"]:
        sys.stderr.write("\n")

    if args.whisper and report["ok"]:
        w = models.whisper_status()
        if not w["present"]:
            print(f"  getting the transcriber (~{w['mb']} MB)…")
            got = models.fetch_whisper()
            if not got["ok"]:
                # Not fatal: faster-whisper fetches this itself on first use.
                # The only thing lost is doing it now, where it is visible.
                print(f"  note: {got['error']} — it will download on first use.")

    if report["ok"]:
        print("done. hold space and talk.")
        return 0
    for f in report["failed"]:
        print(f"  {f['name']}: {f['error']}", file=sys.stderr)
    if report["cancelled"]:
        print("stopped. what downloaded is kept — run it again to resume.",
              file=sys.stderr)
    return 1
