"""
agents_ui — which coding agents this machine has, and what governs them.

Two questions the session header needs to answer, both of which have to be
asked of the machine rather than assumed:

  which agents are installed   so the picker can offer Claude, Codex or Gemini
                               and say "install" instead of failing later
  what rules are in force      the CLAUDE.md / AGENTS.md / GEMINI.md files that
                               shape every reply, global and per project

WHY RULES BELONG IN THIS PRODUCT PARTICULARLY
---------------------------------------------
A context file is the other half of what `mem` does. The vault injects what you
have said and decided; CLAUDE.md states the standing instructions. Together they
are the entire non-model input to a session, and until now the app showed one
and hid the other — so "why did it do that" had an answer sitting in a file the
window never mentioned.

Nothing here writes. Listing a rules file that does not exist yet is useful
(it tells you where to put one); creating it silently is not.
"""
from __future__ import annotations

import os
import shutil
import subprocess
from pathlib import Path

from .paths import CLAUDE_HOME

# name -> (binary, version flag, the context file it reads)
AGENTS = {
    "claude": {"bin": "claude", "label": "Claude Code",
               "rules": "CLAUDE.md",
               "install": "https://claude.com/claude-code",
               # Claude Code's installer is not a one-line npm command that is
               # safe to run for somebody, so this one links out instead of
               # offering a button that would have to lie about what it does.
               "installCmd": ""},
    "codex": {"bin": "codex", "label": "Codex",
              "rules": "AGENTS.md", "install": "npm i -g @openai/codex",
              "installCmd": "npm i -g @openai/codex"},
    "gemini": {"bin": "gemini", "label": "Gemini CLI",
               "rules": "GEMINI.md", "install": "npm i -g @google/gemini-cli",
               "installCmd": "npm i -g @google/gemini-cli"},
}

# Global rules live beside each agent's own config.
GLOBAL_RULES = {
    "claude": CLAUDE_HOME / "CLAUDE.md",
    "codex": Path(os.environ.get("CODEX_HOME", Path.home() / ".codex")) / "AGENTS.md",
    "gemini": Path(os.environ.get("GEMINI_HOME", Path.home() / ".gemini")) / "GEMINI.md",
}

VERSION_TIMEOUT = 4


def _version(binary: str) -> str:
    try:
        p = subprocess.run([binary, "--version"], capture_output=True,
                           text=True, timeout=VERSION_TIMEOUT)
        if p.returncode != 0:
            return ""
        first = (p.stdout or p.stderr).strip().splitlines()
        return first[0].strip()[:40] if first else ""
    except (OSError, subprocess.SubprocessError):
        return ""


def installed(probe_version: bool = True) -> list[dict]:
    """Every supported agent, with whether it is actually here.

    The version probe runs a subprocess per agent, so it is optional: the
    picker wants it, a 2-second roster poll does not.
    """
    out = []
    for name, spec in AGENTS.items():
        path = shutil.which(spec["bin"])
        out.append({
            "name": name,
            "label": spec["label"],
            "installed": bool(path),
            "path": path or "",
            "version": _version(spec["bin"]) if (path and probe_version) else "",
            "install": spec["install"],
            # Whether the app can offer to do it, and what it would run. The
            # command is sent to the UI rather than kept secret because
            # "install this for me" has to be a thing you can read first.
            "installCmd": spec.get("installCmd", "") if not path else "",
            "needsNpm": bool(spec.get("installCmd")) and not shutil.which("npm"),
            "rulesFile": spec["rules"],
        })
    return out


def rules(cwd: str | Path | None = None) -> list[dict]:
    """The context files in force: global for every agent, plus this project's.

    Files that do not exist are listed with `exists: false` rather than hidden.
    "There is no project CLAUDE.md here" is the answer to a real question, and
    an empty list would make it look like the app had not looked.
    """
    out = []
    for name, path in GLOBAL_RULES.items():
        out.append({
            "scope": "global", "agent": name,
            "name": f"Global {AGENTS[name]['rules']}",
            "path": str(path), "exists": path.is_file(),
            "bytes": path.stat().st_size if path.is_file() else 0,
        })
    if cwd:
        root = Path(cwd)
        seen = set()
        for name, spec in AGENTS.items():
            fname = spec["rules"]
            if fname in seen:
                continue                   # AGENTS.md is shared by more than one
            seen.add(fname)
            path = root / fname
            out.append({
                "scope": "project", "agent": name,
                "name": f"Project {fname}",
                "path": str(path), "exists": path.is_file(),
                "bytes": path.stat().st_size if path.is_file() else 0,
            })
    return out


def read_rules(path: str | Path, max_bytes: int = 100_000) -> dict:
    """Show a rules file. Read-only, capped, and never created on demand."""
    p = Path(path)
    try:
        text = p.read_text(encoding="utf-8", errors="replace")
    except OSError as e:
        return {"ok": False, "error": str(e), "text": "", "path": str(p)}
    return {"ok": True, "error": "", "path": str(p),
            "text": text[:max_bytes], "truncated": len(text) > max_bytes}


def snapshot(cwd: str | Path | None = None, probe_version: bool = True) -> dict:
    return {"agents": installed(probe_version), "rules": rules(cwd)}
