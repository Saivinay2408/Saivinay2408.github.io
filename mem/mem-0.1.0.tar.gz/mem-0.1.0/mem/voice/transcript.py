"""
transcript — what each session actually did, read from the record it keeps.

Claude Code appends a JSONL transcript per session at
  ~/.claude/projects/<cwd-slug>/<session-id>.jsonl
and it is typed. A line is a `user` turn or an `assistant` turn; a content block
is `text`, `thinking`, `tool_use` (with the real tool name and arguments) or
`tool_result`; a `system` line with subtype `turn_duration` marks end of turn;
`isSidechain` marks a subagent. Token usage rides along on every assistant
message.

This module replaces voice/tmux_session.py, which reconstructed the same
information by regex-matching `tmux capture-pane` output. That approach could
not reliably tell an assistant sentence from the echo of your own prompt, from
the contents of a file being displayed, or from a status line repainting — and
whatever it got wrong got spoken out loud. Here those are different *types*, so
the distinction is not a judgement call.

One deliberate omission: tool_result content is counted but never carried. The
terminal pane is where you read output. Nothing downstream of this module can
speak a file's contents by accident, because nothing downstream is ever given
them.
"""
from __future__ import annotations

import json
import threading
import time
from pathlib import Path
from typing import Callable, Iterator

# A tool_use whose caller is not "direct" was issued by a subagent. Worth
# distinguishing: "searching the web" from a subagent three levels down is noise,
# not progress you asked about.
DIRECT = "direct"


def _text_of(content) -> str:
    """Flatten a message's text blocks. Thinking and tools are handled separately."""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        return "".join(b.get("text", "") for b in content
                       if isinstance(b, dict) and b.get("type") == "text")
    return ""


def parse_line(obj: dict) -> Iterator[dict]:
    """One transcript record -> zero or more typed events.

    Kept a module-level function rather than a method so it can be unit-tested
    against fixture lines without a file, a session, or a running dashboard.
    """
    kind = obj.get("type")
    side = bool(obj.get("isSidechain"))
    msg = obj.get("message") or {}
    content = msg.get("content")

    if kind == "user":
        # Two very different things arrive as role "user": what you actually
        # typed (a plain string), and tool results the harness feeds back (a
        # list of blocks). Only the first is a prompt.
        if isinstance(content, str):
            text = content.strip()
            if text and not obj.get("isMeta"):
                yield {"kind": "user", "text": text, "sidechain": side}
        elif isinstance(content, list):
            for b in content:
                if not isinstance(b, dict) or b.get("type") != "tool_result":
                    continue
                raw = b.get("content")
                size = len(raw if isinstance(raw, str) else json.dumps(raw or ""))
                yield {"kind": "tool_result", "sidechain": side,
                       "ok": not b.get("is_error"),
                       "id": b.get("tool_use_id", ""),
                       "bytes": size}          # size only — never the content

    elif kind == "assistant":
        for b in (content or []):
            if not isinstance(b, dict):
                continue
            bt = b.get("type")
            if bt == "tool_use":
                caller = (b.get("caller") or {}).get("type", DIRECT)
                yield {"kind": "tool", "sidechain": side,
                       "name": b.get("name", "?"),
                       "input": b.get("input") or {},
                       "id": b.get("id", ""),
                       "direct": caller == DIRECT}
            elif bt == "thinking" and b.get("thinking"):
                yield {"kind": "thinking", "sidechain": side,
                       "text": b["thinking"]}
        text = _text_of(content).strip()
        if text:
            yield {"kind": "assistant", "text": text, "sidechain": side}
        usage = msg.get("usage") or {}
        if usage:
            yield {"kind": "usage", "sidechain": side,
                   "model": msg.get("model", ""),
                   "input": usage.get("input_tokens", 0) or 0,
                   "output": usage.get("output_tokens", 0) or 0,
                   "cacheRead": usage.get("cache_read_input_tokens", 0) or 0,
                   "cacheCreate": usage.get("cache_creation_input_tokens", 0) or 0}

    elif kind == "system" and obj.get("subtype") == "turn_duration":
        # An explicit end-of-turn marker, so nothing here has to guess a turn
        # boundary from silence the way pane-scraping had to.
        yield {"kind": "turn_end", "durationMs": obj.get("durationMs", 0),
               "sidechain": side}


class TranscriptTail:
    """Follows one session's JSONL and yields events as they are appended.

    Polling rather than watching the filesystem: the file is appended to many
    times a second during a turn, poll intervals are already the natural batch
    boundary, and it behaves identically on every platform. There is no event
    to miss — the file is the record.
    """

    def __init__(self, path: Path, from_start: bool = False):
        self.path = Path(path)
        self.offset = 0
        self.buf = ""
        self.started = from_start
        self._opened = False

    def _sync(self) -> None:
        """Attach to the file, and re-attach if it was replaced or truncated."""
        try:
            size = self.path.stat().st_size
        except OSError:
            self._opened = False
            return
        if not self._opened:
            self._opened = True
            # An adopted session may already have hours of history. Replaying it
            # would mean narrating work that finished before you opened the pane,
            # so unless we were asked for the whole file, start at the end.
            self.offset = 0 if self.started else size
            self.buf = ""
        elif size < self.offset:
            self.offset = 0                     # truncated/rotated: start over
            self.buf = ""

    def poll(self) -> list[dict]:
        """Return every event appended since the last call. Never raises."""
        self._sync()
        if not self._opened:
            return []
        events: list[dict] = []
        try:
            with self.path.open("r", encoding="utf-8", errors="replace") as f:
                f.seek(self.offset)
                chunk = f.read()
                self.offset = f.tell()
        except OSError:
            return []
        if not chunk:
            return []
        self.buf += chunk
        # A record may be half-written at the moment we read. Only complete
        # lines are parsed; the remainder stays buffered for the next poll.
        *lines, self.buf = self.buf.split("\n")
        for line in lines:
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
            except ValueError:
                continue
            events.extend(parse_line(obj))
        return events


class TranscriptWatcher:
    """Tails many sessions at once and hands events to one callback.

    Runs on its own thread. The callback receives (pane_id, event) and must not
    block — narration and accounting both do only cheap in-memory work.
    """

    def __init__(self, on_event: Callable[[str, dict], None], interval: float = 0.35):
        self.on_event = on_event
        self.interval = interval
        self._tails: dict[str, TranscriptTail] = {}
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    def watch(self, key: str, path: Path, from_start: bool = False) -> None:
        with self._lock:
            if key not in self._tails:
                self._tails[key] = TranscriptTail(path, from_start=from_start)

    def unwatch(self, key: str) -> None:
        with self._lock:
            self._tails.pop(key, None)

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()

    def _run(self) -> None:
        while not self._stop.is_set():
            with self._lock:
                items = list(self._tails.items())
            for key, tail in items:
                for ev in tail.poll():
                    try:
                        self.on_event(key, ev)
                    except Exception:              # noqa: BLE001 — a bad consumer
                        pass                       # must not stop the stream
            time.sleep(self.interval)
