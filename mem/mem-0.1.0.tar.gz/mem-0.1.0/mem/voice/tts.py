"""tts — sentence-streamed local text-to-speech, interruptible for barge-in.

Kokoro (local ONNX, ~82M params) is the default engine; macOS `say` is the
always-available fallback so the loop can still speak with zero model
weights downloaded. Two more engines (a local voice clone via XTTS, and an
HTTP fallback via ElevenLabs) are optional and only imported if selected.

Every engine's heavy import is deferred into its own `__init__`/method, never
done at module import time, so `import mem.voice.tts` succeeds with
none of these installed.
"""
from __future__ import annotations

import json
import queue
import re
import subprocess
import threading
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import numpy as np

DEFAULT_MODELS_DIR = Path(__file__).resolve().parent.parent / "models"
SENT_RE = re.compile(r"(?<=[.!?])\s+|\n+")


def _models_dir(models_dir: str | Path | None) -> Path:
    return Path(models_dir) if models_dir else DEFAULT_MODELS_DIR


class SentenceStream:
    """Accumulates LLM text deltas and emits complete sentences early, so the
    first sentence can be speaking while the rest of the reply is still
    generating."""

    def __init__(self, min_len: int = 6):
        self.buf = ""
        self.min_len = min_len

    def feed(self, delta: str) -> list[str]:
        self.buf += delta
        out = []
        while True:
            # split at the first boundary past min_len; a too-early boundary
            # must not block later ones, or a whole reply gets held to flush
            cut = None
            for m in SENT_RE.finditer(self.buf):
                if m.start() >= self.min_len:
                    cut = m
                    break
            if not cut:
                break
            out.append(self.buf[:cut.start()].strip())
            self.buf = self.buf[cut.end():]
        return out

    def flush(self) -> list[str]:
        rest = self.buf.strip()
        self.buf = ""
        return [rest] if rest else []


class _ConfigWatcher:
    """Shared re-read-on-mtime-change logic: a voice engine's tunables live
    in a small JSON file, re-read cheaply per sentence so an agent (or the
    user) can edit them live and hear the very next sentence spoken the new
    way, no restart required."""

    def __init__(self, config_path: Path):
        self.config_path = config_path
        self._mtime = 0.0

    def read(self) -> dict:
        try:
            m = self.config_path.stat().st_mtime
        except OSError:
            return {}
        if m == self._mtime:
            return {}
        self._mtime = m
        try:
            return json.loads(self.config_path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return {}


class KokoroTTS:
    """Local ONNX TTS. Voice params (`speed`, `voice`) live in a small JSON
    config beside the model and are re-read per sentence on an mtime check,
    so voice tuning is a file edit, not a restart."""

    def __init__(self, voice: str = "af_bella", speed: float = 1.0,
                models_dir: str | Path | None = None,
                config_path: str | Path | None = None):
        from kokoro_onnx import Kokoro
        models_dir = _models_dir(models_dir)
        self.k = Kokoro(str(models_dir / "kokoro-v1.0.onnx"),
                        str(models_dir / "voices-v1.0.bin"))
        self.voice, self.speed = voice, speed
        self._cfg = _ConfigWatcher(Path(config_path) if config_path
                                   else models_dir.parent / "voice_config.json")

    def _load_config(self):
        cfg = self._cfg.read()
        if not cfg:
            return
        try:
            self.speed = min(2.0, max(0.6, float(cfg.get("speed", self.speed))))
        except (TypeError, ValueError):
            pass
        v = cfg.get("voice")
        if isinstance(v, str) and v.strip():
            self.voice = v.strip()

    def synth(self, text: str) -> tuple["np.ndarray", int]:
        self._load_config()
        try:
            samples, sr = self.k.create(text, voice=self.voice, speed=self.speed, lang="en-us")
        except Exception:                       # bad voice name -> fall back, keep talking
            self.voice = "af_bella"
            samples, sr = self.k.create(text, voice=self.voice, speed=self.speed, lang="en-us")
        import numpy as np
        return samples.astype(np.float32), sr


class XTTSClonedTTS:
    """Optional local zero-shot voice clone (Coqui XTTS-v2) from a reference
    clip. CPU-only by design: this model's autoregressive loop measures
    materially slower on GPU/MPS for short single-sentence synthesis than on
    CPU for the model sizes this project targets. Much slower per sentence
    than Kokoro, traded for higher voice fidelity when a user opts in."""

    SR = 24000

    def __init__(self, speaker_wav: str = "speaker_ref.wav",
                models_dir: str | Path | None = None,
                config_path: str | Path | None = None):
        import os
        os.environ.setdefault("COQUI_TOS_AGREED", "1")
        from TTS.api import TTS
        self.tts = TTS("tts_models/multilingual/multi-dataset/xtts_v2").to("cpu")
        models_dir = _models_dir(models_dir)
        self.speaker_wav = str(models_dir / speaker_wav)
        self._cfg = _ConfigWatcher(Path(config_path) if config_path
                                   else models_dir.parent / "voice_config.json")

    def _load_config(self):
        cfg = self._cfg.read()
        v = cfg.get("xtts_speaker_wav") if cfg else None
        if isinstance(v, str) and v.strip():
            self.speaker_wav = str(_models_dir(None) / v.strip())

    def synth(self, text: str) -> tuple["np.ndarray", int]:
        self._load_config()
        wav = self.tts.tts(text=text, speaker_wav=self.speaker_wav, language="en")
        import numpy as np
        return np.asarray(wav, dtype=np.float32), self.SR


class ElevenLabsTTS:
    """Optional HTTP TTS fallback. Requests raw PCM (no mp3 decode
    dependency) at 16k. The API key is read from a `.env` file beside the
    package or the `ELEVENLABS_API_KEY` environment variable -- never
    hardcoded, never committed."""

    API_URL = "https://api.elevenlabs.io/v1/text-to-speech/{voice_id}"
    SR = 16000

    def __init__(self, voice_id: str = "21m00Tcm4TlvDq8ikWAM",
                model_id: str = "eleven_turbo_v2_5",
                env_path: str | Path | None = None,
                config_path: str | Path | None = None):
        import os
        env_path = Path(env_path) if env_path else Path(__file__).resolve().parent.parent / ".env"
        key = None
        if env_path.exists():
            for line in env_path.read_text().splitlines():
                if line.startswith("ELEVENLABS_API_KEY="):
                    key = line.split("=", 1)[1].strip()
                    break
        self.api_key = key or os.environ.get("ELEVENLABS_API_KEY")
        if not self.api_key:
            raise RuntimeError(f"ELEVENLABS_API_KEY not found in {env_path} or the environment")
        self.voice_id = voice_id
        self.model_id = model_id
        self._cfg = _ConfigWatcher(Path(config_path) if config_path
                                   else DEFAULT_MODELS_DIR.parent / "voice_config.json")

    def _load_config(self):
        cfg = self._cfg.read()
        v = cfg.get("elevenlabs_voice_id") if cfg else None
        if isinstance(v, str) and v.strip():
            self.voice_id = v.strip()

    def synth(self, text: str) -> tuple["np.ndarray", int]:
        import requests
        import numpy as np
        self._load_config()
        r = requests.post(
            self.API_URL.format(voice_id=self.voice_id),
            headers={"xi-api-key": self.api_key, "Content-Type": "application/json"},
            params={"output_format": "pcm_16000"},
            json={"text": text, "model_id": self.model_id},
            timeout=30,
        )
        r.raise_for_status()
        samples = np.frombuffer(r.content, dtype="int16").astype(np.float32) / 32768.0
        return samples, self.SR


class SayTTS:
    """macOS built-in fallback: robotic but bulletproof -- no model weights,
    no network, always available on a Mac."""

    def synth(self, text: str):
        return text, -1     # sentinel: played via the `say` subprocess directly


class PlaybackRef:
    """Timestamped record of what the speaker is emitting right now,
    resampled to 16k. A caller's echo-cancellation logic (not implemented in
    this module) correlates mic input against this window to distinguish
    "the speaker's own playback, heard through the mic" from a real voice --
    threshold-only VAD can never make that distinction, because TTS output
    is acoustically speech too; only the playback side knows what it played.
    """

    def __init__(self):
        self.lock = threading.Lock()
        self.t_start = 0.0
        self.samples16k = None
        self.last_end = 0.0

    def set_clip(self, samples: "np.ndarray", sr: int):
        import time
        import numpy as np
        if sr != 16000:
            n = int(len(samples) * 16000 / sr)
            x = np.interp(np.linspace(0, len(samples) - 1, n),
                          np.arange(len(samples)), samples)
        else:
            x = samples
        with self.lock:
            self.samples16k = x.astype(np.float32)
            self.t_start = time.time()

    def clear(self):
        import time
        with self.lock:
            self.samples16k = None
            self.last_end = time.time()

    def window(self, t_from: float, t_to: float):
        """Playback audio between two wall-clock times (None if not playing)."""
        with self.lock:
            if self.samples16k is None:
                return None
            a = max(0, int((t_from - self.t_start) * 16000))
            b = max(0, int((t_to - self.t_start) * 16000))
            if b <= a or a >= len(self.samples16k):
                return None
            return self.samples16k[a:min(b, len(self.samples16k))]


class Speaker:
    """Serial playback queue with a hard stop for barge-in."""

    def __init__(self, engine):
        self.engine = engine
        self.q: queue.Queue = queue.Queue()
        self.stop_flag = threading.Event()
        self.playing = threading.Event()
        self.ref = PlaybackRef()
        # `say` gives no playback reference to correlate against, so that
        # mode is half-duplex: the mic side must not listen while it speaks.
        self.half_duplex = isinstance(engine, SayTTS)
        self._say_proc = None
        self._worker = threading.Thread(target=self._run, daemon=True)
        self._worker.start()

    def speak(self, text: str):
        if text.strip():
            self.q.put(text.strip())

    def _run(self):
        while True:
            text = self.q.get()
            if self.stop_flag.is_set():
                continue
            self.playing.set()
            try:
                out = self.engine.synth(text)
                if out[1] == -1:                       # `say` fallback: no reference,
                    self._say_proc = subprocess.Popen(["say", out[0]])  # no sounddevice needed
                    self._say_proc.wait()
                    self._say_proc = None
                else:
                    import sounddevice as sd            # only the real-audio path needs this
                    samples, sr = out
                    self.ref.set_clip(samples, sr)     # correlated against, if wired up
                    sd.play(samples, sr)
                    while sd.get_stream().active:
                        if self.stop_flag.is_set():
                            sd.stop()
                            break
                        sd.sleep(30)
                    self.ref.clear()
            except Exception:                          # noqa: BLE001 -- voice must not crash
                pass
            finally:
                if self.q.empty():
                    self.playing.clear()

    def stop(self):
        """Barge-in: silence NOW."""
        self.ref.clear()
        self.stop_flag.set()
        try:
            import sounddevice as sd
            sd.stop()
        except Exception:                              # noqa: BLE001
            pass
        if self._say_proc:
            self._say_proc.kill()
        while not self.q.empty():
            try:
                self.q.get_nowait()
            except queue.Empty:
                break
        self.playing.clear()

    def resume(self):
        self.stop_flag.clear()

    @property
    def busy(self) -> bool:
        return self.playing.is_set() or not self.q.empty()
