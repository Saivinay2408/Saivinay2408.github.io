"""tts — sentence-streamed local text-to-speech, interruptible for barge-in.

Kokoro (local ONNX, ~82M params) is the default engine; macOS `say` is the
always-available fallback so the loop can still speak with zero model
weights downloaded. Two more engines (a local voice clone via XTTS, and an
HTTP fallback via ElevenLabs) are optional and only imported if selected.

Every engine's heavy import is deferred into its own `__init__`/method, never
done at module import time, so `import mem.voice.tts` succeeds with
none of these installed.
"""
from __future__ import annotations

import json
import queue
import re
import subprocess
import threading
import time
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import numpy as np

DEFAULT_MODELS_DIR = Path(__file__).resolve().parent.parent / "models"
SENT_RE = re.compile(r"(?<=[.!?])\s+|\n+")


def _models_dir(models_dir: str | Path | None) -> Path:
    return Path(models_dir) if models_dir else DEFAULT_MODELS_DIR


class SentenceStream:
    """Accumulates LLM text deltas and emits complete sentences early, so the
    first sentence can be speaking while the rest of the reply is still
    generating."""

    def __init__(self, min_len: int = 6):
        self.buf = ""
        self.min_len = min_len

    def feed(self, delta: str) -> list[str]:
        self.buf += delta
        out = []
        while True:
            # split at the first boundary past min_len; a too-early boundary
            # must not block later ones, or a whole reply gets held to flush
            cut = None
            for m in SENT_RE.finditer(self.buf):
                if m.start() >= self.min_len:
                    cut = m
                    break
            if not cut:
                break
            out.append(self.buf[:cut.start()].strip())
            self.buf = self.buf[cut.end():]
        return out

    def flush(self) -> list[str]:
        rest = self.buf.strip()
        self.buf = ""
        return [rest] if rest else []


class _ConfigWatcher:
    """Shared re-read-on-mtime-change logic: a voice engine's tunables live
    in a small JSON file, re-read cheaply per sentence so an agent (or the
    user) can edit them live and hear the very next sentence spoken the new
    way, no restart required."""

    def __init__(self, config_path: Path):
        self.config_path = config_path
        self._mtime = 0.0

    def read(self) -> dict:
        try:
            m = self.config_path.stat().st_mtime
        except OSError:
            return {}
        if m == self._mtime:
            return {}
        self._mtime = m
        try:
            return json.loads(self.config_path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return {}


def _kokoro_leaving_room(model: str, voices: str):
    """Kokoro, told not to take every core.

    onnxruntime defaults to one thread per core, so synthesizing the next
    sentence saturates the machine -- including whatever has to keep the
    speakers fed while the current sentence is still playing. That starvation
    is audible, and it is the reason a reply crackles exactly when it is
    longest.

    Measured here: 10 threads 0.61s a sentence, 8 threads 0.63s. Three percent,
    for two cores that stay out of the audio path.

    Returns None on any failure -- a private attribute on someone else's class
    is not something to be certain about, and the caller falls back to the
    ordinary constructor.
    """
    try:
        import os
        import onnxruntime as ort
        from kokoro_onnx import Kokoro
        so = ort.SessionOptions()
        so.log_severity_level = 3
        so.intra_op_num_threads = max(1, (os.cpu_count() or 4) - 2)
        sess = ort.InferenceSession(model, so, providers=["CPUExecutionProvider"])
        return Kokoro.from_session(sess, voices)
    except Exception:                                   # noqa: BLE001
        return None


class KokoroTTS:
    """Local ONNX TTS. Voice params (`speed`, `voice`) live in a small JSON
    config beside the model and are re-read per sentence on an mtime check,
    so voice tuning is a file edit, not a restart."""

    def __init__(self, voice: str = "af_bella", speed: float = 1.0,
                models_dir: str | Path | None = None,
                config_path: str | Path | None = None):
        from kokoro_onnx import Kokoro
        models_dir = _models_dir(models_dir)
        model = str(models_dir / "kokoro-v1.0.onnx")
        voices = str(models_dir / "voices-v1.0.bin")
        self.k = _kokoro_leaving_room(model, voices) or Kokoro(model, voices)
        self.voice, self.speed = voice, speed
        # The network on the GPU when it can be (gpu.py): same phonemes, same
        # voice, about three times faster. Weights not here yet -> fetch them
        # in the background and switch over when they land.
        from . import gpu
        self.gpu = gpu.accelerate_kokoro(self.k)
        if not self.gpu and gpu.available():
            gpu.prefetch(on_done=self._upgrade)
        self._cfg = _ConfigWatcher(Path(config_path) if config_path
                                   else models_dir.parent / "voice_config.json")

    def _upgrade(self):
        from . import gpu
        self.gpu = gpu.accelerate_kokoro(self.k)

    def _load_config(self):
        cfg = self._cfg.read()
        if not cfg:
            return
        try:
            self.speed = min(2.0, max(0.6, float(cfg.get("speed", self.speed))))
        except (TypeError, ValueError):
            pass
        v = cfg.get("voice")
        if isinstance(v, str) and v.strip():
            self.voice = v.strip()

    def synth(self, text: str) -> tuple["np.ndarray", int]:
        self._load_config()
        try:
            samples, sr = self.k.create(text, voice=self.voice, speed=self.speed, lang="en-us")
        except Exception:                       # bad voice name -> fall back, keep talking
            self.voice = "af_bella"
            samples, sr = self.k.create(text, voice=self.voice, speed=self.speed, lang="en-us")
        import numpy as np
        return samples.astype(np.float32), sr


class XTTSClonedTTS:
    """Optional local zero-shot voice clone (Coqui XTTS-v2) from a reference
    clip. CPU-only by design: this model's autoregressive loop measures
    materially slower on GPU/MPS for short single-sentence synthesis than on
    CPU for the model sizes this project targets. Much slower per sentence
    than Kokoro, traded for higher voice fidelity when a user opts in."""

    SR = 24000

    def __init__(self, speaker_wav: str = "speaker_ref.wav",
                models_dir: str | Path | None = None,
                config_path: str | Path | None = None):
        import os
        os.environ.setdefault("COQUI_TOS_AGREED", "1")
        from TTS.api import TTS
        self.tts = TTS("tts_models/multilingual/multi-dataset/xtts_v2").to("cpu")
        models_dir = _models_dir(models_dir)
        self.speaker_wav = str(models_dir / speaker_wav)
        self._cfg = _ConfigWatcher(Path(config_path) if config_path
                                   else models_dir.parent / "voice_config.json")

    def _load_config(self):
        cfg = self._cfg.read()
        v = cfg.get("xtts_speaker_wav") if cfg else None
        if isinstance(v, str) and v.strip():
            self.speaker_wav = str(_models_dir(None) / v.strip())

    def synth(self, text: str) -> tuple["np.ndarray", int]:
        self._load_config()
        wav = self.tts.tts(text=text, speaker_wav=self.speaker_wav, language="en")
        import numpy as np
        return np.asarray(wav, dtype=np.float32), self.SR


class ElevenLabsTTS:
    """Optional HTTP TTS fallback. Requests raw PCM (no mp3 decode
    dependency) at 16k. The API key is read from a `.env` file beside the
    package or the `ELEVENLABS_API_KEY` environment variable -- never
    hardcoded, never committed."""

    API_URL = "https://api.elevenlabs.io/v1/text-to-speech/{voice_id}"
    SR = 16000

    def __init__(self, voice_id: str = "21m00Tcm4TlvDq8ikWAM",
                model_id: str = "eleven_turbo_v2_5",
                env_path: str | Path | None = None,
                config_path: str | Path | None = None):
        import os
        env_path = Path(env_path) if env_path else Path(__file__).resolve().parent.parent / ".env"
        key = None
        if env_path.exists():
            for line in env_path.read_text().splitlines():
                if line.startswith("ELEVENLABS_API_KEY="):
                    key = line.split("=", 1)[1].strip()
                    break
        self.api_key = key or os.environ.get("ELEVENLABS_API_KEY")
        if not self.api_key:
            raise RuntimeError(f"ELEVENLABS_API_KEY not found in {env_path} or the environment")
        self.voice_id = voice_id
        self.model_id = model_id
        self._cfg = _ConfigWatcher(Path(config_path) if config_path
                                   else DEFAULT_MODELS_DIR.parent / "voice_config.json")

    def _load_config(self):
        cfg = self._cfg.read()
        v = cfg.get("elevenlabs_voice_id") if cfg else None
        if isinstance(v, str) and v.strip():
            self.voice_id = v.strip()

    def synth(self, text: str) -> tuple["np.ndarray", int]:
        import requests
        import numpy as np
        self._load_config()
        r = requests.post(
            self.API_URL.format(voice_id=self.voice_id),
            headers={"xi-api-key": self.api_key, "Content-Type": "application/json"},
            params={"output_format": "pcm_16000"},
            json={"text": text, "model_id": self.model_id},
            timeout=30,
        )
        r.raise_for_status()
        samples = np.frombuffer(r.content, dtype="int16").astype(np.float32) / 32768.0
        return samples, self.SR


class SayTTS:
    """macOS built-in fallback: robotic but bulletproof -- no model weights,
    no network, always available on a Mac."""

    def synth(self, text: str):
        return text, -1     # sentinel: played via the `say` subprocess directly


class PlaybackRef:
    """Timestamped record of what the speaker is emitting right now,
    resampled to 16k. A caller's echo-cancellation logic (not implemented in
    this module) correlates mic input against this window to distinguish
    "the speaker's own playback, heard through the mic" from a real voice --
    threshold-only VAD can never make that distinction, because TTS output
    is acoustically speech too; only the playback side knows what it played.
    """

    def __init__(self):
        self.lock = threading.Lock()
        self.t_start = 0.0
        self.samples16k = None
        self.last_end = 0.0

    def set_clip(self, samples: "np.ndarray", sr: int):
        import time
        import numpy as np
        if sr != 16000:
            n = int(len(samples) * 16000 / sr)
            x = np.interp(np.linspace(0, len(samples) - 1, n),
                          np.arange(len(samples)), samples)
        else:
            x = samples
        with self.lock:
            self.samples16k = x.astype(np.float32)
            self.t_start = time.time()

    def clear(self):
        import time
        with self.lock:
            self.samples16k = None
            self.last_end = time.time()

    def window(self, t_from: float, t_to: float):
        """Playback audio between two wall-clock times (None if not playing)."""
        with self.lock:
            if self.samples16k is None:
                return None
            a = max(0, int((t_from - self.t_start) * 16000))
            b = max(0, int((t_to - self.t_start) * 16000))
            if b <= a or a >= len(self.samples16k):
                return None
            return self.samples16k[a:min(b, len(self.samples16k))]


# ---- playback tuning ----------------------------------------------------
#
# Measured on the machine this was written on, not guessed. See _shape and
# Speaker for what each one is defending against.

FADE_MS = 6.0             # ramp at each clip edge, so an edge cannot click
OUT_LATENCY_S = 0.15      # PortAudio's own buffer: the slack that rides out a
                          # busy CPU without the speakers running dry
PREFETCH = 3              # sentences synthesized ahead of the speakers
WRITE_CHUNK_MS = 20.0     # how often the write loop can notice a barge-in


def _shape(samples, sr: int):
    """Make one clip safe to hand to a speaker. Two guards, both cheap.

    A RAMP AT EACH EDGE. A waveform that starts or ends away from zero is a
    step, and a step is a click. Kokoro's clips happen to begin and end at
    silence already (measured: |first| and |last| below 0.0005), which is
    exactly why this is worth having anyway -- it costs nothing until an
    engine, a voice, or a config change makes it matter.

    A PEAK GUARD. Anything past full scale is clipped by the device into harsh
    broadband noise, which is what "static" sounds like. Kokoro peaks around
    0.54, so again this never fires for it today.
    """
    import numpy as np
    x = np.asarray(samples, dtype=np.float32)
    if not len(x):
        return x
    k = min(len(x) // 2, int(sr * FADE_MS / 1000.0))
    if k > 0:
        x = x.copy()
        ramp = np.linspace(0.0, 1.0, k, dtype=np.float32)
        x[:k] *= ramp
        x[-k:] *= ramp[::-1]
    peak = float(np.abs(x).max())
    if peak > 1.0:
        x = x / peak
    return x


class Speaker:
    """A sentence queue, and one output stream that stays open.

    WHY THE STREAM IS NOT REOPENED PER SENTENCE
    -------------------------------------------
    It used to be `sd.play(samples, sr)` once per sentence, which opens a
    device stream, plays, and closes it. Three things came out of that, all
    audible, and all reported as "clicks and static":

      a click at every boundary   the speakers run at 44100 and Kokoro
                                  produces 24000, so every sentence
                                  renegotiated the device format -- dozens of
                                  times in one long reply

      a gap at every boundary     synthesis and playback were serial: say a
                                  sentence, THEN start synthesizing the next.
                                  Measured 0.27-1.21s of silence dropped into
                                  the middle of a reply, every reply

      dropouts under load         sd.play drives the device from a Python
                                  callback that has to run every few
                                  milliseconds. While Kokoro or whisper has
                                  every core busy, it does not run in time and
                                  the device plays whatever is left in the
                                  buffer

    So: one stream, opened once and held. A generator thread that runs ahead
    of the speakers, so the next sentence is ready before the current one
    ends. And the blocking write API rather than a callback, which puts the
    slack that absorbs a busy CPU in PortAudio's own buffer in C instead of in
    a Python function with a millisecond deadline.

    Measured under eight compute-bound threads, playing a 3.0s clip: the
    callback path delivered 1.05s of it, the blocking path delivered 3.00s.
    """

    def __init__(self, engine):
        self.engine = engine
        self.q: queue.Queue = queue.Queue()                 # text to synthesize
        self._audio: queue.Queue = queue.Queue(maxsize=PREFETCH)
        self.stop_flag = threading.Event()
        self.playing = threading.Event()
        self._synth = threading.Event()
        self.ref = PlaybackRef()
        # `say` gives no playback reference to correlate against, so that
        # mode is half-duplex: the mic side must not listen while it speaks.
        self.half_duplex = isinstance(engine, SayTTS)
        self._say_proc = None
        self._stream = None
        self._sr = 0
        self._gen = threading.Thread(target=self._generate, daemon=True)
        self._gen.start()
        self._worker = threading.Thread(target=self._run, daemon=True)
        self._worker.start()

    def speak(self, text: str):
        if text.strip():
            self.q.put(text.strip())

    # ---- synthesis, one sentence ahead ----------------------------------

    def _generate(self):
        """Turn queued text into audio before the speakers need it.

        The queue this feeds is bounded, on purpose. Unbounded, a long reply
        would synthesize eight sentences that a barge-in then throws away;
        bounded at PREFETCH it stays exactly far enough ahead that the write
        loop never waits.
        """
        while True:
            text = self.q.get()
            if self.stop_flag.is_set():
                continue
            self._synth.set()
            try:
                out = self.engine.synth(text)
            except Exception:                          # noqa: BLE001
                out = None
            finally:
                self._synth.clear()
            if out is None:
                continue
            while not self.stop_flag.is_set():
                try:
                    self._audio.put(out, timeout=0.1)
                    break
                except queue.Full:
                    continue

    # ---- playback -------------------------------------------------------

    def _run(self):
        while True:
            samples, sr = self._audio.get()
            if self.stop_flag.is_set():
                continue
            self.playing.set()
            try:
                if sr == -1:                           # `say`: its own process,
                    self._say_proc = subprocess.Popen(["say", samples])
                    self._say_proc.wait()              # no stream to feed
                    self._say_proc = None
                else:
                    self._write(samples, sr)
            except Exception:                          # noqa: BLE001 -- voice must not crash
                pass
            finally:
                self.playing.clear()

    def _write(self, samples, sr: int):
        """Top the device buffer up, and never wait inside a write.

        `stream.write()` blocks until PortAudio has room, and a barge-in that
        aborts the stream while a write is parked inside it does not reliably
        come back -- measured: the worker wedged, `playing` stayed set, and the
        voice was silent for the rest of the session while claiming to be
        speaking. Four interruptions in a row reproduced it every time.

        So the room is checked first and the write is only ever handed what
        fits. It cannot block, which means the stop flag is honoured at the top
        of the next pass rather than whenever the device feels like returning.
        """
        stream = self._open(sr)
        x = _shape(samples, sr)
        self.ref.set_clip(x, sr)
        step = max(256, int(sr * WRITE_CHUNK_MS / 1000.0))
        i, n = 0, len(x)
        while i < n:
            if self.stop_flag.is_set() or not stream.active:
                break
            room = stream.write_available
            if room <= 0:
                time.sleep(0.005)          # the device is full: it is playing
                continue
            take = min(step, room, n - i)
            stream.write(x[i:i + take])
            i += take
        self.ref.clear()

    def _open(self, sr: int):
        """The one output stream: opened on first use, then kept open.

        Reopened only if an engine hands back a different sample rate, which
        in practice means switching engines mid-session.
        """
        import sounddevice as sd
        if self._stream is not None and self._sr != sr:
            try:
                self._stream.close()
            except Exception:                          # noqa: BLE001
                pass
            self._stream = None
        if self._stream is None:
            self._stream = sd.OutputStream(samplerate=sr, channels=1,
                                           dtype="float32",
                                           latency=OUT_LATENCY_S)
            self._sr = sr
        if not self._stream.active:
            self._stream.start()
        return self._stream

    def stop(self):
        """Barge-in: silence NOW.

        `abort()` and not `stop()`. The whole point of the device buffer is
        that it holds audio you have not heard yet; draining it politely is
        the sixth of a second of lag this is meant not to have.
        """
        self.stop_flag.set()
        self.ref.clear()
        if self._stream is not None:
            try:
                self._stream.abort()
            except Exception:                          # noqa: BLE001
                pass
        if self._say_proc:
            self._say_proc.kill()
        for q in (self.q, self._audio):
            while not q.empty():
                try:
                    q.get_nowait()
                except queue.Empty:
                    break
        # Let the write loop see the flag and leave on its own, so `playing` is
        # cleared by the thread that set it. Clearing it from here instead
        # would report silence while a sentence was demonstrably still being
        # written to the device.
        for _ in range(20):
            if not self.playing.is_set():
                break
            time.sleep(0.01)
        self.playing.clear()

    def resume(self):
        self.stop_flag.clear()

    def close(self):
        """Give the device back. Not part of stop() -- that is barge-in, which
        happens constantly and must leave the stream open."""
        self.stop()
        stream, self._stream = self._stream, None
        if stream is not None:
            try:
                stream.close()
            except Exception:                          # noqa: BLE001
                pass

    @property
    def busy(self) -> bool:
        """Is anything still on its way to the speakers?

        Synthesis counts. It did not have to before, when a sentence was
        synthesized and played by the same thread and `playing` covered both;
        now that the generator runs ahead, leaving it out would report silence
        during the one gap that is still real.
        """
        return (self.playing.is_set() or self._synth.is_set()
                or not self.q.empty() or not self._audio.empty())
