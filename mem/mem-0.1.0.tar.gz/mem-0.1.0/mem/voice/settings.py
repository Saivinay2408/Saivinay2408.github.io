"""
settings — voice and session defaults, from the menu instead of a text editor.

Two files under ~/.mem-voice, deliberately not merged:

  voice.json    speaking voice and rate. Owned by tts.py, which re-reads it
                before every sentence — that hot-reload is what lets "talk
                faster" take effect mid-sentence, and it only works because
                the engine is handed this exact path at construction. It is
                passed in rather than defaulted to, so there is one path and
                not two that have to agree.

  config.json   everything the dashboard itself owns: the model and permission
                mode new panes get, whisper size, and the memory cadence that
                memory_ctl.py already keeps here.

Before this, changing a voice meant asking the clone to edit its own config,
which is a good demo and a bad settings screen.
"""
from __future__ import annotations

import json
from pathlib import Path

from .paths import CONFIG, MODELS as MODELS_DIR, VOICE_CONFIG

SPEED_MIN, SPEED_MAX = 0.6, 2.0
MODELS = ("sonnet", "opus", "haiku", "fable")
# Which coding agent a new terminal starts. Kept here rather than in the page
# because it is a preference about the machine, not about the tab: pick Codex,
# quit, come back, and a new terminal should still be Codex.
AGENTS = ("claude", "codex", "gemini")
PERMISSION_MODES = ("bypassPermissions", "acceptEdits", "plan", "default")
WHISPER_SIZES = ("tiny", "base", "small", "medium")

# Kokoro's voice ids encode language and gender in the prefix: a/b/e/f/h/i/j/p/z
# for American, British, Spanish, French, Hindi, Italian, Japanese, Portuguese
# and Chinese; f/m for the voice. Grouping by that is the difference between a
# list of 54 opaque strings and a list you can choose from.
VOICE_GROUPS = {
    "a": "American", "b": "British", "e": "Spanish", "f": "French",
    "h": "Hindi", "i": "Italian", "j": "Japanese", "p": "Portuguese",
    "z": "Chinese",
}

DEFAULTS = {
    "agent": "claude",
    "model": "sonnet",
    "permissionMode": "bypassPermissions",
    "whisper": "small",
}


# ---- voice ---------------------------------------------------------------

def available_voices() -> list[dict]:
    """Read the voice list out of the model rather than hardcoding it, so it
    stays true if the weights are swapped. Falls back to whatever is configured
    if the model can't be opened — which is the normal state of a fresh install,
    not an error: the weights are downloaded on first run, and until then the
    settings panel should still open and show the one voice it knows about."""
    try:
        from kokoro_onnx import Kokoro
        k = Kokoro(str(MODELS_DIR / "kokoro-v1.0.onnx"),
                   str(MODELS_DIR / "voices-v1.0.bin"))
        ids = sorted(k.get_voices())
    except Exception:                                   # noqa: BLE001
        cur = load_voice().get("voice", "am_michael")
        ids = [cur]
    out = []
    for vid in ids:
        lang = VOICE_GROUPS.get(vid[:1], "Other")
        gender = "female" if vid[1:2] == "f" else "male"
        out.append({"id": vid, "lang": lang, "gender": gender,
                    "name": vid.split("_", 1)[-1].title()})
    return out


def load_voice() -> dict:
    try:
        cfg = json.loads(VOICE_CONFIG.read_text())
    except (OSError, ValueError):
        cfg = {}
    cfg.setdefault("voice", "am_michael")
    cfg.setdefault("speed", 1.06)
    # Muted is a setting, not a session state: someone who works in a room
    # with other people should not have to silence this every morning.
    cfg.setdefault("muted", False)
    return cfg


def save_voice(patch: dict) -> dict:
    cfg = load_voice()
    if "voice" in patch and isinstance(patch["voice"], str):
        cfg["voice"] = patch["voice"]
    if "speed" in patch:
        try:
            cfg["speed"] = round(
                max(SPEED_MIN, min(SPEED_MAX, float(patch["speed"]))), 2)
        except (TypeError, ValueError):
            pass
    if "muted" in patch:
        cfg["muted"] = bool(patch["muted"])
    VOICE_CONFIG.parent.mkdir(parents=True, exist_ok=True)
    VOICE_CONFIG.write_text(json.dumps(cfg, indent=2) + "\n")
    return cfg


# ---- dashboard defaults --------------------------------------------------

def load_defaults() -> dict:
    try:
        cfg = json.loads(CONFIG.read_text())
    except (OSError, ValueError):
        cfg = {}
    return {k: cfg.get(k, v) for k, v in DEFAULTS.items()}


def save_defaults(patch: dict) -> dict:
    """Merge into the shared config without disturbing memory_ctl's keys."""
    try:
        cfg = json.loads(CONFIG.read_text())
    except (OSError, ValueError):
        cfg = {}
    allowed = {
        "agent": AGENTS,
        "model": MODELS,
        "permissionMode": PERMISSION_MODES,
        "whisper": WHISPER_SIZES,
    }
    for key, valid in allowed.items():
        if key in patch and patch[key] in valid:
            cfg[key] = patch[key]
    CONFIG.parent.mkdir(parents=True, exist_ok=True)
    CONFIG.write_text(json.dumps(cfg, indent=2) + "\n")
    return load_defaults()


def snapshot() -> dict:
    """Everything the settings panels need, in one round trip."""
    return {
        "voice": load_voice(),
        "voices": available_voices(),
        "defaults": load_defaults(),
        "options": {
            "models": list(MODELS),
            "permissionModes": list(PERMISSION_MODES),
            "whisper": list(WHISPER_SIZES),
            "speed": {"min": SPEED_MIN, "max": SPEED_MAX, "step": 0.01},
        },
    }
