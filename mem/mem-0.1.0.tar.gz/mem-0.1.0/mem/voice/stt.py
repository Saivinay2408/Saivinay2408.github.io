"""stt — Silero VAD (ONNX) + faster-whisper, the ear of the voice loop.

THE 512 LAW: Silero v5 at 16 kHz consumes EXACTLY 512-sample frames. Feeding
it mic-driver-convenient 480-sample blocks is a real, documented failure
mode: a barge-in path that silently never fires because the VAD sees a
frame shape it cannot score. Everything in this module is built around
frame=512 and raises loudly on anything else, rather than silently
mis-scoring.

All third-party imports (`numpy`, `onnxruntime`, `faster_whisper`) are
deferred into `__init__`/methods rather than done at module import time, so
`import mem.voice.stt` succeeds on a machine with none of them
installed -- the property the verifier depends on to prove there are no dead
references without needing microphone hardware or model weights at all.
"""
from __future__ import annotations

import collections
import time
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import numpy as np

SAMPLE_RATE = 16000
FRAME = 512                     # the law
FRAME_MS = FRAME / SAMPLE_RATE * 1000.0   # 32 ms
DEFAULT_MODELS_DIR = Path(__file__).resolve().parent.parent / "models"


def _models_dir(models_dir: str | Path | None) -> Path:
    return Path(models_dir) if models_dir else DEFAULT_MODELS_DIR


class SileroVAD:
    """Streaming speech-probability over 512-sample frames."""

    def __init__(self, model_path: str | Path | None = None,
                models_dir: str | Path | None = None):
        import numpy as np
        import onnxruntime as ort
        self._np = np
        path = Path(model_path) if model_path else _models_dir(models_dir) / "silero_vad.onnx"
        so = ort.SessionOptions()
        so.log_severity_level = 3
        self.sess = ort.InferenceSession(str(path), so, providers=["CPUExecutionProvider"])
        self.reset()

    def reset(self):
        np = self._np
        self._state = np.zeros((2, 1, 128), dtype=np.float32)
        self._ctx = np.zeros(64, dtype=np.float32)

    def prob(self, frame: "np.ndarray") -> float:
        np = self._np
        if frame.shape[0] != FRAME:
            raise ValueError(f"Silero v5 requires {FRAME}-sample frames @16k, "
                             f"got {frame.shape[0]} (the 480-vs-512 mismatch)")
        # v5 ONNX quirk: the model wants 64 samples of rolling context
        # PREPENDED to each 512 frame (576 in). Bare 512 gives near-zero
        # probs on loud, clear speech; with context it scores correctly.
        x = np.concatenate([self._ctx, frame.astype(np.float32)])
        out, self._state = self.sess.run(
            None, {"input": x.reshape(1, -1),
                   "state": self._state,
                   "sr": np.array(SAMPLE_RATE, dtype=np.int64)})
        self._ctx = frame[-64:].astype(np.float32)
        return float(out[0, 0])


class SmartTurn:
    """Semantic end-of-turn judge (pipecat smart-turn v3, ~8MB, BSD-2):
    whisper-tiny features + a classifier over the last 8s of the turn.
    Answers the question raw VAD silence cannot: "is the speaker done, or
    trailing off mid-thought?" -- endpointing on a fixed silence timer alone
    cuts off sentences like "hi, so..." exactly where a human would keep
    listening."""

    def __init__(self, model_path: str | Path | None = None,
                models_dir: str | Path | None = None):
        import onnxruntime as ort
        from faster_whisper.feature_extractor import FeatureExtractor
        path = Path(model_path) if model_path else _models_dir(models_dir) / "smart-turn-v3.onnx"
        so = ort.SessionOptions()
        so.log_severity_level = 3
        self.sess = ort.InferenceSession(str(path), so, providers=["CPUExecutionProvider"])
        self.fe = FeatureExtractor(feature_size=80, sampling_rate=SAMPLE_RATE,
                                   hop_length=160, n_fft=400)

    def end_prob(self, audio: "np.ndarray") -> float:
        import numpy as np
        a = audio[-8 * SAMPLE_RATE:]
        a = np.pad(a, (8 * SAMPLE_RATE - len(a), 0))
        mel = self.fe(a, padding=False)[:, :800].astype(np.float32)
        logits = self.sess.run(None, {"input_features": mel[None]})[0]
        return float(1.0 / (1.0 + np.exp(-logits[0, 0])))


class Endpointer:
    """Turns a stream of frames into complete utterances -- two-stage
    endpointing.

    start: probability above `start_p` for 2 consecutive frames (a short
    pre-roll is kept so the first syllable is not clipped).

    end: after `silence_soft_ms` of silence, if a `SmartTurn` judge is
    configured, ask whether the turn is semantically complete. Complete ->
    emit immediately. Incomplete ("so...", "the status of...") -> keep
    listening; if speech resumes, the same utterance continues; only at
    `silence_hard_ms` does it give up and emit anyway. Without a SmartTurn
    model this degrades to a single fixed threshold at `silence_hard_ms`.
    """

    def __init__(self, vad: SileroVAD, start_p: float = 0.55, end_p: float = 0.35,
                silence_soft_ms: int = 550, silence_hard_ms: int = 1700,
                preroll_ms: int = 320, max_utt_s: int = 30,
                smart_turn: "SmartTurn | None" = None, end_conf: float = 0.60):
        self.vad = vad
        self.smart = smart_turn
        self.end_conf = end_conf
        self.start_p, self.end_p = start_p, end_p
        self.soft_frames = max(1, int(silence_soft_ms / FRAME_MS))
        self.hard_frames = max(1, int(silence_hard_ms / FRAME_MS))
        self.preroll: collections.deque = collections.deque(maxlen=max(1, int(preroll_ms / FRAME_MS)))
        self.max_frames = int(max_utt_s * 1000 / FRAME_MS)
        self._reset_utt()

    def _reset_utt(self):
        self.in_speech = False
        self.buf: list = []
        self._above = 0
        self._below = 0
        self._judged_at = -1          # silence frame count of the last smart consult

    def _emit(self):
        import numpy as np
        utt = np.concatenate(self.buf)
        self._reset_utt()
        self.vad.reset()
        return utt

    def feed(self, frame: "np.ndarray"):
        """Feed one 512-sample frame. Returns a finished utterance
        (float32 mono @16k) or None. Also exposes `.speaking` for barge-in
        checks."""
        p = self.vad.prob(frame)
        if not self.in_speech:
            self.preroll.append(frame)
            self._above = self._above + 1 if p >= self.start_p else 0
            if self._above >= 2:
                self.in_speech = True
                self.buf = list(self.preroll)
                self._below = 0
            return None
        self.buf.append(frame)
        if p < self.end_p:
            self._below += 1
        else:
            self._below = 0            # speech resumed: same utterance continues
            self._judged_at = -1
        if len(self.buf) >= self.max_frames or self._below >= self.hard_frames:
            return self._emit()
        if self._below >= self.soft_frames and self.smart is not None:
            import numpy as np
            # consult at the soft point, then re-consult every ~350ms of extra silence
            if self._judged_at < 0 or (self._below - self._judged_at) >= 11:
                self._judged_at = self._below
                if self.smart.end_prob(np.concatenate(self.buf)) >= self.end_conf:
                    return self._emit()
        return None

    @property
    def speaking(self) -> bool:
        return self.in_speech


class Transcriber:
    """faster-whisper small/int8: local, sub-second for a short utterance on
    Apple Silicon CPU."""

    def __init__(self, model_size: str = "small"):
        from faster_whisper import WhisperModel
        self.model = WhisperModel(model_size, device="cpu", compute_type="int8")

    def transcribe(self, audio: "np.ndarray") -> tuple[str, float]:
        t0 = time.time()
        segments, _info = self.model.transcribe(
            audio, language="en", beam_size=1, vad_filter=False,
            condition_on_previous_text=False)
        text = " ".join(s.text.strip() for s in segments).strip()
        return text, time.time() - t0
