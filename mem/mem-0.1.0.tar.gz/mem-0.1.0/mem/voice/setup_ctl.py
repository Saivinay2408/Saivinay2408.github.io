"""
setup_ctl — onboarding, inside the window.

A new user should never have to find a terminal to get started. The steps are
the same ones the CLI documents, run as subprocesses with their real output
streamed back, so this is a face over `mem` rather than a second
implementation that can drift from it.

THE ORDER IS THE ARGUMENT
-------------------------
1. check      is an extractor reachable at all? Everything downstream is a
              no-op without one, and finding that out after a ten-minute
              backfill is the worst possible moment.
2. backfill   seed from coding sessions you have already had. This is first
              among the writing steps because it asks nothing and produces a
              better vault than any interview: it is what you actually did,
              not what you say you do when someone asks.
3. consolidate distil those captures into facts that survive.
4. wire       put the vault on the live path for every agent you have.

Steps are separately runnable and separately reportable. A user who has
already wired their agents should be able to run a backfill without being
walked through the whole thing again, and a failure in step 2 must not present
itself as a failure of onboarding as a whole.

NOTHING HERE IS IRREVERSIBLE WITHOUT SAYING SO. `backfill` without `--apply`
writes nothing and is offered first; `wire` merges and backs up. The one step
that spends real money is `consolidate`, and it says so.
"""
from __future__ import annotations

import json
import subprocess
import sys
import threading
from pathlib import Path

from .paths import STATE, ensure_state, vault

STATE_FILE = STATE / "setup.json"

STEPS = [
    {
        "id": "check",
        "name": "Check the extractor",
        "blurb": "Consolidation shells out to a model to turn sessions into "
                 "facts. If that command is missing, everything after this "
                 "quietly writes nothing.",
        "args": ["check-extractor"],
        "writes": False,
    },
    {
        "id": "backfill",
        "name": "Learn from sessions you have already had",
        "blurb": "Reads the transcripts already on this machine. Asks you "
                 "nothing, and is a better source than any interview: it is "
                 "what you did, not what you say you do.",
        "args": ["backfill", "--apply"],
        "dry": ["backfill"],
        "writes": True,
    },
    {
        "id": "consolidate",
        "name": "Distil it into lasting facts",
        "blurb": "The sleep pass: extract, gate, write. This is the step that "
                 "costs model tokens.",
        "args": ["consolidate"],
        "writes": True,
        "costs": True,
    },
    {
        "id": "wire",
        "name": "Wire it into your agents",
        "blurb": "Claude Code gets hooks; Codex and Gemini get an MCP server "
                 "and a context file. Only the agents you actually have are "
                 "touched, and every write is backed up first.",
        "args": ["init"],
        "dry": ["init", "--dry-run"],
        "writes": True,
    },
]

STEP_IDS = [s["id"] for s in STEPS]
TIMEOUT = 1800          # a backfill over thousands of transcripts is not quick


def load() -> dict:
    try:
        data = json.loads(STATE_FILE.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {"done": [], "dismissed": False}
    data.setdefault("done", [])
    data.setdefault("dismissed", False)
    return data


def save(data: dict) -> None:
    ensure_state()
    STATE_FILE.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")


def mark(step: str, ok: bool = True) -> dict:
    data = load()
    done = set(data["done"])
    done.add(step) if ok else done.discard(step)
    data["done"] = sorted(done, key=lambda s: STEP_IDS.index(s)
                          if s in STEP_IDS else 99)
    save(data)
    return data


def dismiss(value: bool = True) -> dict:
    data = load()
    data["dismissed"] = bool(value)
    save(data)
    return data


def status() -> dict:
    """What is done, what is left, and whether the vault has anything in it.

    `vaultNotes` is checked rather than trusted from the state file: somebody
    may have run the CLI directly, and onboarding that insists you have not
    started when the vault holds four hundred notes is worse than useless.
    """
    data = load()
    root = vault()
    notes = 0
    try:
        notes = sum(1 for _ in root.rglob("*.md"))
    except OSError:
        pass
    return {
        "steps": [{k: v for k, v in s.items() if k != "args" and k != "dry"}
                  for s in STEPS],
        "done": data["done"],
        "dismissed": data["dismissed"],
        "vault": str(root),
        "vaultNotes": notes,
        # The prompt to onboard disappears once there is a vault OR the user
        # has said no. Nagging somebody who is already set up is the fastest
        # way to make an onboarding flow something people learn to close.
        "needed": notes < 5 and not data["dismissed"],
    }


class Runner:
    """Runs one onboarding step and streams its real output to the UI.

    One at a time. Two of these write the same vault, and a backfill racing a
    consolidation is a merge conflict inside somebody's memory.
    """

    def __init__(self, dash):
        self.dash = dash
        self.running = ""
        self._lock = threading.Lock()

    def start_all(self) -> dict:
        """Every step, in order, stopping at the first failure.

        THE FOUR STEPS ARE NOT FOUR DECISIONS. They are one decision -- set
        this up -- with an order that matters (an unreachable extractor makes
        everything after it write nothing) and no branch a person is in a
        position to take. Presenting them as four numbered choices with six
        buttons asked the user to understand the pipeline before using it,
        which is exactly the confusion this replaces. Each step is still
        individually runnable underneath, for when something failed and you
        want to retry just that one.
        """
        with self._lock:
            if self.running:
                return {"ok": False, "error": f"{self.running} is still running"}
            self.running = "all"
        threading.Thread(target=self._run_all, daemon=True).start()
        return {"ok": True, "error": ""}

    def _run_all(self) -> None:
        try:
            for step in STEPS:
                self._emit(step="all", line=f"$ mem {' '.join(step['args'])}",
                           start=(step is STEPS[0]))
                code = self._exec(step, list(step["args"]))
                if code != 0:
                    self._emit(step="all", done=True, ok=False,
                               line=f"stopped at \"{step['name']}\" (exit {code}). "
                                    f"Nothing after this ran.")
                    return
                mark(step["id"], True)
            self._emit(step="all", done=True, ok=True,
                       line="done — your vault is wired in.")
        finally:
            self.running = ""
            self.dash.emit_raw({"t": "setup", "v": status()})

    def start(self, step_id: str, dry: bool = False) -> dict:
        step = next((s for s in STEPS if s["id"] == step_id), None)
        if step is None:
            return {"ok": False, "error": f"unknown step {step_id!r}"}
        args = step.get("dry") if dry else step["args"]
        if args is None:
            return {"ok": False, "error": "this step has no dry run"}
        return self.start_args(step_id, args)

    def start_args(self, step_id: str, args: list[str], note: str = "") -> dict:
        """Run an arbitrary `mem` command through the same one-at-a-time gate.

        The interview's final step is `mem onboard <file> --apply`, which is
        not one of the four fixed STEPS but writes the same vault — so it has
        to queue behind them rather than beside them. Two of these running at
        once is a merge conflict inside somebody's memory.
        """
        with self._lock:
            if self.running:
                return {"ok": False, "error": f"{self.running} is still running"}
            self.running = step_id
        step = next((s for s in STEPS if s["id"] == step_id),
                    {"id": step_id, "name": step_id})
        threading.Thread(target=self._run, args=(step, list(args), False, note),
                         daemon=True).start()
        return {"ok": True, "error": ""}

    def _emit(self, **fields) -> None:
        self.dash.emit_raw({"t": "setup.log", **fields})

    def _exec(self, step: dict, args: list[str], sid: str = "") -> int:
        """Run one `mem` command, streaming its output. Returns the exit code."""
        sid = sid or step["id"]
        code = 1
        proc = None
        try:
            proc = subprocess.Popen(
                [sys.executable, "-m", "mem", *args],
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, bufsize=1)
            for line in proc.stdout:                    # type: ignore[union-attr]
                line = line.rstrip()
                if line:
                    self._emit(step=sid, line=line[:400])
            proc.wait(timeout=TIMEOUT)
            code = proc.returncode
        except subprocess.TimeoutExpired:
            if proc:
                proc.kill()
            self._emit(step=sid, line=f"! timed out after {TIMEOUT // 60} minutes")
        except Exception as e:                          # noqa: BLE001
            self._emit(step=sid, line=f"! could not run it: {e}")
        return code

    def _run(self, step: dict, args: list[str], dry: bool, note: str = "") -> None:
        sid = step["id"]
        self._emit(step=sid, line=note or f"$ mem {' '.join(args)}", start=True)
        code = 1
        try:
            code = self._exec(step, args)
        finally:
            self.running = ""
            ok = code == 0
            # A dry run proves nothing about the real one, so it never marks
            # the step complete — it only tells you what would happen.
            if ok and not dry:
                mark(sid, True)
            self._emit(step=sid, done=True, ok=ok, dry=dry,
                       line="done." if ok else f"exited with code {code}")
            self.dash.emit_raw({"t": "setup", "v": status()})
