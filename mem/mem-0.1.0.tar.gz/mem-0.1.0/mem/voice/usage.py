"""
usage — how much you have left, and where it went.

Two sources, because neither alone answers the question:

  Real limits come from `/usage`, which Claude Code fetches live. There is no
  local file holding "43% of your weekly limit remains" — it is not cached on
  disk in any form this could read. So a short-lived hidden terminal runs the
  slash command and the panel parses the two percentages out of it. That is a
  scrape, and it is fenced off in one function (`probe_limits`) with the shape
  of the screen it expects written down, so when Anthropic redesigns it the
  panel degrades to local numbers instead of breaking.

  Local accounting comes from the transcripts, which are exact. Every assistant
  message carries its own usage, so per-session totals, today's totals, and how
  full each session's context window is are all arithmetic, not estimation.

The context meter is the one worth watching. Limit percentages tell you about
the month; context fill tells you which pane is about to auto-compact and lose
the thread.
"""
from __future__ import annotations

import json
import re
import threading
import time
from pathlib import Path

from .paths import PROJECTS, project_slug

# Claude Code's default context window. `--autocompact` can raise the effective
# window, so treat the meter as "how close to a compaction" and not as gospel.
CONTEXT_WINDOW = 200_000

_ANSI = re.compile(r"\x1b\[[0-9;?]*[a-zA-Z]|\x1b\][^\x07\x1b]*(?:\x07|\x1b\\)|\x1b[()][AB0]|\x1b[=>]")
_PCT = re.compile(r"(\d{1,3})\s*%")
_RESET = re.compile(r"Resets\s+(.+?)\s*$")


def _strip_ansi(s: str) -> str:
    return _ANSI.sub("", s).replace("\r", "\n")


def parse_usage_screen(text: str) -> dict:
    """Pull the session and weekly percentages out of a rendered /usage screen.

    The screen looks like:

        Current session
        ████████████▌            51% used
        Resets 9:40pm (Asia/Calcutta)
        Current week (all models)
        ████████████████         56% used
        Resets Aug 4 at 7:30pm (Asia/Calcutta)

    Anchored on the two headings rather than on bar glyphs or line offsets,
    which are the parts most likely to be restyled.
    """
    out: dict = {}
    lines = [l.strip() for l in _strip_ansi(text).splitlines()]
    anchors = (("session", re.compile(r"^current session", re.I)),
               ("week", re.compile(r"^current week", re.I)))
    for key, rx in anchors:
        for i, line in enumerate(lines):
            if not rx.search(line):
                continue
            for probe in lines[i + 1:i + 5]:
                m = _PCT.search(probe)
                if m and "used" in probe.lower():
                    out[f"{key}Pct"] = int(m.group(1))
                r = _RESET.search(probe)
                if r and f"{key}Resets" not in out:
                    out[f"{key}Resets"] = r.group(1)
                if f"{key}Pct" in out and f"{key}Resets" in out:
                    break
            break
    return out


def probe_limits(timeout: float = 22.0) -> dict:
    """Run `/usage` in a throwaway terminal and read the two meters off it.

    Costs one short-lived `claude` process and no tokens — a slash command does
    not call the model. Returns {} if anything at all goes wrong; the caller
    falls back to local numbers.
    """
    from .pty_pane import PtyPane
    pane = None
    try:
        # Wide, so the panel doesn't wrap the percentage away from the word
        # "used" that anchors the parse.
        pane = PtyPane(["claude"], cols=200, rows=50)
        deadline = time.time() + timeout
        time.sleep(5.0)                       # let the TUI paint before typing
        pane.write(b"/usage")
        time.sleep(1.2)
        pane.write(b"\r")
        found: dict = {}
        while time.time() < deadline:
            time.sleep(1.0)
            found = parse_usage_screen(pane.scrollback().decode("utf-8", "replace"))
            if "sessionPct" in found and "weekPct" in found:
                break
        return found
    except Exception:                          # noqa: BLE001 — never fatal
        return {}
    finally:
        if pane is not None:
            pane.close()


# ---- local accounting ----------------------------------------------------

def _tail_lines(path: Path, max_bytes: int = 400_000) -> list[str]:
    """Read the end of a JSONL file. Transcripts reach multiple megabytes and
    the interesting rows are always the recent ones."""
    try:
        size = path.stat().st_size
        with path.open("rb") as f:
            if size > max_bytes:
                f.seek(size - max_bytes)
                f.readline()                   # discard the partial first line
            return f.read().decode("utf-8", "replace").splitlines()
    except OSError:
        return []


def context_fill(session_id: str, cwd: str | Path) -> dict:
    """How full a session's context window is, from its most recent request.

    The prompt size of the last assistant message — fresh input plus everything
    read from or written to cache — is the context that request carried.
    """
    path = PROJECTS / project_slug(cwd) / f"{session_id}.jsonl"
    for line in reversed(_tail_lines(path)):
        try:
            obj = json.loads(line)
        except ValueError:
            continue
        if obj.get("type") != "assistant":
            continue
        u = (obj.get("message") or {}).get("usage") or {}
        total = ((u.get("input_tokens") or 0) + (u.get("cache_read_input_tokens") or 0)
                 + (u.get("cache_creation_input_tokens") or 0))
        if total <= 0:
            continue
        return {"tokens": total, "window": CONTEXT_WINDOW,
                "pct": round(min(100.0, total / CONTEXT_WINDOW * 100), 1)}
    return {"tokens": 0, "window": CONTEXT_WINDOW, "pct": 0.0}


def session_totals(session_id: str, cwd: str | Path) -> dict:
    """Everything one session has spent. Whole-file walk: exact, not sampled."""
    path = PROJECTS / project_slug(cwd) / f"{session_id}.jsonl"
    tot = {"input": 0, "output": 0, "cacheRead": 0, "cacheCreate": 0, "turns": 0}
    try:
        with path.open("r", encoding="utf-8", errors="replace") as f:
            for line in f:
                try:
                    obj = json.loads(line)
                except ValueError:
                    continue
                if obj.get("type") == "system" and obj.get("subtype") == "turn_duration":
                    tot["turns"] += 1
                if obj.get("type") != "assistant":
                    continue
                u = (obj.get("message") or {}).get("usage") or {}
                tot["input"] += u.get("input_tokens") or 0
                tot["output"] += u.get("output_tokens") or 0
                tot["cacheRead"] += u.get("cache_read_input_tokens") or 0
                tot["cacheCreate"] += u.get("cache_creation_input_tokens") or 0
    except OSError:
        pass
    return tot


def today_totals() -> dict:
    """Output tokens and session count across every project touched today.

    Only files modified in the last 24h are opened — the projects directory
    holds hundreds of megabytes of history and none of it changes the answer.
    """
    cutoff = time.time() - 24 * 3600
    out = {"output": 0, "cacheRead": 0, "sessions": 0, "projects": set()}
    try:
        candidates = list(PROJECTS.glob("*/*.jsonl"))
    except OSError:
        return {"output": 0, "cacheRead": 0, "sessions": 0, "projects": 0}
    for path in candidates:
        try:
            if path.stat().st_mtime < cutoff:
                continue
        except OSError:
            continue
        out["sessions"] += 1
        out["projects"].add(path.parent.name)
        for line in _tail_lines(path):
            try:
                obj = json.loads(line)
            except ValueError:
                continue
            if obj.get("type") != "assistant":
                continue
            u = (obj.get("message") or {}).get("usage") or {}
            out["output"] += u.get("output_tokens") or 0
            out["cacheRead"] += u.get("cache_read_input_tokens") or 0
    out["projects"] = len(out["projects"])
    return out


class UsageMonitor:
    """Keeps the meters current.

    "Live" here means three specific things, each of which was missing:

      it refreshes when the number actually moves. A limit percentage changes
      when you spend tokens, so the probe runs after a turn ends rather than
      only on a fixed timer. The timer is now a backstop, not the mechanism.

      it says when it was read. A percentage with no timestamp is indis-
      tinguishable from a percentage that stopped updating an hour ago, which
      is exactly what a stuck meter looks like.

      it admits when the read failed. `probe_limits` returns {} on any error
      and the old code did `if got:` — so a failing probe left the previous
      number on screen forever, looking authoritative.
    """

    LIMIT_INTERVAL = 300.0        # backstop; a turn ending is the real trigger
    LOCAL_INTERVAL = 20.0
    TURN_THROTTLE = 90.0          # a burst of short turns is still one probe
    STALE_AFTER = 900.0           # past this the reading is labelled old

    def __init__(self, dash, probe: bool = True):
        self.dash = dash
        self.probe = probe
        self.limits: dict = {}
        self.read_at: float = 0.0
        self.probing = False
        self.probe_error = ""
        self.last: dict = {}          # last payload, replayed on reconnect
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._lock = threading.Lock()
        self._last_probe = 0.0

    def start(self) -> None:
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()

    def refresh_limits_now(self) -> None:
        threading.Thread(target=self._probe_once, daemon=True).start()

    def on_turn_end(self) -> None:
        """A turn just finished, so the limits just moved. Throttled, because a
        run of one-line turns should not spawn a `claude` every few seconds."""
        if not self.probe or time.time() - self._last_probe < self.TURN_THROTTLE:
            return
        self.refresh_limits_now()

    def _probe_once(self) -> None:
        with self._lock:                    # two probes at once is two processes
            if self.probing:
                return
            self.probing = True
            self._last_probe = time.time()
        self._emit()                        # show that a read is in flight
        try:
            got = probe_limits()
        finally:
            self.probing = False
        if got:
            self.limits = got
            self.read_at = time.time()
            self.probe_error = ""
        else:
            # Deliberately keeps the last good numbers — a failed read is not
            # evidence they changed — but says so, so a frozen meter reads as
            # frozen instead of as current.
            self.probe_error = "couldn't read /usage"
        self._emit()

    def _age(self) -> dict:
        if not self.read_at:
            return {"readAt": None, "ageS": None, "stale": False}
        age = time.time() - self.read_at
        return {"readAt": self.read_at, "ageS": int(age),
                "stale": age > self.STALE_AFTER}

    def _emit(self) -> None:
        local = today_totals()
        payload = {
            "sessionPct": self.limits.get("sessionPct"),
            "weekPct": self.limits.get("weekPct"),
            "sessionLabel": "—" if "sessionPct" not in self.limits else "",
            "weekLabel": "—" if "weekPct" not in self.limits else "",
            "today": local,
            "panes": self._pane_context(),
            "probing": self.probing,
            "probeError": self.probe_error,
            **self._age(),
        }
        payload["tooltip"] = self._tooltip(local, payload)
        self.dash.emit_raw({"t": "usage", "v": payload})
        self.last = payload           # replayed to a client that reconnects

    def _pane_context(self) -> dict:
        """Context fill per open pane — the number that actually bites you.

        Computed here on the slow timer rather than in Pane.info(), which the
        roster broadcasts every two seconds; this reads the tail of a transcript
        per pane and has no business running that often.
        """
        out: dict = {}
        for pane in self.dash.panes.all():
            if not pane.session_id:
                continue
            try:
                out[pane.id] = context_fill(pane.session_id, pane.cwd)
            except Exception:                  # noqa: BLE001
                continue
        return out

    def _tooltip(self, local: dict, p: dict) -> str:
        bits = []
        if p.get("probing"):
            bits.append("Reading /usage…")
        elif p.get("probeError"):
            bits.append(f"{p['probeError']} — showing the last good reading")
        elif p.get("ageS") is not None:
            bits.append(f"Read {_ago(p['ageS'])} ago")
        if self.limits.get("sessionResets"):
            bits.append(f"Session resets {self.limits['sessionResets']}")
        if self.limits.get("weekResets"):
            bits.append(f"Week resets {self.limits['weekResets']}")
        bits.append(f"Today: {local['output']:,} output tokens across "
                    f"{local['sessions']} sessions in {local['projects']} projects")
        return " · ".join(bits)

    def _run(self) -> None:
        # Local numbers first, immediately. The probe takes ~8 seconds against a
        # real screen, and running it before the first emit meant the meters sat
        # empty for that whole time with nothing to say they were loading.
        self._emit()
        if self.probe:
            self._probe_once()
        last_limits = time.time()
        while not self._stop.is_set():
            self._stop.wait(self.LOCAL_INTERVAL)
            if self._stop.is_set():
                break
            if self.probe and time.time() - last_limits >= self.LIMIT_INTERVAL:
                last_limits = time.time()
                self._probe_once()
            else:
                self._emit()


def _ago(seconds: int) -> str:
    if seconds < 90:
        return f"{seconds}s"
    if seconds < 5400:
        return f"{seconds // 60}m"
    return f"{seconds // 3600}h"
