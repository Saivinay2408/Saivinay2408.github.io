"""
speakable — turn what was written into what can be said.

Even a model told to answer conversationally will occasionally hand back a
path, a fenced diff, or a bulleted list. Reading that aloud verbatim is what
made the old voice loop sound like a screen reader, so nothing reaches the
speaker without passing through here.

This is the belt to voice_prompt.py's braces. The system prompt asks for short
spoken sentences and mostly gets them; this guarantees the rest, deterministically
and with no model call.
"""
from __future__ import annotations

import re

# Fenced blocks go entirely. There is no useful way to speak a diff, and the
# terminal pane is already showing it.
_FENCE = re.compile(r"```.*?```", re.S)
_FENCE_OPEN = re.compile(r"```.*", re.S)          # an unterminated fence mid-stream
_INLINE_CODE = re.compile(r"`([^`]*)`")
_IMAGE = re.compile(r"!\[[^\]]*\]\([^)]*\)")
_LINK = re.compile(r"\[([^\]]+)\]\([^)]*\)")
_BARE_URL = re.compile(r"https?://\S+")
_HEADER = re.compile(r"^\s{0,3}#{1,6}\s*", re.M)
_QUOTE = re.compile(r"^\s{0,3}>\s?", re.M)
_BULLET = re.compile(r"^\s*(?:[-*+]|\d+[.)])\s+", re.M)
_RULE = re.compile(r"^\s*([-*_])\s*(?:\1\s*){2,}$", re.M)
_EMPH = re.compile(r"(\*{1,3}|_{1,3}|~~)(?=\S)(.+?)(?<=\S)\1", re.S)
_TABLE_ROW = re.compile(r"^\s*\|.*\|\s*$", re.M)
_EMOJI = re.compile(
    "[\U0001F000-\U0001FAFF\U00002190-\U000021FF\U00002600-\U000027BF"
    "\U0000FE00-\U0000FE0F\U00002B00-\U00002BFF\U0001F1E6-\U0001F1FF]+")
_CHECKBOX = re.compile(r"^\s*\[[ xX]\]\s*", re.M)

# A path only ever needs its last meaningful word spoken. "voice/jarvis.py"
# is "jarvis"; saying the slashes and the dot-p-y is noise nobody wants.
_PATH = re.compile(r"(?:~|\.{1,2})?(?:/[\w.\-]+){2,}/?|\b[\w.\-]+/[\w.\-]+\.\w{1,5}\b")
_FILE = re.compile(r"\b([\w\-]+)\.(?:py|js|ts|tsx|jsx|json|md|html|css|sh|yml|yaml|toml|txt|jsonl)\b")

_SENTENCE = re.compile(r"(?<=[.!?])\s+")
_WS = re.compile(r"[ \t]+")
_BLANKS = re.compile(r"\n{2,}")


def spoken_name(path: str) -> str:
    """A path or filename as you would say it out loud.

    voice/jarvis.py      -> "jarvis"
    scripts/build_index  -> "build index"
    ~/Desktop/AGI        -> "AGI"
    """
    p = (path or "").strip().rstrip("/")
    if not p:
        return ""
    base = p.rsplit("/", 1)[-1]
    stem = base.rsplit(".", 1)[0] if "." in base[1:] else base
    stem = stem.replace("_", " ").replace("-", " ").strip()
    return stem or base


def _paths_to_words(text: str) -> str:
    text = _PATH.sub(lambda m: spoken_name(m.group(0)), text)
    return _FILE.sub(lambda m: m.group(1).replace("_", " ").replace("-", " "), text)


def to_speech(text: str, max_sentences: int = 3, max_chars: int = 420) -> str:
    """Reduce written markdown to a short, sayable line.

    Returns "" when there is nothing worth saying — an answer that was purely a
    code block leaves nothing behind, and silence is the right output for that.
    """
    if not text:
        return ""
    t = _FENCE.sub(" ", text)
    t = _FENCE_OPEN.sub(" ", t)
    t = _IMAGE.sub(" ", t)
    t = _LINK.sub(r"\1", t)
    t = _BARE_URL.sub("a link", t)
    t = _TABLE_ROW.sub(" ", t)
    t = _RULE.sub(" ", t)
    t = _HEADER.sub("", t)
    t = _QUOTE.sub("", t)
    t = _CHECKBOX.sub("", t)
    t = _EMPH.sub(r"\2", t)
    t = _INLINE_CODE.sub(r"\1", t)
    t = _EMOJI.sub("", t)

    # A bulleted list read aloud needs to become a sentence, not a list of
    # fragments with no pauses in it.
    t = _BULLET.sub("", t)
    t = _BLANKS.sub(". ", t)
    t = t.replace("\n", ". ")

    t = _paths_to_words(t)
    t = _WS.sub(" ", t)
    t = re.sub(r"\s*\.\s*(?=\.)", "", t)          # collapse ". . ." runs
    t = re.sub(r"\.{2,}", ".", t)
    t = re.sub(r"\s+([.,!?;:])", r"\1", t)
    t = t.strip(" .,;:-").strip()
    if not t:
        return ""

    parts = _SENTENCE.split(t)
    out = " ".join(parts[:max_sentences]).strip()
    if len(out) > max_chars:
        cut = out[:max_chars]
        # prefer to end on a real boundary rather than mid-word
        for sep in (". ", ", ", " "):
            i = cut.rfind(sep)
            if i > max_chars * 0.6:
                cut = cut[:i]
                break
        out = cut.rstrip(" ,.;:") + "."
    if out and out[-1] not in ".!?":
        out += "."
    return out
