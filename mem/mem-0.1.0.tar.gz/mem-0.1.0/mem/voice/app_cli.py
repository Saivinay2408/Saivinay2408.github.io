"""
`mem app` — put a Dock icon on this machine.

The last step of the installer, and the answer to "I do not want to type a
command every time".

WHY THIS IS A COMMAND AND NOT A DOWNLOAD
----------------------------------------
A bundle built on the machine it will run on is never quarantined:
`com.apple.quarantine` is set by whatever DOWNLOADS a file, so Gatekeeper
never assesses this one. Ship the identical bytes as a .dmg and macOS says the
developer cannot be verified — and since Sequoia the Control-click escape is
gone, so the way through is System Settings, Privacy & Security, Open Anyway.

So building locally is not a workaround for lacking a $99 Developer ID. It is
the reason none is needed.
"""
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path


def main(argv=None) -> int:
    p = argparse.ArgumentParser(
        prog="mem app",
        description="install a Mem icon where you will find it")
    p.add_argument("--to", default="",
                   help="where to put it (default: /Applications when that is "
                        "writable, otherwise ~/Applications)")
    p.add_argument("--build-only", metavar="DIR", default="",
                   help="build there and do not install")
    p.add_argument("--no-reveal", action="store_true",
                   help="do not open a Finder window on the result")
    args = p.parse_args(argv)

    if sys.platform != "darwin":
        print("`mem app` builds a macOS bundle; nothing to do here.\n"
              "Run `mem voice` to open the window.", file=sys.stderr)
        return 1

    from . import appbundle

    try:
        if args.build_only:
            out = Path(args.build_only).expanduser().resolve()
            out.mkdir(parents=True, exist_ok=True)
            app = appbundle.build(out, sys.executable)
            print(f"built {app}")
            return 0
        dest = appbundle.install(to=Path(args.to).expanduser() if args.to else None)
    except OSError as e:
        print(f"could not install the app: {e}", file=sys.stderr)
        return 1

    print(f"installed {dest}")

    # SHOW IT, do not describe where it is.
    #
    # The first version printed "~/Applications" and a tester could not find
    # the app -- Finder's Applications sidebar item is /Applications, and
    # Launchpad reads a cache that had not rescanned. Both are now handled, but
    # the general lesson stands: the end of an install is the worst moment to
    # ask somebody to go looking. Reveal it.
    if not args.no_reveal:
        subprocess.run(["open", "-R", str(dest)], capture_output=True)

    print(f"\nIt should be highlighted in Finder now, and in Spotlight as Mem.")
    print(f"The interpreter it was built against is this one:\n"
          f"  {sys.executable}\n"
          f"Rebuild with `mem app` if that ever moves.")
    return 0
