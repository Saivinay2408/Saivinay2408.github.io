/*
  app — the client.

  Two socket kinds, mirroring the server: one control channel carrying JSON
  (panes, roster, orb state) and one binary socket per terminal. Terminals never
  share a channel with state updates, so a fast repaint can't delay a pane going
  amber.
*/
(function () {
  "use strict";

  const $ = (id) => document.getElementById(id);
  const WS = (path) => `ws://${location.host}${path}`;

  /* xterm's palette, derived from the same tokens as the rest of the console so
     terminal output sits in the design rather than on top of it. */
  const TERM_THEME = {
    background: "#08090b", foreground: "#e7e4de", cursor: "#e7e4de",
    cursorAccent: "#08090b", selectionBackground: "#2b3138",
    black: "#14171b", red: "#b4462f", green: "#7d9b76", yellow: "#c9a227",
    blue: "#6e8ca0", magenta: "#9a7d94", cyan: "#7fa39b", white: "#e7e4de",
    brightBlack: "#6e747c", brightRed: "#d4573b", brightGreen: "#96b98c",
    brightYellow: "#e0b93b", brightBlue: "#87a6ba", brightMagenta: "#b795af",
    brightCyan: "#98c0b7", brightWhite: "#ffffff",
  };

  /* What the orb says it is doing.

     `listening` is the RESTING state -- nothing is held, no audio is being
     captured, the mic is not open. Calling that "listening" was a lie the
     app told about itself every second it was running, and a reasonable
     person reads it as "this thing is recording me". The state that actually
     has the microphone open is `hearing`, and that is the one allowed to say
     it is listening. */
  const STATE_LABEL = {
    idle: "idle", listening: "ready", hearing: "listening",
    thinking: "thinking", working: "working", speaking: "speaking",
    blocked: "needs you", starting: "starting",
  };

  // ---------------------------------------------------------------- toast

  let toastTimer = null;
  function toast(msg) {
    const el = $("toast");
    el.textContent = msg;
    el.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.remove("show"), 5200);
  }

  // ------------------------------------------------------------------ orb

  const orb = new window.Orb($("orb"));
  let orbState = "starting";
  let orbStatus = "";        // live narration: what the session is doing now

  /* The caption is the state word, EXCEPT while work is running — then it is
     the narration, because "editing voice loop" is strictly more informative
     than "working".

     Narration is only true while the work it describes is happening, so it is
     only shown then. The old rule was the other way round (status always won,
     and specific states cleared it), which left "running the tests" on screen
     after the run had finished and the orb had gone back to listening. It also
     raced itself: the server sends the narration line and the state it implies
     as two messages, so whichever landed second decided what you read. */
  function paintState() {
    const lbl = $("orb-state");
    const useStatus = orbState === "working" && orbStatus;
    lbl.textContent = useStatus ? orbStatus : (STATE_LABEL[orbState] || orbState);
    lbl.className = "orb-state " + orbState;
  }

  function setOrbState(s) {
    orbState = s;
    orb.setState(s === "starting" ? "idle" : s);
    paintState();
    $("brand-dot").classList.toggle("live", s !== "idle" && s !== "starting");
  }

  function setOrbStatus(text) {
    orbStatus = text || "";
    paintState();
  }
  setOrbState("starting");

  // --------------------------------------------------------------- panes

  /** One live terminal on screen. Owns its xterm instance and its pty socket. */
  class PaneView {
    constructor(info) {
      this.id = info.id;
      this.info = info;
      this.maximized = false;
      this._build();
      this._connect();
    }

    _build() {
      const el = document.createElement("div");
      el.className = "pane";
      el.dataset.id = this.id;
      el.innerHTML = `
        <div class="pane-head">
          <span class="pane-dot"></span>
          <span class="pane-title"></span>
          <!-- Which agent is running in here. Only shown when it is NOT
               Claude Code: the picker exists so panes can differ, and a
               header that names the agent only when it is the unusual one
               stays quiet in the common case and loud in the case that
               matters. -->
          <span class="pane-agent" hidden></span>
          <span class="pane-cwd"></span>
          <span class="pane-age" title="How long this session has been up"></span>
          <span class="pane-need"></span>
          <span class="pane-acts">
            <span class="pane-ctx" hidden>
              <button class="ctx-trigger" type="button" aria-label="Context used">
                <span class="bar"><i></i></span><span class="ctx-v"></span>
              </button>
              <span class="ctx-pop">
                <span class="ctx-pop-n"></span>
                <span class="ctx-pop-sub"></span>
                <button class="ctx-compact" type="button">Compact now</button>
              </span>
            </span>
            <button class="pane-act voice-act" data-act="voice"
                    aria-label="Talk to this session" aria-pressed="false"
                    >&#9673;</button>
            <button class="pane-act" data-act="max" aria-label="Maximize"
                    title="Fill the window with this session">&#9974;</button>
            <button class="pane-act danger" data-act="close" aria-label="Close"
                    title="Close this pane. The session keeps running — hold alt to stop it too."
                    >&#10005;</button>
          </span>
        </div>
        <div class="pane-term"></div>`;
      this.el = el;
      this.head = el.querySelector(".pane-head");
      this.dot = el.querySelector(".pane-dot");
      this.titleEl = el.querySelector(".pane-title");
      this.agentEl = el.querySelector(".pane-agent");
      this.cwdEl = el.querySelector(".pane-cwd");
      this.ageEl = el.querySelector(".pane-age");
      this.needEl = el.querySelector(".pane-need");
      this.ctxEl = el.querySelector(".pane-ctx");
      this.ctxBar = el.querySelector(".pane-ctx i");
      this.ctxVal = el.querySelector(".ctx-v");
      this.ctxN = el.querySelector(".ctx-pop-n");
      this.ctxSub = el.querySelector(".ctx-pop-sub");
      el.querySelector(".ctx-compact").onclick = () => this.compact();

      el.querySelector('[data-act="max"]').onclick = () => this.toggleMax();
      el.querySelector('[data-act="close"]').onclick = (e) => this.close(e.altKey);
      this.voiceBtn = el.querySelector('[data-act="voice"]');
      this.voiceBtn.onclick = () => send({ t: "voice.target", id: this.id });

      this.term = new window.Terminal({
        theme: TERM_THEME,
        fontFamily: '"SF Mono", SFMono-Regular, Menlo, monospace',
        fontSize: 11.5,
        lineHeight: 1.25,
        cursorBlink: true,
        scrollback: 8000,
        allowProposedApi: true,
        macOptionIsMeta: true,
      });
      this.fit = new window.FitAddon.FitAddon();
      this.term.loadAddon(this.fit);
      try {
        this.term.loadAddon(new window.WebLinksAddon.WebLinksAddon());
      } catch (e) { /* links are a nicety, not a requirement */ }
      this.term.open(el.querySelector(".pane-term"));

      this.term.onData((d) => this._send(d));
      this.term.onBinary((d) => this._send(d));

      // Fit on any layout change: the grid reflows whenever a pane is added,
      // removed, or maximized, and a terminal with stale geometry wraps wrong.
      this.ro = new ResizeObserver(() => this.refit());
      this.ro.observe(el);

      this.apply(this.info);
    }

    _connect() {
      this.sock = new WebSocket(WS(`/pty/${this.id}`));
      this.sock.binaryType = "arraybuffer";
      this.sock.onopen = () => { this.refit(true); };
      this.sock.onmessage = (ev) => {
        if (typeof ev.data === "string") return;
        this.term.write(new Uint8Array(ev.data));
      };
      this.sock.onclose = () => {
        if (!this.destroyed) this.term.write("\r\n\x1b[2m[pane disconnected]\x1b[0m\r\n");
      };
    }

    _send(data) {
      if (!this.sock || this.sock.readyState !== WebSocket.OPEN) return;
      this.sock.send(typeof data === "string" ? new TextEncoder().encode(data) : data);
    }

    refit(force) {
      if (this.destroyed || !this.el.isConnected) return;
      try { this.fit.fit(); } catch (e) { return; }
      const { cols, rows } = this.term;
      if (!cols || !rows) return;
      /* `force` is for the moment the socket opens. The server holds the
         process until a size arrives, so a size that never arrives is a pane
         that never runs — and the dedupe below would swallow it whenever the
         ResizeObserver happened to measure first, which it often does. The
         first message after connecting is therefore always sent. */
      if (force) { this._cols = 0; this._rows = 0; }
      /* Only when the SIZE changed.
         Every layout event ran this, and every run told the PTY to resize —
         which makes the TUI repaint from scratch. Opening six panes sent 78
         resize frames for six terminals, so a single click was followed by a
         burst of full redraws: that is the content jumping around under the
         cursor. A resize to the size it already is has nothing to tell it. */
      if (cols === this._cols && rows === this._rows) return;
      this._cols = cols; this._rows = rows;
      if (this.sock && this.sock.readyState === WebSocket.OPEN) {
        this.sock.send(JSON.stringify({ t: "resize", cols, rows }));
      }
    }

    apply(info) {
      this.info = info;
      this.titleEl.textContent = info.title || "session";
      const agent = info.agent || "claude";
      this.agentEl.hidden = agent === "claude";
      this.agentEl.textContent = agent;
      this.cwdEl.textContent = info.shortCwd || "";
      // Elapsed comes from the server rather than a local timer: a
      // reconnect must not reset every session to zero seconds old.
      this.ageEl.textContent = info.elapsed ? fmtAge(info.elapsed) : "";
      const state = info.alive ? (info.state || "idle") : "stopped";
      this.dot.className = "pane-dot " + state;
      this.dot.title = info.detail || state;
      const blocked = state === "blocked";
      this.el.classList.toggle("needs-you", blocked);
      this.needEl.textContent = blocked ? (info.waitingFor || "waiting on you") : "";
      /* WHERE YOUR VOICE IS POINTED — its own state, and it has to be legible
         at a glance. An invisible "where am I talking" is how you dictate a
         refactor into the wrong repository. It used to follow the focus ring,
         which meant it moved every time you clicked a terminal to read it. */
      const onVoice = !!info.voice;
      this.el.classList.toggle("has-voice", onVoice);
      this.voiceBtn.classList.toggle("on", onVoice);
      this.voiceBtn.setAttribute("aria-pressed", String(onVoice));
      this.voiceBtn.title = onVoice
        ? (info.kind === "voice"
            ? "Your voice goes here — this is your clone."
            : "Your voice goes here. Click to hand it back to your clone.")
        : "Talk to this session instead of your clone.";

      // The focused pane is where the keyboard lands and which repo the left
      // rail describes.
      const wasFocused = this.el.classList.contains("focused");
      this.el.classList.toggle("focused", !!info.focused);
      // Newly focused, and nothing else is asking for the keyboard: take it.
      // Guarded on `keyboardIsBusy` so this can never yank the cursor out of
      // the prompt box or a dialog you are typing in.
      if (info.focused && !wasFocused && !keyboardIsBusy()) {
        this.grabKeyboard();
      }
    }

    /* How full this session's context window is. Shown per pane rather than
       globally because it is a per-session fact, and the pane about to compact
       is the one you want to know about. */
    setContext(ctx) {
      if (!ctx || !ctx.tokens) { this.ctxEl.hidden = true; return; }
      this.ctxEl.hidden = false;
      this.lastCtx = ctx;
      const pct = Math.min(100, ctx.pct || 0);
      const win = ctx.window || 200000;

      // The figure is the prompt size of the session's LAST request. Compacting
      // changes what the NEXT one carries, so until the session takes another
      // turn there is no new number to read — and showing the old one right
      // after you pressed Compact reads as "it didn't work". Say so instead.
      if (this.ctxPending != null) {
        if (ctx.tokens === this.ctxPending) {
          this.ctxVal.textContent = "···";
          this.ctxN.textContent = "Compacted — updates on the next turn";
          this.ctxSub.textContent =
            "The gauge reads the last request, so it refreshes when this " +
            "session next does something.";
          return;
        }
        this.ctxPending = null;        // a fresh reading landed
      }

      this.ctxBar.style.width = pct + "%";
      this.ctxVal.textContent = pct.toFixed(0) + "%";
      const warn = pct >= 75;
      this.ctxEl.classList.toggle("warn", warn);
      this.ctxBar.classList.toggle("warn", warn);

      // The detail lives in the hover panel rather than a title attribute:
      // a native tooltip can't hold a button, and the thing you want when you
      // check how full a session is, is to do something about it.
      this.ctxN.textContent =
        `${fmtK(ctx.tokens)} of ${fmtK(win)} used · ${pct.toFixed(0)}%`;
      this.ctxSub.textContent = warn
        ? "Close to auto-compacting. Compacting now keeps a summary and frees the rest."
        : "Compacting summarises the conversation so far and frees the rest.";
    }

    compact() {
      send({ t: "pane.compact", id: this.id });
      // remember what the gauge said, so we can tell a stale reading from a real one
      this.ctxPending = (this.lastCtx && this.lastCtx.tokens) || 0;
      this.ctxVal.textContent = "···";
      toast(`Compacting ${this.info.title}. The gauge updates on its next turn.`);
    }

    /* One pane full-bleed. The siblings stay MOUNTED but hidden by a rule on
       the host, so their sockets and scrollback survive — and, unlike the
       inline `display: none` this replaces, closing the maximized pane cannot
       leave them hidden forever. */
    toggleMax() {
      const on = !this.el.classList.contains("maximized");
      for (const p of document.querySelectorAll(".pane.maximized")) {
        p.classList.remove("maximized");
      }
      this.el.classList.toggle("maximized", on);
      this.maximized = on;
      syncMax();
      requestAnimationFrame(() => panes.forEach((p) => p.refit()));
    }

    /* Close the pane; the session behind it is a separate question.
       Holding alt says "and stop the session too" — the two are deliberately
       distinct, because closing your view of a background agent should not
       kill an hour of its work. The header tooltip says so. */
    close(alsoStop) {
      send({ t: "pane.close", id: this.id, stop: !!alsoStop });
      // Optimistic: the pane leaves the screen on the click rather than on the
      // round trip. A close that visibly does nothing for 300ms is a close
      // button people press twice and then report as broken.
      this.el.style.display = "none";
      if (this.maximized) { this.el.classList.remove("maximized"); syncMax(); }

      /* AND IF THE SERVER NEVER AGREES, SAY SO.
         Hiding on the click is a promise about what is coming. When the close
         does not actually happen — the socket dropped, the handler raised —
         the old code left the pane hidden forever with nothing on screen to
         explain it, which is indistinguishable from a close button that does
         not work. Two seconds is long past the ~50ms a real close takes. */
      clearTimeout(this._closeTimer);
      this._closeTimer = setTimeout(() => {
        if (this.destroyed || !this.el.isConnected) return;
        this.el.style.display = "";
        this.refit();
        toast("That didn't close — the window may have lost its connection.");
      }, 2000);
    }

    /* TAKE THE KEYBOARD, WITHOUT WAITING FOR A PAINT.

       Every one of these used to be `requestAnimationFrame(() => term.focus())`,
       and requestAnimationFrame does not run while the page is not being
       painted — measured here with document.hidden true and a plain RAF that
       never fired. A window that is behind something, freshly restored, or on
       another Space is exactly that case, so the click landed, the pane lit up
       as selected, and the cursor never arrived. Typing then went nowhere,
       which is "I still can't type in the terminal I selected".

       So: synchronously, which is what a live user gesture wants anyway, and
       again on the next frame for a pane whose xterm has not attached its
       textarea yet. Both are cheap and idempotent. */
    grabKeyboard() {
      if (this.destroyed || !this.el.isConnected) return false;
      const take = () => { try { this.term.focus(); } catch (e) { /* mid-teardown */ } };
      take();
      requestAnimationFrame(take);
      return true;
    }

    destroy() {
      this.destroyed = true;
      clearTimeout(this._closeTimer);
      this.ro.disconnect();
      try { this.sock.close(); } catch (e) { /* already gone */ }
      this.term.dispose();
      this.el.remove();
    }
  }

  const panes = new Map();

  /* WHERE THE KEYBOARD IS.

     Selecting a session and being able to type into it are two different
     things, and only the first was happening: clicking a pane moved the focus
     ring, clicking a row in the rail moved the ring, and in both cases the
     browser's keyboard focus stayed where it was — on the rail button, or on
     <body> where typing goes nowhere at all.

     Everything that selects a session calls this. It is idempotent, it is
     cheap, and it is the only way the cursor gets into a terminal. */
  function focusTerminal(id) {
    const pv = panes.get(id || "");
    if (!pv || pv.destroyed) return false;
    try {
      return pv.grabKeyboard();
    } catch (e) {
      return false;
    }
  }

  /** The pane the server says your voice and keys are pointed at. */
  function focusedPane() {
    for (const pv of panes.values()) {
      if (pv.info && pv.info.focused) return pv;
    }
    return null;
  }

  /** Is the keyboard already somewhere that wants it? */
  /* NOBODY HOLDING THE KEYBOARD MEANS TYPING GOES NOWHERE.

     xterm only focuses itself when you click the text it drew. Everything else
     -- a click on the header, the grid gap, a toast dismissing, a panel
     closing, a re-render -- leaves document.activeElement on <body>. Keys then
     land on nothing at all: no cursor moves, no character appears, and the
     space bar is push-to-talk. Reported as "the claude session isn't taking my
     input, sometimes it just does this", which is exactly what it looks like
     when a session has asked you a question and the answer is going nowhere.

     So: if focus has fallen back to the body and a pane is selected, give it
     back to that pane. It only ever acts when NOTHING else wants the keyboard,
     so it cannot steal from a text field, a dialog, or another terminal. */
  function restoreKeyboardToPane() {
    const el = document.activeElement;
    if (el && el !== document.body) return;            // something wants it
    if (document.querySelector("dialog[open]")) return;
    // Read the selection off the DOM rather than a mirror of it: the
    // `focused` class is set from the server's own pane list, so it cannot
    // drift from what the ring on screen is telling the user.
    const chosen = document.querySelector(".pane.focused") ||
                   document.querySelector(".pane");
    const pane = chosen && panes.get(chosen.dataset.id);
    if (pane) pane.grabKeyboard();
  }

  // On focus leaving anything, and after the pane list re-renders. Deferred a
  // tick because focusout fires BEFORE the new focus target is set, and acting
  // on the intermediate state would fight every ordinary click.
  addEventListener("focusout", () => setTimeout(restoreKeyboardToPane, 0));
  addEventListener("click", () => setTimeout(restoreKeyboardToPane, 0));

  function keyboardIsBusy() {
    const el = document.activeElement;
    if (!el || el === document.body) return false;
    if (el.closest(".pane-term")) return true;      // a terminal already has it
    if (/^(INPUT|TEXTAREA|SELECT)$/.test(el.tagName)) return true;
    return !!el.closest("dialog[open]");
  }

  function renderPanes(list) {
    const seen = new Set();
    for (const info of list) {
      seen.add(info.id);
      const existing = panes.get(info.id);
      if (existing) {
        existing.apply(info);
      } else {
        const pv = new PaneView(info);
        panes.set(info.id, pv);
        $("panes").appendChild(pv.el);
        // You asked for this terminal; you should be able to type in it
        // without clicking it first.
        pv.grabKeyboard();
      }
    }
    for (const [id, pv] of panes) {
      if (!seen.has(id)) {
        // An install pane closing is the most likely moment for a new agent
        // to have appeared on the PATH.
        if (/^install /.test(pv.info.title || "")) send({ t: "agents" });
        pv.destroy();
        panes.delete(id);
      }
    }
    $("pane-count").textContent = String(panes.size);
    $("panes-empty").style.display = panes.size ? "none" : "";
    // "Talking to" is read from the pane list rather than waiting for a voice
    // event, so it is right on connect and right with the mic turned off —
    // where no voice event is ever emitted and the line read "—" forever.
    paintTarget(list.find((i) => i.voice) || null);
    // The rail's running list is a view of exactly this data, so it is
    // repainted from here rather than polled.
    if (sessScope === "running") paintSessionList();
    syncMax();
    layoutColumns();
    regroup(list);
    // a pane appearing or leaving reflows every sibling
    requestAnimationFrame(() => panes.forEach((p) => p.refit()));
  }

  const MIN_PANE_W = 288;    // narrower than this and a TUI wraps into soup
  const MIN_PANE_H = 260;    // and shorter than this it is a title bar
                             // with a terminal caption underneath

  /* Tile the sessions.

     Both axes are computed here rather than left to the grid, and the rule is
     the same for each: fit as many as will still be READABLE, then scroll.
     Panes stretch to fill the area while they fit — a canvas with one session
     on it should not leave two thirds of itself empty — and the moment they
     stop fitting the grid switches to a fixed row height and scrolls, because
     the alternative is sessions squeezed to nothing. */
  function layoutColumns() {
    const host = $("panes");
    const n = panes.size || 1;
    const w = host.clientWidth, h = host.clientHeight;
    if (!w || !h) return;

    const cols = Math.max(1, Math.min(n, Math.floor(w / MIN_PANE_W)));
    const rows = Math.ceil(n / cols);
    const overflowing = rows * MIN_PANE_H > h;

    host.style.setProperty("--cols", String(cols));
    host.style.setProperty("--row-h", overflowing
      ? MIN_PANE_H + "px"
      : `minmax(${MIN_PANE_H}px, 1fr)`);
    host.classList.toggle("overflowing", overflowing);
  }

  /* Whether anything is maximized is a property of the SET of panes, so it
     lives on the host. Recomputed rather than remembered: the maximized pane
     can leave without telling anyone (it closed, or its session ended). */
  function syncMax() {
    $("panes").classList.toggle(
      "has-max", !!document.querySelector(".pane.maximized"));
  }

  /* Sessions in the same repo sit next to each other.

     ORDERING, NOT HEADERS. There used to be a header row per project. It had
     to span every column, which is what broke column collapsing, and in a
     grid whose rows are sized for terminals it also ate a full 210px row to
     say one word. Each tile already names its own repo in its header, so the
     grouping that is actually useful — same project, adjacent — costs nothing
     and says nothing twice.

     Reordering only. A pane owns a live xterm instance, and moving one
     between parent nodes tears down its canvas and drops its socket, so this
     may never reparent a pane. `appendChild` on the element's existing parent
     moves it within the same parent, which xterm survives. */
  function regroup(list) {
    const host = $("panes");
    const order = [];
    const byProject = new Map();
    for (const info of list) {
      const key = info.shortCwd || "elsewhere";
      if (!byProject.has(key)) { byProject.set(key, []); order.push(key); }
      byProject.get(key).push(info);
    }
    for (const key of order) {
      for (const info of byProject.get(key)) {
        const pv = panes.get(info.id);
        if (pv && pv.el.parentNode === host) host.appendChild(pv.el);
      }
    }
  }

  $("btn-more").addEventListener("click", () => openCmd());

  /* Deep links. `#setup`, `#git`, `#rules`, `#projects` open that surface
     directly. Two reasons, both real: an error can point at the exact panel
     that fixes it, and a headless render can be pointed at one — which is how
     this layout gets LOOKED at rather than imagined. */
  const ROUTES = {
    setup:    () => openMenu("setup"),
    interview: () => openInterview(true),
    health:   () => openMenu("health"),
    voice:    () => openMenu("voice"),
    defaults: () => openMenu("defaults"),
    keys:     () => openMenu("keys"),
    sessions: () => openMenu("sessions"),
    projects: () => { send({ t: "menu.projects" }); $("proj-dlg").showModal(); },
    memory:   () => $("mem-dlg").showModal(),
    rules:    () => openRules(),
    git:      () => openGit("log"),
    changes:  () => openGit("changes"),
    log:      () => openGit("log"),
    palette:  () => openCmd(),
  };

  function route() {
    const go = ROUTES[location.hash.replace(/^#/, "")];
    if (go) go();
  }
  addEventListener("hashchange", route);
  // After the first paint, so a panel that reads live state has some to read.
  setTimeout(route, 700);

  // ------------------------------------------------------- control socket

  let sock = null;
  let retry = 0;

  function send(msg) {
    if (sock && sock.readyState === WebSocket.OPEN) sock.send(JSON.stringify(msg));
  }

  function connect() {
    sock = new WebSocket(WS("/ws"));
    sock.onopen = () => {
      retry = 0;
      // Asked for rather than pushed: the version probe shells out once per
      // agent, which is fine on connect and wrong on a 2s timer.
      send({ t: "agents" });
      send({ t: "setup" });
      send({ t: "models" });
      send({ t: "interview.status" });
    };
    sock.onmessage = (ev) => {
      let m;
      try { m = JSON.parse(ev.data); } catch (e) { return; }
      handle(m);
    };
    sock.onclose = () => {
      setOrbState("idle");
      // back off, but never so far that a restarted server feels dead
      retry = Math.min(retry + 1, 6);
      setTimeout(connect, 250 * Math.pow(1.7, retry));
    };
  }

  function handle(m) {
    switch (m.t) {
      case "panes":   renderPanes(m.panes); break;
      case "roster":  break;                       // panes carry what the UI needs
      case "state":   setOrbState(m.v); break;
      case "status":  setOrbStatus(m.v); break;
      case "level":   orb.setLevel(m.v); break;
      case "you":     chatAdd("you", m.v, true); break;
      case "clone":   setSaid(m.v); break;
      case "usage":      renderUsage(m.v); break;
      case "memory":     renderMemory(m.v); break;
      case "memory.log": memLog(m.v); break;
      case "projects":   paintProjects(m.v); break;
      case "sessions":   paintSessions(m.scope, m.cwd, m.v); break;
      case "health":     paintHealth(m.v); break;
      case "settings":   paintSettings(m.v); break;
      case "git":        paintGit(m.v); break;
      case "git.diff":   showDiff(m.path, m.v); break;
      case "git.review": showReview(m.v); break;
      case "git.result": gitResult(m.op, m.v); break;
      case "target":     paintTarget(m.v); break;
      case "dispatched": toast(`Started${m.v.note ? " " + m.v.note : ""}.`); break;
      case "project.scan":   paintScan(m.v); break;
      case "project.result": projectResult(m.op, m.v); break;
      case "muted":          paintMuted(m.v); break;
      case "setup":          paintSetup(m.v); break;
      case "models":         paintModels(m.v); break;
      case "models.progress": modelProgress(m); break;
      case "models.done":    modelsDone(m); break;
      case "interview":      paintInterview(m.v); break;
      case "setup.log":      setupLog(m); break;
      case "agents":         paintAgents(m.v); break;
      case "rules.read":     showRules(m.v); break;
      case "injected":         paintInjected(m.v); break;
      case "injected.preview": paintPreview(m.v); break;
      case "toast":   toast(m.v || ""); break;
      case "error":   toast(m.msg || "Something went wrong."); break;
    }
  }

  /* ---- the conversation

     A scrolling list rather than two replaced lines. Spoken words vanish: if
     the clone mishears you, or answers something you only half-caught, reading
     it back is the only recourse — so both sides stay.

     `you` arrives repeatedly as whisper refines the same utterance, so the
     newest `you` entry is UPDATED in place rather than appended. Appending
     each revision produced four near-identical lines per sentence, which is
     the transcript equivalent of shouting. */
  const CHAT_MAX = 200;
  let lastYou = null;

  function chatAdd(who, text, replaceLast) {
    text = (text || "").trim();
    if (!text) return;
    const list = $("chat");
    $("chat-empty").hidden = true;

    if (replaceLast && lastYou && lastYou.isConnected) {
      lastYou.querySelector(".c-text").textContent = text;
    } else {
      const li = document.createElement("li");
      li.className = "c-line " + who;
      li.innerHTML = `<span class="c-who">${who === "you" ? "you" : "clone"}</span>
                      <span class="c-text"></span>`;
      li.querySelector(".c-text").textContent = text;
      list.appendChild(li);
      if (who === "you") lastYou = li;
      while (list.children.length > CHAT_MAX + 1) {
        const first = list.querySelector(".c-line");
        if (!first) break;
        first.remove();
      }
    }
    // Follow the end only when already there, so reading back through the
    // history is not yanked away every time a new line lands.
    const atEnd = list.scrollHeight - list.scrollTop - list.clientHeight < 60;
    if (atEnd) list.scrollTop = list.scrollHeight;
  }

  function setSaid(text) {
    chatAdd("clone", text, false);
    lastYou = null;              // the answer closes the turn
  }

  // ------------------------------------------------------------- meters

  /* The limits are a scrape of a live screen, so the honest thing to show is
     not just the number but the state of the reading: in flight, how old, or
     failed. A percentage on its own is indistinguishable from a percentage
     that stopped updating an hour ago -- which is what a stuck meter looks
     like, and was the whole complaint. */
  function renderUsage(u) {
    if (!u) return;
    const put = (vId, barId, pct, label) => {
      const v = $(vId), bar = $(barId);
      if (!v) return;
      v.textContent = label;
      const has = typeof pct === "number";
      bar.style.width = has ? Math.min(100, Math.max(0, pct)) + "%" : "0%";
      bar.classList.toggle("warn", has && pct >= 80);
      const meter = v.parentElement;
      meter.classList.toggle("warn", has && pct >= 80);
      meter.classList.toggle("probing", !!u.probing);
      // stale or failed: dim it, so the number stops claiming to be current
      meter.classList.toggle("stale", !u.probing && (!!u.stale || !!u.probeError));
    };
    const age = u.ageS == null ? "" : ` · ${agoShort(u.ageS)}`;
    put("use-session", "use-session-bar", u.sessionPct,
        u.sessionPct == null ? (u.probing ? "reading…" : (u.sessionLabel || "—"))
                             : u.sessionPct + "%" + age);
    put("use-week", "use-week-bar", u.weekPct,
        u.weekPct == null ? (u.probing ? "reading…" : (u.weekLabel || "—"))
                          : u.weekPct + "%");
    $("meter-usage").title = u.tooltip || "Usage";
    $("meter-week").title = u.tooltip || "Weekly usage";
    for (const [id, ctx] of Object.entries(u.panes || {})) {
      const pv = panes.get(id);
      if (pv) pv.setContext(ctx);
    }
  }

  function agoShort(s) {
    if (s < 90) return "now";
    if (s < 5400) return `${Math.floor(s / 60)}m`;
    return `${Math.floor(s / 3600)}h`;
  }

  /* How long a session has been up. Coarse on purpose: nobody needs it to the
     second, and a figure that ticks every second in the corner of your eye is
     a distraction impersonating information. */
  function fmtAge(sec) {
    if (sec < 60) return `${Math.floor(sec)}s`;
    if (sec < 3600) return `${Math.floor(sec / 60)}m`;
    const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60);
    if (sec < 86400) return m ? `${h}h ${m}m` : `${h}h`;
    return `${Math.floor(sec / 86400)}d ${Math.floor((sec % 86400) / 3600)}h`;
  }

  // ---------------------------------------------------------- memory panel

  let memState = null;

  function renderMemory(mem) {
    if (!mem) return;
    memState = mem;
    $("mem-v").textContent = mem.label || "—";
    $("meter-mem").title = mem.tooltip || "Memory";
    if (!$("mem-dlg").open) return;
    paintMemory(mem);
  }

  function paintMemory(mem) {
    const lr = mem.lastRun || {};
    const when = lr.at ? new Date(lr.at).toLocaleString() : "never";
    const line = $("mem-line");
    line.textContent = lr.problem ? lr.problem : `Last folded in ${when}.`;
    line.classList.toggle("problem", !!lr.problem);

    const g = mem.graph || {};
    const cells = [
      { n: mem.notes, k: "notes" },
      { n: g.nodes, k: "nodes" },
      { n: g.edges, k: "links" },
      { n: mem.pending, k: "to fold in", flag: mem.pending > 0 },
      { n: g.dangling, k: "broken links", bad: g.dangling > 0 },
    ];
    /* WHAT PRESSING THE BUTTON WILL COST.

       "3 to fold in" says nothing about whether this is a rounding error or a
       third of a weekly limit, and this is the one control in the app that
       spends real money. The estimate is deliberately rough — four characters
       to a token — and says so, because the useful precision here is "small
       pass" against "big pass", not a number to the token. */
    if (mem.pendingTokens) {
      cells.push({ n: "≈" + fmtK(mem.pendingTokens), k: "tokens to read",
                   flag: mem.pendingTokens > 200000 });
    }
    if (lr.wrote != null) cells.push({ n: lr.wrote, k: "facts written last pass" });
    if (lr.failed) cells.push({ n: lr.failed, k: "extraction failures", bad: true });
    $("mem-grid").innerHTML = cells.map((c) =>
      `<div class="mem-cell ${c.flag ? "flag" : ""} ${c.bad ? "bad" : ""}">
         <span class="mem-n">${c.n == null ? "—" : c.n}</span>
         <span class="mem-k">${c.k}</span>
       </div>`).join("");

    for (const b of $("cadence-seg").querySelectorAll("button")) {
      b.setAttribute("aria-checked", String(b.dataset.c === mem.cadence));
      b.setAttribute("role", "radio");
    }

    /* The on/off switch. Off is not a quieter on: nothing is injected and
       nothing is recorded, so the session behaves exactly as it would with
       none of this installed — which is the whole point of having a switch. */
    const sw = mem.switch || { mode: "on" };
    for (const b of $("mode-seg").querySelectorAll("button")) {
      b.setAttribute("aria-checked", String(b.dataset.m === sw.mode));
      b.setAttribute("role", "radio");
    }
    $("mode-note").textContent = MODE_NOTE[sw.mode] || "";
    $("fold-cost").textContent = foldEstimate(mem);
    // Cadence only means anything if sessions are being recorded at all.
    $("cadence-seg").closest(".fld").style.opacity = sw.captures ? "" : "0.4";
    if (sw.fromEnv) {
      $("mode-note").textContent +=
        "  (set by CLONE_MEMORY in the shell that launched this — "
        + "changing it here won't take effect until you restart)";
    }
  }

  const MODE_NOTE = {
    on: "Loads who you are, recalls what's relevant, and captures this session.",
    "capture-only": "Nothing is injected — sessions still get recorded, so the "
      + "vault keeps learning while it's too thin to be worth reading.",
    off: "Nothing injected, nothing recorded. Plain Claude Code, with the voice "
      + "and everything else still here.",
  };

  $("meter-mem").addEventListener("click", () => {
    $("mem-dlg").showModal();
    if (memState) paintMemory(memState);
  });
  $("mem-close").addEventListener("click", () => $("mem-dlg").close());
  $("cadence-seg").addEventListener("click", (e) => {
    const b = e.target.closest("button[data-c]");
    if (!b) return;
    send({ t: "memory.cadence", cadence: b.dataset.c });
  });
  $("mode-seg").addEventListener("click", (e) => {
    const b = e.target.closest("button[data-m]");
    if (!b) return;
    send({ t: "memory.mode", mode: b.dataset.m });
    // Sessions already running keep the mode they started with; the hooks read
    // the switch per event, so this is the next event onwards, not retroactive.
    if (b.dataset.m !== "on") toast("Memory " + b.dataset.m + " from the next message.");
  });
  function foldEstimate(mem) {
    if (!mem || !mem.pending) return "Nothing waiting. The next pass has "
                                   + "nothing to read.";
    const t = mem.pendingTokens || 0;
    return `${mem.pending} session${mem.pending > 1 ? "s" : ""} waiting, `
         + `≈${fmtK(t)} tokens for the extractor to read (rough: four `
         + `characters to a token). Output is small — the gate rejects most `
         + `candidates — so the read is nearly all of it.`;
  }

  $("mem-run").addEventListener("click", () => {
    $("mem-log").hidden = false;
    $("mem-log").textContent = "";
    $("mem-status").textContent = "Running…";
    send({ t: "memory.consolidate" });
  });

  function memLog(line) {
    const el = $("mem-log");
    el.hidden = false;
    el.textContent += line + "\n";
    el.scrollTop = el.scrollHeight;
    if (/^done|exited with code/.test(line)) $("mem-status").textContent = line;
  }

  /* Quiet mode. Output only: everything else about the session is unchanged,
     which is what makes it usable rather than a way to half-turn-off the app. */
  let muted = false;

  function paintMuted(v) {
    muted = !!v;
    $("btn-mute").setAttribute("aria-pressed", String(muted));

    $("mute-v").textContent = muted ? "muted" : "on";
    document.body.classList.toggle("muted", muted);
  }

  $("btn-mute").addEventListener("click", () => {
    send({ t: "voice.mute", muted: !muted });
    paintMuted(!muted);                 // optimistic: a mute must feel instant
    toast(!muted ? "Muted. It still listens, types and works — it just won't "
                 + "talk." : "Voice on.");
  });

  $("meter-usage").addEventListener("click", () => send({ t: "usage.refresh" }));
  $("meter-week").addEventListener("click", () => send({ t: "usage.refresh" }));

  // -------------------------------------------------------------- inputs

  /* One prompt, two destinations. Unticked it goes to the session you are in;
     ticked it becomes a background task in its own worktree. A second text box
     for the second case is the redundancy that made the window feel sloppy. */
  $("prompt-form").addEventListener("submit", (e) => {
    e.preventDefault();
    const input = $("prompt-input");
    const text = input.value.trim();
    if (!text) return;

    if ($("mode-dispatch").checked) {
      // Not passed an agent: dispatch runs through `claude --bg`, which has no
      // Codex or Gemini equivalent. A parameter the backend drops is worse
      // than one not sent.
      send({ t: "dispatch", prompt: text,
             cwd: (gitState && gitState.cwd) || undefined, isolate: true });
      chatAdd("you", "dispatch: " + text, false);
    } else {
      send({ t: "say", text });
      chatAdd("you", text, false);
    }
    input.value = "";
  });

  const micBtn = $("mic-btn");

  // ---------------------------------------------------------- push to talk

  /* Hold space to talk, release to send.
     Only when you are not typing: a terminal pane and the prompt box both need
     a literal space, and xterm's input is a real <textarea>, so the same check
     covers both. */
  let pttDown = false;

  function typingSomewhere() {
    const el = document.activeElement;
    if (!el) return false;
    return /^(INPUT|TEXTAREA)$/.test(el.tagName) || !!el.closest(".pane-term");
  }

  function setPtt(down) {
    if (down === pttDown) return;
    pttDown = down;
    document.body.classList.toggle("talking", down);
    micBtn.setAttribute("aria-pressed", String(down));
    send({ t: "voice.ptt", down });
  }

  /* Is this space ours to consume, or does someone need a literal space? */
  function spaceIsOurs(e) {
    return e.code === "Space" && !typingSomewhere()
           && !e.metaKey && !e.ctrlKey && !e.altKey;
  }

  /* SWALLOW EVERY SPACE WE CLAIM — AUTO-REPEATS INCLUDED.
     An unhandled space in a webview is a system beep, and holding a key fires
     keydown ~15 times a second, so an early `return` on e.repeat turns the beep
     into a continuous ticking noise for as long as you are talking. The check
     for e.repeat therefore has to come AFTER preventDefault, never instead of
     it. Capture phase so nothing downstream sees it either. */
  addEventListener("keydown", (e) => {
    if (!spaceIsOurs(e)) return;
    e.preventDefault();
    e.stopPropagation();
    if (!e.repeat) setPtt(true);
  }, true);

  addEventListener("keyup", (e) => {
    // Release on any space-up while held, even if focus moved into a terminal
    // mid-hold — otherwise the microphone latches down.
    if (e.code !== "Space" || !pttDown) return;
    e.preventDefault();
    e.stopPropagation();
    setPtt(false);
  }, true);
  // Losing focus mid-hold would otherwise latch it down forever, recording
  // until something else happened to press space again.
  addEventListener("blur", () => setPtt(false));
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) setPtt(false);
  });

  // Press and hold with a mouse: on the orb, or on the mic button. Both are the
  // same gesture as the space bar, because there is only one way to talk to it.
  for (const el of [$("orb"), micBtn]) {
    el.addEventListener("mousedown", (e) => { e.preventDefault(); setPtt(true); });
  }
  addEventListener("mouseup", () => setPtt(false));
  // A drag that ends outside the window never fires mouseup on us.
  addEventListener("mouseleave", () => setPtt(false));

  $("btn-terminal").addEventListener("click", () => send({ t: "pane.open", kind: "plain", agent: chosenAgent }));

  const dlg = $("dispatch-dlg");
  /* The dispatch dialog is still here for the case that needs its extra
     fields — a different directory, a name, a model. The everyday path is the
     tick beside the prompt, and the button that used to sit in the sessions
     rail is gone: three labelled buttons at that size wrapped onto two lines
     and pushed the last one off the edge. It is reachable from ⌘K. */
  function openDispatch() {
    $("d-cwd").value = (gitState && gitState.cwd) || "";
    dlg.showModal();
    $("d-prompt").focus();
  }
  $("dispatch-form").addEventListener("submit", (e) => {
    if (e.submitter && e.submitter.value !== "go") return;
    const prompt = $("d-prompt").value.trim();
    if (!prompt) return;
    send({
      t: "dispatch", prompt,
      cwd: $("d-cwd").value.trim(),
      name: $("d-name").value.trim(),
    });
    $("d-prompt").value = "";
    $("d-name").value = "";
    toast("Dispatched. The pane opens when the session starts.");
  });

  // ---------------------------------------------------------------- menu

  const drawer = $("drawer");
  const scrim = $("scrim");
  let menuTab = "projects";
  let projectsCache = [];
  let sessionCwd = null;

  const TAB_LOADERS = {
    setup:    () => send({ t: "setup" }),
    rules:    () => send({ t: "injected" }),
    health:   () => send({ t: "menu.health" }),
    voice:    () => send({ t: "menu.settings" }),
    defaults: () => send({ t: "menu.settings" }),
    keys:     () => paintKeys(),
  };

  function openMenu(tab) {
    drawer.hidden = false;
    scrim.hidden = false;
    $("menu-btn").setAttribute("aria-expanded", "true");
    showTab(tab || menuTab);
  }

  function closeMenu() {
    drawer.hidden = true;
    scrim.hidden = true;
    $("menu-btn").setAttribute("aria-expanded", "false");
  }

  function showTab(tab) {
    menuTab = tab;
    for (const b of $("drawer-tabs").querySelectorAll("button")) {
      b.setAttribute("aria-selected", String(b.dataset.tab === tab));
    }
    for (const p of drawer.querySelectorAll(".tab-body")) {
      p.hidden = p.dataset.panel !== tab;
    }
    (TAB_LOADERS[tab] || (() => {}))();
  }

  $("menu-btn").addEventListener("click", () =>
    drawer.hidden ? openMenu() : closeMenu());
  $("drawer-close").addEventListener("click", closeMenu);
  scrim.addEventListener("click", closeMenu);
  $("drawer-tabs").addEventListener("click", (e) => {
    const b = e.target.closest("button[data-tab]");
    if (b) showTab(b.dataset.tab);
  });

  // ---- projects

  /* One project list, in the switcher the left rail opens. The menu used to
     carry a second, poorer copy; two lists of the same thing is the padding
     that makes a menu feel long. The loop shape stays because a second view
     (a Projects page) is a plausible next step and this is where it plugs in. */
  const PROJECT_VIEWS = [
    { filter: "proj-filter", rows: "proj-rows" },
  ];

  let projectSort = "recent";

  /* The payload is now {projects, sort, sorts} rather than a bare list: the
     registry owns the sort order, so the server is the one place that knows
     it and both views agree without either holding an opinion. */
  function paintProjects(payload) {
    const list = Array.isArray(payload) ? payload : (payload && payload.projects) || [];
    projectsCache = list;
    if (payload && payload.sort) projectSort = payload.sort;
    paintSortControl(payload && payload.sorts);

    for (const view of PROJECT_VIEWS) {
      const box = $(view.filter), ul = $(view.rows);
      if (!box || !ul) continue;
      const q = box.value.trim().toLowerCase();
      const rows = projectsCache.filter((p) =>
        !q || p.name.toLowerCase().includes(q) || p.cwd.toLowerCase().includes(q));
      if (!rows.length) {
        ul.innerHTML = `<li class="none">${
          q ? "No project matches that." : "Nothing yet — add a folder below."}</li>`;
        continue;
      }
      ul.innerHTML = rows.map((p) => `
        <li class="prow ${p.missing ? "missing" : ""}">
          <button class="row" data-cwd="${esc(p.cwd)}" ${p.missing ? "disabled" : ""}
                  title="${esc(p.cwd)}">
            ${p.live ? '<span class="row-dot"></span>' : ""}
            <span class="row-name">${p.pinned ? "★ " : ""}${esc(p.name)}</span>
            <span class="row-sub">${p.missing ? "folder is gone" : esc(p.parent)}</span>
            <span class="row-meta">${
              p.defaultBranch ? esc(p.defaultBranch) + " · " : ""
            }${p.sessions} · ${esc(agoOf(p.lastActive))}</span>
          </button>
          <span class="prow-acts">
            <button class="lnk" data-act="pin" data-cwd="${esc(p.cwd)}"
                    title="${p.pinned ? "Unpin" : "Pin"}">${p.pinned ? "★" : "☆"}</button>
            <button class="lnk" data-act="rename" data-cwd="${esc(p.cwd)}"
                    title="Rename">✎</button>
            <button class="lnk" data-act="remove" data-cwd="${esc(p.cwd)}"
                    title="Forget this project (the folder is not touched)">✕</button>
          </span>
        </li>`).join("");
    }
  }

  const SORT_LABEL = {
    recent: "Recently changed", lastSession: "Last session",
    activeSessions: "Active sessions", mostVisited: "Most visited",
  };

  function paintSortControl(sorts) {
    const el = $("proj-sort");
    if (!el) return;
    const opts = sorts && sorts.length ? sorts : Object.keys(SORT_LABEL);
    el.innerHTML = opts.map((s) =>
      `<option value="${esc(s)}" ${s === projectSort ? "selected" : ""}
        >${esc(SORT_LABEL[s] || s)}</option>`).join("");
  }

  /* THE WHOLE ROW IS THE TARGET.

     A row is a button with a strip of actions beside it, and the actions are
     invisible until you hover — so the right-hand third of every row was a
     dead zone that swallowed clicks and did nothing at all. Measured: a click
     at the middle-right of a project row landed on the <li>, matched no
     button, and returned. That is the whole of "selecting a project from the
     dropdown doesn't work".

     `rowButton` falls back from the click target to the row's own button, so
     padding, whitespace and the timestamp column all select the row. Actions
     are checked first and still win where they are. */
  function rowButton(e, sel) {
    const act = e.target.closest("button[data-act]");
    if (act) return null;                       // an action, not the row
    const direct = e.target.closest(sel);
    if (direct) return direct;
    const row = e.target.closest("li");
    return row ? row.querySelector(sel) : null;
  }

  for (const view of PROJECT_VIEWS) {
    const box = $(view.filter), ul = $(view.rows);
    if (!box || !ul) continue;
    box.addEventListener("input", () => paintProjects(projectsCache));
    ul.addEventListener("click", (e) => {
      const act = e.target.closest("button[data-act]");
      if (act) { projectAction(act.dataset.act, act.dataset.cwd); return; }

      const b = rowButton(e, "button[data-cwd]");
      if (!b || b.disabled) return;
      send({ t: "pane.open", kind: "plain", cwd: b.dataset.cwd, agent: chosenAgent });
      closeMenu();
      const dlg = $("proj-dlg");
      if (dlg.open) dlg.close();
      toast(`Opening a terminal in ${b.querySelector(".row-name").textContent}.`);
    });
  }

  function projectAction(act, cwd) {
    const p = projectsCache.find((x) => x.cwd === cwd) || { name: cwd };
    if (act === "pin") {
      send({ t: "project.pin", cwd, pinned: !p.pinned });
    } else if (act === "rename") {
      const name = prompt("Name for this project:", p.name);
      if (name && name.trim()) send({ t: "project.rename", cwd, name: name.trim() });
    } else if (act === "remove") {
      // The wording matters. "Remove" reads as "delete", and the whole point
      // is that it does not: this forgets the project and leaves the folder.
      if (confirm(`Forget "${p.name}"?\n\n`
                + `It disappears from this list. The folder on disk is NOT `
                + `touched, and re-adding it brings it straight back.`)) {
        send({ t: "project.remove", cwd });
      }
    }
  }

  const sortSel = $("proj-sort");
  if (sortSel) {
    sortSel.addEventListener("change", () => {
      projectSort = sortSel.value;
      send({ t: "project.sort", sort: projectSort });
    });
  }

  $("proj-add").addEventListener("click", () => {
    const path = $("proj-add-path").value.trim();
    if (!path) { toast("Give a folder path."); return; }
    send({ t: "project.add", cwd: path, name: $("proj-add-name").value.trim() });
    $("proj-add-path").value = "";
    $("proj-add-name").value = "";
  });

  $("proj-scan").addEventListener("click", () => {
    const path = $("proj-scan-path").value.trim();
    if (!path) { toast("Give a workspace folder to scan."); return; }
    $("proj-found").innerHTML = `<li class="loading">Scanning…</li>`;
    send({ t: "project.scan", path });
  });

  function paintScan(res) {
    const ul = $("proj-found");
    if (!res.ok) { ul.innerHTML = `<li class="none">${esc(res.error)}</li>`; return; }
    const fresh = res.found.filter((f) => !f.registered);
    if (!res.found.length) {
      ul.innerHTML = `<li class="none">No git repositories under that folder.</li>`;
      return;
    }
    // Never import silently: everything found is listed, already-registered
    // ones are shown but unchecked, and you choose what actually gets added.
    ul.innerHTML = res.found.map((f) => `
      <li class="frow">
        <input type="checkbox" ${f.registered ? "" : "checked"}
               ${f.registered ? "disabled" : ""} value="${esc(f.cwd)}">
        <span class="f-name">${esc(f.name)}</span>
        <span class="f-sub">${f.registered ? "already added" : esc(f.parent)}</span>
      </li>`).join("")
      + (res.truncated ? `<li class="none">Stopped at ${res.found.length}; narrow the path.</li>` : "");
    $("proj-import").hidden = !fresh.length;
    $("proj-import").textContent = `Import ${fresh.length}`;
  }

  $("proj-import").addEventListener("click", () => {
    const paths = [...$("proj-found").querySelectorAll("input:checked:not(:disabled)")]
      .map((i) => i.value);
    if (!paths.length) { toast("Nothing selected."); return; }
    send({ t: "project.import", paths });
    $("proj-import").hidden = true;
  });

  function projectResult(op, r) {
    if (!r) return;
    if (op === "project.import") {
      const n = (r.added || []).length, bad = (r.failed || []).length;
      toast(bad ? `Added ${n}, ${bad} failed.` : `Added ${n}.`);
      $("proj-found").innerHTML = "";
      return;
    }
    if (!r.ok) { toast(r.error || "That did not work."); return; }
    if (op === "project.add") toast("Added.");
    if (op === "project.remove") toast("Forgotten. The folder is untouched.");
  }

  /* ---- sessions, in the rail

     Three questions, one list:

       running   what is on screen right now — click to select it (◉ marks the
                 one your voice is pointed at; the button is in its header)
       project   what I was doing in THIS repo, closed or not
       recent    what I was doing anywhere

     This is where "the changes list" used to be. A file list is something you
     read once before committing; the sessions are what you move between all
     day, and a closed pane being unrecoverable was the actual gap. Reopening
     resumes the conversation with its context intact rather than starting a
     new one in the same folder. */
  let sessScope = "running";
  const pastRows = { project: [], recent: [] };

  function loadSessions() {
    if (sessScope === "running") { paintSessionList(); return; }
    $("sess-list").innerHTML = `<li class="loading">Reading…</li>`;
    send({ t: "menu.sessions", scope: sessScope,
           cwd: (gitState && gitState.cwd) || undefined });
  }

  function paintSessionList() {
    const ul = $("sess-list");
    if (sessScope === "running") {
      const live = [...panes.values()].map((p) => p.info);
      $("sess-n").textContent = String(live.length);
      ul.innerHTML = live.length ? live.map((i) => `
        <li class="srow ${i.focused ? "on" : ""}" data-pane="${esc(i.id)}">
          <span class="s-dot ${esc(i.alive ? (i.state || "idle") : "stopped")}"></span>
          <button class="s-main" type="button" data-pane="${esc(i.id)}"
                  title="${esc(i.cwd)}">
            <span class="s-name">${esc(i.title)}</span>
            <span class="s-sub">${esc(i.shortCwd)}</span>
          </button>
          ${i.voice ? `<span class="s-voice" title="Your voice goes here">&#9673;</span>` : ""}
          <span class="s-when">${esc(i.elapsed ? fmtAge(i.elapsed) : "")}</span>
          <button class="lnk s-x" type="button" data-close="${esc(i.id)}"
                  title="Close this pane">&#10005;</button>
        </li>`).join("")
        : `<li class="none">Nothing running. Open a terminal, or reopen one below.</li>`;
      return;
    }

    const rows = pastRows[sessScope] || [];
    $("sess-n").textContent = String(rows.length);
    ul.innerHTML = rows.length ? rows.map((s) => `
      <li class="srow">
        <span class="s-dot ${s.live ? "attached" : "past"}"></span>
        <button class="s-main" type="button" data-sid="${esc(s.id)}"
                data-cwd="${esc(s.cwd || sessionCwd || "")}"
                title="Reopen — the conversation keeps its context">
          <span class="s-name">${esc(s.title)}</span>
          <span class="s-sub">${esc(s.project || s.branch || "")}</span>
        </button>
        <span class="s-when">${esc(s.ago)}</span>
      </li>`).join("")
      : `<li class="none">${sessScope === "project"
          ? "No past sessions in this project."
          : "No sessions on this machine yet."}</li>`;
  }

  function paintSessions(scope, cwd, list) {
    sessionCwd = cwd;
    if (scope && scope !== "running") pastRows[scope] = list || [];
    // A slow answer must not paint itself into a list you have moved on from.
    if (scope === sessScope) paintSessionList();
  }

  $("sess-scope").addEventListener("click", (e) => {
    const b = e.target.closest("button[data-scope]");
    if (!b) return;
    sessScope = b.dataset.scope;
    for (const x of $("sess-scope").querySelectorAll("button")) {
      x.setAttribute("aria-checked", String(x.dataset.scope === sessScope));
    }
    loadSessions();
  });

  $("sess-list").addEventListener("click", (e) => {
    const x = e.target.closest("button[data-close]");
    if (x) {
      const pv = panes.get(x.dataset.close);
      if (pv) pv.close(false);
      return;
    }
    // The dot, the elapsed time and the gap around them are part of the row.
    const b = rowButton(e, "button[data-pane], button[data-sid]");
    if (!b) return;
    if (b.dataset.pane) {
      send({ t: "pane.focus", id: b.dataset.pane });
      // Picking a session from the rail means you want to use it. Without
      // this the keyboard stayed on the row you just clicked.
      focusTerminal(b.dataset.pane);
      return;
    }
    send({
      t: "pane.resume", sessionId: b.dataset.sid,
      cwd: b.dataset.cwd || sessionCwd,
      title: b.querySelector(".s-name").textContent.slice(0, 40),
    });
    toast("Reopening that session, with its context.");
  });

  // ---- health

  function paintHealth(h) {
    const failing = h.failing || 0;
    $("health-line").textContent = failing
      ? `${failing} thing${failing > 1 ? "s" : ""} need attention.`
      : "Everything checks out.";
    $("health-line").classList.toggle("problem", failing > 0);
    // surface it on the closed menu too, so a silent breakage still shows
    $("health-flag").hidden = !failing;
    $("menu-flag").hidden = !failing;

    $("health-rows").innerHTML = (h.checks || []).map((c) => {
      const cls = c.ok === true ? "ok" : c.ok === null ? "unknown" : (c.level || "warn");
      return `<li class="check ${cls}">
        <span class="check-top">
          <span class="check-mark"></span>
          <span class="check-name">${esc(c.name)}</span>
          <span class="check-detail">${esc(c.detail)}</span>
        </span>
        ${c.fix ? `<span class="check-fix">${esc(c.fix)}</span>` : ""}
      </li>`;
    }).join("");
  }

  $("health-refresh").addEventListener("click", () => {
    $("health-line").textContent = "Checking…";
    send({ t: "menu.health" });
  });

  // ---- voice + defaults

  const PERM_LABEL = {
    bypassPermissions: "Don't ask", acceptEdits: "Auto-edit",
    plan: "Plan only", default: "Ask",
  };

  function seg(id, pairs, current, attr) {
    $(id).innerHTML = pairs.map(([val, label]) =>
      `<button type="button" role="radio" data-${attr}="${esc(val)}"
        aria-checked="${String(val === String(current))}">${esc(label)}</button>`).join("");
  }

  function paintSettings(s) {
    const v = s.voice || {};
    $("speed").value = v.speed != null ? v.speed : 1.06;
    paintSpeed($("speed").value);

    // grouped by language, because 54 raw ids is a list, not a choice
    const byLang = {};
    for (const opt of s.voices || []) (byLang[opt.lang] = byLang[opt.lang] || []).push(opt);
    $("voice-pick").innerHTML = Object.entries(byLang).map(([lang, opts]) =>
      `<optgroup label="${esc(lang)}">${opts.map((o) =>
        `<option value="${esc(o.id)}" ${o.id === v.voice ? "selected" : ""}>${
          esc(o.name)} · ${esc(o.gender)}</option>`).join("")}</optgroup>`).join("");

    const d = s.defaults || {};
    const o = s.options || {};
    seg("model-seg", (o.models || []).map((x) => [x, x]), d.model, "v");
    seg("perm-seg", (o.permissionModes || []).map(
      (x) => [x, PERM_LABEL[x] || x]), d.permissionMode, "v");
    seg("whisper-seg", (o.whisper || []).map((x) => [x, x]), d.whisper, "v");
  }

  /* The travelled part of the track is painted from the value, because a
     WebKit range gives you no way to style "left of the thumb" on its own. */
  function paintSpeed(v) {
    const el = $("speed");
    const min = Number(el.min), max = Number(el.max);
    const pct = ((Number(v) - min) / (max - min)) * 100;
    el.style.setProperty("--fill", pct.toFixed(1) + "%");
    $("speed-val").textContent = `${Number(v).toFixed(2)}×`;
  }

  $("speed").addEventListener("input", (e) => paintSpeed(e.target.value));
  $("speed").addEventListener("change", (e) =>
    send({ t: "settings.voice", patch: { speed: Number(e.target.value) } }));
  // Judged by ear or not at all: 1.06x against 1.24x is meaningless written down.
  $("speed-test").addEventListener("click", () => send({ t: "voice.test" }));
  $("voice-pick").addEventListener("change", (e) =>
    send({ t: "settings.voice", patch: { voice: e.target.value } }));
  [["model-seg", "model"], ["perm-seg", "permissionMode"],
   ["whisper-seg", "whisper"]].forEach(([id, key]) => {
    $(id).addEventListener("click", (e) => {
      const b = e.target.closest("button[data-v]");
      if (!b) return;
      const patch = {};
      patch[key] = b.dataset.v;
      send({ t: "settings.defaults", patch });
    });
  });

  // ---- keys

  /* Kept honest against the code. This list said "drag divider" for a while
     after the divider was deleted, which is the specific way a shortcuts sheet
     becomes worse than no sheet: it is the one place a user cannot check for
     themselves. */
  const KEYS = [
    ["space", "Hold to talk, release to send"],
    ["⌘K", "Command palette — every action, by name"],
    ["⌘/", "This list"],
    ["/", "Jump to the prompt"],
    ["esc", "Leave the prompt, or close what is open"],
    ["click a pane", "Talk and type to that session, in its repo"],
    ["⌥ + ✕", "Close a pane AND stop the session behind it"],
    ["↑ ↓", "Move through the palette; ↵ runs"],
  ];

  function paintKeys() {
    $("keys-rows").innerHTML = KEYS.map(([k, what]) =>
      `<li><kbd>${esc(k)}</kbd><span>${esc(what)}</span></li>`).join("");
  }

  // ---- helpers

  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }

  function fmtK(n) {
    return n >= 1000 ? `${(n / 1000).toFixed(n >= 100000 ? 0 : 1)}k`
                     : String(n);
  }

  function agoOf(iso) {
    if (!iso) return "";
    const s = Math.max(0, (Date.now() - new Date(iso).getTime()) / 1000);
    if (s < 3600) return `${Math.floor(s / 60) || 1}m`;
    if (s < 86400) return `${Math.floor(s / 3600)}h`;
    if (s < 86400 * 7) return `${Math.floor(s / 86400)}d`;
    return `${Math.floor(s / (86400 * 7))}w`;
  }

  /* The splitter is gone with the stacked layout: the voice rail is its own
     column now, so there is no height for a drag handle to take away from it.
     Removed rather than hidden — a listener bound to an element that no longer
     exists is a null dereference waiting for the next person to re-add the id. */

  // ------------------------------------------------- where am I, and git

  let gitState = { files: [] };

  function paintTarget(t) {
    // "talking to" is the safety line for push-to-talk: you are about to
    // dictate into a real session and you should be able to see which one
    // without clicking anything. The clone is named as the clone rather than
    // as "voice", because that is what it is and it is the resting state.
    const el = $("target-name");
    if (!t) { el.textContent = "—"; el.title = ""; return; }
    el.textContent = t.kind === "voice" ? "your clone" : (t.title || "—");
    el.title = t.cwd || "";
  }

  function paintGit(g) {
    gitState = g || { files: [] };
    const files = gitState.files || [];

    $("here-name").textContent = gitState.project || "—";
    $("here-path").textContent = gitState.cwd || "";
    $("here-branch-name").textContent =
      gitState.repo ? (gitState.branch || "detached") : "no repo";

    const dot = $("git-dot");
    dot.className = "git-dot " + (!gitState.repo ? "none"
                                  : files.length ? "dirty" : "clean");
    $("here-branch").title = gitState.label || "";

    $("git-count").textContent = String(files.length);
    $("gtab-n").textContent = files.length ? String(files.length) : "";
    $("git-actions").hidden = !gitState.repo;
    $("here-changes").hidden = !gitState.repo;

    // Totals beside the count. Blank rather than "+0 −0" when nothing changed:
    // a row of zeroes is noise that reads, at a glance, like data.
    const delta = $("git-delta");
    delta.innerHTML = (gitState.add || gitState.rem)
      ? `<span class="add">+${gitState.add}</span><span class="rem">−${gitState.rem}</span>`
      : "";

    paintMiniLog();

    const note = $("git-note");
    note.className = "git-note" + (gitState.error ? " bad" : "");
    const bits = [];
    if (gitState.error) bits.push(gitState.error);
    if (gitState.ahead) bits.push(`${gitState.ahead} to push`);
    if (gitState.behind) bits.push(`${gitState.behind} to pull`);
    if (gitState.conflicts) bits.push(`${gitState.conflicts} conflict(s)`);
    note.textContent = bits.join(" · ");

    // The panel is a view of the same state, so it has to follow it. Without
    // this, committing from the rail leaves an open panel showing files that
    // are no longer changed.
    if ($("git-dlg").open) paintGitPanel();
  }

  function gitResult(op, r) {
    if (!r) return;
    if (!r.ok) { toast(r.error || `${op} failed`); return; }
    const said = {
      "git.commit": "Committed.", "git.push": "Pushed.",
      "git.branch": "Switched branch.",
      "git.worktree": r.path ? `Worktree at ${r.path}` : "Worktree created.",
    }[op];
    if (said) toast(said);
    if (op === "git.commit") $("commit-msg").value = "";
  }

  function showDiff(path, d) {
    $("diff-title").textContent = path || "Diff";
    const body = $("diff-body");
    body.innerHTML = "";
    if (d.error) { body.textContent = d.error; }
    else if (!d.text) { body.textContent = "No changes."; }
    else {
      // Coloured by first character. A real parser is not worth it here: the
      // only thing being conveyed is added/removed/context, and getting that
      // wrong is visually obvious rather than silently misleading.
      for (const line of d.text.split("\n")) {
        const span = document.createElement("span");
        span.className = line.startsWith("+") ? "add"
                       : line.startsWith("-") ? "del"
                       : line.startsWith("@@") ? "hunk" : "";
        span.textContent = line + "\n";
        body.appendChild(span);
      }
      if (d.truncated) {
        const more = document.createElement("span");
        more.className = "hunk";
        more.textContent = "\n… diff truncated; open the file to see the rest.\n";
        body.appendChild(more);
      }
    }
    $("diff-dlg").showModal();
  }

  $("diff-close").addEventListener("click", () => $("diff-dlg").close());
  $("git-refresh").addEventListener("click", () => send({ t: "git.refresh" }));

  // ---------------------------------------------------- the full git panel

  /* The rail's glance at the same history the panel draws in full.

     Six commits, lanes and subjects, no metadata: at 250px a date column and
     an author column would take the space the subject needs, and the subject
     is the only part that tells you what happened. Everything else is one
     click away in the panel. */
  const MINI_COMMITS = 6;

  function paintMiniLog() {
    const ul = $("mini-log");
    const log = (gitState.log || []).slice(0, MINI_COMMITS);
    if (!gitState.repo) {
      ul.innerHTML = `<li class="none">Not a git repository.</li>`;
      return;
    }
    if (!log.length) {
      ul.innerHTML = `<li class="none">No commits yet.</li>`;
      return;
    }
    ul.innerHTML = log.map((c) => `
      <li title="${esc(c.short)} · ${esc(c.author)} · ${esc(c.when)}">
        ${laneSvg(c, true)}
        <span class="ml-sub">${esc(c.subject)}</span>
        <span class="ml-when">${esc(shortWhen(c.when))}</span>
      </li>`).join("");
  }

  /* "6 minutes ago" is fifteen characters of a 250px rail and twelve of them
     are the word "minutes". git's own %ar is right in the panel, where there
     is room for it, and wrong here. */
  function shortWhen(s) {
    const m = /^(\d+)\s*(second|minute|hour|day|week|month|year)/.exec(s || "");
    if (!m) return (s || "").replace(" ago", "");
    return m[1] + { second: "s", minute: "m", hour: "h", day: "d",
                    week: "w", month: "mo", year: "y" }[m[2]];
  }

  const LANE_W = 13, ROW_H = 22, DOT_R = 3.5;
  const MINI_LANE_W = 9, MINI_ROW_H = 17, MINI_DOT_R = 2.6;
  // Lane colours cycle. Deliberately muted and few: a graph where every branch
  // is a different saturated hue is a chart of nothing.
  const LANE_COLOURS = ["#7d9b76", "#c9a227", "#6e8ba0", "#a0786e", "#8a7da0", "#6e747c"];

  function laneSvg(c, mini) {
    /* One row of the graph.

       Drawn per row rather than as one tall SVG so rows can be added, removed
       and hovered independently, and so a long history costs nothing until it
       is scrolled to. The vertical for this commit's own lane is split at the
       dot: a line above means "has children", below means "has parents", and a
       root commit correctly shows only the top half.

       `mini` is the same geometry at rail scale. One function rather than two,
       because the graph in the rail and the graph in the panel disagreeing
       about where a branch went would be worse than having no rail graph. */
    const lw = mini ? MINI_LANE_W : LANE_W;
    const rh = mini ? MINI_ROW_H : ROW_H;
    const dr = mini ? MINI_DOT_R : DOT_R;
    const w = Math.max(1, c.width) * lw;
    const x = c.lane * lw + lw / 2;
    const colour = LANE_COLOURS[c.lane % LANE_COLOURS.length];
    const parts = [];

    for (const t of c.through) {
      const tx = t * lw + lw / 2;
      parts.push(`<line x1="${tx}" y1="0" x2="${tx}" y2="${rh}"
                        stroke="${LANE_COLOURS[t % LANE_COLOURS.length]}"
                        stroke-width="1.5" opacity="0.55"/>`);
    }
    parts.push(`<line x1="${x}" y1="0" x2="${x}" y2="${rh / 2}"
                      stroke="${colour}" stroke-width="1.5" opacity="0.55"/>`);
    if (c.parents.length) {
      parts.push(`<line x1="${x}" y1="${rh / 2}" x2="${x}" y2="${rh}"
                        stroke="${colour}" stroke-width="1.5" opacity="0.55"/>`);
    }
    parts.push(`<circle cx="${x}" cy="${rh / 2}" r="${c.merge ? dr + 1 : dr}"
                        fill="${c.merge ? "var(--void)" : colour}"
                        stroke="${colour}" stroke-width="1.5"/>`);

    return `<svg class="lane" width="${w}" height="${rh}"
                 viewBox="0 0 ${w} ${rh}" aria-hidden="true">${parts.join("")}</svg>`;
  }

  function paintGitPanel() {
    const g = gitState;
    $("git-title").textContent = g.project || "Git";
    $("git-sub").textContent = [g.cwd, g.branch && `on ${g.branch}`]
      .filter(Boolean).join("  ·  ");

    // changes
    const ch = $("gchanges");
    const files = g.files || [];
    ch.innerHTML = files.length ? "" :
      `<li class="gf-empty">Nothing changed.</li>`;
    for (const f of files) {
      const cut = f.path.lastIndexOf("/");
      const dir = cut < 0 ? "" : f.path.slice(0, cut + 1);
      const base = cut < 0 ? f.path : f.path.slice(cut + 1);
      const li = document.createElement("li");
      const staged = f.staged && !f.untracked;
      li.innerHTML = `
        <input type="checkbox" ${staged ? "checked" : ""}
               aria-label="Stage ${esc(f.path)}">
        <span class="gf-tag ${f.conflict ? "conflict" : (f.staged ? "staged" : "")}"
              >${esc(f.conflict ? "conflict" : (f.staged || f.unstaged || ""))}</span>
        <span class="gc-path"><b>${esc(base)}</b><span>${esc(dir)}</span></span>
        <span class="gc-delta">${f.add ? `<span class="add">+${f.add}</span>` : ""}${
          f.rem ? `<span class="rem">−${f.rem}</span>` : ""}</span>`;
      // Per-file staging survives the move out of the rail. "Stage all" covers
      // the common case; committing half of what you changed is the case that
      // matters when it comes up.
      li.querySelector("input").addEventListener("change", (e) =>
        send({ t: e.target.checked ? "git.stage" : "git.unstage",
               cwd: g.cwd, paths: [f.path] }));
      li.querySelector(".gc-path").addEventListener("click", () =>
        send({ t: "git.diff", cwd: g.cwd, path: f.path, staged: !!f.staged }));
      ch.appendChild(li);
    }

    // branches
    const b = g.branches || { branches: [], current: "" };
    $("gbranches").innerHTML = (b.branches || []).map((name) => `
      <li><button class="row" data-branch="${esc(name)}">
        <span class="row-name">${esc(name)}</span>
        <span class="row-sub">${name === b.current ? "current" : "switch to"}</span>
      </button></li>`).join("") || `<li class="none">No branches yet.</li>`;
    const trees = g.worktrees || [];
    const wt = $("gworktrees");
    wt.innerHTML = "";
    if (trees.length <= 1) {
      wt.textContent = "One working tree. A dispatched task gets its own "
                     + "automatically, so two agents never share this one.";
    } else {
      for (const t of trees) {
        const row = document.createElement("div");
        row.className = "wt-row";
        // The first entry is the main checkout; removing it is not a thing.
        const main = t.path === g.root;
        row.innerHTML = `<span class="wt-b">${esc(t.branch || "?")}</span>
          <span class="wt-p">${esc(t.path)}</span>` +
          (main ? `<span class="wt-x">main</span>`
                : `<button class="lnk wt-x" title="Remove this worktree">remove</button>`);
        if (!main) {
          row.querySelector("button").addEventListener("click", () => {
            if (!confirm(`Remove the worktree at ${t.path}?\n\n`
                       + `Uncommitted work in it is not recoverable.`)) return;
            send({ t: "git.worktree.remove", cwd: g.cwd, path: t.path,
                   deleteBranch: true });
          });
        }
        wt.appendChild(row);
      }
    }

    // log. The author is printed only when it CHANGES: in a repo with one
    // person in it, a name repeated down forty rows is forty rows of nothing,
    // and it is exactly the column the subject needed.
    let lastAuthor = null;
    $("glog").innerHTML = (g.log || []).map((c) => {
      const showAuthor = c.author !== lastAuthor;
      lastAuthor = c.author;
      return `
      <li>
        ${laneSvg(c)}
        <span class="g-sha">${esc(c.short)}</span>
        ${c.refs.map((r) => `<span class="g-ref ${r.startsWith("HEAD") ? "head" : ""}"
                              >${esc(r.replace("HEAD -> ", ""))}</span>`).join("")}
        <span class="g-sub">${esc(c.subject)}</span>
        <span class="g-meta" title="${esc(c.author)}">${
          showAuthor ? esc(c.author) + " · " : ""}${esc(c.when)}</span>
      </li>`;
    }).join("") || `<li class="none">No commits yet.</li>`;
  }

  function showGTab(name) {
    for (const b of $("gtabs").querySelectorAll("button")) {
      b.setAttribute("aria-selected", String(b.dataset.gtab === name));
    }
    for (const p of document.querySelectorAll(".gpanel")) {
      p.hidden = p.dataset.gpanel !== name;
    }
  }

  /* The rail opens the panel on CHANGES, because a count of changed files is
     what you just clicked; everything else opens it on the graph. */
  $("here-changes").addEventListener("click", () => openGit("changes"));
  // The glance graph opens the full one: same thing, with room for it.
  $("mini-log").addEventListener("click", () => openGit("log"));

  function openGit(tab) {
    paintGitPanel();
    showGTab(tab || "log");
    if (!$("git-dlg").open) $("git-dlg").showModal();
  }
  $("git-close").addEventListener("click", () => $("git-dlg").close());
  $("gtabs").addEventListener("click", (e) => {
    const b = e.target.closest("button[data-gtab]");
    if (b) showGTab(b.dataset.gtab);
  });
  $("gbranches").addEventListener("click", (e) => {
    const b = e.target.closest("button[data-branch]");
    if (b) send({ t: "git.branch", cwd: gitState.cwd, name: b.dataset.branch });
  });
  $("gbranch-create").addEventListener("click", () => {
    const name = $("gbranch-new").value.trim();
    if (!name) { toast("Name the branch first."); return; }
    send({ t: "git.branch", cwd: gitState.cwd, name, create: true });
    $("gbranch-new").value = "";
  });
  $("gworktree-create").addEventListener("click", () => {
    const name = $("gbranch-new").value.trim();
    if (!name) { toast("Name the branch the worktree should be on."); return; }
    send({ t: "git.worktree", cwd: gitState.cwd, name });
    $("gbranch-new").value = "";
  });

  // ---- uncommitted vs "what did this branch do"

  let gscope = "uncommitted";

  $("gscope").addEventListener("click", (e) => {
    const b = e.target.closest("button[data-scope]");
    if (!b) return;
    gscope = b.dataset.scope;
    for (const x of $("gscope").querySelectorAll("button")) {
      x.setAttribute("aria-checked", String(x.dataset.scope === gscope));
    }
    $("gchanges").hidden = gscope === "base";
    $("greview").hidden = gscope !== "base";
    if (gscope === "base") {
      $("greview").textContent = "Reading…";
      send({ t: "git.review", cwd: gitState.cwd });
    }
  });

  function showReview(r) {
    const el = $("greview");
    el.innerHTML = "";
    if (r.error) { el.textContent = r.error; return; }
    if (!r.text) {
      el.textContent = `Nothing differs from ${r.base}.`;
      return;
    }
    const head = document.createElement("span");
    head.className = "hunk";
    head.textContent =
      `${r.files.length} file(s) vs ${r.base}   +${r.add} −${r.rem}\n\n`;
    el.appendChild(head);
    for (const line of r.text.split("\n")) {
      const s = document.createElement("span");
      s.className = line.startsWith("+") ? "add"
                  : line.startsWith("-") ? "del"
                  : line.startsWith("@@") || line.startsWith("diff ") ? "hunk" : "";
      s.textContent = line + "\n";
      el.appendChild(s);
    }
    if (r.truncated) {
      const more = document.createElement("span");
      more.className = "hunk";
      more.textContent = "\n… truncated.\n";
      el.appendChild(more);
    }
  }

  // ------------------------------------------------------------- onboarding

  let setupState = null;
  let firstRunShown = false;

  /* ---- the speech models

     THE ONE PIECE OF ONBOARDING THAT CANNOT BE SKIPPED AND HAD NO UI.
     Without these four files the microphone opens, the orb draws, and holding
     space does nothing -- because the failure is a missing file raised inside
     the first utterance, where nobody sees it. So: say which files, say what
     each one does, say how big, and offer one button. Nobody should have to
     leave the window, find a terminal, or learn what a .onnx is. */

  let modelState = null;
  let modelBusy = false;

  const MB = (n) => (n >= 1e9 ? (n / 1e9).toFixed(1) + " GB"
                              : Math.round(n / 1e6) + " MB");

  /* ONE PLACE DECIDES WHETHER THIS IS FINISHED.
     It was computed in paintModels and again in setBusy, with different
     expressions -- so the "Get them" button reappeared under a card reading
     "ready", because the second one ran last and disagreed. */
  function modelsReady() {
    if (!modelState) return false;
    const w = modelState.whisper || {};
    return !!modelState.ready && !(w.known && !w.present);
  }

  function paintModels(v) {
    modelState = v;
    const card = $("mdl-card");
    if (!v) { card.hidden = true; return; }
    card.hidden = false;

    const w0 = v.whisper || {};
    const done = modelsReady();

    $("mdl-list").innerHTML = v.items.map((i) => `
      <li class="${i.present ? "have" : ""}" data-name="${esc(i.name)}">
        <span class="mdl-dot"></span>
        <span class="mdl-what">${esc(i.what)}</span>
        <span class="mdl-sz">${i.present ? "ready" : MB(i.size)}</span>
      </li>`).join("")
      + (w0.known ? `
      <li class="${w0.present ? "have" : ""}" data-name="whisper">
        <span class="mdl-dot"></span>
        <span class="mdl-what">turning what you said into words</span>
        <span class="mdl-sz">${w0.present ? "ready" : "~" + w0.mb + " MB"}</span>
      </li>` : "");

    const w = v.whisper || {};
    const needWhisper = w.known && !w.present;
    $("mdl-state").textContent = done ? "ready"
      : `${v.missing + (needWhisper ? 1 : 0)} to download`;

    if (done) {
      /* Collapse. A finished setup step that keeps explaining itself is
         clutter in a panel somebody opens for the thing that is NOT done. */
      $("mdl-what").hidden = true;
      $("mdl-get").hidden = true;
      $("mdl-cost").textContent = "Everything the voice needs is on this machine.";
    } else {
      $("mdl-what").hidden = false;
      $("mdl-get").hidden = modelBusy;
      const need = v.missingBytes + (needWhisper ? w.mb * 1e6 : 0);
      $("mdl-get").textContent = "Get them · " + MB(need);
      /* Say what it costs in the units people actually worry about, and say
         the private part out loud -- this is the moment somebody wonders
         whether their voice is about to go to a server. */
      $("mdl-cost").textContent = modelBusy ? "" : "Downloaded once. Nothing leaves this machine.";
    }
    setBusy(modelBusy);
    maybeOpenFirstRun();
  }

  function setBusy(on) {
    modelBusy = on;
    $("mdl-bar").hidden = !on;
    $("mdl-stop").hidden = !on;
    $("mdl-get").hidden = on || modelsReady();
    if (!on) $("mdl-bar").classList.remove("wait");
  }

  function modelProgress(m) {
    setBusy(true);
    const bar = $("mdl-bar");
    if (m.indeterminate) {
      bar.classList.add("wait");
      $("mdl-cost").textContent = "getting the transcriber…";
    } else {
      bar.classList.remove("wait");
      const pct = m.allTotal ? Math.min(100, (m.allDone / m.allTotal) * 100) : 0;
      bar.querySelector("i").style.width = pct.toFixed(1) + "%";
      $("mdl-cost").textContent =
        `${MB(m.allDone)} of ${MB(m.allTotal)} · ${m.file}`;
    }
    // Light the row being worked on, so the list is a place to look rather
    // than a legend for a bar.
    const list = $("mdl-list");
    for (const li of list.children) {
      li.classList.toggle("busy", !li.classList.contains("have")
        && li.dataset.name === m.file);
    }
  }

  function modelsDone(m) {
    setBusy(false);
    $("mdl-bar").querySelector("i").style.width = "0%";
    if (m.status) paintModels({ ...m.status, whisper: m.whisper });
    for (const li of $("mdl-list").children) li.classList.remove("busy");

    if (m.cancelled) {
      $("mdl-cost").textContent = "Stopped. What downloaded is kept — press Get them to resume.";
      return;
    }
    if (m.ok) {
      $("mdl-cost").textContent = m.whisperError
        ? "Ready. The transcriber will finish on first use."
        : "Ready. Hold space and talk.";
      toast("Voice models ready.");
      // The health flag was raised by these being missing; ask again rather
      // than leaving a red mark on a problem that is now fixed.
      send({ t: "menu.health" });
      return;
    }

    /* A FAILURE HAS TO STAY ON THE SCREEN.

       This used to be a toast and nothing else. On a machine whose Python had
       no CA certificates, all four downloads failed in under a second: the bar
       never visibly moved, a toast flashed past, and the card went back to
       saying "4 to download" with no reason anywhere. From the outside that is
       a button that does nothing -- which is exactly how it was reported.

       So the reason goes in the card, next to the button that will retry it,
       and stays until something changes. */
    const first = (m.failed && m.failed[0]) || null;
    const why = first ? first.error : (m.error || "the download failed");
    const el = $("mdl-cost");
    el.textContent = why;
    el.classList.add("bad");
    $("mdl-get").textContent = "Try again";
    $("mdl-get").hidden = false;

    // And mark which files are still missing, so a partial success reads as
    // partial rather than as total failure.
    const failed = new Set((m.failed || []).map((f) => f.name));
    for (const li of $("mdl-list").children) {
      li.classList.toggle("failed", failed.has(li.dataset.name));
    }
    toast(first ? `${first.name}: ${first.error}` : why);
  }

  $("mdl-get").addEventListener("click", () => {
    setBusy(true);
    $("mdl-cost").classList.remove("bad");
    for (const li of $("mdl-list").children) li.classList.remove("failed");
    // Instant feedback. A 365 MB download can take a second to produce its
    // first progress event, and a button that looks inert for that second is
    // a button people press twice.
    $("mdl-bar").querySelector("i").style.width = "0%";
    $("mdl-cost").textContent = "starting…";
    send({ t: "models.fetch", whisper: true });
  });
  $("mdl-stop").addEventListener("click", () => {
    $("mdl-cost").textContent = "stopping…";
    send({ t: "models.cancel" });
  });

  /* FIRST RUN OPENS ITSELF.

     A window that says nothing about setup is one you use for a week before
     discovering it had a setup page. The Setup PAGE, not the interview: the
     free step comes first, because backfilling sessions you have already had
     asks you nothing and is a better source than answering questions.

     THE DECISION NEEDS THREE MESSAGES THAT ARRIVE INDEPENDENTLY, which is why
     it is not inside any one of their handlers. It used to live in paintSetup
     and read `ivState`, a variable filled by a DIFFERENT message -- so when
     `setup` arrived first, which is the common order because it is the cheaper
     call, the condition saw null and skipped. It only ran once, so the panel
     then never opened at all: a fresh install with nothing set up, and nothing
     on screen to say so. Reported exactly that way.

     So each handler calls this, and this decides when it has enough to. */
  function maybeOpenFirstRun() {
    if (firstRunShown) return;
    if (!setupState || !ivState || !modelState) return;   // wait for all three

    const needsSetup = !!setupState.needed && !ivState.answered;
    // Missing speech models are the more urgent of the two: without them the
    // microphone opens and holding space does nothing at all.
    const needsModels = !modelsReady();
    if (!needsSetup && !needsModels) return;

    firstRunShown = true;
    openMenu("setup");
  }

  function paintSetup(v) {
    setupState = v;
    const done = new Set(v.done);

    $("setup-line").textContent = v.vaultNotes
      ? `${v.vaultNotes} notes in ${v.vault}`
      : `Nothing in your vault yet. ${v.vault}`;

    // The Setup badge only shows while there is something to do. A permanent
    // dot on a menu is a thing people stop seeing within a day.
    $("setup-flag").hidden = !v.needed;
    $("menu-flag").hidden = $("menu-flag").hidden && !v.needed;

    maybeOpenFirstRun();

    /* The card carries the whole story: what is left, and what it costs. The
       steps below are for retrying one that failed, not for reading first. */
    const left = v.steps.filter((s) => !done.has(s.id));
    $("setup-state").textContent = !left.length
      ? "done"
      : done.size ? `${left.length} of ${v.steps.length} left`
                  : `${v.steps.length} steps, one button`;
    $("setup-all").textContent = done.size && left.length ? "Finish setting up"
                               : left.length ? "Set it up" : "Run it again";
    $("setup-cost").textContent = left.some((s) => s.costs)
      ? "one step spends model tokens" : "";
    $("setup-detail").open = !left.length && done.size > 0;

    $("setup-steps").innerHTML = v.steps.map((s, i) => `
      <li class="step ${done.has(s.id) ? "done" : ""}">
        <span class="s-n">${done.has(s.id) ? "✓" : i + 1}</span>
        <div class="s-body">
          <span class="s-name">${esc(s.name)}</span>
          <span class="s-blurb">${esc(s.blurb)}</span>
          <span class="s-acts">
            ${s.dry !== false && (s.id === "backfill" || s.id === "wire")
              ? `<button class="btn-ghost" data-step="${esc(s.id)}" data-dry="1">Preview</button>` : ""}
            <button class="btn-solid" data-step="${esc(s.id)}">${
              s.costs ? "Run (costs tokens)" : "Run"}</button>
          </span>
        </div>
      </li>`).join("");
  }

  $("setup-steps").addEventListener("click", (e) => {
    const b = e.target.closest("button[data-step]");
    if (!b) return;
    $("setup-log").hidden = false;
    $("setup-log").textContent = "";
    send({ t: "setup.run", step: b.dataset.step, dry: b.dataset.dry === "1" });
  });

  /* ------------------------------------------------------- the interview

     Ten questions, asked one at a time. The dialog is the whole surface: the
     question, why it is being asked, and one text box that holds the running
     answer.

     SPOKEN ANSWERS APPEND AND DO NOT ADVANCE. Nobody answers "who are your
     people" in one breath, and a question that jumped forward on the first
     pause would cut people off mid-thought. The box stays editable so a
     mistranscribed sentence is something to fix rather than an answer lost. */
  let ivState = null;

  function paintInterview(v) {
    ivState = v;
    maybeOpenFirstRun();
    const at = v.at + 1;
    $("iv-progress").textContent = v.answered
      ? `${v.answered} of ${v.n} answered`
      : `${v.n} questions, about twenty minutes`;
    $("iv-open").textContent = v.answered && !v.done ? "Continue" : "Start";

    if (!$("iv-dlg").open) return;
    const q = v.current;
    if (!q) return;
    $("iv-count").textContent = `${at} of ${v.n}`;
    $("iv-section").textContent = `${q.section}. ${q.sectionTitle}`;
    $("iv-q").textContent = q.ask;
    $("iv-hint").textContent = q.hint || "";
    $("iv-why").textContent = q.why || "";
    $("iv-mode").textContent = q.typed ? "typing suits this one" : "";
    // Never overwrite what you are in the middle of editing.
    if (document.activeElement !== $("iv-answer")) $("iv-answer").value = v.answer || "";

    $("iv-marks").innerHTML = v.marks.map((m, i) => `
      <button type="button" class="iv-mark ${m.state} ${i === v.at ? "on" : ""}"
              data-at="${i}" title="Question ${m.num} — ${m.state}"
              aria-label="Question ${m.num}, ${m.state}"></button>`).join("");

    // The finish button is offered as soon as the core is done rather than at
    // the last question: three sections in you have a working clone, and
    // that is the promise the docs make.
    const core = v.coreLeft <= 0;
    $("iv-finish").disabled = !v.answered;
    $("iv-end-note").textContent = !v.answered
      ? "Answer at least one question first."
      : core
        ? "Enough for a working clone. This sends your answers to your "
          + "extractor (claude by default) and spends tokens; the drafts of "
          + "who you are land in proposals/ for you to read before anything "
          + "installs them."
        : `${v.coreLeft} more of the first six and you have a working clone. `
          + "You can read in what you have any time.";
  }

  function ivSave(next) {
    send({ t: "interview.answer", text: $("iv-answer").value, next: !!next });
  }

  function openInterview(resume) {
    $("iv-dlg").showModal();
    send({ t: "interview.start", at: resume ? undefined : 0 });
  }

  $("iv-open").addEventListener("click", () => openInterview(!!(ivState && ivState.answered)));
  $("iv-close").addEventListener("click", () => {
    // Leaving saves. It is a pause, not a discard -- and it hands your voice
    // back to the sessions, which is the thing you would be stuck without.
    ivSave(false);
    send({ t: "interview.stop" });
    $("iv-dlg").close();
  });
  $("iv-dlg").addEventListener("close", () => send({ t: "interview.stop" }));
  $("iv-next").addEventListener("click", () => ivSave(true));
  $("iv-back").addEventListener("click", () => { ivSave(false); send({ t: "interview.go", at: (ivState.at || 0) - 1 }); });
  $("iv-skip").addEventListener("click", () => send({ t: "interview.skip" }));
  $("iv-again").addEventListener("click", () => send({ t: "interview.repeat" }));
  $("iv-marks").addEventListener("click", (e) => {
    const b = e.target.closest("button[data-at]");
    if (!b) return;
    ivSave(false);
    send({ t: "interview.go", at: Number(b.dataset.at) });
  });
  $("iv-finish").addEventListener("click", () => {
    if (!confirm("Read your answers into the vault?\n\n"
               + "This sends the text of your answers to your extractor "
               + "(claude by default) and costs tokens. Nothing about who you "
               + "are is installed without you reading it first.")) return;
    $("iv-dlg").close();
    openMenu("setup");
    $("setup-log").hidden = false;
    $("setup-log").textContent = "";
    send({ t: "interview.finish" });
  });

  $("setup-all").addEventListener("click", () => {
    $("setup-log").hidden = false;
    $("setup-log").textContent = "";
    send({ t: "setup.run", step: "all" });
  });

  $("setup-dismiss").addEventListener("click", () => {
    send({ t: "setup.dismiss", value: true });
    toast("Hidden. Setup stays in this menu if you want it.");
  });

  function setupLog(m) {
    const el = $("setup-log");
    el.hidden = false;
    if (m.start) el.textContent = "";
    el.textContent += (m.line || "") + "\n";
    el.scrollTop = el.scrollHeight;
    if (m.done && !m.ok) toast("That step did not finish — see the output.");
  }

  // ------------------------------------------------- agents and their rules

  let agentState = { agents: [], rules: [] };
  let chosenAgent = "claude";

  function paintAgents(v) {
    agentState = v || { agents: [], rules: [] };
    // The server owns which agent is chosen -- it is what `+` actually uses,
    // and it survives a reload. The page only overrides it on a click.
    if (agentState.chosen) chosenAgent = agentState.chosen;
    const here = agentState.agents.filter((a) => a.installed);

    // Never leave the picker naming an agent that is not here. If the chosen
    // one vanished (uninstalled between launches), fall back to one that is.
    if (!here.some((a) => a.name === chosenAgent) && here.length) {
      chosenAgent = here[0].name;
    }

    const el = $("agent-pick");
    el.innerHTML = agentState.agents.map((a) => `
      <button type="button" data-agent="${esc(a.name)}"
              class="${a.name === chosenAgent ? "on" : ""} ${a.installed ? "" : "off"}"
              title="${esc(a.installed
                ? (a.version || a.path)
                : a.installCmd
                  ? "Not installed — click to install it (" + a.installCmd + ")"
                  : "Not installed — " + a.install)}">
        ${esc(a.name)}${a.installed ? "" : " ⤓"}
      </button>`).join("");

  }

  $("agent-pick").addEventListener("click", (e) => {
    const b = e.target.closest("button[data-agent]");
    if (!b) return;
    const a = agentState.agents.find((x) => x.name === b.dataset.agent);
    if (!a) return;
    if (!a.installed) {
      /* AN UNINSTALLED AGENT OFFERS TO INSTALL ITSELF.

         Printing `npm i -g @openai/codex` at somebody is not help, it is
         homework — they now have to find a terminal, retype it, and come
         back. Clicking installs it in a pane they can watch, which is the
         same command, run in front of them, with its prompts and failures
         readable. Claude Code has no one-line installer, so that one still
         links out rather than pretending. */
      if (!a.installCmd) {
        toast(`${a.label} installs from its own site: ${a.install}`);
        return;
      }
      if (a.needsNpm) {
        toast(`${a.label} needs npm, which is not on this machine. `
            + `Install Node first, then try again.`);
        return;
      }
      if (!confirm(`Install ${a.label}?\n\nRuns in a terminal you can watch:\n\n`
                 + `    ${a.installCmd}\n\nIt is a global npm install; nothing `
                 + `else on your machine is touched.`)) return;
      send({ t: "agent.install", name: a.name });
      return;
    }
    // Both, in this order. `chosen` is what paintAgents reads back, so setting
    // only the variable meant the very next repaint restored the server's
    // older answer and the click appeared not to take -- the picker sprang
    // back and `+` opened the agent you had just moved away from.
    chosenAgent = a.name;
    agentState.chosen = a.name;
    paintAgents(agentState);
    // Persisted, because which agent you work in is a fact about your machine
    // and not about this tab: choose Codex, quit, come back, still Codex.
    send({ t: "settings.defaults", patch: { agent: a.name } });
  });

  /* ---- what your agents are told

     The old page listed the CLAUDE.md files in force, which is a directory
     listing wearing a feature's clothes: nobody opens those files, and the
     question they actually have — WHAT DID THIS ADD TO MY AGENT — was left
     for them to answer by reading markdown. This shows the text. */
  let injState = null;

  function paintInjected(v) {
    injState = v;
    const a = v.always || {};
    $("rules-sub").textContent = `Reading ${v.vault}`;
    $("inj-always-n").textContent = a.tokens ? `≈${fmtK(a.tokens)} tokens` : "";
    $("inj-always-text").textContent = a.ok
      ? (a.text || "Nothing yet — your identity core is empty.")
        + (a.truncated ? "\n\n… truncated." : "")
      : a.error;
    $("inj-always-src").textContent = (a.sources || [])
      .map((s) => `${s.name}: ${s.exists ? fmtBytes(s.bytes) : "not written yet"}`)
      .join("   ·   ");

    const ul = $("rules-list");
    ul.innerHTML = (v.config || []).map((c) => `
      <li class="rrow ${c.exists ? "" : "absent"}">
        <button class="row" data-path="${esc(c.path)}" ${c.exists ? "" : "disabled"}>
          <span class="row-name">${esc(c.name)}</span>
          <span class="row-sub">${esc(c.path)}</span>
          <span class="row-meta">${
            !c.exists ? "not created"
            : c.managed ? "ours + yours"
            : "untouched"}</span>
        </button>
        <span class="r-scope">${esc(c.scope)}</span>
      </li>`).join("") || `<li class="none">No rules files anywhere yet.</li>`;

    $("inj-learned-list").innerHTML = (v.learned || []).map((n) => `
      <li class="rrow">
        <button class="row" data-path="${esc(n.path)}">
          <span class="row-name">${esc(n.title)}</span>
          <span class="row-sub">${esc(n.quote || "")}</span>
          <span class="row-meta">${esc(n.folder)}</span>
        </button>
      </li>`).join("") || `<li class="none">Nothing learned yet.</li>`;
  }

  function paintPreview(v) {
    const el = $("inj-preview");
    el.hidden = false;
    el.textContent = !v.ok ? v.error
      : v.empty ? v.why
      : `≈${fmtK(v.tokens)} tokens would be added:\n\n` + v.text
        + (v.truncated ? "\n\n… truncated." : "");
  }

  $("inj-go").addEventListener("click", () =>
    send({ t: "injected.preview", text: $("inj-q").value }));
  $("inj-q").addEventListener("keydown", (e) => {
    if (e.key === "Enter") { e.preventDefault(); $("inj-go").click(); }
  });

  function fmtBytes(n) {
    if (!n) return "empty";
    return n < 1024 ? `${n} B` : `${(n / 1024).toFixed(1)} kB`;
  }

  for (const id of ["rules-list", "inj-learned-list"]) {
    $(id).addEventListener("click", (e) => {
      const b = rowButton(e, "button[data-path]");
      if (b && !b.disabled) send({ t: "rules.read", path: b.dataset.path });
    });
  }

  function showRules(r) {
    const el = $("rules-body");
    el.hidden = false;
    el.textContent = r.ok
      ? (r.text || "(empty file)") + (r.truncated ? "\n\n… truncated." : "")
      : r.error;
  }

  /* Rules is not a sessions-rail control. It answers "why did it just do
     that", which is a question about configuration — so it is a page in the
     menu, next to the other things that shape a reply, rather than a
     permanent icon beside the button that opens a terminal. */
  function openRules() {
    $("rules-body").hidden = true;
    openMenu("rules");
  }

  // ------------------------------------------------------ command palette

  const cmdDlg = $("cmd-dlg");
  let cmdRows = [], cmdAt = 0;

  /* Built fresh each time it opens, because half the entries depend on current
     state — which project you are in, which panes exist. A palette listing a
     pane that closed ten minutes ago is worse than no palette. */
  function commands() {
    const g = gitState || {};
    const list = [
      { grp: "voice", name: "Talk", sub: "hold space instead", run: () => $("prompt-input").focus() },
      { grp: "session", name: "New terminal", sub: g.project || "", run: () => send({ t: "pane.open", kind: "plain", cwd: g.cwd, agent: chosenAgent }) },
      { grp: "session", name: "Dispatch a task", sub: "runs in its own worktree", run: () => openDispatch() },
      { grp: "git", name: "Git", sub: g.label || "", run: () => openGit("log") },
      { grp: "git", name: "Review changes", sub: "everything this branch did", run: () => { openGit("changes"); $("gscope-base").click(); } },
      { grp: "git", name: "Commit", sub: "stage all, then write a message", run: () => { openGit("changes"); $("btn-stage-all").click(); $("commit-msg").focus(); } },
      { grp: "git", name: "Push", sub: g.ahead ? `${g.ahead} ahead` : "", run: () => send({ t: "git.push", cwd: g.cwd }) },
      { grp: "git", name: "Branches", sub: (g.branches || {}).current || "", run: () => openGit("branches") },
      { grp: "git", name: "History", sub: "commit graph", run: () => openGit("log") },
      { grp: "memory", name: "Memory", sub: "on, learn only, or off", run: () => $("mem-dlg").showModal() },
      { grp: "memory", name: "Consolidate now", sub: "fold sessions into memory", run: () => send({ t: "memory.consolidate" }) },
      { grp: "app", name: "Build my clone", sub: "the ten questions, out loud or typed", run: () => openInterview(true) },
      { grp: "app", name: "Rules", sub: "the CLAUDE.md files in force here", run: () => openRules() },
      { grp: "app", name: "Health", sub: "what is broken", run: () => openMenu("health") },
      { grp: "app", name: "Voice settings", sub: "rate and voice", run: () => openMenu("voice") },
      { grp: "app", name: "Defaults", sub: "model, permissions", run: () => openMenu("defaults") },
    ];
    for (const p of projectsCache.slice(0, 40)) {
      if (p.missing) continue;
      list.push({ grp: "project", name: p.name, sub: p.parent,
                  run: () => send({ t: "pane.open", kind: "plain", cwd: p.cwd, agent: chosenAgent }) });
    }
    for (const pv of panes.values()) {
      const name = pv.info.title || "session";
      list.push({ grp: "pane", name, sub: pv.info.shortCwd || "",
                  run: () => { send({ t: "pane.focus", id: pv.id });
                               focusTerminal(pv.id); } });
      list.push({ grp: "voice", name: `Talk to ${name}`,
                  sub: pv.info.voice ? "your voice is already here"
                                     : "instead of your clone",
                  run: () => send({ t: "voice.target", id: pv.id }) });
    }
    return list;
  }

  function paintCmd() {
    const q = $("cmd-input").value.trim().toLowerCase();
    const all = commands();
    cmdRows = q
      ? all.filter((c) => (c.name + " " + c.sub + " " + c.grp).toLowerCase().includes(q))
      : all;
    cmdAt = Math.min(cmdAt, Math.max(0, cmdRows.length - 1));
    $("cmd-list").innerHTML = cmdRows.length
      ? cmdRows.map((c, i) => `
          <li aria-selected="${i === cmdAt}" data-i="${i}">
            <span class="c-grp">${esc(c.grp)}</span>
            <span class="c-name">${esc(c.name)}</span>
            <span class="c-sub">${esc(c.sub || "")}</span>
          </li>`).join("")
      : `<li class="none" style="color:var(--faint);padding:14px">Nothing matches that.</li>`;
  }

  function runCmd(i) {
    const c = cmdRows[i];
    if (!c) return;
    cmdDlg.close();
    try { c.run(); } catch (err) { toast(String(err)); }
  }

  function openCmd() {
    // Refresh the project list so the palette can offer them by name.
    send({ t: "menu.projects" });
    $("cmd-input").value = "";
    cmdAt = 0;
    paintCmd();
    cmdDlg.showModal();
    $("cmd-input").focus();
  }

  $("cmd-input").addEventListener("input", () => { cmdAt = 0; paintCmd(); });
  $("cmd-input").addEventListener("keydown", (e) => {
    if (e.key === "ArrowDown" || (e.key === "n" && e.ctrlKey)) {
      cmdAt = Math.min(cmdAt + 1, cmdRows.length - 1); paintCmd(); e.preventDefault();
    } else if (e.key === "ArrowUp" || (e.key === "p" && e.ctrlKey)) {
      cmdAt = Math.max(cmdAt - 1, 0); paintCmd(); e.preventDefault();
    } else if (e.key === "Enter") {
      runCmd(cmdAt); e.preventDefault();
    }
  });
  $("cmd-list").addEventListener("click", (e) => {
    const li = e.target.closest("li[data-i]");
    if (li) runCmd(Number(li.dataset.i));
  });

  $("btn-stage-all").addEventListener("click", () => {
    const paths = (gitState.files || []).map((f) => f.path);
    if (paths.length) send({ t: "git.stage", cwd: gitState.cwd, paths });
  });

  $("btn-commit").addEventListener("click", () => {
    const message = $("commit-msg").value.trim();
    if (!message) { toast("A commit needs a message."); return; }
    send({ t: "git.commit", cwd: gitState.cwd, message });
  });

  $("btn-push").addEventListener("click", () => send({ t: "git.push", cwd: gitState.cwd }));

  $("here-branch").addEventListener("click", () => {
    const b = gitState.branches;
    if (!b || !b.branches || !b.branches.length) return;
    const name = prompt(
      `Branch (current: ${b.current}).\nExisting: ${b.branches.join(", ")}\n\n` +
      `A name not in that list is created.`, b.current);
    if (!name || name === b.current) return;
    send({ t: "git.branch", cwd: gitState.cwd, name: name.trim(),
           create: !b.branches.includes(name.trim()) });
  });

  // ------------------------------------------------------ project switch

  $("here-project").addEventListener("click", () => {
    send({ t: "menu.projects" });
    $("proj-dlg").showModal();
  });
  $("proj-close").addEventListener("click", () => $("proj-dlg").close());

  // Clicking a pane selects it: the rail, the git panel, the keyboard. NOT
  // your voice — that moves only on the ◉ button in the header. Capture phase
  // so it still registers when the click lands on the terminal itself, which
  // stops propagation for its own selection.
  $("panes").addEventListener("mousedown", (e) => {
    const el = e.target.closest(".pane");
    if (!el || !el.dataset.id) return;

    /* A HEADER BUTTON IS NOT A SELECTION.
       This used to fire pane.focus first and check for a button afterwards,
       so pressing ✕ or ⛶ also sent a focus round trip: the server broadcast
       the whole pane list, every pane re-applied, and every terminal refit —
       measured at ~78 resize frames — all between the mousedown and the mouseup
       of the click you were trying to make. The button does its own job; it
       does not need the pane selected first. */
    if (e.target.closest(".pane-acts")) return;
    send({ t: "pane.focus", id: el.dataset.id });

    /* AND PUT THE CURSOR IN THE TERMINAL.

       xterm focuses itself when you click the text it drew, and does not when
       you click anything else: the header, the border, the padding around the
       rows, the gap under a short screen. Those clicks left the keyboard on
       <body>, where typing goes nowhere and the space bar is push-to-talk —
       which is exactly "I can't type into the terminal whenever I want".
       Clicking a button in the header is the one place that must keep its own
       focus, or the button loses the click that pressed it. */
    if (e.target.closest("button")) return;
    const pv = panes.get(el.dataset.id);
    if (pv) pv.grabKeyboard();
  }, true);

  // ----------------------------------------------------------- shortcuts

  /* THE SAFETY NET.

     If a printable key is pressed while nothing owns the keyboard, it goes to
     the session you have selected — the pane is focused and the character is
     forwarded, so the first letter is not eaten either. There should be no
     way left to be looking at a session, type, and have nothing happen.

     Only bare keys: modifiers are shortcuts, and space is push-to-talk. */
  addEventListener("keydown", (e) => {
    if (e.metaKey || e.ctrlKey || e.altKey) return;
    if (e.key.length !== 1 || e.key === " ") return;
    if (keyboardIsBusy() || document.querySelector("dialog[open]")) return;
    if (!drawer.hidden) return;
    const pv = focusedPane() || panes.values().next().value;
    if (!pv) return;
    e.preventDefault();
    pv.grabKeyboard();
    pv._send(e.key);
  }, true);

  addEventListener("keydown", (e) => {
    const typing = /^(INPUT|TEXTAREA)$/.test(document.activeElement.tagName)
                   || document.activeElement.closest(".pane-term");

    // Cmd-K works everywhere, including inside a terminal pane. That is the
    // point of a palette: it is the one key that always means "show me what I
    // can do", so it must not be swallowed by whatever has focus.
    if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
      e.preventDefault();
      e.stopPropagation();
      cmdDlg.open ? cmdDlg.close() : openCmd();
      return;
    }
    // ⌘/ for the shortcut sheet, the macOS convention. Also captured, so it
    // works from inside a terminal pane like the palette does.
    if ((e.metaKey || e.ctrlKey) && e.key === "/") {
      e.preventDefault();
      e.stopPropagation();
      openMenu("keys");
      return;
    }
    if (e.key === "/" && !typing) { e.preventDefault(); $("prompt-input").focus(); }
    if (e.key === "Escape") {
      // outermost first
      if (cmdDlg.open) { /* <dialog> closes itself on Escape */ }
      else if (!drawer.hidden) { e.preventDefault(); closeMenu(); }
      else if (document.activeElement === $("prompt-input")) $("prompt-input").blur();
    }
  }, true);

  /* A resized window changes how many tiles fit, not just how big they are.
     Without the relayout the grid kept whatever column count it was given the
     last time a pane appeared — so shrinking the window left two columns of
     panes drawn straight over the voice rail. */
  addEventListener("resize", () => {
    layoutColumns();
    panes.forEach((p) => p.refit());
  });

  connect();
})();
