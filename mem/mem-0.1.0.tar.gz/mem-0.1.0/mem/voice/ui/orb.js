/*
  orb — the instrument.

  Not a glowing ball. It is a ring trace on black, and every deformation in it
  is a real number: your microphone level pushes it out while you talk, the
  synthesized speech envelope pushes it out while the clone talks, and when it is
  thinking there is no audio at all, so the ring goes quiet and a sweep runs
  around it instead. That mapping is the whole idea — if the orb is moving,
  something is actually happening, and the shape tells you what.

  Canvas 2D rather than WebGL on purpose: an oscilloscope trace is a line, and
  lines are what this API is good at. It also makes idling genuinely cheap,
  which matters for something that sits on screen all day.
*/
(function () {
  "use strict";

  const TAU = Math.PI * 2;
  const POINTS = 168;          // ring resolution
  const TRACES = 3;            // stacked traces read as phosphor persistence

  /* state -> how the ring behaves.
       drive  which real signal deforms it (mic level, speech envelope)
       pulse  a slow breath in the radius, for states with no signal to plot
       rate   breaths per second
     Listening has nothing to measure — you are not talking yet — so a breath is
     what makes it read as awake and waiting rather than as a frozen circle. */
  const MODES = {
    idle:      { color: "--faint",   amp: 0.010, calm: 0.55, sweep: 0,    drive: 0.0, pulse: 0.008, rate: 0.10 },
    listening: { color: "--mute",    amp: 0.022, calm: 1.00, sweep: 0,    drive: 0.0, pulse: 0.055, rate: 0.30 },
    hearing:   { color: "--s-you",   amp: 0.030, calm: 1.35, sweep: 0,    drive: 1.0, pulse: 0.018, rate: 0.55 },
    // Decoding what you just said. Still your colour, because it is still your
    // words being handled -- but nothing to plot yet, so it spins instead.
    thinking:  { color: "--s-you",   amp: 0.016, calm: 1.60, sweep: 1.6,  drive: 0.0, pulse: 0.020, rate: 0.90 },
    // drive is deliberately non-zero: progress narration is spoken during work,
    // and it should ripple the ring it belongs to rather than switch the orb
    // over to the speaking state and steal the caption.
    working:   { color: "--s-work",  amp: 0.020, calm: 0.75, sweep: 1.0,  drive: 0.45, pulse: 0.030, rate: 0.50 },
    speaking:  { color: "--s-speak", amp: 0.028, calm: 1.15, sweep: 0,    drive: 1.0, pulse: 0.014, rate: 0.45 },
    blocked:   { color: "--s-block", amp: 0.014, calm: 0.30, sweep: 0.35, drive: 0.0, pulse: 0.060, rate: 0.55 },
  };

  function css(name) {
    return getComputedStyle(document.documentElement).getPropertyValue(name).trim();
  }

  // #rrggbb -> "r, g, b" so alpha can vary per trace without re-parsing
  function rgb(hex) {
    const h = hex.replace("#", "");
    const n = parseInt(h.length === 3 ? h.split("").map(c => c + c).join("") : h, 16);
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  }

  class Orb {
    constructor(canvas) {
      this.c = canvas;
      this.ctx = canvas.getContext("2d");
      this.mode = "idle";
      this.level = 0;          // raw input 0..1
      this.smooth = 0;         // ballistics-smoothed level (what we draw)
      this.t = 0;
      this.sweep = 0;
      this.pt = 0;             // breath clock, in real seconds
      this.colorCache = {};
      this.reduced = matchMedia("(prefers-reduced-motion: reduce)").matches;
      this.lastFrame = 0;
      this.painted = false;
      this._resize();
      // A window resize is not the only thing that changes this element's size.
      // Dragging the sessions splitter, opening a pane, or the stage reflowing
      // all resize the orb with no window event at all — which used to leave a
      // stale bitmap stretched into the new box.
      if (typeof ResizeObserver === "function") {
        new ResizeObserver(() => this._resize()).observe(this.c);
      } else {
        addEventListener("resize", () => this._resize());
      }
      requestAnimationFrame(this._frame.bind(this));
    }

    setState(mode) {
      if (MODES[mode]) this.mode = mode;
    }

    /* Level is fed from Python: mic RMS while you speak, playback envelope
       while the clone speaks. Values outside 0..1 are clamped rather than trusted. */
    setLevel(v) {
      this.level = Math.max(0, Math.min(1, Number(v) || 0));
    }

    /* Keep the drawing surface exactly the shape of the element.
     *
     * The bug this replaces: the backing store was made square (size x size)
     * while the CSS box was whatever the flex column gave it. A canvas bitmap
     * is stretched to fill its box, so the moment the stage squeezed the orb's
     * height — resizing the window, dragging the splitter — a square bitmap got
     * drawn into a shorter box and the circle came out as an oval.
     *
     * Now the bitmap matches the box, and the circle is sized from the SHORTER
     * side and centred. Both axes get the same radius in the same pixel space,
     * so it cannot render as an ellipse no matter what shape the box is. */
    _resize() {
      const dpr = Math.min(devicePixelRatio || 1, 2);
      const box = this.c.getBoundingClientRect();
      const w = Math.max(1, Math.round(box.width) || 220);
      const h = Math.max(1, Math.round(box.height) || 220);
      if (w === this.w && h === this.h) return;
      this.w = w;
      this.h = h;
      this.size = Math.min(w, h);          // the circle's diameter basis
      this.c.width = Math.round(w * dpr);
      this.c.height = Math.round(h * dpr);
      this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      this.painted = false;                // the surface was cleared by resizing
    }

    _color(varName) {
      if (!this.colorCache[varName]) this.colorCache[varName] = rgb(css(varName) || "#888888");
      return this.colorCache[varName];
    }

    /* Ambient wobble. Three sines at irrational-ish ratios never line back up,
       so the ring keeps moving without a visible loop point — cheaper and
       calmer than sampling a noise texture. */
    _ambient(a, t) {
      return Math.sin(a * 3 + t * 0.7) * 0.55
           + Math.sin(a * 5 - t * 1.1) * 0.30
           + Math.sin(a * 8 + t * 1.9) * 0.15;
    }

    _frame(now) {
      requestAnimationFrame(this._frame.bind(this));
      // A page can load while hidden (a background tab, a window opened behind
      // another). Skipping every frame then leaves a blank canvas that only
      // fills in once you look at it — so the first paint always happens, and
      // only the animation waits for the page to be visible.
      if (document.hidden && this.painted) return;

      const m = MODES[this.mode] || MODES.idle;
      // A visible breath has to be drawn smoothly or it reads as a stutter, so
      // anything that pulses counts as lively. Only a truly idle orb throttles.
      const lively = this.smooth > 0.01 || m.sweep > 0 || m.pulse >= 0.03
                     || this.mode === "hearing" || this.mode === "speaking";
      // Idling at 60fps all day for a ring that is barely moving is rude to the
      // battery; a quiet orb redraws about eight times a second instead.
      const minGap = lively ? 0 : 120;
      if (now - this.lastFrame < minGap) return;
      const dt = Math.min(0.05, (now - this.lastFrame) / 1000) || 0.016;
      this.lastFrame = now;

      // VU ballistics: jump to a transient, fall back slowly. Tracking the raw
      // value makes the ring twitch; this makes it read as a meter.
      const target = this.level * m.drive;
      const k = target > this.smooth ? 0.45 : 0.06;
      this.smooth += (target - this.smooth) * k;

      if (!this.reduced) {
        this.t += dt * m.calm;
        this.sweep += dt * (0.9 + m.sweep * 1.4);
        // real seconds, so the breath rate means the same thing in every state
        this.pt += dt;
      }
      this._draw(m);
      this.painted = true;
    }

    _draw(m) {
      const ctx = this.ctx;
      const S = this.size;                 // shorter side: the circle's basis
      const cx = this.w / 2, cy = this.h / 2;   // centre of the box, not of S
      // The breath. A pure sine reads as mechanical; easing it so the orb hangs
      // slightly at the top of each cycle is what makes it feel like breathing
      // rather than a throbbing button.
      const phase = Math.sin(this.pt * m.rate * TAU);
      const breath = 1 + (m.pulse || 0) * (this.reduced ? 0 : phase * (0.75 + 0.25 * phase * phase));
      const base = S * 0.30 * breath;
      const [r, g, b] = this._color(m.color);
      const lvl = this.smooth;

      ctx.clearRect(0, 0, this.w, this.h);

      // inner bloom — the only "glow", and it only brightens with real signal
      const bloom = ctx.createRadialGradient(cx, cy, 0, cx, cy, base * 1.5);
      bloom.addColorStop(0, `rgba(${r},${g},${b},${0.05 + lvl * 0.16})`);
      bloom.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = bloom;
      ctx.fillRect(0, 0, this.w, this.h);

      for (let tr = 0; tr < TRACES; tr++) {
        const phase = tr * 0.6;
        const scale = 1 - tr * 0.045;
        const alpha = tr === 0 ? 0.92 : 0.92 * (0.34 / tr);
        const pts = [];
        for (let i = 0; i < POINTS; i++) {
          const a = (i / POINTS) * TAU;
          const wob = this._ambient(a, this.t + phase) * m.amp;
          // Signal deforms in a few lobes rather than uniformly, so a loud
          // moment reads as a shape and not just a bigger circle.
          const lobe = (0.55 + 0.45 * Math.sin(a * 4 - this.t * 2.2));
          const rad = base * scale * (1 + wob + lvl * 0.20 * lobe);
          pts.push([cx + Math.cos(a) * rad, cy + Math.sin(a) * rad]);
        }

        ctx.beginPath();
        const last = pts[POINTS - 1];
        ctx.moveTo((last[0] + pts[0][0]) / 2, (last[1] + pts[0][1]) / 2);
        for (let i = 0; i < POINTS; i++) {
          const p = pts[i], q = pts[(i + 1) % POINTS];
          ctx.quadraticCurveTo(p[0], p[1], (p[0] + q[0]) / 2, (p[1] + q[1]) / 2);
        }
        ctx.closePath();
        ctx.strokeStyle = `rgba(${r},${g},${b},${alpha})`;
        ctx.lineWidth = tr === 0 ? 1.4 : 1;
        ctx.stroke();
      }

      // thinking has no audio to plot, so it gets a sweep instead of a flat ring
      if (m.sweep > 0 && !this.reduced) {
        const head = this.sweep % TAU;
        const arc = 0.55 + m.sweep * 0.5;
        const grad = ctx.createLinearGradient(
          cx + Math.cos(head - arc) * base, cy + Math.sin(head - arc) * base,
          cx + Math.cos(head) * base,       cy + Math.sin(head) * base);
        grad.addColorStop(0, `rgba(${r},${g},${b},0)`);
        grad.addColorStop(1, `rgba(${r},${g},${b},0.85)`);
        ctx.beginPath();
        ctx.arc(cx, cy, base * 1.10, head - arc, head);
        ctx.strokeStyle = grad;
        ctx.lineWidth = 1.6;
        ctx.lineCap = "round";
        ctx.stroke();
      }

      // a still center mark: something to read the deformation against
      ctx.beginPath();
      ctx.arc(cx, cy, 1.6, 0, TAU);
      ctx.fillStyle = `rgba(${r},${g},${b},${0.30 + lvl * 0.5})`;
      ctx.fill();
    }
  }

  window.Orb = Orb;
})();
