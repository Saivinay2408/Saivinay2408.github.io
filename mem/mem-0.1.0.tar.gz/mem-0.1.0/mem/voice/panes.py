"""
panes — the set of terminals currently on screen, and how they get there.

Two ways a pane appears:
  1. you open one (the voice pane at startup, or a new terminal from the UI)
  2. the roster poll notices a session this app didn't start — an agent
     dispatched work in the background, or you have `claude` open elsewhere —
     and adopts it

(2) is what makes "watch them manage everything on your behalf" literal rather
than aspirational: you say "look into the flaky test", the voice session runs
`claude --bg`, and a pane for it shows up on its own a second later.
"""
from __future__ import annotations

import os
import threading
import time
import uuid
from pathlib import Path
from typing import Callable

from . import supervisor
from .paths import LAUNCH_CWD, clone_cwd, transcript_path
from .pty_pane import PtyPane


class Pane:
    """A PtyPane plus the dashboard's view of what it is."""

    def __init__(self, pid: str, pty: PtyPane, kind: str, title: str,
                 cwd: str, session_id: str = "", adopted: bool = False,
                 agent: str = "claude"):
        self.id = pid
        self.pty = pty
        self.kind = kind                 # voice | plain | attached
        # claude | codex | gemini. Only claude sessions have a transcript we
        # can read, so this is what everything downstream checks before it
        # tries to narrate or count tokens for a pane.
        self.agent = agent
        self.title = title
        self.cwd = cwd
        self.session_id = session_id
        self.adopted = adopted           # we attached to it, we didn't start it
        self.state = "idle"              # mirrored from the roster
        self.detail = ""
        self.waiting_for = ""
        self.started = time.time()
        # Set when the pane stops, so a finished session reports how long it
        # ran rather than a clock that keeps counting after it died.
        self.ended = 0.0

    @property
    def elapsed(self) -> float:
        return (self.ended or time.time()) - self.started

    @property
    def project_cwd(self) -> str:
        """Where this pane counts as being, for the left rail and the git panel.

        Not the same question as "what is its working directory". The clone's
        working directory is the vault, which is a notebook and not a project:
        pointing PROJECT at it makes the rail announce "no repo" and the git
        panel describe a folder of markdown. What you want to see while the
        clone is selected is the code you are working on, so that is what it
        reports.
        """
        return str(LAUNCH_CWD) if self.kind == "voice" else self.cwd

    def info(self) -> dict:
        alive = self.pty.alive
        if not alive and not self.ended:
            self.ended = time.time()
        return {
            "id": self.id,
            "kind": self.kind,
            "agent": self.agent,
            "title": self.title,
            "cwd": self.cwd,
            "shortCwd": Path(self.cwd).name or self.cwd,
            "sessionId": self.session_id,
            "adopted": self.adopted,
            "state": self.state,
            "detail": self.detail,
            "waitingFor": self.waiting_for,
            "alive": alive,
            "exitCode": self.pty.exit_code,
            "elapsed": round(self.elapsed),
            "startedAt": self.started,
        }


class PaneManager:
    """Owns every pane. Thread-safe; the roster poller runs off the event loop."""

    def __init__(self, on_change: Callable[[], None] | None = None):
        self._panes: dict[str, Pane] = {}
        self._lock = threading.RLock()
        self._on_change = on_change or (lambda: None)
        # sessions we deliberately do not adopt (you closed their pane; adopting
        # it again on the next 2s poll would make the close button useless)
        self._ignored: set[str] = set()
        # Which pane you are looking at. Set by the UI on click or focus. It
        # decides which repo the left rail describes and which working tree the
        # git panel acts on. It deliberately does NOT decide where your voice
        # goes — see _voice_target.
        self._focused: str = ""
        # Where your voice goes. Empty means the clone (the voice session), and
        # empty is the default and the resting state. Only the "talk here"
        # button in a pane's header ever sets it.
        self._voice_target: str = ""

    # ---- queries --------------------------------------------------------

    def get(self, pane_id: str) -> Pane | None:
        with self._lock:
            return self._panes.get(pane_id)

    def all(self) -> list[Pane]:
        with self._lock:
            return list(self._panes.values())

    def info(self) -> list[dict]:
        focused = self.focused_pane()
        fid = focused.id if focused else ""
        target = self.target_pane()
        tid = target.id if target else ""
        return [{**p.info(), "focused": p.id == fid, "voice": p.id == tid}
                for p in self.all()]

    def voice_pane(self) -> Pane | None:
        return next((p for p in self.all() if p.kind == "voice"), None)

    def focus(self, pane_id: str) -> bool:
        """Point everything at a pane. Unknown ids clear focus rather than
        raising: a click can race a pane closing, and the honest result of
        "focus something that is gone" is no focus, not an error."""
        with self._lock:
            self._focused = pane_id if pane_id in self._panes else ""
            return bool(self._focused)

    def focused_pane(self) -> Pane | None:
        """The pane you are looking at: the left rail, the git panel, the
        keyboard. Falls back to the voice session so "which repo am I in" has
        an answer before you have clicked anything."""
        with self._lock:
            pane = self._panes.get(self._focused)
        if pane is not None and pane.pty.alive:
            return pane
        return self.voice_pane()

    def target_pane(self) -> Pane | None:
        """Where a spoken utterance lands. Explicit, never inferred.

        This used to be the focused pane, and that was wrong in a way that
        broke conversations. Selecting a terminal is something you do to read
        it, to type one command in it, to see what it is doing — you do it
        constantly, and mid-sentence. Voice is not like that: you say
        something, it goes away and works, and it answers. Tying the second to
        the first meant a click while the clone was thinking silently
        redirected the answer, ended the turn as far as the loop was concerned,
        and left the reply unspoken. It looked like the voice had died.

        So the destination is the clone unless you say otherwise, and you say
        otherwise with the button in a pane's header. The clone is the right
        default because it is the one that knows everything: your vault, your
        projects, and how to dispatch work to the rest of them.
        """
        with self._lock:
            pane = self._panes.get(self._voice_target)
        if pane is not None and pane.pty.alive:
            return pane
        return self.voice_pane()

    def voice_target_id(self) -> str:
        """The pane the voice is pointed at, resolved. Empty if nothing is."""
        pane = self.target_pane()
        return pane.id if pane else ""

    def set_voice_target(self, pane_id: str) -> Pane | None:
        """Point the voice at a pane, or hand it back to the clone.

        A toggle on purpose: pressing the button on the pane that already has
        the voice returns it to the clone, so the same control both takes and
        gives back and there is no separate "release" to go looking for. An
        unknown or dead id also lands on the clone rather than raising — the
        pane can close between the click and the message arriving, and the
        honest answer to "talk to something that is gone" is the default.
        """
        with self._lock:
            pane = self._panes.get(pane_id)
            if pane is None or not pane.pty.alive or pane_id == self._voice_target:
                self._voice_target = ""
            else:
                self._voice_target = pane_id
        return self.target_pane()

    # ---- opening --------------------------------------------------------

    def open_voice(self, model: str = "sonnet",
                   permission_mode: str = "bypassPermissions") -> Pane:
        """The clone. Its UUID is generated here, not discovered, so its
        transcript path is known before it starts (see supervisor).

        It opens IN THE VAULT rather than in whatever project you happened to
        launch from. That is what makes it the clone rather than one more
        session with a system prompt: it is standing in its own memory, so it
        can read and edit the notes, run `mem` against the right vault without
        being told which, and drive your projects from outside any one of them.
        Project terminals still open in projects — see open_plain.
        """
        sid = str(uuid.uuid4())
        cmd = supervisor.voice_pane_cmd(sid, model, permission_mode)
        return self._spawn(cmd, clone_cwd(), "voice", "clone", session_id=sid)

    def open_plain(self, cwd: str | Path = LAUNCH_CWD, model: str = "",
                   agent: str = "claude") -> Pane:
        """A hand-driven terminal, running whichever agent the header is on.

        The generated session id is Claude Code's alone — it is what lets the
        transcript be tailed from the first turn. Codex and Gemini keep their
        own session stores in their own formats, so a pane running one carries
        no session id at all rather than an id nothing will ever match.
        """
        sid = str(uuid.uuid4()) if agent == "claude" else ""
        cmd = supervisor.plain_pane_cmd(model=model, session_id=sid, agent=agent)
        title = Path(cwd).name or "terminal"
        return self._spawn(cmd, cwd, "plain", title, session_id=sid, agent=agent)

    def open_resume(self, session_id: str, cwd: str | Path, title: str = "",
                    model: str = "") -> Pane:
        """Reopen a past conversation as a pane.

        cwd matters as much as the id: a session resumed from the wrong
        directory reads the wrong files, and its transcript lives under the
        original project either way.
        """
        cmd = supervisor.resume_cmd(session_id, model=model)
        return self._spawn(cmd, cwd, "plain", title or "resumed",
                           session_id=session_id)

    def open_shell(self, command: str, cwd: str | Path = LAUNCH_CWD,
                   title: str = "shell") -> Pane:
        """One command, in a real terminal, in front of you.

        Used for installs. `-lc` so it is a LOGIN shell: a GUI app inherits
        almost no environment, and npm, node and the rest live on a PATH that
        only a login shell assembles -- without it the command fails with
        "npm: command not found" on a machine that plainly has npm.

        The shell stays open when the command exits so its output, and any
        failure, can still be read.
        """
        shell = os.environ.get("SHELL", "/bin/zsh")
        script = f"{command}; echo; echo '[done — you can close this pane]'; exec {shell} -l"
        return self._spawn([shell, "-lc", script], cwd, "plain", title)

    def adopt(self, session: dict) -> Pane:
        """Open a pane onto a session that already exists."""
        sid = session.get("sessionId") or session.get("id") or ""
        cmd = supervisor.attach_cmd(session.get("id") or sid)
        pane = self._spawn(cmd, session.get("cwd") or LAUNCH_CWD, "attached",
                           session.get("name") or "session",
                           session_id=sid, adopted=True)
        pane.state = session.get("state", "idle")
        return pane

    def _spawn(self, cmd: list[str], cwd: str | Path, kind: str, title: str,
               session_id: str = "", adopted: bool = False,
               agent: str = "claude") -> Pane:
        pty = PtyPane(cmd, cwd=cwd, session_id=session_id, label=title)
        pane = Pane(uuid.uuid4().hex[:8], pty, kind, title, str(cwd),
                    session_id, adopted, agent)
        with self._lock:
            self._panes[pane.id] = pane
        self._on_change()
        return pane

    # ---- closing --------------------------------------------------------

    def close(self, pane_id: str, stop_session: bool = False,
              delete_session: bool = False) -> None:
        """Close a pane.

        Closing the pane and ending the session are deliberately separate. A pane
        is a window onto a session; you often want to stop looking at a
        background agent without killing its work. `stop_session` ends it,
        `delete_session` also drops it and its worktree.
        """
        with self._lock:
            pane = self._panes.pop(pane_id, None)
            # A voice pointed at a pane that no longer exists is the one state
            # that must never persist: it would send your next sentence
            # nowhere and say nothing about why. Closing the target hands the
            # voice back to the clone.
            if self._voice_target == pane_id:
                self._voice_target = ""
        if pane is None:
            return
        if pane.session_id:
            self._ignored.add(pane.session_id)
        pane.pty.close()
        if delete_session and pane.session_id:
            supervisor.remove(pane.session_id)
        elif stop_session and pane.session_id:
            supervisor.stop(pane.session_id)
        self._on_change()

    def close_all(self) -> None:
        for pane in self.all():
            pane.pty.close()
        with self._lock:
            self._panes.clear()

    # ---- roster sync ----------------------------------------------------

    def sync_roster(self, sessions: list[dict], auto_adopt: bool = True) -> bool:
        """Reconcile the daemon's session list against what's on screen.

        Returns True if anything changed, so the caller only broadcasts on a
        real edit rather than every two seconds.
        """
        changed = False
        by_session = {p.session_id: p for p in self.all() if p.session_id}

        for s in sessions:
            sid = s.get("sessionId") or ""
            pane = by_session.get(sid)
            if pane is not None:
                for attr, key in (("state", "state"), ("detail", "detail"),
                                  ("waiting_for", "waitingFor")):
                    val = s.get(key, "")
                    if getattr(pane, attr) != val and val:
                        setattr(pane, attr, val)
                        changed = True
                continue
            if not auto_adopt or not sid or sid in self._ignored:
                continue
            # Only adopt background sessions. Interactive ones are `claude`
            # windows you already have open in your own terminal — attaching a
            # second view onto a TUI someone is actively typing in fights them
            # for the input stream.
            if s.get("kind") == "background":
                self.adopt(s)
                changed = True

        # a pane whose process exited is no longer a terminal, it's a corpse
        for pane in self.all():
            if not pane.pty.alive and pane.state not in ("done", "failed", "stopped"):
                pane.state = "stopped"
                changed = True
                # Same rule as closing it: the voice does not stay pointed at
                # a session that has stopped answering.
                with self._lock:
                    if self._voice_target == pane.id:
                        self._voice_target = ""
        return changed

    # ---- transcript -----------------------------------------------------

    def transcript_for(self, pane: Pane) -> Path | None:
        if not pane.session_id:
            return None
        return transcript_path(pane.session_id, pane.cwd)
