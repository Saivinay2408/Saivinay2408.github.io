"""
narrate — saying what an agent is doing, from what it actually did.

The old loop spoke whatever prose survived a regex filter over the terminal
pane, which is why it read out prompts, file contents and status lines. This
takes typed events instead (see transcript.py) and produces its own short line
for each. Two consequences worth being explicit about:

  * It can only ever narrate a `tool` event. A `user` prompt or a `tool_result`
    has no template and no code path here, so "it said my prompt out loud" and
    "it read the file to me" are not bugs that can recur — there is nothing to
    fix, because there is nothing that could produce them.

  * It costs nothing. No model call, no token, no latency. Progress narration
    for a fleet of agents should not itself be a workload.

Phrasing is present-tense and first-person-plural-free ("reading jarvis", not
"I am now going to read the file jarvis dot pie"), because it is spoken over
work in progress and competes with the answer for attention.
"""
from __future__ import annotations

import re
import time
from typing import Callable

from .speakable import spoken_name

# How a Bash command reads out loud. Ordered: first match wins, so put the
# specific patterns above the general ones.
_BASH = (
    (r"\bgit\s+commit", "committing"),
    (r"\bgit\s+push", "pushing"),
    (r"\bgit\s+(?:status|diff|log|show)", "checking git"),
    (r"\bgit\s+(?:checkout|switch|branch)", "switching branches"),
    (r"\bgit\b", "running git"),
    (r"\b(?:pytest|jest|vitest|go test|cargo test)\b|\bnpm (?:run )?test\b", "running the tests"),
    (r"\b(?:npm|pnpm|yarn|bun)\s+(?:i|install|add)\b|\bpip3?\s+install\b|\buv\s+(?:pip\s+)?(?:add|install)\b",
     "installing packages"),
    (r"\b(?:npm|pnpm|yarn|bun)\s+run\s+(?:dev|start)\b", "starting the dev server"),
    (r"\b(?:npm|pnpm|yarn|bun)\s+run\s+build\b|\bmake\b|\bcargo build\b", "building it"),
    (r"\bmdfind\b|\bfind\b|\bgrep\b|\brg\b|\bag\b", "searching the machine"),
    (r"\bopen\s+-a\b|\bopen\s+http|\bcode\s\b", "opening it"),
    (r"\bscreencapture\b", "taking a look at the screen"),
    (r"\bosascript\b", "driving the app"),
    (r"\bcurl\b|\bwget\b", "fetching that"),
    (r"\bclaude\s+--bg\b", "starting a background session"),
    (r"\bclaude\s+(?:agents|stop|rm|attach)\b", "checking the other sessions"),
    (r"\b(?:mkdir|cp|mv|touch|chmod)\b", "moving files around"),
    (r"\b(?:ls|cat|head|tail|wc|stat)\b", "looking at files"),
    (r"\bpython3?\b|\bnode\b|\buv run\b", "running a script"),
)

# Tools that are pure bookkeeping. Narrating them is chatter, not progress.
_SILENT = {"TodoWrite", "TaskCreate", "TaskUpdate", "TaskList", "TaskGet",
           "ExitPlanMode", "EnterPlanMode", "ReportFindings", "NotebookRead"}


def _bash_phrase(cmd: str) -> str:
    c = " " + (cmd or "").strip()
    for pattern, phrase in _BASH:
        if re.search(pattern, c, re.I):
            return phrase
    return "running a command"


def describe(ev: dict) -> str:
    """A `tool` event as one short spoken clause, or "" to stay quiet."""
    name = ev.get("name", "")
    if name in _SILENT:
        return ""
    inp = ev.get("input") or {}

    if name == "Bash":
        return _bash_phrase(str(inp.get("command", "")))
    if name == "Read":
        return f"reading {spoken_name(str(inp.get('file_path', '')))}".strip()
    if name == "Write":
        return f"writing {spoken_name(str(inp.get('file_path', '')))}".strip()
    if name in ("Edit", "MultiEdit", "NotebookEdit"):
        return f"editing {spoken_name(str(inp.get('file_path', '')))}".strip()
    if name in ("Grep", "Glob"):
        return "searching the code"
    if name == "WebSearch":
        return "searching the web"
    if name == "WebFetch":
        return "reading a page"
    if name in ("Agent", "Task"):
        return "handing that to a subagent"
    if name.startswith("mcp__"):
        return "using a connected tool"
    return f"running {re.sub(r'(?<!^)(?=[A-Z])', ' ', name).lower()}"


def _verb(phrase: str) -> str:
    """The activity, without its object. "reading narrate" -> "reading".

    Forty consecutive Reads are one activity, not forty pieces of news. This is
    what lets the narrator say "reading the voice files" once instead of naming
    each file at you.
    """
    return (phrase or "").split(" ", 1)[0]


def _for_how_long(seconds: float) -> str:
    """Elapsed time as somebody would actually say it."""
    if seconds < 90:
        return "a minute"
    return f"{int(round(seconds / 60))} minutes"


class Narrator:
    """Turns one session's event stream into speech and orb status.

    Two output channels on purpose:

      say(text)     goes to the speakers. Expensive: it occupies the room, and
                    the room is shared with whoever you are sitting next to.
      status(text)  goes to the orb caption. Cheap, so it updates freely and
                    is where progress is actually watched.

    THE RULE FOR THE SPOKEN CHANNEL: a line is only worth saying if it tells you
    something you do not already know. Everything below follows from that, and
    every previous bug here was a violation of it:

      * "still working" was spoken whenever a turn went quiet before its first
        tool call. It is the one sentence that carries no information at all —
        the orb is already lit, so "something is happening" was never in doubt.
        It is now impossible to say: waiting lines name the activity or they
        are not spoken.

      * waiting lines repeated on a fixed 28-second timer for as long as one
        step lasted, so a four-minute install said the same sentence eight
        times. The gap now escalates — 30s, 75s, 3min, 7min — because the
        second reassurance is worth much less than the first and the sixth is
        worth nothing. Nobody in a room repeats themselves on a metronome.

      * a session BLOCKED on a permission prompt kept being narrated as
        working, which was not merely annoying but false. Waiting lines are
        gated on `allow` now, and the loop refuses while anything is blocked —
        it has already said the more urgent thing.

      * a waiting line could land while you were holding the key to talk, or
        over the tail of the answer you were listening to. Same gate.

      * consecutive tools of the same kind were each announced. Now only a
        CHANGE of activity is news, so reading nine files says "reading" once.
    """

    SAY_GAP = 9.0            # min seconds between spoken progress lines
    SAME_VERB_GAP = 25.0     # ...and much longer if it is the same activity
    STATUS_WAIT = 7.0        # caption switches to "still ..." after this
    # How long the silence must last before the Nth spoken reassurance. The
    # last value repeats, so a very long job stays quiet rather than silent.
    WAIT_STEPS = (30.0, 75.0, 180.0, 420.0)

    def __init__(self, say: Callable[[str], None], status: Callable[[str], None],
                 allow: Callable[[], bool] | None = None):
        self.say = say
        self.status = status
        # "Is the room free right now." The narrator decides WHAT is worth
        # saying; the loop is the only thing that knows whether you are
        # talking, whether a reply is playing, and whether a session is stuck.
        self.allow = allow or (lambda: True)
        self.reset()

    def reset(self) -> None:
        self.last_say = 0.0
        self.last_said_verb = ""
        self.last_event = time.time()
        self.last_phrase = ""
        self.waits_said = 0          # how many reassurances this turn has cost
        self.said_waiting = 0.0
        self.working = False
        self.last_status = ""

    def _status(self, text: str) -> None:
        """Caption, deduped.

        tick() runs at the orb's frame rate, so an unguarded status() re-sent
        the identical "still running the tests" twelve times a second for as
        long as a slow step lasted — a websocket message and a DOM write each
        time, for a string nobody could see change.
        """
        if text == self.last_status:
            return
        self.last_status = text
        self.status(text)

    def begin_turn(self) -> None:
        self.working = True
        self.last_event = time.time()
        self.said_waiting = 0.0
        self.waits_said = 0
        self.last_phrase = ""
        self.last_said_verb = ""
        self._status("thinking")

    def end_turn(self) -> None:
        self.working = False
        self.last_phrase = ""

    def note_activity(self) -> None:
        """Something happened that is not a tool call — the agent is writing.

        Without this the narrator counted a streaming answer as silence and
        could interrupt it to report that nothing was happening.
        """
        self.last_event = time.time()

    def feed(self, ev: dict) -> None:
        """Consume one transcript event. Only `tool` events can produce speech."""
        kind = ev.get("kind")
        if kind == "user":
            # Structurally unreachable as speech: there is no branch below that
            # could say it. Kept explicit so the guarantee is readable.
            self.begin_turn()
            return
        if kind == "turn_end":
            self.end_turn()
            return
        if kind != "tool":
            return

        # Subagent tool calls are somebody else's progress. The caption can show
        # them; interrupting the room for them cannot be justified.
        phrase = describe(ev)
        if not phrase:
            return
        self.last_event = time.time()
        self.said_waiting = 0.0
        self.last_phrase = phrase
        self._status(phrase if ev.get("direct", True) else f"subagent: {phrase}")

        if not ev.get("direct", True):
            return
        self._maybe_say(phrase)

    def _maybe_say(self, phrase: str) -> None:
        """Speak a progress line, if it is news and the room is free."""
        now = time.time()
        same = _verb(phrase) == self.last_said_verb
        gap = self.SAME_VERB_GAP if same else self.SAY_GAP
        if now - self.last_say < gap:
            return
        if not self.allow():
            return
        # A run of the same activity is announced by its verb alone. "reading
        # narrate, reading speakable, reading tts" is a list; "reading" is the
        # fact, and the caption still shows which file.
        text = _verb(phrase) if same else phrase
        self.last_say = now
        self.last_said_verb = _verb(phrase)
        self.say(text)

    def tick(self) -> None:
        """Call a few times a second. Emits waiting messages when work stalls.

        The caption and the speaker part company here, and deliberately: the
        caption says "still running the tests" seven seconds in, every time,
        because it is free and it is what you glance at. The speaker holds off
        for thirty, then longer each time, and only ever with a phrase that
        names what is actually happening.
        """
        if not self.working:
            return
        now = time.time()
        quiet = now - self.last_event
        if quiet < self.STATUS_WAIT:
            return

        base = self.last_phrase or "thinking"
        self._status(f"still {base}")

        # NOTHING TO SAY IS A REASON TO SAY NOTHING.
        # Before the first tool call there is no activity to name, and "still
        # working" is not one — the orb already says that much, in a channel
        # that does not interrupt anybody.
        if not self.last_phrase:
            return

        step = self.WAIT_STEPS[min(self.waits_said, len(self.WAIT_STEPS) - 1)]
        if quiet < step or now - self.said_waiting < step:
            return
        if not self.allow():
            return               # try again on a later tick, once the room is free

        self.said_waiting = now
        self.waits_said += 1
        # The first reassurance is the phrase. Later ones have already said
        # that much, so what they add is how long it has been going.
        self.say(f"still {base}" if self.waits_said == 1
                 else f"{base}, {_for_how_long(quiet)} now")
