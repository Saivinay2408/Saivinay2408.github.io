"""
pty_pane — one real terminal per pane.

Each pane owns a pseudo-terminal running the genuine `claude` TUI. Not a
re-render of it, not a log tail: the actual program, with its actual permission
prompts, slash commands, and keybindings. The browser side is xterm.js, so what
you look at and type into is the same thing you'd get running `claude` by hand.

This replaces the old arrangement — a tmux session scraped with `capture-pane`
plus a separate AppleScript-spawned Terminal.app window (voice/tmux_session.py).
Owning the PTY directly means there is no second window to manage, and reading
the session no longer means guessing at repainted text.
"""
from __future__ import annotations

import fcntl
import os
import pty
import signal
import struct
import subprocess
import termios
import threading
import time
import uuid
from collections import deque
from pathlib import Path
from typing import Callable

from .paths import LAUNCH_CWD

# Enough scrollback to redraw a pane on reconnect without unbounded growth.
SCROLLBACK_BYTES = 256 * 1024
READ_CHUNK = 65536

# Variables that identify the Claude Code session we were launched FROM.
#
# This matters more than it looks. If the dashboard is started from inside a
# Claude session — which is exactly what happens when you ask your clone to
# restart it — every pane inherits these, and the nested `claude` decides it is
# a child process. The visible consequence is:
#
#   "Transcript saving is off — inherited CLAUDE_CODE_CHILD_SESSION marker"
#
# ...which silently disables the JSONL transcripts that transcript.py, the voice
# narration, and the token accounting are all read from. The dashboard would
# come up looking perfectly healthy and simply never speak or count anything.
#
# Deliberately a denylist, not a `CLAUDE_CODE_*` wildcard: names in that space
# also carry real user configuration (Bedrock/Vertex routing, output limits)
# that a pane should keep.
PARENT_SESSION_VARS = (
    "CLAUDECODE",
    "CLAUDE_CODE_CHILD_SESSION",
    "CLAUDE_CODE_SESSION_ID",
    "CLAUDE_CODE_HOST_SESSION_ID",
    "CLAUDE_CODE_ENTRYPOINT",
    "CLAUDE_CODE_EXECPATH",
    "CLAUDE_CODE_SDK_HAS_HOST_AUTH_REFRESH",
    "CLAUDE_CODE_SDK_HAS_OAUTH_REFRESH",
    "CLAUDE_AGENT_SDK_VERSION",
    "CLAUDE_PID",
    "CLAUDE_EFFORT",
    "CLAUDE_CODE_EMIT_TOOL_USE_SUMMARIES",
    "CLAUDE_CODE_REPORT_FINDINGS",
    "CLAUDE_CODE_ENABLE_ASK_USER_QUESTION_TOOL",
    "CLAUDE_CODE_EAGER_FLUSH",
    "CLAUDE_CODE_DISABLE_CRON",
    "CLAUDE_CODE_PREVIEW_CLASSIFIER_FLOOR",
    "CLAUDE_PREVIEW_CLASSIFIER_FLOOR",
)


def _become_session_leader(slave_fd: int) -> None:
    """Run in the child between fork and exec.

    setsid() alone is not enough on macOS: the TUI needs this pty to be its
    *controlling* terminal, otherwise job control, SIGWINCH, and raw-mode input
    all misbehave. TIOCSCTTY is what actually attaches it.
    """
    os.setsid()
    fcntl.ioctl(slave_fd, termios.TIOCSCTTY, 0)


class PtyPane:
    """A live PTY plus the plumbing to mirror it to any number of viewers.

    Bytes flow out on a reader thread and are fanned out to subscribers; bytes
    flow in from `write()`. Subscriber callbacks run ON THE READER THREAD, so a
    subscriber must not block — the websocket handler hands off to the event
    loop immediately (see server.py).
    """

    # The size the pty is born with if nobody ever measures the pane. Only a
    # fallback: the process is normally not started until a real size arrives.
    START_COLS, START_ROWS = 80, 24

    # How long to wait for a viewer before starting anyway. A pane must run
    # even if no browser ever attaches to it — a dispatched background session
    # that nobody has scrolled to is still doing work.
    START_DEADLINE = 3.0

    def __init__(self, cmd: list[str], cwd: str | Path = LAUNCH_CWD,
                 cols: int = START_COLS, rows: int = START_ROWS,
                 session_id: str | None = None, label: str = "",
                 defer: bool = True):
        """THE PROCESS IS NOT STARTED HERE, BY DEFAULT.

        A TUI reads its size once, at boot, and lays out against it. Claude
        Code in particular fixes the width of its banner and tips panel then
        and does not recompute it, so a session born at the guessed 80 columns
        and resized to 49 a moment later spends the rest of its life drawing a
        layout for a pane it is not in — the fragments down the side of a
        re-tiled pane, and the wrapping that no later resize repairs.

        Every repaint trick downstream of that is damage control. The fix is
        not to guess: hold the process until a viewer has said how big the pane
        actually is, then start it at that size, and its first frame is already
        correct. `defer=False` is for callers that have a real size in hand.

        A pane nobody ever looks at still has to run, so START_DEADLINE starts
        it at the guess rather than leaving it pending forever.
        """
        self.session_id = session_id or str(uuid.uuid4())
        self.label = label
        self.cwd = str(cwd)
        self.cols, self.rows = cols, rows
        self.cmd = cmd
        self.error: str | None = None

        self._subs: list[Callable[[bytes], None]] = []
        self._lock = threading.Lock()
        self._scroll: deque[bytes] = deque()
        self._scroll_len = 0
        self._started = False
        self._closed = False
        self._start_lock = threading.Lock()
        self.proc = None
        self.master = -1
        self._deadline: threading.Timer | None = None

        env = dict(os.environ)
        # A TUI with no TERM falls back to dumb output; xterm.js speaks the full
        # xterm-256color/truecolor dialect, so say so.
        env["TERM"] = "xterm-256color"
        env["COLORTERM"] = "truecolor"
        env["LINES"], env["COLUMNS"] = str(rows), str(cols)
        # A stale key here makes `claude` authenticate as an API user instead of
        # the logged-in subscription, which bills differently and can fail
        # outright when the key has expired. Strip it so panes always use the
        # interactive login the user already has.
        env.pop("ANTHROPIC_API_KEY", None)
        env.pop("ANTHROPIC_AUTH_TOKEN", None)
        for var in PARENT_SESSION_VARS:
            env.pop(var, None)
        # Transcripts are not a nice-to-have here — they are the event stream the
        # whole dashboard reads. Ask for them explicitly rather than relying on
        # the default, so a pane can never come up silently unreadable.
        env["CLAUDE_CODE_FORCE_SESSION_PERSISTENCE"] = "1"
        self._env = env

        if defer:
            # Nothing exists yet — no pty, no process. `start` builds both.
            self._deadline = threading.Timer(
                self.START_DEADLINE, lambda: self.start(self.cols, self.rows))
            self._deadline.daemon = True
            self._deadline.start()
        else:
            self.start(cols, rows)

    # ---- starting -------------------------------------------------------

    def start(self, cols: int, rows: int) -> bool:
        """Open the pty at this size and run the command in it.

        Idempotent and safe from any thread: the first caller wins and every
        later one is a no-op, because the viewer's first resize and the
        deadline timer race each other by design.

        Returns True if this call is the one that started it.
        """
        with self._start_lock:
            if self._started or self._closed:
                return False
            self._started = True
            if self._deadline is not None:
                self._deadline.cancel()
                self._deadline = None
            if cols >= 20 and rows >= 5:
                self.cols, self.rows = cols, rows

        self._env["LINES"] = str(self.rows)
        self._env["COLUMNS"] = str(self.cols)

        self.master, slave = pty.openpty()
        # The size is set BEFORE the fork, so the program's very first read of
        # its own geometry is the real one. This is the whole point of
        # deferring: there is no "wrong size" period to repaint out of.
        self._set_size(self.cols, self.rows)
        try:
            self.proc = subprocess.Popen(
                self.cmd, cwd=self.cwd, env=self._env,
                stdin=slave, stdout=slave, stderr=slave,
                preexec_fn=lambda: _become_session_leader(slave),
                close_fds=True,
            )
        except (OSError, ValueError) as e:
            # `claude` missing from PATH, or a cwd that no longer exists. This
            # used to propagate out of the constructor and take the whole
            # dashboard down with a traceback before the window ever appeared —
            # for a condition whose right home is the pane that failed.
            self.error = str(e)
            self._fail(f"could not start {self.cmd[0]!r}: {e}")
        finally:
            os.close(slave)          # the child holds the only copy it needs

        self._reader = threading.Thread(target=self._read_loop, daemon=True)
        self._reader.start()
        return True

    @property
    def started(self) -> bool:
        return self._started

    def _fail(self, msg: str) -> None:
        """Turn a failed launch into a pane that explains itself.

        A dead pane replays its scrollback to any viewer (see server.py), so
        writing the reason there is what puts it on screen.
        """
        text = (f"\r\n\x1b[31m{msg}\x1b[0m\r\n\r\n"
                f"\x1b[2mcwd: {self.cwd}\x1b[0m\r\n").encode()
        self._scroll.append(text)
        self._scroll_len += len(text)

    # ---- output ---------------------------------------------------------

    def _read_loop(self) -> None:
        while True:
            try:
                data = os.read(self.master, READ_CHUNK)
            except OSError:
                data = b""           # pty closed: the child is gone
            if not data:
                break
            with self._lock:
                self._scroll.append(data)
                self._scroll_len += len(data)
                while self._scroll_len > SCROLLBACK_BYTES and len(self._scroll) > 1:
                    self._scroll_len -= len(self._scroll.popleft())
                subs = list(self._subs)
            for fn in subs:
                try:
                    fn(data)
                except Exception:            # noqa: BLE001 — one dead viewer
                    pass                     # must never kill the pane

    def subscribe(self, fn: Callable[[bytes], None]) -> Callable[[], None]:
        """Register a viewer. Returns the unsubscribe callable."""
        with self._lock:
            self._subs.append(fn)

        def off() -> None:
            with self._lock:
                if fn in self._subs:
                    self._subs.remove(fn)
        return off

    def scrollback(self) -> bytes:
        with self._lock:
            return b"".join(self._scroll)

    # ---- input ----------------------------------------------------------

    def write(self, data: bytes) -> None:
        # Typing into a pane that has not started yet is a real sequence: the
        # voice loop can submit before any browser has measured anything. Start
        # it at whatever size we have rather than dropping the keystroke.
        if not self._started:
            self.start(self.cols, self.rows)
        try:
            os.write(self.master, data)
        except OSError as e:
            self.error = str(e)

    # ---- geometry -------------------------------------------------------

    def _set_size(self, cols: int, rows: int) -> None:
        # No pty yet: the pane is still waiting for a size to start at. Its
        # record has already been updated by the caller, and `start` sets the
        # window before the fork, so there is nothing to do here.
        if self.master < 0:
            return
        try:
            fcntl.ioctl(self.master, termios.TIOCSWINSZ,
                        struct.pack("HHHH", rows, cols, 0, 0))
        except OSError:
            pass

    def resize(self, cols: int, rows: int) -> None:
        if cols < 20 or rows < 5:            # xterm.js reports 0 mid-layout
            return
        if (cols, rows) == (self.cols, self.rows):
            return
        self.cols, self.rows = cols, rows
        self._set_size(cols, rows)

    def force_size(self, cols: int, rows: int) -> None:
        """Set the window size on the tty without touching our own record.

        This is the "make it repaint" primitive, and both obvious alternatives
        were tried against the real program and do not work:

          * SIGWINCH with the size UNCHANGED does nothing at all. Claude Code's
            renderer only re-renders when a dimension actually differs, so the
            polite request is a no-op — asking for a repaint after clearing the
            screen left the pane permanently blank, which is how this was
            found.

          * changing the width DOES force a full redraw, but the renderer
            erases its previous frame by counting the lines that frame
            occupied, and that count was computed at the OLD width. So every
            width change strands exactly one frame on screen: the stack of
            broken box borders down a pane that has just been re-tiled.

        The caller therefore pairs a size change with suppressing output — see
        server._pty_ws.settle_repaint, which spends the stranded frame into a
        client that is not looking, clears, and only then lets the good one
        through.
        """
        self._set_size(cols, rows)

    def repaint(self) -> None:
        """Provoke one full redraw at the size this pane already has."""
        if not self._started:
            return
        c, r = self.cols, self.rows
        self.force_size(max(20, c - 1), r)
        time.sleep(0.06)
        self.force_size(c, r)

    # Kept for callers that still use the old name.
    nudge_redraw = repaint

    # ---- lifecycle ------------------------------------------------------

    @property
    def alive(self) -> bool:
        # A pane waiting for its size counts as alive. It has no process yet,
        # but it is going to have one, and every caller asking this question --
        # "should I draw it, tail it, let the voice point at it" -- wants yes.
        if not self._started:
            return not self._closed
        return self.proc is not None and self.proc.poll() is None

    @property
    def exit_code(self) -> int | None:
        if not self._started:
            return None
        return 127 if self.proc is None else self.proc.poll()

    def close(self) -> None:
        """Ask the whole process group to go, then insist."""
        with self._start_lock:
            self._closed = True
            if self._deadline is not None:
                self._deadline.cancel()
                self._deadline = None
            if not self._started:
                # Closed before it ever ran. Nothing to signal, nothing to shut.
                self._started = True
                return
        if self.proc is not None and self.proc.poll() is None:
            try:
                os.killpg(os.getpgid(self.proc.pid), signal.SIGTERM)
            except (ProcessLookupError, PermissionError):
                self.proc.terminate()
            try:
                self.proc.wait(timeout=3)
            except subprocess.TimeoutExpired:
                try:
                    os.killpg(os.getpgid(self.proc.pid), signal.SIGKILL)
                except (ProcessLookupError, PermissionError):
                    self.proc.kill()
        try:
            os.close(self.master)
        except OSError:
            pass
