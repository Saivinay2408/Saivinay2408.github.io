"""
git — the repository, usable from the window.

The point is not to be a git client. It is that an agent is editing your working
tree while you watch, and the questions that matter in that moment — what did it
just change, is that safe to keep, which branch am I on, is this tree dirty
before I let another session loose in it — should be answerable without leaving
the window and losing the thread.

FOUR RULES, ALL LEARNED THE HARD WAY
------------------------------------
1. **Nothing here writes without being asked.** Reads happen on a timer; stage,
   commit, push, branch and worktree operations happen only when a person
   clicks. There is no auto-commit, and there will not be one: an agent that
   commits on your behalf turns a bad edit into a bad edit you now have to
   revert, in history.

2. **Git must never wait for a human.** A subprocess blocked on a credential
   prompt looks exactly like a hung dashboard. `GIT_TERMINAL_PROMPT=0` and an
   explicit timeout on every call, so a push that needs auth fails in seconds
   with a message instead of freezing the panel.

3. **Porcelain v2, never the human-readable output.** `git status` is meant for
   people and changes between versions; `--porcelain=v2 -z` is a documented,
   NUL-delimited, machine format that also survives filenames containing
   spaces, quotes and newlines. Parsing the pretty output is the same mistake
   as scraping a terminal, which this project has already made once.

4. **`--no-optional-locks` on reads.** A status poll every few seconds must not
   take `index.lock` out from under a session that is trying to commit.
"""
from __future__ import annotations

import os
import subprocess
from dataclasses import dataclass, field
from pathlib import Path

TIMEOUT = 15
PUSH_TIMEOUT = 120          # a real network operation, unlike everything else

# Applied to every invocation. The dashboard is not a terminal and can never
# answer a prompt, so anything that would ask has to fail instead.
ENV = {
    **os.environ,
    "GIT_TERMINAL_PROMPT": "0",
    "GIT_OPTIONAL_LOCKS": "0",
    "GCM_INTERACTIVE": "never",
    "LC_ALL": "C",
}

# porcelain v2 XY codes -> what a person would call it.
STATUS_WORD = {
    "M": "modified", "A": "added", "D": "deleted", "R": "renamed",
    "C": "copied", "T": "typechange", "U": "conflict", "?": "untracked",
}


@dataclass
class FileChange:
    path: str
    staged: str = ""            # index status, "" when unstaged
    unstaged: str = ""          # worktree status
    untracked: bool = False
    conflict: bool = False

    def as_dict(self) -> dict:
        return {
            "path": self.path,
            "staged": STATUS_WORD.get(self.staged, self.staged),
            "unstaged": STATUS_WORD.get(self.unstaged, self.unstaged),
            "untracked": self.untracked,
            "conflict": self.conflict,
        }


@dataclass
class Status:
    repo: bool = False
    root: str = ""
    branch: str = ""
    detached: bool = False
    upstream: str = ""
    ahead: int = 0
    behind: int = 0
    files: list[FileChange] = field(default_factory=list)
    error: str = ""

    @property
    def dirty(self) -> bool:
        return bool(self.files)

    def as_dict(self) -> dict:
        return {
            "repo": self.repo, "root": self.root, "branch": self.branch,
            "detached": self.detached, "upstream": self.upstream,
            "ahead": self.ahead, "behind": self.behind, "dirty": self.dirty,
            "files": [f.as_dict() for f in self.files],
            "staged": sum(1 for f in self.files if f.staged and not f.untracked),
            "conflicts": sum(1 for f in self.files if f.conflict),
            "error": self.error,
            "label": self.label(),
        }

    def label(self) -> str:
        """One line small enough for the rail."""
        if self.error:
            return "git: " + self.error[:40]
        if not self.repo:
            return "not a repo"
        bits = [self.branch or "detached"]
        if self.ahead:
            bits.append(f"↑{self.ahead}")
        if self.behind:
            bits.append(f"↓{self.behind}")
        if self.files:
            bits.append(f"{len(self.files)} changed")
        return " ".join(bits)


def _run(args: list[str], cwd: str | Path, timeout: int = TIMEOUT) -> tuple[int, str, str]:
    try:
        p = subprocess.run(["git", *args], cwd=str(cwd), env=ENV,
                           capture_output=True, text=True, timeout=timeout)
        return p.returncode, p.stdout, p.stderr
    except subprocess.TimeoutExpired:
        return 124, "", f"git {args[0]} timed out after {timeout}s"
    except (OSError, ValueError) as e:
        return 127, "", str(e)


def _read(args: list[str], cwd: str | Path, timeout: int = TIMEOUT):
    """A read. `--no-optional-locks` so polling cannot steal index.lock from a
    session that is mid-commit."""
    return _run(["--no-optional-locks", *args], cwd, timeout)


def is_repo(cwd: str | Path) -> bool:
    code, out, _ = _read(["rev-parse", "--is-inside-work-tree"], cwd)
    return code == 0 and out.strip() == "true"


def status(cwd: str | Path) -> Status:
    """Branch, tracking, and every changed file.

    Parses `--porcelain=v2 -z --branch --untracked-files=normal`. The NUL
    delimiter is the whole reason this is reliable: a filename may legally
    contain a newline, and a line-based parser silently mangles it into two
    entries — one of which does not exist.
    """
    st = Status()
    code, out, err = _read(
        ["status", "--porcelain=v2", "-z", "--branch", "--untracked-files=normal"],
        cwd)
    if code != 0:
        low = err.lower()
        if "not a git repository" in low:
            return st                       # repo=False, and that is not an error
        st.error = err.strip().splitlines()[0] if err.strip() else f"exit {code}"
        return st

    st.repo = True
    rc, root, _ = _read(["rev-parse", "--show-toplevel"], cwd)
    st.root = root.strip() if rc == 0 else str(cwd)

    # Rename entries carry TWO NUL-separated paths, so the record stream cannot
    # be consumed with a plain split — the second path has to be pulled by the
    # reader that knows it is coming.
    records = out.split("\0")
    i = 0
    while i < len(records):
        rec = records[i]
        i += 1
        if not rec:
            continue
        kind, _, rest = rec.partition(" ")

        if kind == "#":
            head, _, value = rest.partition(" ")
            if head == "branch.head":
                st.branch = value.strip()
                st.detached = value.strip() == "(detached)"
            elif head == "branch.upstream":
                st.upstream = value.strip()
            elif head == "branch.ab":
                for part in value.split():
                    if part.startswith("+"):
                        st.ahead = int(part[1:] or 0)
                    elif part.startswith("-"):
                        st.behind = int(part[1:] or 0)
            continue

        if kind == "?":
            st.files.append(FileChange(path=rest, unstaged="?", untracked=True))
        elif kind == "u":
            fields = rest.split(" ", 10)
            st.files.append(FileChange(path=fields[-1], conflict=True, unstaged="U"))
        elif kind in ("1", "2"):
            fields = rest.split(" ", 8)
            xy = fields[0]
            path = fields[-1]
            if kind == "2":
                i += 1              # rename/copy: the original path follows
            st.files.append(FileChange(
                path=path,
                staged="" if xy[0] == "." else xy[0],
                unstaged="" if xy[1] == "." else xy[1],
            ))
    return st


def _is_untracked(cwd: str | Path, path: str) -> bool:
    code, out, _ = _read(["ls-files", "--error-unmatch", "--", path], cwd)
    return code != 0 or not out.strip()


def diff(cwd: str | Path, path: str = "", staged: bool = False,
         max_bytes: int = 200_000) -> dict:
    """A unified diff, capped.

    The cap is not politeness. A generated lockfile or a checked-in binary
    produces a diff megabytes long, and pushing that down a websocket to be
    syntax-highlighted is how the window locks up on the one repo that most
    needs looking at.
    """
    args = ["diff", "--no-color", "--no-ext-diff"]
    if staged:
        args.append("--cached")
    if path:
        args += ["--", path]
    code, out, err = _read(args, cwd)
    if code != 0:
        return {"text": "", "error": err.strip(), "truncated": False}

    if not out and not staged and path and _is_untracked(cwd, path):
        # `git diff` says nothing about a file git has never seen, which reads
        # as "no changes" for a file that is entirely new. Show it as additions.
        #
        # The untracked test is load-bearing and was missing at first: without
        # it, a CLEAN tracked file also produces an empty diff and was rendered
        # as if every line had just been added.
        target = Path(cwd) / path
        try:
            if target.is_file():
                body = target.read_text(encoding="utf-8", errors="replace")
                out = f"--- /dev/null\n+++ b/{path}\n" + "".join(
                    f"+{ln}\n" for ln in body.splitlines()[:2000])
        except OSError:
            pass

    truncated = len(out) > max_bytes
    return {"text": out[:max_bytes], "error": "", "truncated": truncated}


def numstat(cwd: str | Path, staged: bool = False) -> dict[str, tuple[int, int]]:
    """path -> (added, removed) for the working tree.

    `--numstat` rather than counting lines out of a diff: it is one call for
    every file instead of one per file, and it reports a binary change as `-`
    rather than a wrong number.
    """
    args = ["diff", "--numstat", "--no-color"]
    if staged:
        args.append("--cached")
    code, out, _ = _read(args, cwd)
    if code != 0:
        return {}
    counts: dict[str, tuple[int, int]] = {}
    for line in out.splitlines():
        parts = line.split("\t")
        if len(parts) != 3:
            continue
        add, rem, path = parts
        counts[path] = (0 if add == "-" else int(add or 0),
                        0 if rem == "-" else int(rem or 0))
    return counts


def log(cwd: str | Path, limit: int = 40) -> list[dict]:
    """Commits, with the parent list so the graph can be drawn.

    `%P` is what makes a graph possible at all: without the parents you have a
    list, and the interesting shape of a history — where it forked, where it
    merged — is exactly the part that lives in those edges.
    """
    fmt = "%H%x1f%h%x1f%an%x1f%ar%x1f%s%x1f%P%x1f%D"
    code, out, _ = _read(
        ["log", f"-{limit}", "--all", "--date-order", f"--pretty=format:{fmt}"], cwd)
    if code != 0:
        return []
    rows = []
    for line in out.splitlines():
        parts = line.split("\x1f")
        if len(parts) != 7:
            continue
        sha, short, author, when, subject, parents, refs = parts
        rows.append({
            "sha": sha, "short": short, "author": author, "when": when,
            "subject": subject,
            "parents": parents.split() if parents else [],
            "refs": [r.strip() for r in refs.split(",") if r.strip()],
        })
    return rows


# How many columns the graph is allowed to use. Beyond this the lanes are
# narrower than they are legible, and a repository with twelve concurrent
# branches is not going to be understood from a 268px rail anyway.
MAX_LANES = 6


def graph(commits: list[dict]) -> list[dict]:
    """Assign each commit a lane, and say which lanes pass through beside it.

    The standard algorithm, kept deliberately small. Walking newest-first, a
    lane is "reserved" by a commit for its first parent; other parents claim
    new lanes. A commit takes whichever lane was reserved for it, or the first
    free one if nothing reserved it (that is a branch tip).

    Computed on the server rather than in the browser because it is a pure
    function of the commit list, and putting it here means it is testable
    without a DOM.
    """
    lanes: list[str | None] = []       # lane index -> sha it is waiting for
    out = []

    for c in commits:
        sha = c["sha"]
        try:
            col = lanes.index(sha)
        except ValueError:
            col = next((i for i, v in enumerate(lanes) if v is None), len(lanes))
            if col == len(lanes):
                lanes.append(None)

        # Clear EVERY lane waiting on this commit, not just the first. When a
        # branch rejoins the trunk, two lanes are both waiting on the shared
        # ancestor; freeing only one leaves the other reserved forever, and the
        # graph draws a phantom vertical running down past every older commit.
        # This is git's `|/` convergence, and it was wrong until it was drawn.
        for i, waiting in enumerate(lanes):
            if waiting == sha:
                lanes[i] = None

        # Lanes still waiting on some other commit are drawn as pass-through
        # verticals beside this row.
        through = [i for i, v in enumerate(lanes) if v is not None and i != col]

        parents = c["parents"]
        if parents:
            lanes[col] = parents[0]
            for extra in parents[1:]:
                if extra in lanes:
                    continue
                free = next((i for i, v in enumerate(lanes) if v is None), len(lanes))
                if free == len(lanes):
                    lanes.append(None)
                lanes[free] = extra

        while lanes and lanes[-1] is None:
            lanes.pop()

        out.append({**c,
                    "lane": min(col, MAX_LANES - 1),
                    "through": sorted({min(t, MAX_LANES - 1) for t in through}),
                    "merge": len(parents) > 1,
                    "width": min(max(len(lanes), col + 1), MAX_LANES)})
    return out


def branches(cwd: str | Path) -> dict:
    code, out, _ = _read(
        ["for-each-ref", "--sort=-committerdate", "--count=50",
         "--format=%(refname:short)%09%(HEAD)", "refs/heads/"], cwd)
    if code != 0:
        return {"current": "", "branches": []}
    names, current = [], ""
    for line in out.splitlines():
        name, _, head = line.partition("\t")
        names.append(name)
        if head.strip() == "*":
            current = name
    return {"current": current, "branches": names}


# ------------------------------------------------------------------- writing
# Everything below changes the repository, and is only ever reached from an
# explicit click. See rule 1 in the module docstring.

def stage(cwd: str | Path, paths: list[str]) -> dict:
    if not paths:
        return {"ok": False, "error": "nothing selected"}
    code, _, err = _run(["add", "--", *paths], cwd)
    return {"ok": code == 0, "error": err.strip()}


def unstage(cwd: str | Path, paths: list[str]) -> dict:
    if not paths:
        return {"ok": False, "error": "nothing selected"}
    code, _, err = _run(["restore", "--staged", "--", *paths], cwd)
    return {"ok": code == 0, "error": err.strip()}


def commit(cwd: str | Path, message: str, all_tracked: bool = False) -> dict:
    """Commit what is staged.

    No author is set and no trailer is added. The commit is the user's, made
    from their machine with their own git identity, and a tool that quietly
    signs its own name to somebody's history has overstepped.
    """
    message = (message or "").strip()
    if not message:
        return {"ok": False, "error": "a commit needs a message"}
    args = ["commit", "-m", message]
    if all_tracked:
        args.insert(1, "-a")
    code, out, err = _run(args, cwd)
    if code != 0:
        detail = (err.strip() or out.strip() or f"exit {code}")
        if "nothing to commit" in (out + err).lower():
            detail = "nothing staged to commit"
        return {"ok": False, "error": detail}
    return {"ok": True, "error": "", "output": out.strip()[:400]}


def push(cwd: str | Path) -> dict:
    """Push the current branch, setting upstream on first push.

    Cannot prompt: with GIT_TERMINAL_PROMPT=0 a repository needing credentials
    fails fast and says so, rather than leaving the window looking frozen while
    a hidden subprocess waits for a password nobody can type.
    """
    st = status(cwd)
    if not st.repo:
        return {"ok": False, "error": "not a repo"}
    if st.detached or not st.branch:
        return {"ok": False, "error": "detached HEAD; check out a branch first"}
    args = ["push"] if st.upstream else ["push", "--set-upstream", "origin", st.branch]
    code, out, err = _run(args, cwd, timeout=PUSH_TIMEOUT)
    if code != 0:
        return {"ok": False, "error": (err.strip() or out.strip())[:400]}
    return {"ok": True, "error": "", "output": (err.strip() or out.strip())[:400]}


def switch_branch(cwd: str | Path, name: str, create: bool = False) -> dict:
    """Switch branches, refusing to do it over uncommitted work.

    `git switch` would carry the changes across, which is occasionally what
    somebody wants and is never what somebody wants when an agent has just
    edited eleven files they have not read yet.
    """
    name = (name or "").strip()
    if not name:
        return {"ok": False, "error": "no branch named"}
    st = status(cwd)
    if st.dirty:
        return {"ok": False, "error": f"{len(st.files)} uncommitted change(s); "
                                      "commit or stash them first"}
    args = ["switch", "-c", name] if create else ["switch", name]
    code, out, err = _run(args, cwd)
    return {"ok": code == 0, "error": (err.strip() or out.strip())[:300]}


def worktrees(cwd: str | Path) -> list[dict]:
    code, out, _ = _read(["worktree", "list", "--porcelain"], cwd)
    if code != 0:
        return []
    trees, cur = [], {}
    for line in out.splitlines():
        if not line.strip():
            if cur:
                trees.append(cur); cur = {}
            continue
        key, _, value = line.partition(" ")
        if key == "worktree":
            cur["path"] = value
        elif key == "branch":
            # Strip only the `refs/heads/` prefix. `rsplit("/", 1)` turned
            # `refs/heads/session/fix-flaky` into `fix-flaky`, which silently
            # broke every comparison against a namespaced branch name — and
            # session branches are all namespaced.
            cur["branch"] = value[len("refs/heads/"):] if value.startswith("refs/heads/") \
                else value
        elif key == "detached":
            cur["branch"] = "(detached)"
    if cur:
        trees.append(cur)
    return trees


def worktree_home() -> Path:
    """Where managed worktrees live.

    Under our own state directory, NOT beside the repository. The first version
    put them at `<repo>/../<repo>-<branch>`, which is what git's own docs show
    and which quietly scatters directories across whatever folder your projects
    happen to sit in — it put a stray `mem-k` on a real Desktop within an hour.
    One managed location means they can also be listed and cleaned up.
    """
    from .paths import STATE
    return Path(os.environ.get("MEM_WORKTREES", STATE / "worktrees"))


def _slug(text: str, limit: int = 32) -> str:
    keep = [c if (c.isalnum() or c in "-_") else "-" for c in text.strip().lower()]
    return "-".join(filter(None, "".join(keep).split("-")))[:limit] or "task"


def session_branch(name: str) -> str:
    """`session/<slug>`. Namespaced so a glance at `git branch` tells you which
    branches an agent made and which you made yourself."""
    return f"session/{_slug(name)}"


def add_worktree(cwd: str | Path, branch: str, parent: str | Path | None = None) -> dict:
    """A separate checkout for a background session.

    This is the one git feature here that prevents damage rather than reporting
    it. Two agents dispatched into one working tree will interleave edits, and
    the loser's work is simply gone — there is no conflict marker for "we both
    wrote this file, out of order". A worktree gives each its own.
    """
    branch = (branch or "").strip()
    if not branch:
        return {"ok": False, "error": "no branch named"}
    st = status(cwd)
    if not st.repo:
        return {"ok": False, "error": "not a git repository"}
    root = Path(st.root or cwd)

    if parent:
        dest = Path(parent)
    else:
        home = worktree_home()
        home.mkdir(parents=True, exist_ok=True)
        dest = home / f"{root.name}-{_slug(branch)}"
        # Two sessions dispatched with the same name must not collide.
        n = 2
        while dest.exists():
            dest = home / f"{root.name}-{_slug(branch)}-{n}"
            n += 1
    if dest.exists():
        return {"ok": False, "error": f"{dest} already exists"}

    # A branch can only be checked out in one worktree. Say that in those
    # words: git's own message for it arrives mixed into the "Preparing
    # worktree" progress text and reads like an internal failure.
    for tree in worktrees(cwd):
        if tree.get("branch") == branch:
            return {"ok": False,
                    "error": f"{branch} is already checked out at {tree.get('path')}"}

    base = st.branch if not st.detached else "HEAD"
    code, out, err = _run(["worktree", "add", "-b", branch, str(dest), base], cwd)
    if code != 0:
        # The branch may exist without a worktree; attach rather than rename.
        code, out, err = _run(["worktree", "add", str(dest), branch], cwd)
    if code != 0:
        detail = err.strip() or out.strip()
        # git prints progress to stderr, so the real reason is usually last.
        detail = next((ln for ln in reversed(detail.splitlines())
                       if ln.strip() and not ln.startswith("Preparing")), detail)
        return {"ok": False, "error": detail[:300]}
    return {"ok": True, "error": "", "path": str(dest), "branch": branch, "base": base}


def remove_worktree(cwd: str | Path, path: str, delete_branch: bool = False) -> dict:
    """Take a worktree away again.

    Refuses while the tree is dirty unless git itself is happy, because the
    whole point of a worktree is that the work in it is real. `--force` is
    deliberately not passed: losing an agent's uncommitted output to a stray
    click is exactly the failure this module exists to prevent.
    """
    # Read the branch name BEFORE removing anything. Looking it up afterwards
    # searches a list the removal has already deleted the entry from, so
    # `delete_branch` silently did nothing and left the branch behind.
    branch = next((t.get("branch") for t in worktrees(cwd)
                   if t.get("path") == path), "")

    code, out, err = _run(["worktree", "remove", path], cwd)
    if code != 0:
        return {"ok": False, "error": (err.strip() or out.strip())[:300]}
    if delete_branch and branch and branch != "(detached)":
        _run(["branch", "-D", branch], cwd)
    return {"ok": True, "error": "", "branch": branch}


def base_branch(cwd: str | Path) -> str:
    """What this branch should be compared against.

    In order: the upstream's own branch name, then whichever of main/master/
    develop exists. A guess, but a checkable one — `diff_vs_base` reports which
    base it used, so a wrong guess is visible rather than silently changing
    what "review changes" means.

    Returns "" when you are already ON the trunk. There is no meaningful "what
    did this branch change" for the branch everything else is measured against,
    and the first version answered that question by picking an unrelated
    feature branch and diffing against it — confidently, and backwards.
    """
    st = status(cwd)
    if st.detached or not st.branch:
        return ""
    if st.upstream and "/" in st.upstream:
        remote_branch = st.upstream.split("/", 1)[1]
        if remote_branch != st.branch:
            return remote_branch
    trunks = ("main", "master", "develop")
    if st.branch in trunks:
        return ""
    names = branches(cwd)["branches"]
    return next((c for c in trunks if c in names), "")


def diff_vs_base(cwd: str | Path, base: str = "", max_bytes: int = 400_000) -> dict:
    """Everything this branch changed, not just what is uncommitted.

    The question a review actually asks. An agent that ran for an hour and made
    nine commits shows *nothing* under `git diff`, and a panel that only knows
    about uncommitted work would report that as "no changes" — the most
    misleading possible answer.

    Three dots, not two: `A...B` diffs from the merge base, so commits that
    landed on the base branch after this one forked are not attributed to it.
    """
    base = base or base_branch(cwd)
    if not base:
        return {"text": "", "error": "no base branch to compare against",
                "base": "", "files": [], "truncated": False}

    stat = _read(["diff", "--numstat", f"{base}...HEAD"], cwd)
    files = []
    if stat[0] == 0:
        for line in stat[1].splitlines():
            parts = line.split("\t")
            if len(parts) == 3:
                add, rem, path = parts
                files.append({"path": path,
                              "add": 0 if add == "-" else int(add or 0),
                              "rem": 0 if rem == "-" else int(rem or 0)})

    code, out, err = _read(["diff", "--no-color", f"{base}...HEAD"], cwd)
    if code != 0:
        return {"text": "", "error": err.strip()[:300], "base": base,
                "files": files, "truncated": False}
    return {"text": out[:max_bytes], "error": "", "base": base,
            "files": files, "truncated": len(out) > max_bytes,
            "add": sum(f["add"] for f in files),
            "rem": sum(f["rem"] for f in files)}


def snapshot(cwd: str | Path) -> dict:
    """Everything the git panel needs for one project, in one call.

    One call rather than five round trips: the panel repaints whenever focus
    moves, and a panel assembled from five separate messages spends a visible
    moment showing a branch from one repository next to a file list from
    another.
    """
    st = status(cwd)
    out = st.as_dict()
    if not st.repo:
        return out

    unstaged, staged = numstat(cwd), numstat(cwd, staged=True)
    total_add = total_rem = 0
    for f in out["files"]:
        add, rem = staged.get(f["path"], unstaged.get(f["path"], (0, 0)))
        f["add"], f["rem"] = add, rem
        total_add += add
        total_rem += rem

    out["add"], out["rem"] = total_add, total_rem
    out["branches"] = branches(cwd)
    out["log"] = graph(log(cwd, 40))
    out["worktrees"] = worktrees(cwd)
    return out
