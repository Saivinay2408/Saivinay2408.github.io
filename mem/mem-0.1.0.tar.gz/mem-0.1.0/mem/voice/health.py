"""
health — the things that fail quietly.

This section exists because of what building the dashboard turned up. On this
machine, all at once and with no visible symptom: the memory consolidation job
was not loaded in launchd, its headless token had expired so every extraction
returned nothing, and an MCP server was sitting unauthenticated. The vault
looked healthy. Nothing was wrong on screen. It simply had not learned anything
in six days.

That is the failure mode this project already takes seriously elsewhere —
`verify_memory.py` exists so the graph cannot be quietly unsound, and the
consolidation reject gate exists so junk cannot quietly get in. This is the same
idea pointed at the machine around it.

Every check returns a fix you can actually run, because a red dot that does not
tell you what to do is just anxiety.
"""
from __future__ import annotations

import json
import shutil
import subprocess
import time

from .paths import CLAUDE_HOME, CONSOLIDATE_LOG, vault

TIMEOUT = 6


def _sh(args: list[str], timeout: int = TIMEOUT) -> tuple[int, str]:
    try:
        p = subprocess.run(args, capture_output=True, text=True, timeout=timeout)
        return p.returncode, (p.stdout or "") + (p.stderr or "")
    except (OSError, subprocess.SubprocessError):
        return 127, ""


def _check(name: str, ok: bool | None, detail: str, fix: str = "",
           level: str = "warn") -> dict:
    """level: 'warn' is amber and 'bad' is red; ok=None means "couldn't tell"."""
    return {"name": name, "ok": ok, "detail": detail, "fix": fix, "level": level}


def check_claude() -> dict:
    if not shutil.which("claude"):
        return _check("Claude Code", False, "not on PATH",
                      "Install it, or add it to PATH.", "bad")
    code, out = _sh(["claude", "--version"])
    ver = out.strip().split()[0] if out.strip() else "?"
    return _check("Claude Code", code == 0, ver or "unknown")


def check_mem() -> dict:
    """The library this whole dashboard is a face for. Its absence is the one
    failure that makes every check below meaningless, so it is checked first
    and says plainly how to fix itself."""
    try:
        import mem                                 # noqa: F401
    except ImportError:
        return _check("Mem", False, "not installed",
                      "pip install mem", "bad")
    return _check("Mem", True, f"vault at {vault()}")


def check_scheduler() -> dict:
    """Whether anything is going to fold sessions into memory on its own.

    There is no launchd plist any more — the dashboard runs the pass itself
    while it is open (see memory_ctl). So the honest question is not "is a job
    installed" but "is the interval set to something other than never".
    """
    from .memory_ctl import cadence_seconds, load_config
    cfg = load_config()
    if not cfg.get("autoConsolidate") or cadence_seconds() <= 0:
        return _check("Memory schedule", False, "nothing scheduled",
                      "Pick an interval in Memory, or press Consolidate now.")
    return _check("Memory schedule", True,
                  f"every {cfg.get('cadence')} while this window is open")


def check_extractor() -> dict:
    """Consolidation shells out to a model to extract candidate facts. When
    that call fails, mem logs 'extractor returned no JSON' — which reads
    like a parsing bug and is actually auth. Distinguishing the two is the
    whole reason this check exists.

    The cheap version is used deliberately: reading the last pass out of the
    log costs nothing, where actually invoking the extractor costs a model
    call every time somebody opens the Health tab.
    """
    try:
        with CONSOLIDATE_LOG.open("rb") as f:
            size = f.seek(0, 2)
            f.seek(max(0, size - 60_000))
            tail = f.read().decode("utf-8", "replace")
    except OSError:
        return _check("Extractor", None, "no pass has run yet",
                      "mem check-extractor")
    from .memory_ctl import START_MARKER
    start = tail.rfind(START_MARKER)
    block = tail[start:] if start >= 0 else tail
    failed = block.count("! extractor")
    wrote = block.count("wrote:")
    if failed and not wrote:
        return _check("Extractor", False,
                      f"last pass: {failed} failures, 0 facts written",
                      "Nothing could be distilled. Diagnose it with "
                      "`mem check-extractor`.", "bad")
    if failed:
        return _check("Extractor", True,
                      f"last pass: {wrote} facts written, {failed} failures")
    return _check("Extractor", True, f"last pass: {wrote} facts written")


def check_vault() -> dict:
    idx = vault() / "index.json"
    try:
        data = json.loads(idx.read_text())
    except (OSError, ValueError):
        return _check("Memory graph", None, "index.json not readable",
                      "mem index")
    dangling = len(data.get("dangling") or [])
    nodes = len(data.get("nodes") or [])
    edges = len(data.get("edges") or [])
    if dangling:
        return _check("Memory graph", False,
                      f"{dangling} broken links across {nodes} notes",
                      "mem maintain --apply", "bad")
    return _check("Memory graph", True, f"{nodes} nodes, {edges} links, sound")


def check_backlog() -> dict:
    """Captured but not distilled. A little is normal; a lot means the pass has
    stopped running and the clone is not learning."""
    from .memory_ctl import vault_stats
    pending = vault_stats()["pending"]
    if pending > 50:
        return _check("Memory backlog", False,
                      f"{pending} sessions captured but never distilled",
                      "Clear the schedule and extractor checks above, then "
                      "press Consolidate now.")
    if pending:
        return _check("Memory backlog", True, f"{pending} waiting for the next pass")
    return _check("Memory backlog", True, "nothing waiting")


def check_mcp() -> dict:
    cache = CLAUDE_HOME / "mcp-needs-auth-cache.json"
    try:
        data = json.loads(cache.read_text())
    except (OSError, ValueError):
        return _check("MCP servers", True, "none needing attention")
    names = list(data) if isinstance(data, dict) else list(data or [])
    if names:
        return _check("MCP servers", False,
                      f"{len(names)} need authentication: {', '.join(map(str, names[:3]))}",
                      "Run /mcp inside any session to authenticate.")
    return _check("MCP servers", True, "all authenticated")


def check_daemon() -> dict:
    code, out = _sh(["claude", "daemon", "status"])
    if code != 0:
        return _check("Session daemon", None, "not running",
                      "Starts on its own with the first background session.")
    first = next((l for l in out.splitlines() if l.strip()), "running")
    return _check("Session daemon", True, first.strip()[:70])


def check_mic() -> dict:
    """Whether an input device exists at all. macOS only reveals a permission
    problem as a stream of silence, which the voice loop reports separately."""
    try:
        import sounddevice as sd
        ins = [d for d in sd.query_devices() if d.get("max_input_channels", 0) > 0]
        if not ins:
            return _check("Microphone", False, "no input device",
                          "Connect a microphone.", "bad")
        default = sd.query_devices(kind="input")
        return _check("Microphone", True, str(default.get("name", "default"))[:50])
    except Exception as e:                              # noqa: BLE001
        return _check("Microphone", None, f"unavailable ({type(e).__name__})")


def check_voice_models() -> dict:
    """Whether the speech weights are actually on this machine.

    This is the check whose absence made a broken install look like a working
    one. Without these files the microphone is live, the orb is drawn, and
    nothing happens when you hold the space bar -- because the failure is a
    file that is not there, raised inside the first utterance, where nobody
    sees it. Saying so in the Health tab, by name, with a button, is the
    difference between "the voice is broken" and "it needs 325 MB".
    """
    from . import models
    st = models.status()
    if st["ready"]:
        return _check("Speech models", True, "all four present")
    gone = [i["name"] for i in st["items"] if not i["present"]]
    mb = st["missingBytes"] / 1e6
    return _check("Speech models", False,
                  f"{len(gone)} missing ({mb:.0f} MB) — " + ", ".join(gone),
                  "Open Setup and press Get the speech models.", "bad")


def check_window() -> dict:
    """Whether a desktop window can actually be opened.

    pywebview is the `gui` extra, not the `voice` one, and installing only
    `voice` yields an app that starts, serves its UI, and shows nothing --
    because the fallback prints a URL, and in a Dock launch that goes to a log.
    The failure is invisible from the outside and looks exactly like a crash,
    so it gets a name here.
    """
    try:
        import webview                                  # noqa: F401
    except ImportError:
        return _check("Desktop window", False, "pywebview is not installed",
                      'pip install "mem[gui]" — until then it opens in your '
                      "browser instead.", "warn")
    return _check("Desktop window", True, "pywebview")


CHECKS = (check_mem, check_claude, check_daemon, check_scheduler,
          check_extractor, check_vault, check_backlog, check_mcp, check_mic,
          check_voice_models, check_window)


def run_all() -> dict:
    """Every check. Slow ones shell out, so this is called on demand, not on a
    timer — the menu asks for it when you open Health."""
    started = time.time()
    results = []
    for fn in CHECKS:
        try:
            results.append(fn())
        except Exception as e:                          # noqa: BLE001
            results.append(_check(fn.__name__, None, f"check failed: {e}"))
    bad = [r for r in results if r["ok"] is False]
    return {
        "checks": results,
        "failing": len(bad),
        "worst": "bad" if any(r["level"] == "bad" for r in bad)
                 else ("warn" if bad else "ok"),
        "tookMs": int((time.time() - started) * 1000),
    }
