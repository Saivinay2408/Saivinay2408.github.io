"""
supervisor — a client for Claude Code's own session daemon.

Anthropic ships a per-user supervisor process that already owns the hard parts of
running many sessions: dispatch, worker pre-warming, restart-on-update, surviving
sleep, git-worktree isolation, and per-session state. `claude agents` is its TUI.
This module is a second client of the same daemon, so the dashboard inherits all
of that instead of reimplementing it against `ps` and tmux.

Verified against Claude Code 2.1.221:
  claude agents --json [--all] [--cwd P]   list sessions
  claude --bg "<prompt>" [--name N]        dispatch a background session
  claude stop <id> / claude rm <id>        end one / delete it and its worktree
  ~/.claude/jobs/<short-id>/state.json     richer state than the list gives

`claude agents --json` reports interactive sessions (any `claude` you have open in
a terminal) as well as background ones, so panes appear for sessions this app did
not start — which is exactly what you want when an agent spawns its own.
"""
from __future__ import annotations

import json
import subprocess
import time
from pathlib import Path

from .paths import JOBS, LAUNCH_CWD
from .voice_prompt import voice_system

TIMEOUT = 10


def _run(args: list[str], cwd: str | Path = LAUNCH_CWD, timeout: int = TIMEOUT):
    """Run a claude CLI command. Never raises; failures surface as (code, err)."""
    try:
        p = subprocess.run(args, cwd=str(cwd), capture_output=True, text=True,
                           timeout=timeout)
        return p.returncode, p.stdout, p.stderr
    except subprocess.TimeoutExpired:
        return 124, "", f"timed out after {timeout}s: {' '.join(args)}"
    except FileNotFoundError:
        return 127, "", "`claude` is not on PATH"


def _job_state(short_id: str) -> dict:
    """Extra per-session detail the daemon writes but the list command omits.

    state.json carries `detail` ("(idle — send a prompt to start)") and `needs`
    ("send a prompt to start"), which is what makes a blocked pane able to say
    what it is actually blocked ON rather than just showing an amber dot.
    """
    try:
        return json.loads((JOBS / short_id / "state.json").read_text())
    except (OSError, ValueError):
        return {}


def roster(all_sessions: bool = False, cwd: str | Path | None = None) -> list[dict]:
    """Every live session the daemon knows about, normalized for the UI.

    Normalizing matters: interactive sessions come back without `state` (the
    daemon isn't driving them), while background ones carry the full lifecycle.
    The UI should not have to special-case that, so an interactive session
    reports state "attached" rather than an empty cell.
    """
    args = ["claude", "agents", "--json"]
    if all_sessions:
        args.append("--all")
    if cwd:
        args += ["--cwd", str(cwd)]
    code, out, err = _run(args)
    if code != 0:
        return []
    try:
        raw = json.loads(out or "[]")
    except ValueError:
        return []

    sessions = []
    for s in raw:
        sid = s.get("sessionId") or ""
        short = s.get("id") or sid[:8]
        extra = _job_state(short) if short else {}
        sessions.append({
            "id": short,
            "sessionId": sid,
            "name": s.get("name") or short or "session",
            "cwd": s.get("cwd") or "",
            "kind": s.get("kind") or "background",
            "state": s.get("state") or extra.get("state")
                     or ("attached" if s.get("kind") == "interactive" else "idle"),
            "waitingFor": s.get("waitingFor") or extra.get("needs") or "",
            "detail": extra.get("detail") or s.get("status") or "",
            "pid": s.get("pid"),
            "startedAt": s.get("startedAt"),
        })
    sessions.sort(key=lambda s: s.get("startedAt") or 0)
    return sessions


def dispatch(prompt: str, cwd: str | Path = LAUNCH_CWD, name: str = "",
             model: str = "", permission_mode: str = "") -> dict:
    """Start a background session. Returns {"ok": bool, "error": str}.

    Deliberately does NOT wait for the session to appear in the roster — the
    roster poll will pick it up within a couple of seconds and the pane opens
    itself. Blocking here would just make the button feel broken.
    """
    args = ["claude", "--bg"]
    if name:
        args += ["--name", name]
    if model:
        args += ["--model", model]
    if permission_mode:
        args += ["--permission-mode", permission_mode]
    args.append(prompt)
    code, out, err = _run(args, cwd=cwd, timeout=30)
    return {"ok": code == 0, "error": (err or out).strip() if code else ""}


def stop(session_id: str) -> dict:
    code, out, err = _run(["claude", "stop", session_id])
    return {"ok": code == 0, "error": (err or out).strip() if code else ""}


def remove(session_id: str) -> dict:
    code, out, err = _run(["claude", "rm", session_id])
    return {"ok": code == 0, "error": (err or out).strip() if code else ""}


# ---- commands the dashboard runs inside its own PTYs ---------------------

def voice_pane_cmd(session_id: str, model: str = "sonnet",
                   permission_mode: str = "bypassPermissions") -> list[str]:
    """The session you talk to.

    Two things here are load-bearing:

    --session-id  we generate the UUID rather than discovering it, so the
                  transcript path is known before the process has even started
                  and transcript.py can begin tailing immediately. Discovering it
                  afterwards means racing the first turn.

    --append-system-prompt  the voice prompt, built fresh here rather than
                  imported as a constant: it is personalised from the vault,
                  and the vault can gain a name between one pane and the next.
                  Its absence in the old tmux path is why spoken replies read
                  like terminal output. See voice_prompt.py.
    """
    cmd = ["claude", "--session-id", session_id, "--model", model,
           "--append-system-prompt", voice_system()]
    if permission_mode:
        cmd += ["--permission-mode", permission_mode]
    return cmd


def attach_cmd(session_id: str) -> list[str]:
    """Open an existing supervised session in one of our PTYs."""
    return ["claude", "attach", session_id]


def resume_cmd(session_id: str, model: str = "") -> list[str]:
    """Reopen a past conversation, with its context intact.

    Deliberately not --fork-session: picking a session out of the menu means you
    want to carry on with that one, and forking would quietly leave the thread
    you were looking for untouched somewhere else.
    """
    cmd = ["claude", "--resume", session_id]
    if model:
        cmd += ["--model", model]
    return cmd


def plain_pane_cmd(model: str = "", session_id: str = "",
                   agent: str = "claude") -> list[str]:
    """A normal coding agent, for panes you open to work in by hand.

    No voice prompt: these should behave exactly like the agent does anywhere
    else, because that is what you are expecting when you open one.

    `agent` is whichever of claude / codex / gemini the header picker is on.
    Only Claude Code gets the extra flags: `--session-id` exists so we can tail
    the transcript we already know the path of, and `--model` takes Anthropic's
    names. Codex and Gemini name their models differently and keep their own
    session stores, so passing either across would be a guess that fails at
    launch. They are started bare, which is exactly what running them by hand
    does.
    """
    if agent == "codex":
        return ["codex"]
    if agent == "gemini":
        return ["gemini"]
    cmd = ["claude"]
    if session_id:
        cmd += ["--session-id", session_id]
    if model:
        cmd += ["--model", model]
    return cmd


def daemon_ok() -> bool:
    code, _, _ = _run(["claude", "daemon", "status"], timeout=5)
    return code == 0


def wait_for_transcript(path: Path, timeout: float = 20.0) -> bool:
    """Block until a session's transcript file exists.

    Claude Code creates it on the first turn, not at launch, so anything that
    reads a brand-new session has to tolerate the gap.
    """
    deadline = time.time() + timeout
    while time.time() < deadline:
        if path.exists():
            return True
        time.sleep(0.2)
    return False


def folder_is_trusted(cwd: str | Path) -> bool | None:
    """Has Claude Code been told this folder is safe?

    The first time `claude` runs somewhere new it asks "do you trust the files
    in this folder?", and until that is answered the session ignores every
    keystroke. That is indistinguishable, from the outside, from a terminal
    that does not work — it is the single most reported bug in this dashboard,
    and every report was this prompt.

    So it is worth knowing in advance rather than watching someone discover it.
    The answer lives in ~/.claude.json under the absolute path.

    Returns None when it cannot be determined — no config file yet, or a shape
    we do not recognise. None is not False: claiming a folder is untrusted on
    a machine we simply cannot read would put a warning in front of people who
    have no problem.
    """
    cfg = Path.home() / ".claude.json"
    try:
        data = json.loads(cfg.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    projects = data.get("projects")
    if not isinstance(projects, dict):
        return None
    entry = projects.get(str(Path(cwd).resolve()))
    if not isinstance(entry, dict):
        return False                 # never opened there: it will ask
    return bool(entry.get("hasTrustDialogAccepted"))
