"""
voice_loop — mic in, speech out, wrapped around a real terminal.

    hold space -> faster-whisper -> the voice pane's PTY
                                          |
                   transcript.jsonl <------+
                            |
          narrate/speakable -> Kokoro -> speakers

Reuses what was sound in the old stack: stt.py for whisper and tts.py for
Kokoro and sentence streaming. What changed is everything on the far side of
the microphone — where the words go, and where the reply comes from — and,
since the hands-free mode was dropped, everything on this side too.

Three properties the old loop did not have:

  Delivery is confirmed, not assumed. The retired tmux session typed the text
  with `tmux send-keys`, slept 150ms, and sent Enter, hoping the TUI's
  paste-detect debounce had closed. When it hadn't, the text sat in the input
  box unsent and nothing said so. Here the transcript is watched for the
  matching `user` entry (measured: it lands ~0.4s after a real submit) and
  Enter is retried, then reported as an error if it still didn't take.

  Speech comes from typed events, not from the screen. See narrate.py.

  It cannot interrupt itself. Recording only happens while you hold a key, and
  pressing it silences the speaker first — so the clone never hears its own
  reply. See _mic_run.
"""
from __future__ import annotations

import sys
import threading
import time

from .narrate import Narrator, describe
from .paths import MODELS, VOICE_CONFIG
from .speakable import to_speech
from .transcript import TranscriptWatcher

SEND_CONFIRM_S = 1.5          # measured: a real submit lands in ~0.4s
LEVEL_HZ = 12                 # orb updates per second
SPEECH_TAIL_S = 0.45          # silence before a reply counts as finished
PTT_MIN_SAMPLES = 8000        # ~0.5s held; shorter is a stray keypress

# HOW MUCH AUDIO THE DRIVER HANDS OVER AT A TIME.
#
# This is not the 512 of stt.py's frame law. That law is about what Silero is
# fed, and the push-to-talk path does not use Silero at all -- it concatenates
# what you said and gives the whole thing to whisper.
#
# What 512 samples DOES mean here is a 32ms deadline for a Python function to
# run, on a machine that is also running four terminals, a websocket server,
# and an ONNX model. When it misses, the driver drops the audio before anything
# in this file can see it, and the end of your sentence is simply gone. That is
# not a theory: measured on this machine, capturing for three seconds while
# eight compute-bound threads ran, a 512-sample block lost 58% of the audio and
# a 4096-sample block lost none.
MIC_BLOCK = 4096              # ~256ms per callback, an 8x wider deadline

# ...and the cost of a wide block is that when you let go of the key, the block
# holding the last quarter-second of your sentence is still inside the driver.
# So the recording is not closed at the keystroke; it is closed once that block
# lands. This is the ceiling on how long to wait for it.
PTT_TAIL_S = 0.45

# What the orb can be, most urgent first. This order IS the state machine —
# see _derive_state.
STATES = ("idle", "hearing", "thinking", "speaking", "working", "blocked", "listening")


class _Remote:
    """One remote turn: where its answer goes, and what it has said so far."""

    def __init__(self, sink, speak: bool, progress=None, stream=None):
        self.sink = sink                  # callable(text) -> None, the answer
        self.speak = speak                # also say it out loud on the Mac?
        self.progress = progress          # callable(phrase) | None, while working
        self.stream = stream              # callable(text) | None, each part as it lands
        self.parts: list[str] = []

    def deliver(self, fallback: str = "") -> None:
        text = "\n\n".join(p for p in self.parts if p.strip()) or fallback
        try:
            self.sink(text)
        except Exception as e:                              # noqa: BLE001
            print(f"[remote] could not deliver a reply: {e}", file=sys.stderr)


class VoiceLoop:
    """Owns the microphone and the speaker for the whole dashboard.

    ONE PLACE DECIDES THE STATE.

    This used to be four places. The transcript callback set "working", the
    tick loop set "speaking", the push-to-talk handler set "hearing", and the
    utterance thread set "working" again — four threads writing one variable,
    last writer wins. The visible symptoms were all the same bug:

      * narrating progress made the orb flip to "speaking", which wiped the
        very caption the narration had just written ("running the tests"
        replaced by the word "speaking" ~80ms later)
      * "reading jarvis" stayed on screen while it had gone back to listening
      * transcribing your speech was reported as the session "working", when
        no turn had started yet
      * "blocked" existed in the design and could never fire at all

    Now nothing assigns a state. Facts are recorded — are you holding the key,
    is whisper decoding, is a REPLY playing, is a turn running, is a session
    stuck — and _derive_state reads them in one ordered pass.
    """

    def __init__(self, dash, whisper: str = "small"):
        self.dash = dash
        self.whisper_size = whisper
        self.speaker = None
        self.stt = None
        self._mic_thread = None
        self._tick_thread = None
        self._stop = threading.Event()

        # transcript -> narration/speech
        # Keyed by pane, because more than one session can be mid-turn: the
        # one you have just pointed the voice at, and the one you pointed it
        # at a moment ago that is still finishing its answer.
        self._spoken: dict[str, set[str]] = {}
        self._user_seen = 0                 # confirms a submit actually landed
        self._state = "idle"
        # Read once at startup so a muted session stays muted across restarts.
        try:
            from .settings import load_voice
            self.muted = bool(load_voice().get("muted"))
        except Exception:                                   # noqa: BLE001
            self.muted = False
        self._state_lock = threading.Lock()

        # ---- the facts the state is derived from ------------------------
        self._alive = False                 # the loop actually started
        self._turns: set[str] = set()       # panes with a turn running right now
        self._transcribing = False          # whisper is decoding what you said
        self._blocked: list[str] = []       # sessions waiting on you, by name
        # Which kind of audio is playing. Narration is part of working and must
        # not steal the orb; only the answer is "speaking".
        self._speech_kind = ""              # "" | "reply" | "progress"
        self._last_busy = 0.0
        self._watching = ""                 # pane the voice is pointed at
        # Panes still being tailed after the voice moved off them, because they
        # were mid-turn when it did. Retired the moment their turn ends.
        self._lingering: set[str] = set()

        # Push-to-talk, and the only way in. Held from the UI: the space bar,
        # the mic button, or the orb.
        self.ptt_held = False
        self._ptt_buf: list = []
        self._ptt_release = 0.0        # when the key came up; 0 when not recording
        self._pumping = False          # something is draining the microphone
        self._dropped = 0              # capture the driver threw away, if it says so
        self._dropped_at_press = 0

        self.narrator = Narrator(say=self._speak_progress, status=self._status,
                                 allow=self._room_is_free)
        self.watcher = TranscriptWatcher(self._on_event)

        # Turns that came from somewhere other than this room (Telegram, the
        # phone app). Keyed by pane: the reply is collected from the same typed
        # transcript the voice reads, and handed back when the turn ends.
        self._remote: dict[str, _Remote] = {}
        # Told when a session starts waiting on you (the phone bridge listens).
        self.on_blocked: list = []
        self._remote_lock = threading.Lock()

        # What it feels, from what is happening. See mood.py: every colour on
        # the orb is caused by a real event, so it can be trusted.
        from .mood import Mood
        self.mood = Mood(emit=lambda snap: self.dash.emit("feel", snap))
        try:
            from .settings import load_voice
            self.mood.enabled = load_voice().get("feelings", True) is not False
        except Exception:                                   # noqa: BLE001
            pass

    # ---- lifecycle ------------------------------------------------------

    def start(self) -> None:
        from .tts import KokoroTTS, SayTTS, Speaker
        try:
            # Both paths are passed in rather than defaulted to. tts.py re-reads
            # the config file per sentence to make a speed change take effect
            # mid-reply, and that only works if it is watching the same file the
            # settings panel writes — so there is one path, named once, here.
            self.speaker = Speaker(KokoroTTS(models_dir=MODELS,
                                             config_path=VOICE_CONFIG))
        except Exception as e:                          # noqa: BLE001
            print(f"[voice] kokoro unavailable ({e}); using the system voice",
                  file=sys.stderr)
            self.speaker = Speaker(SayTTS())

        self.attach_voice_pane()
        self.watcher.start()

        self._alive = True
        self._tick_thread = threading.Thread(target=self._tick_run, daemon=True)
        self._tick_thread.start()
        self._mic_thread = threading.Thread(target=self._mic_run, daemon=True)
        self._mic_thread.start()
        self._apply_state()

    def attach_target_pane(self) -> None:
        """Listen to whichever pane the voice is pointed at.

        Called at startup, whenever the pane set changes, and whenever you
        press "talk here" on a pane — but NOT when you merely click a terminal.
        That was the old behaviour and it is the bug this fixes: selecting a
        session is something you do constantly and mid-sentence, and it used to
        unwatch the session you were actually in conversation with. The reply
        you were waiting for arrived in a transcript nobody was reading, the
        turn was marked finished, and the orb went back to resting. It looked
        exactly like the voice had stopped working, which is what it was.

        A session that is MID-TURN when the voice leaves keeps being tailed
        until that turn ends. You asked it a question; you get the answer, even
        if you have already moved on. That is the whole reason the watcher is
        keyed by pane instead of holding one file.

        Re-attaching on a pane-set change is separate and still needed: closing
        the voice pane and opening a new one used to leave the watcher tailing
        a transcript nothing was writing to. The dashboard looked fine and had
        simply gone deaf.
        """
        pane = self.dash.panes.target_pane()
        if pane is None or pane.id == self._watching:
            return
        path = self.dash.panes.transcript_for(pane)
        if path is None:
            return

        previous = self._watching
        if previous:
            if previous in self._turns:
                self._lingering.add(previous)   # let it finish answering
            else:
                self._retire(previous)
        # From the start for a session we just created, whose whole history IS
        # this conversation; from the end for one that was already running,
        # because replaying an hour of somebody else's turns would narrate the
        # entire backlog at you the moment you pointed the voice at it.
        fresh = pane.kind == "voice" or not previous
        self.watcher.watch(pane.id, path, from_start=fresh)
        self._watching = pane.id
        self._spoken.pop(pane.id, None)
        self.dash.emit("target", {"paneId": pane.id, "title": pane.title,
                                  "cwd": pane.cwd, "kind": pane.kind})
        self._apply_state()

    def _retire(self, pane_id: str) -> None:
        """Stop tailing a pane and forget what it said."""
        self.watcher.unwatch(pane_id)
        self._lingering.discard(pane_id)
        self._turns.discard(pane_id)
        self._spoken.pop(pane_id, None)

    # Kept because the server and older callers use the previous name, and a
    # silent no-op here would mean the watcher never attaches at all.
    attach_voice_pane = attach_target_pane

    def stop(self) -> None:
        self._alive = False
        self._stop.set()
        self.watcher.stop()
        if self.speaker:
            self.speaker.close()

    def set_blocked(self, names: list[str]) -> None:
        """Sessions that are waiting on you, pushed in by the roster poll.

        This is the only source for the "needs you" state. The orb showed it in
        its palette from the first version and nothing ever set it, because the
        fact lives in the daemon's roster and the voice loop had no path to it.
        """
        names = list(names or [])
        self.mood.set_blocked(bool(names))
        if names == self._blocked:
            return
        fresh = [n for n in names if n not in self._blocked]
        self._blocked = names
        self._apply_state()
        # Say it once, when it starts — a session that needs you is the one
        # thing worth interrupting for, and repeating it every poll is not.
        if fresh:
            for cb in list(self.on_blocked):
                try:
                    cb(fresh)
                except Exception:                           # noqa: BLE001
                    pass
        if fresh and not self._turns and not self.ptt_held:
            who = fresh[0]
            self._speak_progress(f"{who} needs you." if len(fresh) == 1
                                 else f"{len(fresh)} sessions need you.")

    def set_ptt(self, down: bool) -> None:
        """Space pressed or released.

        Pressing also silences whatever it is currently saying — the same
        gesture that starts your turn ends its turn, which is what makes
        interrupting feel immediate rather than like waiting for a gap.
        """
        down = bool(down)
        if down == self.ptt_held:
            return
        self.ptt_held = down
        if down:
            self.mood.hearing()
            self._ptt_buf = []
            self._dropped_at_press = self._dropped
            if self.speaker is not None:
                self.speaker.stop()
            self._speech_kind = ""
            if self._turns:
                self._interrupt_turns()
            self._apply_state()
        else:
            self.dash.emit("level", 0.0)
            # NOT closed here. The last block of what you said is still inside
            # the audio driver at this instant; _pump closes the recording when
            # it arrives. See MIC_BLOCK.
            self._ptt_release = time.monotonic()
            if self._pumping:
                self._apply_state()     # _pump closes it when the tail lands
            else:
                # Nothing is draining the microphone -- no audio device, or a
                # test. Close it here, so a release always finishes a turn
                # rather than leaving one open forever.
                self._close_utterance()

    def _close_utterance(self) -> None:
        """End the recording and send it to whisper.

        Called from the microphone thread once the tail has landed, so that
        everything captured while the key was down is in the buffer -- which is
        the whole point, and was the bug.
        """
        self._ptt_release = 0.0
        buf, self._ptt_buf = self._ptt_buf, []
        if self._dropped > self._dropped_at_press:
            # Say so. This failure used to be completely silent: the driver
            # threw audio away, whisper transcribed what was left, and a
            # half-sentence went to the session looking like something you had
            # chosen to say.
            self._dropped_at_press = self._dropped
            self.dash.hub.send_threadsafe(
                {"t": "error",
                 "msg": "The machine was too busy to record all of that — "
                        "some audio was dropped."})
        if sum(len(f) for f in buf) < PTT_MIN_SAMPLES:
            self._apply_state()
            return
        import numpy as np
        threading.Thread(target=self._handle_utterance,
                         args=(np.concatenate(buf),), daemon=True).start()

    # ---- the state machine ----------------------------------------------

    def _reply_playing(self) -> bool:
        """Is the ANSWER currently coming out of the speakers?

        Narration deliberately does not count. It is spoken while the session
        works, so treating it as "speaking" made the orb change colour every
        few seconds during a long turn and overwrote the progress caption with
        the word that caption had itself caused.
        """
        sp = self.speaker
        if sp is None or self._speech_kind != "reply":
            return False
        if sp.busy:
            self._last_busy = time.time()
            return True
        # `busy` blinks false between two sentences while the next one is still
        # being synthesized. Without a tail the orb twitches out of speaking
        # mid-reply.
        return time.time() - self._last_busy < SPEECH_TAIL_S

    def _derive_state(self) -> str:
        """The one ordered pass. Most urgent first; the first true wins."""
        if not self._alive:
            return "idle"
        if self.ptt_held:
            return "hearing"        # you are talking. Nothing outranks that.
        if self._transcribing:
            return "thinking"       # decoding your words; no turn has started
        if self._reply_playing():
            return "speaking"       # the answer, not the narration
        if self._turns:
            return "working"        # narration belongs here
        if self._blocked:
            return "blocked"        # nothing running, something waiting on you
        return "listening"          # at rest and ready; the orb breathes

    def _apply_state(self) -> None:
        """Recompute and broadcast. Safe to call from any thread, often."""
        s = self._derive_state()
        with self._state_lock:
            if s == self._state:
                return
            self._state = s
        self.dash.emit("state", s)

    @property
    def state(self) -> str:
        """The current state, for a client that just connected. Without this a
        reload left the orb showing "idle" until something happened to change
        it — which, at rest, is never."""
        return self._state

    def _status(self, text: str) -> None:
        """What it is doing right now — replaces the orb's state label.

        Deliberately NOT the same channel as the answer. Progress ("reading
        jarvis", "still running the tests") and the reply are different kinds of
        statement, and putting them in one element means the answer you are
        reading gets overwritten by a status line a moment later.
        """
        self.dash.emit("status", text)

    # ---- muted ----------------------------------------------------------

    def set_muted(self, muted: bool) -> None:
        """Stop it talking, without stopping it working.

        A quiet session is a real mode: you are next to someone, or on a call,
        and you still want to type at four agents and watch them go. Muting
        silences OUTPUT only -- narration and replies -- and leaves the
        microphone, the transcript and every session exactly as they were, so
        the conversation is still there to read.
        """
        self.muted = bool(muted)
        if self.muted and self.speaker is not None:
            self.speaker.stop()          # including whatever is mid-sentence
        self._apply_state()

    def _enqueue(self, text: str, kind: str) -> None:
        """Hand one line to the speaker, recording WHAT it is.

        `kind` is load-bearing, not bookkeeping: it is what keeps narration out
        of the "speaking" state. See _reply_playing.

        `resume()` is not optional here either. Speaker.stop() (barge-in, and
        every new submission) latches a stop_flag that makes its worker DROP
        every queued sentence until something clears it — so without this, the
        voice goes permanently silent after the first thing you say to it. The
        flag is cleared at the point where new speech is genuinely wanted
        rather than in stop(), so a barge-in still kills the audio in flight.
        """
        if self.speaker is None or self.muted or self.on_phone_call():
            return
        # A reply outranks narration: if the answer starts while a progress
        # line is queued, the audio that matters is the answer.
        if kind == "reply" or self._speech_kind != "reply":
            self._speech_kind = kind
        self._last_busy = time.time()
        self.speaker.resume()
        self.speaker.speak(text)

    def on_phone_call(self) -> bool:
        """A call is live (call.py): the Mac says nothing at all.

        Not only politeness. If you are near the laptop, its speakers reach the
        phone's microphone, and the phone's echo cancellation only removes what
        the PHONE played. So anything the Mac says is heard by the call as you
        talking: it cut the call's own answers off and sent fragments of the
        Mac's narration back in as new requests."""
        c = getattr(self.dash, "call", None)
        return c is not None and not getattr(c, "closed", True)

    def _room_is_free(self) -> bool:
        """May narration speak right now?

        Four times when the answer is no, and all four produced complaints:

          you are talking          holding the key is the one thing that
                                   outranks everything; speaking over it also
                                   un-latches the stop flag mid-recording
          whisper is decoding      your sentence has landed and the reply is
                                   about to; a progress line here lands in the
                                   half-second gap and sounds like an answer
          the reply is playing     progress talking over the answer you asked
                                   for is the worst trade this loop can make
          a session needs you      "still working" while something waits on you
                                   is not annoying, it is false. set_blocked
                                   has already said the thing that matters

        The narrator asks rather than being told, because these are facts about
        right now and it is called twelve times a second.
        """
        if self.ptt_held or self._transcribing:
            return False
        if self._blocked:
            return False
        return not self._reply_playing()

    def _speak_progress(self, text: str) -> None:
        """Narration out loud. Never the answer, and never the caption either.

        The Narrator has already written this phrase to the caption through its
        own (deduped) status channel before deciding whether it is also worth
        saying out loud. Emitting it again here sent every spoken line twice —
        visible on the wire as two identical "reading speakable" frames.
        """
        if not text:
            return
        self._enqueue(text, "progress")

    def say_sample(self, text: str = "") -> None:
        """One sentence, out loud, so a setting can be HEARD.

        A speaking-rate slider is unusable without this. 1.06× against 1.24×
        means nothing on a screen; the difference is entirely in the ear, and
        without a way to hear it the control is a number you nudge and hope
        about.

        Deliberately not routed through `_say`: this is not the clone
        answering you, so it does not belong in the conversation transcript.
        It is spoken as a reply rather than as narration, so the orb goes to
        `speaking` and pressing space stops it like anything else.
        """
        self._enqueue(text or "This is how I sound at this speed.", "reply")
        self._apply_state()

    def _say(self, text: str) -> None:
        """The reply — spoken, and shown in the one serif line on the page."""
        if not text:
            return
        self._enqueue(text, "reply")
        self.dash.emit("clone", text)
        self._apply_state()

    # ---- inbound from the transcript ------------------------------------

    def _on_event(self, pane_id: str, ev: dict) -> None:
        kind = ev.get("kind")
        if not ev.get("sidechain"):
            self.mood.on_event(ev)
        if kind == "user":
            self._user_seen += 1
            self._spoken[pane_id] = set()
            self._turns.add(pane_id)
            self.dash.emit("you", ev.get("text", ""))
            self._apply_state()
            self.narrator.feed(ev)
            return

        if kind == "assistant":
            # The answer, made sayable. Interim text ("on it, checking the mic
            # loop") is spoken as it arrives rather than held to the end —
            # that IS the conversation, and holding it makes a 17-second turn
            # feel like a hang.
            # An agent writing prose is working, and the narrator has to know:
            # without this it counted a streaming answer as dead air and could
            # interrupt the reply to report that nothing was happening.
            self.narrator.note_activity()
            remote = self._remote_for(pane_id) if not ev.get("sidechain") else None
            if remote is not None:
                # The phone gets the written answer, markdown and all: it is
                # read there, not heard, so nothing needs making sayable.
                remote.parts.append(ev.get("text", "").strip())
                if remote.stream is not None:
                    # A call speaks each part the moment it lands, the way
                    # the room does, instead of waiting for the whole turn.
                    try:
                        remote.stream(ev.get("text", ""))
                    except Exception:                       # noqa: BLE001
                        pass
                if not remote.speak:
                    self.dash.emit("clone", to_speech(ev.get("text", "")))
                    return
            said = to_speech(ev.get("text", ""))
            seen = self._spoken.setdefault(pane_id, set())
            if said and said not in seen:
                seen.add(said)
                self._say(said)
            return

        if kind == "turn_end":
            if not ev.get("sidechain"):
                with self._remote_lock:
                    remote = self._remote.pop(pane_id, None)
                if remote is not None:
                    remote.deliver("Done.")
            self.narrator.feed(ev)
            self._turns.discard(pane_id)
            # A session we only kept listening to so it could finish its answer
            # has now finished it. Let it go.
            if pane_id in self._lingering:
                self._retire(pane_id)
            # A turn ending is the moment the limit percentages actually moved,
            # so it is the moment worth re-reading them. The 5-minute timer is
            # only a backstop now.
            usage = getattr(self.dash, "usage", None)
            if usage is not None:
                usage.on_turn_end()
            # The turn being over in the transcript does NOT mean the reply has
            # finished coming out of the speakers, and it must not cut the orb
            # off mid-sentence. _derive_state handles that: _reply_playing is
            # still true, so "speaking" outranks the turn having ended.
            self._apply_state()
            return

        if kind == "tool" and not ev.get("sidechain"):
            remote = self._remote_for(pane_id)
            if remote is not None and remote.progress is not None:
                try:
                    remote.progress(describe(ev))
                except Exception:                           # noqa: BLE001
                    pass
        self.narrator.feed(ev)

    def _reap_dead_turns(self) -> None:
        """A turn whose session is gone never sends turn_end.

        Nothing closed that loop, so a session that exited mid-turn — crashed,
        quit, killed — left the orb on "working" and the narrator reassuring
        you about a process that no longer exists. There is no event for this;
        the only way to know is to look.
        """
        if not self._turns:
            return
        panes = getattr(self.dash, "panes", None)
        if panes is None:
            return
        for pane_id in list(self._turns):
            pane = panes.get(pane_id)
            if pane is None or not pane.pty.alive:
                self._turns.discard(pane_id)
                with self._remote_lock:
                    remote = self._remote.pop(pane_id, None)
                if remote is not None:
                    remote.deliver("The session ended before it answered.")
                if pane_id in self._lingering:
                    self._retire(pane_id)
        if not self._turns:
            self.narrator.end_turn()

    def _tick_run(self) -> None:
        """The heartbeat: re-derive the state, and draw the orb off real audio.

        It no longer decides anything. Every transition this used to own now
        falls out of _derive_state; this just calls it often enough that a
        change in the underlying facts (audio draining, a tail expiring) shows
        up within one frame.
        """
        import numpy as np
        was_quiet = True
        while not self._stop.is_set():
            self._reap_dead_turns()
            self.narrator.tick()
            self._apply_state()
            self.mood.tick()                   # decay; urgency is held while blocked

            sp = self.speaker
            busy = sp is not None and sp.busy
            if busy:
                was_quiet = False
                # Deform the orb off what is actually coming out of the speaker,
                # not off a timer. PlaybackRef already holds the played samples
                # for echo cancellation; this is the same data, read for display.
                try:
                    now = time.time()
                    win = sp.ref.window(now - 0.08, now)
                    if win is not None and len(win):
                        rms = float(np.sqrt((win.astype(np.float64) ** 2).mean()))
                        self.dash.emit("level", min(1.0, rms * 7.0))
                except Exception:                       # noqa: BLE001
                    pass
            elif not was_quiet and time.time() - self._last_busy >= SPEECH_TAIL_S:
                # Only past the tail — `busy` blinks false between two sentences
                # while the next is synthesizing, and clearing _speech_kind on
                # that blink would defeat the very hysteresis it exists for.
                # One zero on the falling edge, not 12 a second forever.
                was_quiet = True
                self._speech_kind = ""
                self.dash.emit("level", 0.0)
            time.sleep(1.0 / LEVEL_HZ)

    # ---- submitting -----------------------------------------------------

    def submit_remote(self, text: str, sink, speak_on_mac: bool = False,
                      progress=None, stream=None) -> bool:
        """A turn from your phone: same session, same memory, answer sent back.

        `sink(text)` receives the whole answer once the turn ends (or a short
        explanation if it never became a turn). Unless `speak_on_mac`, the Mac
        stays quiet for it, because the person asking is not in the room.
        """
        pane = self.dash.panes.target_pane()
        if pane is None or not pane.pty.alive:
            sink("Your clone's session is not running on the Mac. Open Mem there, "
                 "or send /new to start one.")
            return False
        with self._remote_lock:
            old = self._remote.pop(pane.id, None)
            self._remote[pane.id] = _Remote(sink, speak_on_mac, progress, stream)
        if old is not None:
            old.deliver("(interrupted by your next message)")
        if self.submit_text(text):
            return True
        with self._remote_lock:
            r = self._remote.pop(pane.id, None)
        if r is not None:
            r.deliver("That did not reach the session. It may be waiting on a "
                      "question: send /screen to see it, or /keys to answer.")
        return False

    def _remote_for(self, pane_id: str):
        with self._remote_lock:
            return self._remote.get(pane_id)

    def submit_text(self, text: str) -> bool:
        """Send one utterance to the pane you are in, and verify it landed.

        Returns False (and surfaces an error) if the text went into the input
        box but never became a turn — the failure mode the old loop had no way
        to notice.
        """
        text = (text or "").strip()
        if not text:
            return False

        # An interview in progress owns your voice. Both halves of the input
        # come through here — spoken and typed — so this is the one place it
        # has to be intercepted, and answers cannot leak into a coding session
        # by arriving down the other path.
        iv = getattr(self.dash, "interview", None)
        if iv is not None and iv.take_utterance(text):
            return True

        pane = self.dash.panes.target_pane()
        if pane is None or not pane.pty.alive:
            self.dash.hub.send_threadsafe(
                {"t": "error", "msg": "The voice session isn't running. Open a new one."})
            return False

        if self.speaker is not None:
            self.speaker.stop()          # a new instruction supersedes the old answer
        self._speech_kind = ""
        before = self._user_seen
        # Clear whatever is already in the input box before typing.
        #
        # The box is not reliably empty: Claude Code pre-fills a predicted next
        # prompt after a turn, and you may have half-typed a thought yourself.
        # Writing into that APPENDS, and the result is submitted as one string —
        # measured, with the line left dirty:
        #     submitted: 'GARBAGE_PREFILLreply with exactly: CLEAN'
        # Ctrl-U (kill line) empties it first; with it, the same test submits
        # exactly what was said.
        pane.pty.write(b"\x15")
        time.sleep(0.05)
        pane.pty.write(text.encode())
        # Let the TUI's paste-vs-type debounce close before Enter arrives, so it
        # reads as a submit and not as a literal newline in the box.
        time.sleep(0.12)
        pane.pty.write(b"\r")

        if self._wait_for_turn(before):
            return True
        pane.pty.write(b"\r")            # one retry: a missed debounce window
        if self._wait_for_turn(before):
            return True

        self.dash.hub.send_threadsafe({
            "t": "error",
            "msg": "That didn't send — the session may be waiting on a prompt. "
                   "Check the pane."})
        self._apply_state()
        return False

    def _wait_for_turn(self, before: int) -> bool:
        deadline = time.time() + SEND_CONFIRM_S
        while time.time() < deadline:
            if self._user_seen > before:
                return True
            time.sleep(0.05)
        return False

    # ---- the microphone -------------------------------------------------

    def _mic_run(self) -> None:
        """Capture audio only while the key is held.

        There used to be a hands-free path here as well: voice-activity
        detection deciding where your turn ended, with acoustic echo
        cancellation to stop the clone hearing its own reply and interrupting
        itself. It was never reliable, and it could not be — text-to-speech
        output *is* speech, so a detector is right to flag it, and separating
        the two comes down to correlating the microphone against what was
        played, through whatever the room does to it.

        Push-to-talk deletes the problem instead of managing it. Pressing
        silences the speaker before a single frame is captured, so there is no
        echo to cancel, no endpoint to guess, and no way to mishear a
        conversation you were having with someone else. That is why this loop
        is twenty lines and the old one was ninety.
        """
        import sounddevice as sd
        import queue as _q
        from .stt import SAMPLE_RATE, Transcriber

        self.stt = Transcriber(self.whisper_size)
        audio_q: _q.Queue = _q.Queue()

        def cb(indata, frames, t, status):
            # Nothing but a copy and a put. Everything else -- the level, the
            # buffering, the decision to stop -- happens in _pump, because this
            # function runs on the audio driver's thread and anything slow here
            # is audio nobody ever gets.
            if status and status.input_overflow:
                self._dropped += 1
            audio_q.put(indata[:, 0].copy())

        with sd.InputStream(samplerate=SAMPLE_RATE, channels=1, dtype="float32",
                            blocksize=MIC_BLOCK, callback=cb):
            self._pump(audio_q)

    def _pump(self, audio_q) -> None:
        """Move captured audio into the recording, and decide when it ends.

        Separate from _mic_run so the part that loses the end of your sentence
        can be tested with a fake queue and no microphone.
        """
        import numpy as np
        import queue as _q

        since_release = 0
        self._pumping = True
        try:
            while not self._stop.is_set():
                try:
                    frame = audio_q.get(timeout=0.05)
                except _q.Empty:
                    frame = None

                if frame is not None and (self.ptt_held or self._ptt_release):
                    # A block still filling inside the driver when you let go
                    # holds the end of your sentence. It is kept, not dropped.
                    self._ptt_buf.append(frame)
                    if self.ptt_held:
                        rms = float(np.sqrt((frame ** 2).mean()))
                        self.dash.emit("level", min(1.0, rms * 9.0))

                if not self._ptt_release:
                    since_release = 0
                    continue
                if frame is not None:
                    since_release += 1
                # Closed as soon as a block has arrived since the key came up
                # and nothing else is waiting -- usually well inside the
                # ceiling, which is only there for a microphone that has
                # stopped delivering at all.
                if (since_release and audio_q.empty()) or \
                        time.monotonic() - self._ptt_release >= PTT_TAIL_S:
                    since_release = 0
                    self._close_utterance()
        finally:
            self._pumping = False

    def _interrupt_turns(self) -> None:
        """Barge-in: stop whatever is mid-turn, the way Escape does by hand.

        Every running turn, not just the one the voice currently points at. If
        you asked A something, moved the voice to B, and then pressed space,
        you meant "stop" — and A is the one still talking.

        On the push-to-talk hot path, so it must not raise: an exception here
        would leave ptt_held already true with the state never recomputed —
        recording, with an orb that never said it was listening.
        """
        try:
            for pane_id in list(self._turns):
                pane = self.dash.panes.get(pane_id)
                if pane is not None and pane.pty.alive:
                    pane.pty.write(b"\x1b")
        except Exception:                               # noqa: BLE001
            pass

    def _handle_utterance(self, utt) -> None:
        """Decode what you said, then send it.

        `thinking`, not `working`: nothing is working yet. Whisper is decoding
        audio and no turn exists. Reporting that as the session working meant
        the orb claimed progress on a turn that had not been submitted, and if
        the decode came back empty it had claimed it for nothing.
        """
        if self.stt is None:
            return
        self._transcribing = True
        self._apply_state()
        try:
            text, _ = self.stt.transcribe(utt)
        except Exception as e:                          # noqa: BLE001
            # A failed decode used to leave the orb stuck on "working" with no
            # turn behind it and nothing on screen to say why.
            self.dash.hub.send_threadsafe(
                {"t": "error", "msg": f"Couldn't transcribe that ({type(e).__name__})."})
            return
        finally:
            self._transcribing = False
            self._apply_state()

        text = (text or "").strip()
        # One word is a real instruction when you deliberately held a key to
        # say it: "stop", "commit", "yes".
        if not text:
            return
        self.dash.emit("you", text)
        self.submit_text(text)
