"""
registry — the projects you have chosen, as opposed to the ones you happen to
have worked in.

TWO SOURCES, ON PURPOSE
-----------------------
`projects.py` DISCOVERS projects by reading Claude Code's transcript directory.
That is free, needs no setup, and is right on day one — a new user opens the app
and everything they have ever worked on is already listed.

This module is the other half: projects the user explicitly added, named,
pinned, or imported. Discovery cannot express any of those, because there is
nowhere in a transcript to record "I care about this one".

The merged list is discovery ∪ registry, with the registry winning on any field
it has an opinion about. A registered project stays listed even with no
transcripts at all, which is what makes "Add Project" mean something for a repo
you have not opened yet.

REMOVING IS REGISTRY-ONLY
-------------------------
`remove` forgets a project. It never touches the directory. That is stated here
because it is the one operation in this file where a reasonable person might
assume otherwise, and the assumption would cost them a repository.
"""
from __future__ import annotations

import json
import subprocess
import threading
import time
from pathlib import Path

from .paths import STATE, ensure_state

FILE = STATE / "projects.json"

SORTS = ("recent", "lastSession", "activeSessions", "mostVisited")
DEFAULT_SORT = "recent"

# How deep `scan` looks for repositories. Two levels covers the common
# ~/code/<org>/<repo> layout; going deeper turns a scan of a home directory
# into a filesystem crawl.
SCAN_DEPTH = 2
SCAN_LIMIT = 300
SKIP_DIRS = {"node_modules", ".git", "venv", ".venv", "__pycache__", "target",
             "build", "dist", "Library", ".Trash", ".cache"}

_lock = threading.RLock()


# ------------------------------------------------------------------ storage

def load() -> dict:
    try:
        data = json.loads(FILE.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {"projects": {}, "sort": DEFAULT_SORT}
    if not isinstance(data, dict):
        return {"projects": {}, "sort": DEFAULT_SORT}
    data.setdefault("projects", {})
    data.setdefault("sort", DEFAULT_SORT)
    # Projects you have asked not to see. Kept as a list of paths rather than
    # by deleting anything: the source of most rows is DISCOVERY, and there is
    # nothing there to delete -- see `hidden` below.
    data.setdefault("hidden", [])
    return data


def save(data: dict) -> None:
    """Write via a temp file and replace.

    A half-written projects.json is indistinguishable from a corrupt one on the
    next read, and the recovery is "you lost your project list". os.replace is
    atomic on the same filesystem, so a crash mid-write leaves the old file.
    """
    ensure_state()
    tmp = FILE.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
    tmp.replace(FILE)


def _key(path: str | Path) -> str:
    return str(Path(path).expanduser().resolve())


# ------------------------------------------------------------------ mutating

def add(path: str | Path, name: str = "") -> dict:
    """Register a folder. Validates before writing anything.

    The emptiness check is on the RAW input, not on the Path. `Path("")` is
    `Path(".")`, which exists and is a directory, so validating after the
    conversion let an empty field silently register whatever directory the app
    happened to be launched from.
    """
    if not str(path).strip():
        return {"ok": False, "error": "no path given"}
    p = Path(path).expanduser()
    if not p.exists():
        return {"ok": False, "error": f"{p} does not exist"}
    if not p.is_dir():
        return {"ok": False, "error": f"{p} is not a folder"}

    cwd = _key(p)
    with _lock:
        data = load()
        # Adding something you previously forgot is how you un-forget it.
        if cwd in data.get("hidden", []):
            data["hidden"] = [h for h in data["hidden"] if h != cwd]
        if cwd in data["projects"]:
            save(data)
            return {"ok": False, "error": "already added", "cwd": cwd}
        data["projects"][cwd] = {
            "name": name.strip() or Path(cwd).name,
            "pinned": False,
            "visits": 0,
            "addedAt": time.time(),
            "lastVisit": 0.0,
        }
        save(data)
    return {"ok": True, "error": "", "cwd": cwd}


def remove(path: str | Path) -> dict:
    """Forget a project. THE DIRECTORY IS NOT TOUCHED.

    Dropping the registry entry is only half of it, and on its own it does
    nothing you can see. Most rows in the list are DISCOVERED -- every folder
    with a transcript under ~/.claude/projects is one -- so a project you
    remove is rediscovered on the very next read and reappears exactly where
    it was. That is the "I removed it and it is still there" bug: the removal
    worked, and the list was rebuilt from somewhere else.

    So a removal is also a standing instruction not to show it again. It is
    reversible (`add` un-hides), it survives a restart, and it still never
    touches a single file in the directory.
    """
    cwd = _key(path)
    with _lock:
        data = load()
        known = cwd in data["projects"]
        data["projects"].pop(cwd, None)
        hidden = set(data.get("hidden", []))
        hidden.add(cwd)
        data["hidden"] = sorted(hidden)
        save(data)
    return {"ok": True, "error": "", "wasRegistered": known}


def unhide(path: str | Path) -> None:
    """Adding a project back is also un-forgetting it."""
    cwd = _key(path)
    with _lock:
        data = load()
        hidden = [h for h in data.get("hidden", []) if h != cwd]
        if len(hidden) != len(data.get("hidden", [])):
            data["hidden"] = hidden
            save(data)


def _patch(path: str | Path, **fields) -> dict:
    cwd = _key(path)
    with _lock:
        data = load()
        entry = data["projects"].get(cwd)
        if entry is None:
            # Acting on a discovered-but-unregistered project registers it.
            # Otherwise pinning something you can see would silently do nothing.
            entry = {"name": Path(cwd).name, "pinned": False, "visits": 0,
                     "addedAt": time.time(), "lastVisit": 0.0}
            data["projects"][cwd] = entry
        entry.update(fields)
        save(data)
    return {"ok": True, "error": "", "cwd": cwd}


def rename(path: str | Path, name: str) -> dict:
    name = (name or "").strip()
    if not name:
        return {"ok": False, "error": "a project needs a name"}
    return _patch(path, name=name)


def pin(path: str | Path, pinned: bool = True) -> dict:
    return _patch(path, pinned=bool(pinned))


def set_default_branch(path: str | Path, branch: str) -> dict:
    return _patch(path, defaultBranch=(branch or "").strip())


def visit(path: str | Path) -> None:
    """Record that a project was opened. Best-effort and never raises: this is
    called on a hot path and losing a visit count is not worth an exception."""
    try:
        cwd = _key(path)
        with _lock:
            data = load()
            entry = data["projects"].setdefault(cwd, {
                "name": Path(cwd).name, "pinned": False, "visits": 0,
                "addedAt": time.time(), "lastVisit": 0.0})
            entry["visits"] = int(entry.get("visits", 0)) + 1
            entry["lastVisit"] = time.time()
            save(data)
    except Exception:                                   # noqa: BLE001
        pass


def set_sort(mode: str) -> str:
    mode = mode if mode in SORTS else DEFAULT_SORT
    with _lock:
        data = load()
        data["sort"] = mode
        save(data)
    return mode


# -------------------------------------------------------------------- import

def scan(root: str | Path, depth: int = SCAN_DEPTH) -> dict:
    """Find git repositories under a workspace folder.

    Bounded in three ways — depth, a hard result cap, and a skip list — because
    the natural thing to type into "workspace path" is a home directory, and an
    unbounded walk of one takes minutes and finds ten thousand `node_modules`.
    """
    # Raw input first, for the same reason as `add`: Path("") is Path(".").
    if not str(root).strip():
        return {"ok": False, "error": "no path given", "found": []}
    base = Path(root).expanduser()
    if not base.is_dir():
        return {"ok": False, "error": f"{base} is not a folder", "found": []}

    known = set(load()["projects"])
    found: list[dict] = []

    def walk(d: Path, level: int) -> None:
        if len(found) >= SCAN_LIMIT or level > depth:
            return
        try:
            entries = sorted(x for x in d.iterdir() if x.is_dir())
        except OSError:
            return
        for child in entries:
            if child.name in SKIP_DIRS or child.name.startswith("."):
                continue
            if (child / ".git").exists():
                cwd = _key(child)
                found.append({"cwd": cwd, "name": child.name,
                              "parent": str(child.parent),
                              "registered": cwd in known})
                # Do not descend into a repository. Submodules and vendored
                # checkouts would otherwise each be offered as a project.
                continue
            walk(child, level + 1)

    walk(base, 1)
    return {"ok": True, "error": "", "found": found,
            "truncated": len(found) >= SCAN_LIMIT}


def import_many(paths: list[str]) -> dict:
    """Register several at once, reporting each outcome.

    Partial success is the normal case — one path moved, one is already there —
    and collapsing that into a single ok/failed would hide which is which.
    """
    added, failed = [], []
    for p in paths:
        res = add(p)
        (added if res["ok"] else failed).append(
            {"cwd": str(Path(p)), "error": res.get("error", "")})
    return {"ok": not failed, "added": added, "failed": failed}


# --------------------------------------------------------------------- query

def _default_branch(cwd: str) -> str:
    try:
        out = subprocess.run(
            ["git", "--no-optional-locks", "symbolic-ref", "--short", "HEAD"],
            cwd=cwd, capture_output=True, text=True, timeout=4)
        return out.stdout.strip() if out.returncode == 0 else ""
    except (OSError, subprocess.SubprocessError):
        return ""


def merged(discovered: list[dict], live_cwds: set[str] | None = None) -> dict:
    """Discovery ∪ registry, sorted by the stored mode.

    Registry fields win where they exist: a renamed project keeps its name even
    though discovery would call it by its folder, and a pinned one stays pinned
    whatever its activity says.
    """
    live = live_cwds or set()
    data = load()
    reg = data["projects"]
    hidden = set(data.get("hidden", []))
    by_cwd: dict[str, dict] = {}

    for p in discovered:
        cwd = _key(p["cwd"])
        if cwd in hidden:
            continue                    # you told us to forget this one
        by_cwd[cwd] = dict(p)

    for cwd, entry in reg.items():
        row = by_cwd.get(cwd)
        if row is None:
            exists = Path(cwd).is_dir()
            row = {"cwd": cwd, "slug": "", "name": Path(cwd).name,
                   "parent": str(Path(cwd).parent), "sessions": 0,
                   "lastActive": None, "lastActiveTs": 0.0, "branch": "",
                   "live": cwd in live, "missing": not exists}
            by_cwd[cwd] = row
        row["registered"] = True
        row["pinned"] = bool(entry.get("pinned"))
        row["visits"] = int(entry.get("visits", 0))
        row["lastVisit"] = float(entry.get("lastVisit", 0.0))
        if entry.get("name"):
            row["name"] = entry["name"]
        if entry.get("defaultBranch"):
            row["defaultBranch"] = entry["defaultBranch"]

    rows = list(by_cwd.values())
    for row in rows:
        row.setdefault("registered", False)
        row.setdefault("pinned", False)
        row.setdefault("visits", 0)
        row.setdefault("lastVisit", 0.0)
        row["active"] = 1 if row.get("live") else 0
        if "defaultBranch" not in row and not row.get("missing"):
            row["defaultBranch"] = row.get("branch") or ""

    mode = data.get("sort", DEFAULT_SORT)
    keys = {
        "recent": lambda r: r["lastActiveTs"],
        "lastSession": lambda r: r["lastActiveTs"],
        "activeSessions": lambda r: (r["active"], r["lastActiveTs"]),
        "mostVisited": lambda r: (r["visits"], r["lastActiveTs"]),
    }
    rows.sort(key=keys.get(mode, keys["recent"]), reverse=True)
    # Pinned first, and stable within each group so the chosen sort still
    # orders them. A pin is a statement about importance, not about recency.
    rows.sort(key=lambda r: not r["pinned"])
    return {"projects": rows, "sort": mode, "sorts": list(SORTS)}
