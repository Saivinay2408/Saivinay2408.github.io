"""
paths — every filesystem location the dashboard depends on, in one place.

Most of these are Claude Code's own on-disk layout. They are load-bearing, so
they live here with a note on how each was verified, rather than being spelled
inline at the call site where a future reader would have to trust them blind.

WHAT CHANGED WHEN THIS BECAME A PACKAGE
---------------------------------------
The dashboard grew up inside one repo that was both the code and the vault, so
it could say `ROOT = <repo>` and find everything relative to that. Installed
from PyPI there is no repo: the code is in site-packages, the vault is wherever
the user put it, and the two have nothing to do with each other. There is
deliberately no `ROOT` here any more, and each location is resolved on its own
terms.

  LAUNCH_CWD  where you ran the command. This is what `ROOT` was actually
              being used for at most call sites — the default working
              directory for a new session — and cwd is the honest version of
              that for an installed tool.
  vault()     asked of mem rather than reimplemented, so the dashboard
              and the hooks can never disagree about which vault is live.
  STATE       ~/.mem-voice. Ours, machine-local, and deliberately NOT
              inside the vault: the vault is a git repo the user may sync
              between machines, and a chosen whisper size is not something
              that should follow them across machines or show up in a diff.
"""
from __future__ import annotations

import os
from pathlib import Path

def _launch_cwd() -> Path:
    """Where a new session should open.

    Normally this is where you ran the command, which is the honest answer:
    you were in a project, you asked for a window, you get that project.

    A DOUBLE-CLICKED APP HAS NO SUCH ANSWER. macOS launches it with the
    filesystem root as its working directory, so the window opened on "/" —
    the rail said "no repo", the git panel had nothing to show, and the voice
    session started in a directory nobody has ever wanted an agent in. Home is
    the closest thing to a right answer when there is no context at all, and
    the project switcher is one click away from there.
    """
    here = Path.cwd().resolve()
    return Path.home() if here == Path("/") else here


# Captured once at import, on purpose: panes take this as a default argument,
# and a default that drifted when something called os.chdir would open
# sessions in surprising places.
LAUNCH_CWD = _launch_cwd()

# Claude Code's state directory. CLAUDE_CONFIG_DIR overrides it, same as the CLI.
CLAUDE_HOME = Path(os.environ.get("CLAUDE_CONFIG_DIR", Path.home() / ".claude"))

# One directory per project cwd, named by replacing every "/" with "-".
#   ~/Desktop/thing -> ~/.claude/projects/-Users-you-Desktop-thing/
# Inside it, one <session-id>.jsonl per session — the live transcript.
PROJECTS = CLAUDE_HOME / "projects"

# Background sessions supervised by the daemon: ~/.claude/jobs/<short-id>/state.json
JOBS = CLAUDE_HOME / "jobs"

# Our own state. Not in the vault (see above), not in ~/.claude — that is
# Claude Code's directory and we are a guest in it.
STATE = Path(os.environ.get("MEM_VOICE_HOME", Path.home() / ".mem-voice"))

# Dashboard config: consolidation cadence, model defaults, chosen voice.
CONFIG = STATE / "config.json"

# Voice engine config, watched live by tts.py so a speed change takes effect on
# the next sentence rather than the next launch.
VOICE_CONFIG = STATE / "voice.json"

# Downloaded model weights (Silero VAD, whisper, Kokoro). Big, machine-local,
# and re-downloadable — exactly the wrong thing to put in a synced vault.
MODELS = Path(os.environ.get("MEM_VOICE_MODELS", STATE / "models"))

# Where `mem consolidate` output is tee'd when the dashboard runs it, so
# the memory panel can say WHY a pass failed and not merely that it did.
CONSOLIDATE_LOG = STATE / "consolidate.log"


def vault() -> Path:
    """The live vault.

    One function answers this for the whole product, and it is the core's. If
    the two halves ever disagreed, the dashboard would cheerfully report
    statistics for one vault while the hooks wrote to another — the kind of bug
    that takes a week to see.

    When these were separate packages this had a fallback for "the memory half
    is not installed". They are one package now, so that branch could not fire,
    and a dead fallback is worse than none: it is a second answer to a question
    that must only ever have one.
    """
    from mem.config import vault_path
    return vault_path()


def clone_cwd() -> Path:
    """Where the clone itself lives: the vault, not a project.

    The clone is the session that knows everything about you, and everything
    it knows is in there — the notes, the identity file, the inbox, the
    provenance. Standing it up inside one of your repositories made it a
    session that happened to have memory. Standing it up IN the memory makes
    it the thing that has it: able to read and edit its own notes, run `mem`
    against the right vault without being told which one, and dispatch work
    into your projects from outside all of them.

    Falls back to the launch directory when there is no vault yet — a fresh
    install before `mem init`, where the honest answer is "wherever you are".
    """
    try:
        v = vault()
    except Exception:                                   # noqa: BLE001
        return LAUNCH_CWD
    return v if v.is_dir() else LAUNCH_CWD


def ensure_state() -> Path:
    """Create ~/.mem-voice on first use. Called by whoever writes first."""
    STATE.mkdir(parents=True, exist_ok=True)
    return STATE


def project_slug(cwd: str | Path) -> str:
    """Claude Code's project-directory name for a working directory.

    Lossy and NOT reversible — see projects.py, which is why the real cwd is
    read from inside each transcript rather than from its filename.
    """
    return str(Path(cwd).resolve()).replace("/", "-")


def transcript_path(session_id: str, cwd: str | Path) -> Path:
    """Where a session's live JSONL transcript is written."""
    return PROJECTS / project_slug(cwd) / f"{session_id}.jsonl"
