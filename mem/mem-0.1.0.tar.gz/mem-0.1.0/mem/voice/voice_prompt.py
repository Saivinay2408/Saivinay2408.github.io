"""
voice_prompt — the system prompt for the session you TALK to.

WHY IT EXISTS
-------------
Its absence was the single biggest voice bug in the stack this replaced. One
brain implementation appended a spoken-style prompt; the widget used the *other*
one, which launched `claude` with no `--append-system-prompt` at all. So the
model wrote for a terminal — headings, paths, code, bullets — and that got run
through text-to-speech. "It doesn't sound like a conversation" was not a TTS
problem or a prompting subtlety. The instructions were simply never sent.

Every pane the dashboard spawns for voice gets this. Panes you open to work in
by hand do not: those should behave like ordinary Claude Code.

WHY IT IS BUILT, NOT A CONSTANT
-------------------------------
This used to be a string literal naming one particular person, their home
directory and their folders. That is correct for exactly one user and wrong,
and slightly uncanny, for everybody else — a stranger's clone introducing
itself with the author's name. The prompt is now assembled from the vault's own
identity, and degrades to a plain, unnamed assistant when the vault has no name
to give. Nothing about a specific machine is hardcoded anywhere in it.
"""
from __future__ import annotations

import re
from pathlib import Path

# The parts that are true regardless of who is talking.
_SPEECH = """VOICE MODE. Your reply is spoken aloud by TTS, so:
- answer in 1-3 short conversational sentences unless explicitly asked for detail
- never read code, paths, or markdown aloud; do the work with tools, then say what you did in plain words ("done, committed it" / "wrote it to the plan file")
- numbers rounded, no bullet lists, no headers, no emoji
- do NOT narrate your own tool calls out loud ("now I'll read the file..."). The dashboard already speaks progress from the real event stream. Say what you found or did, not what you are about to do."""

# they/them throughout, deliberately. The vault yields a name, and a name is
# not a statement of pronouns — guessing from one would misgender a real person
# in every session, where the neutral form reads correctly for everybody.
_CLONE = """- you are {name}'s clone, speaking with their own memory; talk like them, first person, casual
- the person talking to you IS {name}. never say "your projects" or "you designed" about their work: it is YOUR work. say "my projects", "i designed", "i'm building". you two are the same person"""

_PLAIN = """- speak as a direct, capable assistant. first person, casual, no preamble
- you have access to this person's memory vault; use what it tells you about them rather than guessing"""

_ORCHESTRATOR = """ORCHESTRATOR. You can start and supervise other coding sessions, and they show up as panes in the dashboard automatically:
- `claude --bg "<task>"` dispatches a background session (add `--name <short-name>` so it is identifiable).
- `claude agents --json` lists every live session and its state.
- `claude stop <id>` / `claude rm <id>` end one.
Prefer dispatching real work to background sessions over doing long jobs inline — that is the whole point of the dashboard. After dispatching, say so in one short phrase ("started it in the background, watch the second pane")."""

_SELF = """YOU ARE THIS DASHBOARD. This session is the brain of the window you are speaking through (mic -> whisper -> you -> local TTS -> speakers, with your session rendered as a live terminal pane).
- Tune your own voice LIVE: edit {voice_config} — "speed" (0.6-2.0) and "voice" (a kokoro voice id like am_michael, af_bella, bf_emma). It hot-reloads on the very next sentence you speak. "talk faster" means DO IT (bump speed ~0.15), confirm briefly, never say you can't.
- Do not resurrect terminal scraping. The dashboard reads structured transcripts; that is why it is accurate."""

_NAVIGATOR = """SYSTEM NAVIGATOR. You are on this person's machine with read access and app-control powers. ACT, don't describe. Never destructive (no deleting or overwriting outside the current project, no sudo).

Your toolbox (all via Bash):
- FIND anything: `mdfind -name 'thesis'` (Spotlight on macOS), `mdfind "kMDItemTextContent == '*keyword*'"` for content; `ls`, `find`, `grep` under the home directory. Read any file directly.
- OPEN + NAVIGATE: `open -a "App"`, `open <file-or-url>`, `code <folder>`. App control via osascript.
- SEE the screen when you need eyes: `screencapture -x /tmp/screen.png` then Read /tmp/screen.png. Use this to verify an app actually opened, or to answer "what am I looking at".
- The see-act-verify loop for anything GUI: act (open/osascript) -> screencapture -> Read -> confirm from what you SEE, not from exit codes.

Rules: after acting, confirm in ONE short spoken phrase ("vs code is up with the notes folder"). Ambiguous target -> do the most likely thing and say which you picked. Never guess a path: find the real one first."""

_NAME_RE = re.compile(r"^\s*(?:name|preferred_name|full_name)\s*::?\s*(.+?)\s*$",
                      re.M | re.I)


def vault_name(vault: Path | None = None) -> str:
    """The user's name, from the vault's identity note.

    Returns "" when the vault cannot say — a fresh install, a vault with no
    identity yet, mem not installed at all. Every one of those is normal,
    and the prompt has a perfectly good unnamed form, so none of them is worth
    raising over or guessing about. Guessing here would mean a clone that
    confidently calls the user by the wrong name.
    """
    try:
        if vault is None:
            from .paths import vault as vault_path
            vault = vault_path()
        text = (Path(vault) / "identity.md").read_text(encoding="utf-8")
    except (OSError, ImportError):
        return ""
    match = _NAME_RE.search(text)
    if match:
        return _clean(match.group(1))
    # Fall back to the H1, which is how most identity notes open. It is usually
    # a label and then the name -- "Identity core — Ada Lovelace" -- so take the
    # part after the last separator. Without that the clone introduces itself as
    # "Identity core — Ada Lovelace's clone", which is worse than being unnamed.
    head = re.search(r"^#\s+(.+?)\s*$", text, re.M)
    if not head:
        return ""
    # A colon, pipe or dash separates the label from the name. The hyphen is the
    # only one that requires spaces on both sides, because "Jean-Luc" must not
    # be split into "Luc"; the others cannot occur inside a name.
    tail = re.split(r"\s*[—–:|]\s+|\s+-\s+", head.group(1))[-1]
    return _clean(tail)


def _clean(value: str) -> str:
    """A name, or nothing. Never a sentence.

    Anything long enough to be prose is not a name, and putting prose here
    produces a clone that opens every session by misquoting the vault at you.
    Returning "" falls back to the unnamed prompt, which reads fine.
    """
    value = value.strip().strip("[]*_").strip()
    if not value or len(value) > 60 or "\n" in value:
        return ""
    return value


def build(name: str = "", voice_config: Path | str | None = None) -> str:
    """Assemble the prompt. `name` empty means the unnamed, non-clone form."""
    if voice_config is None:
        from .paths import VOICE_CONFIG
        voice_config = VOICE_CONFIG

    persona = _CLONE.format(name=name) if name else _PLAIN
    return "\n".join([
        _SPEECH,
        persona,
        "",
        _SELF.format(voice_config=voice_config),
        "",
        _ORCHESTRATOR,
        "",
        _NAVIGATOR,
    ])


def voice_system(vault: Path | None = None) -> str:
    """The prompt for a voice pane, personalised from the vault if it can be."""
    return build(vault_name(vault))
