"""
call — a real-time voice call between your phone and Mem, over the internet,
with no phone network in it.

    phone (browser)  ──WebRTC, end-to-end encrypted──▶  this Mac
                     ◀── the clone's voice ───────────

The phone's page offers a WebRTC connection (POST /phone/call); this module
answers it with aiortc. After that the audio flows straight between the two
devices: there is no server in the middle, no SIM, no carrier, no paid voice
API. Over Tailscale the path is your own encrypted tailnet, and WebRTC
encrypts the call again on top (DTLS-SRTP), the way FaceTime does.

What happens on the Mac, per call:

    phone mic ─▶ 16 kHz ─▶ Silero VAD ─▶ utterance ─▶ whisper ─▶ the clone
                                                                    │
    phone speaker ◀─ 48 kHz ◀─ Kokoro, sentence by sentence ◀───────┘

Why hands-free works here when it was dropped in the room: the old problem was
the Mac hearing its own voice through its own speakers. On a call the phone's
browser cancels the echo (getUserMedia echoCancellation — the same processing
a FaceTime call gets), so what reaches the Mac is you, not the reply. That is
also what makes barge-in safe: start talking while it answers and it stops.

Everything is local: whisper hears, Kokoro speaks, your existing coding
subscription thinks. Nothing about the call costs anything.
"""
from __future__ import annotations

import asyncio
import fractions
import json
import queue
import re
import sys
import threading
import time

OUT_RATE = 48000
OUT_FRAME = 960                       # 20 ms at 48 kHz: what WebRTC expects
IN_RATE = 16000
VAD_FRAME = 512                       # Silero's frame (stt.FRAME)

# How long you must keep talking over the answer before it stops for you.
# Long enough that a cough or "mm" does not cut it off.
BARGE_IN_S = 0.35
# Narration while it works, at most this often, and only into silence.
PROGRESS_EVERY_S = 12.0


def _sentences(text: str) -> list[str]:
    """Split an answer into speakable pieces, so the first one can start
    playing while the rest are still being synthesized."""
    parts = re.split(r"(?<=[.!?])\s+|\n+", text.strip())
    out, cur = [], ""
    for p in parts:
        p = p.strip()
        if not p:
            continue
        cur = f"{cur} {p}".strip() if cur else p
        if len(cur) >= 24:            # avoid "Yes." "OK." as separate clips
            out.append(cur)
            cur = ""
    if cur:
        out.append(cur)
    return out


def _resample(x, sr_from: int, sr_to: int):
    import numpy as np
    x = np.asarray(x, dtype="float32").reshape(-1)
    if sr_from == sr_to or not len(x):
        return x
    n = int(round(len(x) * sr_to / sr_from))
    return np.interp(np.linspace(0, len(x) - 1, n), np.arange(len(x)), x).astype("float32")


def _chime(sr: int = OUT_RATE):
    """A short, soft two-note 'got it' — so you know you were heard even with
    the phone in your pocket, before the answer has started."""
    import numpy as np
    def tone(f, d):
        t = np.arange(int(sr * d)) / sr
        env = np.minimum(1.0, np.minimum(t / 0.01, (d - t) / 0.04))
        return 0.12 * np.sin(2 * np.pi * f * t) * env
    return np.concatenate([tone(660, 0.07), np.zeros(int(sr * 0.03)), tone(880, 0.09)]).astype("float32")


# --------------------------------------------------------------------------
# outgoing audio
# --------------------------------------------------------------------------

def _out_track_class():
    from aiortc import MediaStreamTrack

    class VoiceOut(MediaStreamTrack):
        """The clone's side of the call: a 48 kHz stream that is silence until
        there is something to say. `push` queues speech, `clear` drops it
        (barge-in)."""
        kind = "audio"

        def __init__(self):
            super().__init__()
            import numpy as np
            self._np = np
            self._buf = np.zeros(0, dtype="int16")
            self._lock = threading.Lock()
            self._t0 = None
            self._pts = 0

        def push(self, samples, sr: int) -> None:
            np = self._np
            x = _resample(samples, sr, OUT_RATE)
            pcm = (np.clip(x, -1.0, 1.0) * 32767).astype("int16")
            with self._lock:
                self._buf = np.concatenate([self._buf, pcm])

        def clear(self) -> None:
            with self._lock:
                self._buf = self._np.zeros(0, dtype="int16")

        @property
        def playing(self) -> bool:
            return len(self._buf) > 0

        @property
        def remaining_s(self) -> float:
            return len(self._buf) / OUT_RATE

        async def recv(self):
            import av
            np = self._np
            if self._t0 is None:
                self._t0 = time.monotonic()
            # Pace to real time: WebRTC wants frames as they would be heard.
            wait = self._t0 + self._pts / OUT_RATE - time.monotonic()
            if wait > 0:
                await asyncio.sleep(wait)
            with self._lock:
                chunk = self._buf[:OUT_FRAME]
                self._buf = self._buf[OUT_FRAME:]
            if len(chunk) < OUT_FRAME:
                chunk = np.concatenate([chunk, np.zeros(OUT_FRAME - len(chunk), dtype="int16")])
            frame = av.AudioFrame.from_ndarray(chunk.reshape(1, -1), format="s16", layout="mono")
            frame.sample_rate = OUT_RATE
            frame.pts = self._pts
            frame.time_base = fractions.Fraction(1, OUT_RATE)
            self._pts += OUT_FRAME
            return frame

    return VoiceOut


# --------------------------------------------------------------------------
# one call
# --------------------------------------------------------------------------

class Call:
    """One phone call. Owns the peer connection, the ears and the mouth.

    `voice` is the dashboard's VoiceLoop (for submit_remote and its loaded
    models); `vad` / `stt` / `synth` can be injected so tests run without
    models."""

    def __init__(self, dash, *, vad=None, stt=None, synth=None, speak_on_mac=False,
                 log_timings=True):
        from aiortc import RTCConfiguration, RTCPeerConnection
        self.dash = dash
        self.voice = getattr(dash, "voice", None)
        # No STUN/TURN: on a tailnet (or the same Wi-Fi) both ends can reach
        # each other directly, and asking a public STUN server would tell a
        # third party that a call is happening.
        self.pc = RTCPeerConnection(RTCConfiguration(iceServers=[]))
        self.out = _out_track_class()()
        self.pc.addTrack(self.out)
        self.channel = None
        self.muted = False
        self.closed = False
        self.started = time.time()
        self.speak_on_mac = speak_on_mac
        self.log_timings = log_timings
        self.loop = asyncio.get_event_loop()

        self._vad = vad
        self._stt = stt
        self._synth = synth
        self._frames: queue.Queue = queue.Queue(maxsize=400)
        self._say_q: queue.Queue = queue.Queue()
        self._state = "listening"
        self._turn_open = False
        self._last_progress = 0.0
        self._threads: list[threading.Thread] = []

        @self.pc.on("datachannel")
        def _on_dc(ch):
            self.channel = ch
            ch.on("message", self._on_message)
            self.send({"t": "state", "v": self._state})

        @self.pc.on("track")
        def _on_track(track):
            if track.kind == "audio":
                asyncio.ensure_future(self._consume(track))

        @self.pc.on("connectionstatechange")
        async def _on_state():
            if self.pc.connectionState in ("failed", "closed", "disconnected"):
                await self.close()

    # ---- signalling -----------------------------------------------------

    async def answer(self, sdp: str, kind: str = "offer") -> dict:
        from aiortc import RTCSessionDescription
        await self.pc.setRemoteDescription(RTCSessionDescription(sdp=sdp, type=kind))
        await self.pc.setLocalDescription(await self.pc.createAnswer())
        # The Mac goes quiet for the call (VoiceLoop.on_phone_call), starting
        # with whatever it is saying right now.
        # Check the transcript for the answer more often while on a call: the
        # room's 0.35 s poll is invisible there, but on a call it is lag.
        w = getattr(self.voice, "watcher", None)
        if w is not None and hasattr(w, "interval"):
            self._poll_was = w.interval
            w.interval = 0.1
        spk = getattr(self.voice, "speaker", None)
        if spk is not None:
            try:
                spk.stop()
            except Exception:                               # noqa: BLE001
                pass
        for fn in (self._ears, self._mouth):
            t = threading.Thread(target=fn, daemon=True, name=f"call-{fn.__name__}")
            t.start()
            self._threads.append(t)
        return {"sdp": self.pc.localDescription.sdp, "type": self.pc.localDescription.type}

    async def close(self) -> None:
        if self.closed:
            return
        self.closed = True
        self.out.clear()
        w = getattr(self.voice, "watcher", None)
        if w is not None and getattr(self, "_poll_was", None):
            w.interval = self._poll_was
        self._frames.put(None)
        self._say_q.put(None)
        try:
            await self.pc.close()
        except Exception:                                   # noqa: BLE001
            pass
        if getattr(self.dash, "call", None) is self:
            self.dash.call = None

    # ---- talking to the phone's page -------------------------------------

    def send(self, msg: dict) -> None:
        """To the phone, over the call's own data channel. Thread-safe."""
        ch = self.channel
        if ch is None or self.closed:
            return
        def _go():
            try:
                if ch.readyState == "open":
                    ch.send(json.dumps(msg))
            except Exception:                               # noqa: BLE001
                pass
        try:
            self.loop.call_soon_threadsafe(_go)
        except RuntimeError:
            pass

    def _set_state(self, s: str) -> None:
        if s != self._state:
            self._state = s
            self.send({"t": "state", "v": s})

    def _on_message(self, raw) -> None:
        try:
            m = json.loads(raw)
        except (TypeError, ValueError):
            return
        t = m.get("t")
        if t == "mute":
            self.muted = bool(m.get("on"))
        elif t == "stop":
            # Stop talking, and stop the work too: the call's Escape key.
            self.out.clear()
            _drain(self._say_q)
            if self.voice is not None:
                self.voice._interrupt_turns()
            self._set_state("listening")
        elif t == "hangup":
            asyncio.ensure_future(self.close())

    # ---- ears -------------------------------------------------------------

    async def _consume(self, track) -> None:
        """Phone audio -> 16 kHz mono float frames for the ears thread. Runs on
        the event loop, so it does nothing but convert and hand over."""
        import av
        import numpy as np
        from aiortc.mediastreams import MediaStreamError
        rs = av.AudioResampler(format="s16", layout="mono", rate=IN_RATE)
        pending = np.zeros(0, dtype="float32")
        while not self.closed:
            try:
                frame = await track.recv()
            except MediaStreamError:
                break
            for f in rs.resample(frame):
                pcm = f.to_ndarray().reshape(-1).astype("float32") / 32768.0
                pending = np.concatenate([pending, pcm])
            while len(pending) >= VAD_FRAME:
                chunk, pending = pending[:VAD_FRAME], pending[VAD_FRAME:]
                try:
                    self._frames.put_nowait(chunk)
                except queue.Full:
                    pass                   # the ears fell behind; drop, never block the call
        await self.close()

    def _load_ears(self):
        if self._vad is None:
            from .paths import MODELS
            from .stt import Endpointer, SileroVAD, SmartTurn
            vad = SileroVAD(models_dir=MODELS)
            smart = None
            try:
                smart = SmartTurn(models_dir=MODELS)
            except Exception:                               # noqa: BLE001
                pass
            # Without the turn judge, a fixed pause ends your turn. Shorter than
            # the room's: on a call, silence means "your go".
            self._vad = Endpointer(vad, smart_turn=smart,
                                   silence_hard_ms=1100 if smart else 800)
        if self._stt is None:
            from .phone_audio import _stt
            self._stt = _stt(self.voice)

    def _ears(self) -> None:
        try:
            self._load_ears()
        except Exception as e:                              # noqa: BLE001
            self.send({"t": "note", "v": f"The Mac could not load its ears ({type(e).__name__})."})
            return
        self.send({"t": "ready"})
        over = 0                                            # frames of you over the answer
        while not self.closed:
            frame = self._frames.get()
            if frame is None:
                return
            if self.muted:
                continue
            import numpy as np
            self.send_level(float(np.sqrt((frame ** 2).mean())))
            utt = self._vad.feed(frame)
            if self._vad.speaking:
                if self.out.playing:
                    over += 1
                    if over * VAD_FRAME / IN_RATE >= BARGE_IN_S:
                        # Barge-in: you are talking over it, so it stops.
                        self.out.clear()
                        _drain(self._say_q)
                        over = 0
                elif self._state in ("listening", "speaking"):
                    self._set_state("hearing")
            else:
                over = 0
            if utt is not None:
                self._heard(utt)

    _lvl_at = 0.0

    def send_level(self, rms: float) -> None:
        now = time.monotonic()
        if now - self._lvl_at >= 0.1:
            self._lvl_at = now
            self.send({"t": "level", "v": round(min(1.0, rms * 9.0), 3)})

    def _heard(self, utt) -> None:
        if len(utt) < IN_RATE * 0.35:          # a click, not a sentence
            self._set_state("listening")
            return
        self._set_state("thinking")
        self._t = {"end": time.monotonic()}
        try:
            text, _ = self._stt.transcribe(utt)
        except Exception as e:                              # noqa: BLE001
            self.send({"t": "note", "v": f"Couldn't hear that ({type(e).__name__})."})
            self._set_state("listening")
            return
        text = (text or "").strip()
        if not text or _filler(text):
            self._set_state("listening")
            return
        self._t["text"] = time.monotonic()
        self.send({"t": "you", "v": text})
        self.out.push(_chime(), OUT_RATE)
        # Off the ears thread: submitting waits for the session to confirm,
        # and the ears must keep listening meanwhile (barge-in, the next thing
        # you say).
        threading.Thread(target=self.ask, args=(text,), daemon=True, name="call-ask").start()

    def ask(self, text: str) -> None:
        """Send words to the clone; its answer comes back as speech."""
        if self.voice is None:
            self._say("Mem's voice is off on the Mac, so I can't take a call right now.")
            return
        self._turn_open = True
        self._set_state("working")

        def stream(part: str) -> None:
            from .speakable import to_speech
            self._t.setdefault("first_text", time.monotonic())
            said = to_speech(part)
            if said:
                self.send({"t": "clone", "v": part.strip()})
                self._say(said)

        def done(_full: str) -> None:
            self._turn_open = False
            # An answer that never streamed (an error, "Done.") still gets said.
            if _full and not _full.startswith("(interrupted"):
                if not self._spoke_this_turn:
                    self.send({"t": "clone", "v": _full})
                    self._say(_full)
            self._spoke_this_turn = False
            if not self.out.playing and self._say_q.empty():
                self._set_state("listening")

        def progress(phrase: str) -> None:
            now = time.monotonic()
            self.send({"t": "status", "v": phrase})
            if (phrase and now - self._last_progress >= PROGRESS_EVERY_S
                    and not self.out.playing and self._say_q.empty()):
                self._last_progress = now
                self._say(phrase, progress=True)

        self._spoke_this_turn = False
        ok = self.voice.submit_remote(text, done, speak_on_mac=self.speak_on_mac,
                                      progress=progress, stream=stream)
        self._t["sent"] = time.monotonic()
        if not ok:
            self._turn_open = False

    _spoke_this_turn = False
    _t: dict = {}

    def _report_timing(self) -> None:
        """Where the wait went, per turn: to the phone (shown small) and to a
        log on the Mac, so 'it feels laggy' becomes numbers to fix."""
        t = self._t
        row = {"hear": _ms(t, "end", "text"), "send": _ms(t, "text", "sent"),
               "think": _ms(t, "sent", "first_text"), "voice": _ms(t, "first_text", "audio"),
               "total": _ms(t, "end", "audio")}
        self.send({"t": "timing", "v": row})
        if not self.log_timings:
            return
        try:
            from .paths import STATE
            with open(STATE / "call-timings.log", "a") as f:
                f.write(json.dumps({"at": time.strftime("%Y-%m-%d %H:%M:%S"), **row}) + "\n")
        except Exception:                                   # noqa: BLE001
            pass

    # ---- mouth ------------------------------------------------------------

    def _say(self, text: str, progress: bool = False) -> None:
        first = not progress and not self._spoke_this_turn
        if not progress:
            self._spoke_this_turn = True
        parts = _sentences(text)
        if first and parts and len(parts[0]) > 70:
            # The first thing said is what you wait for, so make it short:
            # up to the first comma, and synthesize the rest while it plays.
            cut = parts[0].find(", ", 20)
            if 0 < cut < 60:
                parts[0:1] = [parts[0][:cut + 1], parts[0][cut + 2:]]
        for s in parts:
            self._say_q.put(s)

    def _mouth(self) -> None:
        """Synthesize queued sentences one at a time, and keep the orb honest
        about whether it is speaking."""
        synth = self._synth
        if synth is None:
            from .phone_audio import synth as _s
            synth = lambda t: _s(t, self.voice)            # noqa: E731
        while not self.closed:
            try:
                s = self._say_q.get(timeout=0.15)
            except queue.Empty:
                if not self.out.playing and self._state == "speaking":
                    self._set_state("working" if self._turn_open else "listening")
                continue
            if s is None:
                return
            try:
                samples, sr = synth(s)
            except Exception as e:                          # noqa: BLE001
                print(f"[call] synth failed: {e}", file=sys.stderr)
                continue
            if samples is not None and sr and not self.closed:
                self.out.push(samples, sr)
                self._set_state("speaking")
                if self._t and "audio" not in self._t and "end" in self._t:
                    self._t["audio"] = time.monotonic()
                    self._report_timing()


def _ms(t: dict, a: str, b: str):
    return int((t[b] - t[a]) * 1000) if a in t and b in t else None


def _drain(q: queue.Queue) -> None:
    try:
        while True:
            item = q.get_nowait()
            if item is None:           # keep the shutdown signal
                q.put(None)
                return
    except queue.Empty:
        pass


_FILLER = re.compile(r"^(um+|uh+|hmm+|mm+|ah+|thank you|thanks|you)$", re.I)


def _filler(text: str) -> bool:
    """Whisper's favourite hallucinations on noise, and noises that are not a
    request. "Thank you." from a quiet room is the classic one."""
    return bool(_FILLER.match(text.strip().strip(".!?, ")))
