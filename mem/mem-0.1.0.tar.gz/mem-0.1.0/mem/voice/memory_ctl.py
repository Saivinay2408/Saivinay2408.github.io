"""
memory_ctl — the vault, from the dashboard.

The consolidation pipeline already exists and works — `mem consolidate`,
`maintain`, `index`, `verify`. What it has never had is a face: no way to see
how far behind it is, what it accepted or threw away, or whether the graph is
still sound.

This exposes it without reimplementing it. Every operation shells out to the
same `mem` commands a user would type by hand, so there is exactly one
implementation of the sleep pass and the dashboard cannot drift from it.

WHO RUNS THE PASS
-----------------
In the repo this grew up in, a launchd plist ran the pass every two hours and
the dashboard only reported on it. That arrangement had a standing tax: a
scheduled job cannot reach the login Keychain, so it needed a separate
long-lived token, and when that token expired every extraction silently
returned nothing for six days.

Installed as a package there is no plist. The dashboard is a long-running
process the user starts themselves, so it runs the pass on its own cadence, as
that user, with their normal login auth — and the whole headless-token problem
stops existing. The cost is honest and stated in the UI: the pass runs when the
dashboard is running. Nothing is captured-and-lost while it is closed (capture
is the agent's Stop hook, which is always on); the distilling just waits.

Worth surfacing deliberately: the reject count. A memory system that accepts
everything is a log. The gate throwing candidates away is the feature, so the
panel shows it rather than hiding it as an error.
"""
from __future__ import annotations

import json
import re
import subprocess
import sys
import threading
import time
from datetime import datetime, timezone
from pathlib import Path

from .paths import CONFIG, CONSOLIDATE_LOG, ensure_state, vault

NOTE_DIRS = ("concepts", "episodic", "goals", "organizations", "people",
             "procedures", "projects", "proposals", "skills", "artifacts")

CADENCES = {
    "off": 0,
    "30m": 1800,
    "2h": 7200,
    "6h": 21600,
    "daily": 86400,
}
DEFAULT_CADENCE = "2h"

# The pass, in the order the shell script used to run it. `verify` is last and
# its failure is reported rather than raised: an unsound graph is something you
# need told about, not something that should abort the run that found it.
PASS = (
    ("consolidate", ["consolidate"]),
    ("maintain", ["maintain", "--apply"]),
    ("index", ["index"]),
    ("verify", ["verify"]),
)

START_MARKER = "--- consolidate start ---"
DONE_MARKER = "--- done ---"
LOG_TRIM_BYTES = 1_000_000
LOG_KEEP_BYTES = 200_000


# ---- config --------------------------------------------------------------

def load_config() -> dict:
    try:
        cfg = json.loads(CONFIG.read_text())
    except (OSError, ValueError):
        cfg = {}
    cfg.setdefault("cadence", DEFAULT_CADENCE)
    cfg.setdefault("autoConsolidate", True)
    return cfg


def save_config(patch: dict) -> dict:
    cfg = load_config()
    cfg.update({k: v for k, v in patch.items() if k in ("cadence", "autoConsolidate")})
    if cfg.get("cadence") not in CADENCES:
        cfg["cadence"] = DEFAULT_CADENCE
    CONFIG.parent.mkdir(parents=True, exist_ok=True)
    CONFIG.write_text(json.dumps(cfg, indent=2) + "\n")
    return cfg


def cadence_seconds() -> int:
    return CADENCES.get(load_config().get("cadence", DEFAULT_CADENCE), 7200)


# ---- vault state ---------------------------------------------------------

# Four characters to a token; see pendingTokens.
CHARS_PER_TOKEN = 4

_CONSOLIDATED_FALSE = re.compile(r"^consolidated:\s*false\s*$", re.M | re.I)


def vault_stats() -> dict:
    """What the vault holds right now, plus how far behind consolidation is."""
    root = vault()
    counts = {}
    for d in NOTE_DIRS:
        try:
            counts[d] = sum(1 for _ in (root / d).rglob("*.md"))
        except OSError:
            counts[d] = 0

    # How far behind consolidation is, AND WHAT CATCHING UP WILL COST.
    #
    # "3 to fold in" says nothing about whether pressing the button spends a
    # rounding error or a third of a weekly limit -- and this is the one
    # button in the app that spends real money, so the number belongs next to
    # it rather than in a doc. Every pending capture is read once by the
    # extractor, so the input side is simply their size; the output is small
    # and bounded by the gate, so it is not guessed at here.
    pending = 0
    pending_bytes = 0
    for p in (root / "episodic").rglob("*.md"):
        try:
            text = p.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        if _CONSOLIDATED_FALSE.search(text[:600]):
            pending += 1
            pending_bytes += len(text)

    graph = {"nodes": 0, "edges": 0, "dangling": 0}
    try:
        idx = json.loads((root / "index.json").read_text())
        graph = {"nodes": len(idx.get("nodes") or []),
                 "edges": len(idx.get("edges") or []),
                 "dangling": len(idx.get("dangling") or [])}
    except (OSError, ValueError):
        pass

    return {
        "counts": counts,
        "notes": sum(counts.values()),
        "pending": pending,
        # Rough on purpose and labelled that way everywhere it is shown: real
        # tokenisation needs the model's own tokeniser, and four characters
        # per token answers the only question being asked, which is "is this
        # a small pass or a big one".
        "pendingTokens": round(pending_bytes / CHARS_PER_TOKEN),
        "pendingBytes": pending_bytes,
        "graph": graph,
        "lastRun": last_run(),
        "cadence": load_config().get("cadence", DEFAULT_CADENCE),
    }


def last_run() -> dict:
    """When consolidation last ran and how it went, read from its own log.

    The log's vocabulary is mem's own, read out of its source rather than
    guessed at (`mem/consolidate.py`):

      "  wrote: fact[key] -> note.md"          a fact made it into the vault
      "  REJECT: ...: reason"                  the gate threw a candidate away
      "  ! extractor ..."                      the extraction step failed
      "FAIL: ..." / "OK: ..."                  the verifier's verdict

    The two frame markers are ours, written by Consolidator around the run. In
    the old shell-script arrangement those were also guessed at from outside;
    now the same process writes and reads them, so "did the pass finish" is a
    fact rather than an inference.

    Distinguishing "ran and wrote nothing" from "ran and could not extract" is
    the point. Those look identical in the vault and mean opposite things — the
    first is a quiet week, the second is a broken pipeline, and the project this
    came from spent one of those without noticing.
    """
    info = {"at": None, "wrote": None, "rejected": None, "failed": None,
            "ok": None, "completed": None, "problem": ""}
    try:
        mtime = CONSOLIDATE_LOG.stat().st_mtime
        info["at"] = datetime.fromtimestamp(mtime, timezone.utc).isoformat()
        with CONSOLIDATE_LOG.open("rb") as f:
            size = f.seek(0, 2)
            f.seek(max(0, size - LOG_KEEP_BYTES))
            tail = f.read().decode("utf-8", "replace")
    except OSError:
        return info

    start = tail.rfind(START_MARKER)
    block = tail[start:] if start >= 0 else tail
    info["wrote"] = len(re.findall(r"^\s*wrote:", block, re.M))
    info["rejected"] = len(re.findall(r"^\s*REJECT:", block, re.M))
    info["failed"] = len(re.findall(r"^\s*!\s*extractor", block, re.M))
    info["completed"] = DONE_MARKER in block
    info["ok"] = not re.search(r"^FAIL:", block, re.M)

    if info["failed"] and not info["wrote"]:
        info["problem"] = ("The extractor could not reach a model, so nothing was "
                           "distilled. Check it with `mem check-extractor`.")
    elif not info["completed"]:
        info["problem"] = f"The last pass did not finish. See {CONSOLIDATE_LOG}."
    elif info["ok"] is False:
        info["problem"] = "The last pass reported an unsound graph."
    return info


def summary_label(stats: dict) -> str:
    """The one string small enough for the top rail.

    Memory being OFF outranks every other fact about the vault: how many notes
    it holds does not matter if none of them are reaching your sessions, and a
    meter that reads "380 notes" while injecting nothing is a lie of omission.
    """
    mode = (stats.get("switch") or {}).get("mode", "on")
    if mode == "off":
        return "off"
    n = stats["notes"]
    pending = stats["pending"]
    label = f"{n} notes" + (f" · {pending} to fold in" if pending else "")
    return f"{label} · not injecting" if mode == "capture-only" else label


# ---- running the pipeline ------------------------------------------------

class Consolidator:
    """Runs the sleep pass on demand and streams its output to the UI.

    Only ever one at a time: two passes writing the vault concurrently is how
    you get a merge conflict inside your own memory.
    """

    def __init__(self, dash):
        self.dash = dash
        self.running = False
        self._lock = threading.Lock()

    def run_now(self) -> bool:
        with self._lock:
            if self.running:
                return False
            self.running = True
        threading.Thread(target=self._run, daemon=True).start()
        return True

    def _emit(self, line: str) -> None:
        self.dash.emit_raw({"t": "memory.log", "v": line})

    def _log(self, handle, line: str) -> None:
        """To the UI live, and to the log for last_run() to read afterwards."""
        self._emit(line[:300])
        try:
            handle.write(line + "\n")
            handle.flush()
        except OSError:
            pass

    def _trim(self) -> None:
        """Keep the log from growing without bound. The old shell script did
        this too; it has to live somewhere, and this is the only writer."""
        try:
            if CONSOLIDATE_LOG.stat().st_size <= LOG_TRIM_BYTES:
                return
            with CONSOLIDATE_LOG.open("rb") as f:
                f.seek(-LOG_KEEP_BYTES, 2)
                keep = f.read()
            CONSOLIDATE_LOG.write_bytes(keep)
        except OSError:
            pass

    def _run(self) -> None:
        ensure_state()
        self._trim()
        stamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        try:
            handle = CONSOLIDATE_LOG.open("a", encoding="utf-8")
        except OSError as e:                            # noqa: BLE001
            self._emit(f"couldn't open the log: {e}")
            self.running = False
            return
        try:
            self._log(handle, f"[{stamp}] {START_MARKER}")
            for label, args in PASS:
                if not self._step(handle, label, args):
                    break
            else:
                self._log(handle, f"[{datetime.now():%Y-%m-%d %H:%M:%S}] {DONE_MARKER}")
        finally:
            handle.close()
            self.running = False
            self.dash.emit_raw({"t": "memory", "v": snapshot()})

    def _step(self, handle, label: str, args: list[str]) -> bool:
        """One `mem <cmd>`. Returns False if the pass should stop here.

        `verify` failing does NOT stop anything — it is the step whose whole job
        is to report, and aborting on its verdict would mean the one run that
        detected a problem is also the one that skipped writing it down.
        """
        self._emit(f"{label}…")
        try:
            proc = subprocess.Popen(
                [sys.executable, "-m", "mem", *args],
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, bufsize=1)
        except (OSError, ValueError) as e:
            self._log(handle, f"! could not run `mem {label}`: {e}")
            return False
        try:
            for line in proc.stdout:                    # type: ignore[union-attr]
                line = line.rstrip()
                if line:
                    self._log(handle, line)
            proc.wait(timeout=900)
        except subprocess.TimeoutExpired:
            proc.kill()
            self._log(handle, f"! `mem {label}` timed out after 15 minutes")
            return False
        if proc.returncode != 0 and label != "verify":
            self._log(handle, f"! `mem {label}` exited {proc.returncode}")
            return False
        return True


def memory_switch():
    """The on/off switch, imported from the same module the hooks use.

    Deliberately not reimplemented here. Two copies of "is memory on" is how
    the dashboard ends up showing a state the sessions don't agree with. The
    import is deferred so this module loads on a machine where mem has
    not been installed yet — the dashboard should start and *say* so.
    """
    from mem import switch
    return switch


def snapshot() -> dict:
    s = vault_stats()
    # We are the scheduler now, and only while we are running. Reported rather
    # than assumed so the UI can say which of the two it is.
    s["scheduled"] = bool(load_config().get("autoConsolidate")) and cadence_seconds() > 0
    try:
        s["switch"] = memory_switch().status()
    except Exception:                              # noqa: BLE001
        s["switch"] = {"mode": "on", "injects": True, "captures": True,
                       "description": "on", "fromEnv": False}
    # after the switch is read: the label reports it
    s["label"] = summary_label(s)
    lr = s["lastRun"]
    if not s["scheduled"] and not lr.get("problem"):
        lr["problem"] = ("Nothing will fold sessions into memory on its own. "
                         "Pick an interval above, or press Consolidate now.")
    bits = [s["switch"]["description"],
            f"{s['notes']} notes", f"{s['graph']['nodes']} nodes",
            f"{s['graph']['edges']} links"]
    if s["pending"]:
        bits.append(f"{s['pending']} sessions not yet folded in")
    if lr.get("at"):
        bits.append(f"last pass {lr['at'][:16].replace('T', ' ')}Z")
    if lr.get("problem"):
        bits.append(lr["problem"])
    s["tooltip"] = " · ".join(bits)
    return s


class MemoryMonitor:
    """Pushes vault state to the UI, and runs the pass on the chosen cadence."""

    REFRESH = 60.0

    def __init__(self, dash):
        self.dash = dash
        self.consolidator = Consolidator(dash)
        self.last: dict = {}          # last snapshot, replayed on reconnect
        self._stop = threading.Event()
        self._last_auto = time.time()

    def start(self) -> None:
        threading.Thread(target=self._run, daemon=True).start()

    def stop(self) -> None:
        self._stop.set()

    def _run(self) -> None:
        while not self._stop.is_set():
            self.last = snapshot()
            self.dash.emit_raw({"t": "memory", "v": self.last})
            cfg = load_config()
            every = cadence_seconds()
            # This IS the schedule now — see the module docstring. It cannot
            # double-run: the Consolidator refuses a second concurrent pass and
            # the clock only advances when one is actually started.
            if cfg.get("autoConsolidate") and every and \
                    time.time() - self._last_auto >= every:
                self._last_auto = time.time()
                self.consolidator.run_now()
            self._stop.wait(self.REFRESH)
