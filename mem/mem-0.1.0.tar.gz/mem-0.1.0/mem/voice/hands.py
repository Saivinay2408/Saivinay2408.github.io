"""
hands — the clone driving your Mac with a cursor of its own, on your terms.

THE ENGINE IS CUA DRIVER (github.com/trycua/cua, MIT). It gives an agent its
own on-screen cursor and clicks, types, scrolls and drags in real apps IN THE
BACKGROUND: your mouse does not move and the app you are in stays in front.
It reads each app's accessibility tree, so the clone clicks "the Send button"
rather than a guessed pixel. It is a signed (Developer ID) app, which is what
makes its two permissions -- Accessibility and Screen Recording -- a one-time
switch that survives updates. Mem installs it, pins its version, turns its
telemetry off, and keeps it out of every other agent on the machine; only
Mem's voice session is given it.

WHAT MEM ADDS IS THE HIERARCHY: how much the clone may do on its own.

    watch   it may look (screenshots, the accessibility tree) and point.
            Nothing is clicked or typed.
    ask     every action is put to you first -- spoken, on the window, and on
            the phone -- and runs only on a yes.            (the default)
    free    it just acts.

Some things are asked about at EVERY level: sending, buying, paying, deleting,
passwords, killing apps, running scripts, downloads, the clipboard. The
level is one setting (STATE/hands.json), changeable from the window, the
phone, or by voice.

HOW IT IS ENFORCED, not merely requested: the voice session's Claude Code runs
`gate` (below) as a PreToolUse hook on every hands tool and every Bash call.
A hook's "deny" holds even under bypassPermissions, so the level is a wall,
not a suggestion in a prompt. Bash is watched too, so `cua-driver call click`
cannot walk around it.

`gate` is deliberately stdlib-only: it runs before every tool call.
"""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

LEVELS = ("watch", "ask", "free")
DEFAULT_LEVEL = "ask"
SERVER = "hands"                       # MCP server name -> tools are mcp__hands__*
PREFIX = f"mcp__{SERVER}__"
# Tested against this release. install.sh installs exactly it.
PINNED = "0.49.11"
APP = "/Applications/CuaDriver.app"

# Looking, never acting.
_READ = {
    "get_desktop_state", "get_window_state", "get_screen_size", "get_cursor_position",
    "get_config", "get_guide", "get_session", "get_agent_cursor_state",
    "get_recording_state", "get_browser_state", "get_accessibility_tree",
    "list_apps", "list_windows", "list_sessions", "check_permissions",
    "check_for_update", "health_report", "zoom", "page", "verify_state",
    "parse_visual_regions", "start_session", "end_session",
    "set_agent_cursor_enabled", "set_agent_cursor_motion", "set_agent_cursor_theme",
    "move_cursor",
}
# Asked about even in "free": irreversible, or reaches outside the screen.
_ALWAYS_ASK = {
    "kill_app", "run_script", "browser_download", "browser_set_input_files",
    "clipboard_read", "clipboard_write", "set_config", "install_extension",
    "replay_trajectory", "install_ffmpeg",
}
_RISKY = re.compile(
    r"\b(send|submit|pay|payment|buy|purchase|order|checkout|check out|delete|"
    r"remove|trash|erase|wipe|transfer|password|passcode|passphrase|"
    r"post|publish|tweet|sign ?in|log ?in|unsubscribe|empty)\b", re.I)


def _home() -> Path:
    return Path(os.environ.get("MEM_VOICE_HOME", Path.home() / ".mem-voice"))


CONFIG_NAME = "hands.json"


# ---- the level ----------------------------------------------------------------

def level() -> str:
    try:
        v = json.loads((_home() / CONFIG_NAME).read_text()).get("level")
    except (OSError, ValueError, AttributeError):
        v = None
    return v if v in LEVELS else DEFAULT_LEVEL


def set_level(v: str) -> str:
    v = (v or "").strip().lower()
    if v not in LEVELS:
        raise ValueError(f"level must be one of {', '.join(LEVELS)}")
    p = _home() / CONFIG_NAME
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps({"level": v}) + "\n")
    tmp.replace(p)
    return v


# ---- the engine -----------------------------------------------------------------

def driver() -> str:
    """Path to the cua-driver CLI, or ""."""
    for p in (shutil.which("cua-driver"), str(Path.home() / ".local/bin/cua-driver"),
              f"{APP}/Contents/MacOS/cua-driver"):
        if p and os.path.exists(p):
            return p
    return ""


def installed_version() -> str:
    exe = driver()
    if not exe:
        return ""
    try:
        out = subprocess.run([exe, "--version"], capture_output=True, text=True,
                             timeout=5).stdout
    except (OSError, subprocess.TimeoutExpired):
        return ""
    m = re.search(r"(\d+\.\d+\.\d+)", out or "")
    return m.group(1) if m else ""


def permissions() -> dict:
    """{'accessibility': bool|None, 'screen': bool|None} for Cua Driver itself.
    Never prompts."""
    exe = driver()
    if not exe:
        return {"accessibility": None, "screen": None}
    try:
        p = subprocess.run([exe, "permissions", "status", "--json"],
                           capture_output=True, text=True, timeout=15)
        st = json.loads(p.stdout or "{}")
    except (OSError, subprocess.TimeoutExpired, ValueError):
        return {"accessibility": None, "screen": None}

    def find(d, *keys):
        for k in keys:
            if isinstance(d, dict) and k in d:
                v = d[k]
                if isinstance(v, dict):
                    v = v.get("granted", v.get("ok", v.get("enabled")))
                return bool(v) if v is not None else None
        return None
    return {"accessibility": find(st, "accessibility", "Accessibility"),
            "screen": find(st, "screen_recording", "screenRecording", "screen")}


def status() -> dict:
    exe = driver()
    st = {"installed": bool(exe), "version": installed_version() if exe else "",
          "pinned": PINNED, "level": level()}
    if exe:
        st.update(permissions())
    st["ready"] = bool(exe and st.get("accessibility") and st.get("screen"))
    return st


def grant() -> int:
    """Cua Driver's own two-switch guide (it names Cua Driver in System
    Settings, not Mem or a terminal)."""
    exe = driver()
    if not exe:
        print("Cua Driver is not installed. Re-run Mem's installer:\n"
              "  curl -fsSL https://saivinay.me/mem/install.sh | sh")
        return 1
    return subprocess.call([exe, "permissions", "grant"])


def call(tool: str, args: dict | None = None, timeout: float = 20) -> dict:
    """Run one cua-driver tool and return its JSON result. Raises on failure."""
    exe = driver()
    if not exe:
        raise RuntimeError("Cua Driver is not installed")
    p = subprocess.run([exe, "call", tool, json.dumps(args or {})],
                       capture_output=True, text=True, timeout=timeout)
    if p.returncode != 0:
        raise RuntimeError((p.stderr or p.stdout or f"{tool} failed").strip()[:300])
    try:
        return json.loads(p.stdout or "{}")
    except ValueError:
        return {"text": p.stdout}


def mcp_config() -> dict | None:
    """The --mcp-config for Mem's voice session, or None if there is no engine."""
    exe = driver()
    if not exe:
        return None
    return {"mcpServers": {SERVER: {"command": exe, "args": ["mcp"]}}}


_FAIL_CLOSED = json.dumps({"hookSpecificOutput": {
    "hookEventName": "PreToolUse", "permissionDecision": "deny",
    "permissionDecisionReason": "The hands gate could not run, so nothing was "
                                "done. Tell them hands need fixing (mem hands status)."}})


def hook_settings(python: str | None = None) -> dict:
    """The --settings that puts `gate` in front of every hands tool and Bash.

    FAIL CLOSED for the hands tools: Claude Code treats a hook that crashes
    as "carry on", so a broken gate (a bad install, a missing module) would
    silently mean no gate at all. Found exactly that way: a stale install,
    level on watch, and TextEdit opened anyway. So if the gate does not answer,
    the shell prints a deny instead. Bash fails OPEN: a broken gate must not
    take every shell command in the voice session down with it, and the Bash
    check only exists to stop a walk-around, not to be the wall.
    """
    import shlex
    py = shlex.quote(python or sys.executable)
    gate = f"{py} -m mem.voice.hands gate"
    closed = f"{gate} || printf '%s\\n' {shlex.quote(_FAIL_CLOSED)}"
    return {"hooks": {"PreToolUse": [
        {"matcher": f"{PREFIX}.*",
         "hooks": [{"type": "command", "command": closed, "timeout": 150}]},
        {"matcher": "Bash",
         "hooks": [{"type": "command", "command": gate, "timeout": 20}]},
    ]}}


# ---- deciding -------------------------------------------------------------------

def _strings(x, out: list) -> list:
    if isinstance(x, str):
        out.append(x)
    elif isinstance(x, dict):
        for k, v in x.items():
            if k not in ("element_token", "capture_id", "session", "snapshot_id"):
                _strings(v, out)
    elif isinstance(x, list):
        for v in x:
            _strings(v, out)
    return out


def _steps(args: dict) -> list[tuple[str, dict]]:
    out = []
    for s in args.get("steps") or []:
        if not isinstance(s, dict):
            continue
        if "tool" in s:
            out.append((str(s.get("tool")), s.get("args") or {}))
        else:
            for k, v in s.items():
                if k not in ("wait_for", "expect") and isinstance(v, dict):
                    out.append((k, v))
    return out


def classify(tool: str, args: dict) -> str:
    """'read', 'act', or 'risky'."""
    tool = tool.removeprefix(PREFIX)
    if tool == "run_steps":
        kinds = [classify(t, a) for t, a in _steps(args)] or ["act"]
        if "risky" in kinds:
            return "risky"
        return "act" if "act" in kinds else "read"
    if tool in _ALWAYS_ASK:
        return "risky"
    if tool in _READ:
        return "read"
    if tool in ("press_key", "hotkey"):
        keys = " ".join(_strings(args, [])).lower()
        # Return in a mail/chat window is a send; cmd+delete is a delete.
        if re.search(r"\b(return|enter)\b", keys) and re.search(r"\bcmd|command\b", keys):
            return "risky"
        if re.search(r"\b(delete|backspace)\b", keys) and re.search(r"\bcmd|command\b", keys):
            return "risky"
    if _RISKY.search(" ".join(_strings(args, []))):
        return "risky"
    return "act"


def _what(tool: str, args: dict) -> str:
    """'click "Send" in Mail' -- short enough to say out loud."""
    tool = tool.removeprefix(PREFIX)
    if tool == "run_steps":
        parts = [_what(t, a) for t, a in _steps(args)]
        if not parts:
            return "do several steps"
        s = ", then ".join(parts[:4])
        return s + (f", and {len(parts) - 4} more steps" if len(parts) > 4 else "")
    name = args.get("name") or args.get("title") or args.get("label")
    app = args.get("app") or args.get("bundle_id")
    verb = {
        "click": "click", "double_click": "double-click", "right_click": "right-click",
        "type_text": "type", "set_value": "fill in", "press_key": "press",
        "hotkey": "press", "scroll": "scroll", "drag": "drag", "launch_app": "open",
        "bring_to_front": "bring forward", "invoke_menu": "choose the menu item",
        "kill_app": "force-quit", "run_script": "run a script",
        "clipboard_write": "change the clipboard", "clipboard_read": "read the clipboard",
        "browser_click": "click", "browser_type": "type", "browser_navigate": "go to",
        "browser_download": "download", "set_window_frame": "move a window",
    }.get(tool, tool.replace("_", " "))
    obj = ""
    if tool in ("type_text", "browser_type"):
        t = str(args.get("text") or "")
        obj = f'"{t[:60]}{"…" if len(t) > 60 else ""}"'
    elif tool == "set_value":
        obj = f'"{str(args.get("value") or "")[:60]}" into {name or "a field"}'
    elif tool in ("press_key", "hotkey"):
        obj = str(args.get("key") or args.get("keys") or args.get("combo") or "")
    elif tool == "browser_navigate":
        obj = str(args.get("url") or "")
    elif tool == "invoke_menu":
        path = args.get("path") or args.get("menu_path") or []
        obj = " > ".join(map(str, path)) if isinstance(path, list) else str(path)
    elif name:
        obj = f'"{name}"'
    elif tool in ("click", "double_click", "right_click") and "x" in args:
        obj = "a spot on the screen"
    s = f"{verb} {obj}".strip()
    if app and tool != "launch_app":
        s += f" in {app}"
    elif tool == "launch_app" and app:
        s = f"open {app}"
    return s


_CUA_CLI = re.compile(r"(^|[\s;&|/`(])cua-driver(\s|$)")
_CUA_SAFE = re.compile(r"cua-driver\s+(--version|--help|list-tools|describe|status|"
                       r"permissions\s+status|doctor|get_)", re.I)


def decide(tool: str, args: dict, lvl: str | None = None) -> tuple[str, str]:
    """('allow' | 'deny' | 'ask', reason)."""
    lvl = lvl or level()
    if tool == "Bash":
        cmd = str((args or {}).get("command") or "")
        if _CUA_CLI.search(cmd) and not _CUA_SAFE.search(cmd):
            return "deny", ("Use the hands tools (mcp__hands__*), not the cua-driver CLI, "
                            "so the control level you set applies.")
        return "allow", ""
    kind = classify(tool, args or {})
    if kind == "read":
        return "allow", ""
    if lvl == "watch":
        return "deny", ("Hands are on WATCH: you may look and point but not act. "
                        "Say what you would do and ask them to switch hands to "
                        "Ask or Free.")
    if lvl == "free" and kind == "act":
        return "allow", ""
    return "ask", _what(tool, args or {})


def _ask_mem(what: str, tool: str, risky: bool) -> tuple[bool, str]:
    """Put it to the person through the Mem window. Blocks until they answer."""
    import urllib.request
    port = os.environ.get("MEM_PORT", "").strip()
    if not port:
        try:
            port = (_home() / "port").read_text().strip()
        except OSError:
            port = ""
    if not port:
        return False, "Mem's window is not open, so nobody can approve this. Not done."
    body = json.dumps({"what": what, "tool": tool, "risky": risky}).encode()
    req = urllib.request.Request(f"http://127.0.0.1:{port}/hands/ask", data=body,
                                 headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=140) as r:
            res = json.loads(r.read() or b"{}")
    except Exception as e:                              # noqa: BLE001
        return False, f"Could not ask for approval ({type(e).__name__}). Not done."
    if res.get("allow"):
        return True, ""
    return False, res.get("reason") or "They said no. Do not do it; ask what they want instead."


def gate(stdin=None) -> int:
    """The PreToolUse hook. Reads Claude Code's hook JSON on stdin."""
    try:
        payload = json.load(stdin or sys.stdin)
    except ValueError:
        return 0
    tool = str(payload.get("tool_name") or "")
    args = payload.get("tool_input") or {}
    verdict, why = decide(tool, args)
    if verdict == "ask":
        ok, why = _ask_mem(why, tool.removeprefix(PREFIX),
                           classify(tool, args) == "risky")
        verdict = "allow" if ok else "deny"
    if verdict == "allow":
        return 0                         # say nothing: the normal flow continues
    print(json.dumps({"hookSpecificOutput": {
        "hookEventName": "PreToolUse",
        "permissionDecision": "deny",
        "permissionDecisionReason": why}}))
    return 0


# ---- spoken answers -------------------------------------------------------------

_YES = re.compile(r"^\W*(yes|yeah|yep|yup|ya|sure|ok|okay|go ahead|do it|go for it|"
                  r"approve[d]?|allow( it)?|please do|confirm(ed)?|affirmative|haan|"
                  r"ha)\b", re.I)
_NO = re.compile(r"^\W*(no|nope|nah|don'?t|do not|stop|cancel|deny|wait|hold on|"
                 r"never mind|nevermind|not now)\b", re.I)


def spoken_answer(text: str) -> bool | None:
    """True for a yes, False for a no, None if it is neither."""
    t = (text or "").strip()
    if _NO.search(t):
        return False
    if _YES.search(t):
        return True
    return None


# ---- `mem hands` ----------------------------------------------------------------

def main(argv: list[str] | None = None) -> int:
    argv = list(argv if argv is not None else sys.argv[1:])
    cmd = argv[0] if argv else "status"
    if cmd == "gate":
        return gate()
    if cmd in LEVELS:
        set_level(cmd)
        print(f"Hands: {cmd}. Restart isn't needed.")
        return 0
    if cmd == "level":
        if len(argv) > 1:
            print(f"Hands: {set_level(argv[1])}")
        else:
            print(level())
        return 0
    if cmd == "grant":
        return grant()
    if cmd == "status":
        st = status()
        if not st["installed"]:
            print("engine        : not installed (re-run Mem's installer)")
        else:
            v = st["version"]
            print(f"engine        : Cua Driver {v}" + ("" if v == PINNED else f" (Mem is tested with {PINNED})"))
            ok = lambda b: "on" if b else ("off" if b is False else "unknown")  # noqa: E731
            print(f"accessibility : {ok(st.get('accessibility'))}")
            print(f"screen        : {ok(st.get('screen'))}")
        print(f"level         : {st['level']}  (mem hands watch|ask|free)")
        if st["installed"] and not st["ready"]:
            print("\nTurn the switches on once: mem hands grant")
        return 0
    print(__doc__.strip().split("\n\n")[0])
    print("\nusage: mem hands [status|watch|ask|free|grant]")
    return 2


if __name__ == "__main__":
    sys.exit(main())
