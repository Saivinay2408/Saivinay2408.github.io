"""
interview — onboarding as a conversation, in the window.

`docs/QUICKSTART.md` is ten questions that produce a working clone. Answering
it means copying a markdown file, finding an editor, writing under each
heading, saving it somewhere, then running two CLI commands. That is a fine
path for the person who is already sold, and it is the wrong first thing to
ask of anyone else — most people who install this will never open that file.

So the app asks. One question at a time, spoken out loud and printed to read,
answered by holding space or by typing. At the end it writes exactly the
markdown `mem onboard` already parses and runs it, so this is a FACE over the
existing pipeline and not a second one that can drift from it.

THREE THINGS THAT ARE NOT OPTIONAL, AND WHY
-------------------------------------------
1. Everything is saved as you go. `~/.mem-voice/interview.json` after every
   answer. These questions take real thought and some of them are personal;
   losing that to a closed window would be unforgivable, and "start again"
   is not a recovery path a person will take twice.

2. Skipping is a first-class answer. A skipped question costs you the facts it
   would have produced and nothing else. There is no completeness score, and
   nothing downstream checks whether you finished.

3. The last step is explicit and it says what it costs. `--apply` sends your
   answers to whatever MEM_EXTRACTOR_CMD points at, which by default is a
   hosted model. That is a real trade and it is made with a button that says
   so, not silently at the end of a wizard.

WHY THE QUESTIONS ARE IN THIS FILE
----------------------------------
`docs/` is not shipped in the wheel; the package is. Rather than have the app
read a file that may not exist, the set lives here — and each entry carries a
SHORT form as well, because a question written to be read on a page ("For each
thing: what it is, why you started it, what done looks like…") is unbearable
read aloud. Written form goes in the file for the extractor, spoken form comes
out of the speaker. tests/test_interview.py checks this list against
docs/QUICKSTART.md whenever the repo is present, so the two cannot drift.
"""
from __future__ import annotations

import datetime
import json
import threading
from pathlib import Path

from .paths import STATE, ensure_state

STATE_FILE = STATE / "interview.json"

# section: (number, title, feeds)  ->  questions
SECTIONS = [
    {
        "num": 1, "title": "Right now", "feeds": ["projects/", "goals/"],
        "why": "This is what loads into every session. It goes stale fastest "
               "and matters most day to day.",
        "questions": [
            {
                "num": 1,
                "ask": "What are you actually working on right now?",
                "hint": "For each thing: what it is, why you started it, what "
                        "done looks like, and what is blocking it. Include the "
                        "dead ones you have not admitted are dead.",
                "question": "What are you actually working on right now? For "
                            "each thing: what it is, why you started it, what "
                            "\"done\" looks like, and what is currently "
                            "blocking it. Include the dead ones you have not "
                            "admitted are dead.",
            },
            {
                "num": 2,
                "ask": "What are you trying to be true in a year that is not "
                       "true today?",
                "hint": "Career, money, health, relationships, skill — "
                        "whatever is real, not what sounds good.",
                "question": "What are you trying to be true in a year that is "
                            "not true today? Career, money, health, "
                            "relationships, skill — whatever is real, not what "
                            "sounds good.",
            },
        ],
    },
    {
        "num": 2, "title": "Your people", "feeds": ["people/"],
        "why": "The highest-value section. An agent that does not know who "
               "your people are will write to your co-founder the way it "
               "writes to a stranger.",
        "questions": [
            {
                "num": 3,
                "ask": "Who comes up constantly in your life and work?",
                "hint": "For each: who they are to you, what they are actually "
                        "like, what you are working on together, and what you "
                        "would never say to them.",
                "question": "Who comes up constantly in your life and work? "
                            "For each: who they are to you, what they are "
                            "actually like, what you are working on together, "
                            "and what you would never say to them.",
            },
        ],
    },
    {
        "num": 3, "title": "How you decide", "feeds": ["identity", "eval/"],
        "why": "Skip everything else before you skip this one. It is what "
               "makes a clone make your call rather than the median call.",
        "questions": [
            {
                "num": 4,
                "ask": "Describe two recent decisions where the obvious answer "
                       "was wrong and you did something else.",
                "hint": "What did you see that the obvious answer missed?",
                "question": "Describe two recent decisions where the obvious "
                            "answer was wrong and you did something else. What "
                            "did you see that the obvious answer missed?",
            },
            {
                "num": 5,
                "ask": "When you are stuck between two good options, what "
                       "actually breaks the tie?",
                "hint": "Not what you would say in an interview. Speed, cost, "
                        "who it affects, reversibility, whether it is "
                        "interesting, something else?",
                "question": "When you are stuck between two good options, what "
                            "actually breaks the tie — not what you would say "
                            "in an interview. Speed, cost, who it affects, "
                            "reversibility, whether it is interesting, "
                            "something else?",
            },
            {
                "num": 6,
                "ask": "What do you always say no to?",
                "hint": "Kinds of work, kinds of people, kinds of requests. Be "
                        "specific enough that an agent could apply the rule.",
                "question": "What do you always say no to? Kinds of work, "
                            "kinds of people, kinds of requests. Be specific "
                            "enough that an agent could apply the rule.",
            },
        ],
    },
    {
        "num": 4, "title": "How you write", "feeds": ["identity", "output register"],
        "why": "This is the section that produces the \"that actually sounds "
               "like me\" moment, and it does it from examples rather than "
               "description. Typing suits it better than talking.",
        "questions": [
            {
                "num": 7,
                "ask": "Paste four or five things you have written to other "
                       "people.",
                "hint": "Real ones — messages, emails, a commit message, a "
                        "post. Yours only, no replies. Mix registers: casual, "
                        "formal, and something written while annoyed.",
                "question": "Paste four or five things you have written to "
                            "other people. Real ones — messages, emails, a "
                            "commit message, a post. Yours only, no replies. "
                            "Mix registers: something casual, something "
                            "formal, something written while annoyed.",
                "typed": True,
            },
            {
                "num": 8,
                "ask": "What in AI-written text makes you wince?",
                "hint": "Words, punctuation, structures, openers. Name them "
                        "exactly — these become hard rules.",
                "question": "What in AI-written text makes you wince? Words, "
                            "punctuation, structures, openers. Name them "
                            "exactly, because these become hard rules.",
            },
        ],
    },
    {
        "num": 5, "title": "How you build", "feeds": ["procedures/"],
        "why": "",
        "questions": [
            {
                "num": 9,
                "ask": "What is your stack, and what are your non-negotiables "
                       "when you build?",
                "hint": "The rules you apply without thinking, and how you "
                        "know a piece of work is actually finished rather than "
                        "nearly finished.",
                "question": "What is your stack, and what are your "
                            "non-negotiables when you build? The rules you "
                            "apply without thinking about them, and how you "
                            "know a piece of work is actually finished rather "
                            "than nearly finished.",
            },
        ],
    },
    {
        "num": 6, "title": "Hard lines and blind spots", "feeds": ["identity"],
        "why": "",
        "questions": [
            {
                "num": 10,
                "ask": "What must this never do or say on your behalf, no "
                       "matter who asks — and what are you genuinely bad at?",
                "hint": "The second half matters: name where you would rather "
                        "be pushed back on than agreed with.",
                "question": "Two things: what must this never do or say on "
                            "your behalf, no matter who asks — and what are "
                            "you genuinely bad at, where you would rather be "
                            "pushed back on than agreed with?",
            },
        ],
    },
]

# Answering the first three sections is enough for a working clone; that is
# the promise QUICKSTART makes, and the app makes the same one at question 6.
CORE_THROUGH = 6

QUESTIONS = [
    {**q, "section": s["num"], "sectionTitle": s["title"], "why": s["why"]}
    for s in SECTIONS for q in s["questions"]
]

SKIPPED = "skip"


def _load() -> dict:
    try:
        data = json.loads(STATE_FILE.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    if not isinstance(data, dict):
        return {}
    return data


class Interview:
    """One interview at a time, saved after every answer.

    Held by the Dashboard rather than the voice loop, because it must work
    identically whether you are speaking or typing — and with the mic off
    entirely, which is how most people will first try it.
    """

    def __init__(self, dash) -> None:
        self.dash = dash
        self._lock = threading.RLock()
        data = _load()
        self.answers: dict[str, str] = {
            str(k): v for k, v in (data.get("answers") or {}).items()
            if isinstance(v, str)}
        self.at: int = int(data.get("at") or 0)
        self.active: bool = False
        self.done: bool = bool(data.get("done"))

    # ---- state ----------------------------------------------------------

    def _save(self) -> None:
        ensure_state()
        STATE_FILE.write_text(json.dumps({
            "answers": self.answers, "at": self.at, "done": self.done,
        }, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    def status(self) -> dict:
        """Everything the UI needs to draw the panel, answered or not."""
        with self._lock:
            q = QUESTIONS[self.at] if 0 <= self.at < len(QUESTIONS) else None
            answered = sum(1 for k, v in self.answers.items()
                           if v and v.strip().lower() != SKIPPED)
            return {
                "active": self.active,
                "at": self.at,
                "n": len(QUESTIONS),
                "answered": answered,
                "done": self.done,
                "coreLeft": max(0, CORE_THROUGH - answered),
                "current": dict(q) if q else None,
                "answer": self.answers.get(str(q["num"]), "") if q else "",
                # A list for the strip of dots, so you can see the shape of
                # what is left and jump back to something you rushed.
                "marks": [{"num": x["num"],
                           "state": self._mark(x["num"])} for x in QUESTIONS],
            }

    def _mark(self, num: int) -> str:
        v = (self.answers.get(str(num)) or "").strip()
        if not v:
            return "open"
        return "skipped" if v.lower() == SKIPPED else "answered"

    def _emit(self) -> None:
        self.dash.emit_raw({"t": "interview", "v": self.status()})

    # ---- driving --------------------------------------------------------

    def start(self, at: int | None = None) -> dict:
        with self._lock:
            self.active = True
            if at is not None:
                self.at = max(0, min(int(at), len(QUESTIONS) - 1))
            elif self.at >= len(QUESTIONS):
                self.at = 0
        self._emit()
        self.speak_current()
        return self.status()

    def stop(self) -> dict:
        """Leave the interview. Answers stay; this is a pause, not a discard.

        Load-bearing beyond politeness: while the interview is active your
        voice goes to IT and not to the session you are looking at, so there
        has to be an unmistakable way out. Anything else is a mode you can get
        stuck in, which is the worst thing a voice interface can do.
        """
        with self._lock:
            self.active = False
        self._emit()
        return self.status()

    def go(self, at: int) -> dict:
        with self._lock:
            self.at = max(0, min(int(at), len(QUESTIONS) - 1))
            self._save()
        self._emit()
        if self.active:
            self.speak_current()
        return self.status()

    def answer(self, text: str, advance: bool = True) -> dict:
        """Record an answer. Speech arrives here in pieces, so it APPENDS.

        Nobody answers "who are your people" in one breath. Each utterance is
        added to the answer rather than replacing it, which also means a
        mistranscribed sentence is a sentence to edit rather than a lost
        answer — the text box holds the running answer and stays editable.
        """
        text = (text or "").strip()
        if not text:
            return self.status()
        with self._lock:
            q = QUESTIONS[self.at]
            key = str(q["num"])
            prev = (self.answers.get(key) or "").strip()
            self.answers[key] = f"{prev}\n\n{text}".strip() if prev else text
            self._save()
        self._emit()
        if advance:
            self.next()
        return self.status()

    def replace(self, text: str) -> dict:
        """What the text box holds is the answer. Used when you edit it."""
        with self._lock:
            self.answers[str(QUESTIONS[self.at]["num"])] = (text or "").strip()
            self._save()
        self._emit()
        return self.status()

    def skip(self) -> dict:
        with self._lock:
            self.answers[str(QUESTIONS[self.at]["num"])] = SKIPPED
            self._save()
        return self.next()

    def next(self) -> dict:
        with self._lock:
            last = self.at >= len(QUESTIONS) - 1
            if not last:
                self.at += 1
            # Where you are is part of what gets restored. Saving the answer
            # but not the position reopened the interview on a question you
            # had already answered, which reads as work lost even though it
            # was not.
            self._save()
        self._emit()
        if self.active and not last:
            self.speak_current()
        return self.status()

    def back(self) -> dict:
        return self.go(self.at - 1)

    # ---- the voice half -------------------------------------------------

    def speak_current(self) -> None:
        """Ask the question out loud.

        Short form only. The written question carries the "for each: what it
        is, why you started it…" clauses because on a page they are a helpful
        checklist, and read aloud they are a wall you have stopped listening
        to by the third comma. The full text is on screen the whole time.
        """
        voice = getattr(self.dash, "voice", None)
        if voice is None:
            return
        q = QUESTIONS[self.at] if 0 <= self.at < len(QUESTIONS) else None
        if q is None:
            return
        try:
            voice.say_sample(q["ask"])
        except Exception:                                   # noqa: BLE001
            pass                                            # a silent question is still a question

    def take_utterance(self, text: str) -> bool:
        """Called by the voice loop before it sends anything to a session.

        Returns True if the interview consumed it. `advance=False` on purpose:
        a spoken answer usually comes in several goes, and auto-advancing on
        the first pause would cut people off mid-thought. You move on when you
        say so.
        """
        if not self.active:
            return False
        self.answer(text, advance=False)
        return True

    # ---- the end --------------------------------------------------------

    def markdown(self) -> str:
        """Exactly the shape `mem onboard` parses.

        Sections as `## <n>. <title> (feeds: …)`, questions as `<n>. <text>`
        with a blank line before each one — the parser uses that blank line to
        tell a real question from an enumerated list inside an answer, so it is
        structural here rather than cosmetic. Unanswered questions are written
        with `skip` under them, which the parser already understands.
        """
        when = datetime.date.today().isoformat()
        out = [f"# Interview — answered in the app, {when}", ""]
        for s in SECTIONS:
            feeds = ", ".join(s["feeds"])
            out.append(f"## {s['num']}. {s['title']}"
                       + (f" (feeds: {feeds})" if feeds else ""))
            out.append("")
            for q in s["questions"]:
                out.append(f"{q['num']}. {q['question']}")
                out.append("")
                out.append((self.answers.get(str(q["num"])) or SKIPPED).strip())
                out.append("")
        return "\n".join(out) + "\n"

    def write(self) -> Path:
        ensure_state()
        path = STATE / f"interview-{datetime.date.today().isoformat()}.md"
        path.write_text(self.markdown(), encoding="utf-8")
        with self._lock:
            self.done = True
            self.active = False
            self._save()
        self._emit()
        return path
