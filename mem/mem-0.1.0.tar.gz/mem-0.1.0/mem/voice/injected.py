"""
injected — what your agents are actually being told, and what we changed to
tell them.

This replaces a page that listed CLAUDE.md files. That page answered a
question nobody asks ("where do rules files live?") and left the real one
unanswered: THIS THING EDITS WHAT MY AGENT SEES — show me what it adds.

Nobody opens a directory of markdown to find out. So the page shows the text
itself:

  always      the identity block loaded at the start of every session, exactly
              as the hook emits it
  per message the recall block, which depends on what you type — so instead of
              describing it, you type something and see what would be added
  config      the block we wrote into each agent's rules file, separated from
              the part you wrote, because "what did it change in my CLAUDE.md"
              deserves an answer more precise than "look at the file"
  learned     the newest facts in the vault, each with the words of yours it
              was extracted from

Everything here is read-only and every item names a file, because the point of
showing it is that you can go and change it.
"""
from __future__ import annotations

import re
from pathlib import Path

from ..config import vault_path
from . import agents_ui

# Rough, and labelled as rough wherever it is shown. Real tokenisation needs
# the model's own tokeniser; four characters per token is close enough to
# answer "is this block enormous or not", which is the actual question.
CHARS_PER_TOKEN = 4

RECENT_NOTES = 8
PREVIEW_CHARS = 4000


def _approx_tokens(text: str) -> int:
    return round(len(text) / CHARS_PER_TOKEN)


def always() -> dict:
    """The session-start block, produced by the same function the hook calls.

    Not a reconstruction of it: `hooks.session_start` is imported and run, so
    what this page shows and what your agent receives cannot drift apart.
    """
    from ..hooks import IDENTITY_CORE, session_start

    vault = vault_path()
    try:
        text = session_start(vault)
    except Exception as e:                                  # noqa: BLE001
        return {"ok": False, "error": f"{type(e).__name__}: {e}",
                "text": "", "tokens": 0, "sources": []}

    sources = []
    for name in IDENTITY_CORE:
        path = vault / name
        try:
            size = path.stat().st_size
        except OSError:
            size = 0
        sources.append({"name": name, "path": str(path),
                        "exists": size > 0, "bytes": size})
    return {"ok": True, "error": "", "text": text[:PREVIEW_CHARS],
            "truncated": len(text) > PREVIEW_CHARS,
            "tokens": _approx_tokens(text), "sources": sources}


def preview(prompt: str) -> dict:
    """What would be added to your agent's context if you sent this message.

    The recall block is relevance-gated, so most messages get nothing at all —
    and "nothing" is the answer people least expect and most need to see. A
    description of the mechanism cannot show that; running it can.
    """
    from ..hooks import prompt_submit

    text = (prompt or "").strip()
    if not text:
        return {"ok": True, "text": "", "tokens": 0, "empty": True,
                "why": "Type something you would actually ask."}
    try:
        block = prompt_submit(text, vault_path()) or ""
    except Exception as e:                                  # noqa: BLE001
        return {"ok": False, "error": f"{type(e).__name__}: {e}",
                "text": "", "tokens": 0}
    return {
        "ok": True, "error": "", "text": block[:PREVIEW_CHARS],
        "truncated": len(block) > PREVIEW_CHARS,
        "tokens": _approx_tokens(block),
        "empty": not block,
        "why": "" if block else
               "Nothing relevant enough. Retrieval has a floor and injects "
               "nothing rather than injecting noise — most messages land here, "
               "and that is the design working.",
    }


def config(cwd: str = "") -> list[dict]:
    """Per agent: the block we wrote into its rules file, and what is yours.

    Split on the markers `mem init` writes. Anything outside them was written
    by a person and is reported as such, because the fear this page exists to
    settle is "what did it do to my CLAUDE.md".
    """
    from ..agents import BLOCK_END, BLOCK_START

    out = []
    for rule in agents_ui.rules(cwd or None):
        path = Path(rule["path"])
        row = {
            "agent": rule.get("agent", ""),
            "name": rule["name"],
            "scope": rule["scope"],
            "path": str(path),
            "exists": rule["exists"],
            "ours": "",
            "yoursBytes": 0,
            "managed": False,
        }
        if rule["exists"]:
            try:
                text = path.read_text(encoding="utf-8")
            except OSError:
                text = ""
            if BLOCK_START in text and BLOCK_END in text:
                inner = text.split(BLOCK_START, 1)[1].split(BLOCK_END, 1)[0]
                row["ours"] = inner.strip()[:PREVIEW_CHARS]
                row["managed"] = True
                rest = (text.split(BLOCK_START, 1)[0]
                        + text.split(BLOCK_END, 1)[1])
                row["yoursBytes"] = len(rest.strip())
            else:
                row["yoursBytes"] = len(text.strip())
        out.append(row)
    return out


def _title(path: Path) -> str:
    try:
        head = path.read_text(encoding="utf-8")[:800]
    except OSError:
        return path.stem
    m = re.search(r"^#\s+(.+)$", head, re.M)
    if m:
        return m.group(1).strip()
    m = re.search(r"^title:\s*(.+)$", head, re.M)
    return m.group(1).strip() if m else path.stem


def _quote(path: Path) -> str:
    """The user's own words this note was grounded in.

    The vault records provenance because extraction is not allowed to invent a
    fact and attribute it to nothing. Surfacing that quote here is what turns
    "it decided this about you" into something you can check.
    """
    try:
        text = path.read_text(encoding="utf-8")
    except OSError:
        return ""
    # The vault's own shape: one fact per line under "Current facts", as
    #   - key:: the claim (valid_from: <date>, provenance: [[the-session]])
    # The claim is the part worth showing; the provenance link is what makes it
    # checkable, so both come back.
    m = re.search(r"^-\s+([a-z_]+)::\s*(.+?)\s*\(valid_from:.*?provenance:\s*"
                  r"\[\[([^\]]+)\]\]", text, re.M | re.I)
    if m:
        return f"{m.group(2).strip()[:200]}  —  {m.group(3).strip()}"
    m = re.search(r"^-\s+([a-z_]+)::\s*(.+)$", text, re.M | re.I)
    if m:
        return m.group(2).strip()[:220]
    m = re.search(r"^>\s+(.+)$", text, re.M)
    return m.group(1).strip()[:220] if m else ""


def learned(limit: int = RECENT_NOTES) -> list[dict]:
    """The newest facts in the vault, with the words they came from."""
    vault = vault_path()
    try:
        notes = [p for p in vault.rglob("*.md")
                 if "proposals" not in p.parts and "episodic" not in p.parts]
    except OSError:
        return []
    notes.sort(key=lambda p: p.stat().st_mtime if p.exists() else 0, reverse=True)
    out = []
    for path in notes[:limit]:
        try:
            when = path.stat().st_mtime
        except OSError:
            when = 0
        out.append({
            "title": _title(path),
            "path": str(path),
            "folder": path.parent.name,
            "quote": _quote(path),
            "at": when,
        })
    return out


def snapshot(cwd: str = "") -> dict:
    """`cwd` is the project you are looking at: its rules file is part of the
    answer, and which one that is changes as you move between panes."""
    return {
        "vault": str(vault_path()),
        "always": always(),
        "config": config(cwd),
        "learned": learned(),
    }
