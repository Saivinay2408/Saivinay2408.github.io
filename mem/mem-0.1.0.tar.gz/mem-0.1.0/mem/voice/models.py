"""
models — the speech weights, and getting them without leaving the window.

WHY THIS EXISTS
---------------
`tts.py` and `stt.py` open four `.onnx`/`.bin` files by name and expect them to
be in `MEM_VOICE_MODELS`. Nothing ever put them there. On the machine this was
written on they are symlinks into a folder that exists nowhere else, so the
voice worked for exactly one person and every other install came up with a
window, an orb, and a microphone that does nothing — with no error, because
the failure is a missing file at the moment you first hold the space bar.

That made a missing downloader a release blocker for the `pip install` line,
not only for a packaged app. This is that downloader.

WHAT IT GUARANTEES
------------------
- **A partial file is never mistaken for a good one.** Downloads land in
  `<name>.part` and are renamed only after the digest matches. A cancelled or
  crashed download leaves a `.part`, which is resumed, not trusted.
- **Every byte is verified.** These are 365 MB fetched over the network and
  written into somebody's home directory; the SHA-256 of each is pinned here
  and checked before the file is put into service. A mirror that silently
  serves something else fails loudly instead of producing a voice model that
  segfaults onnxruntime.
- **It resumes.** A dropped connection 300 MB into the voice model must not
  start again from zero, so `.part` files continue with a Range request.
- **Stdlib only.** The memory engine has no dependencies and this is imported
  by the health check, which has to run on an install that never had the voice
  extra. urllib is enough.

WHISPER IS DELIBERATELY NOT HERE
--------------------------------
`faster-whisper` fetches its own weights from Hugging Face through
`huggingface_hub`, with its own cache, resume and integrity checking. Pinning a
second copy of that by hand would mean owning a mirror of somebody else's
release process. What this module does instead is *notice* whether it has
already happened, and offer to make it happen now with a progress bar, rather
than letting a 480 MB silent download start the first time somebody holds the
space bar and looks at a window that appears frozen. See `whisper_status`.
"""
from __future__ import annotations

import hashlib
import os
import shutil
import urllib.error
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Iterable

from .paths import MODELS

# How much to read per chunk. Big enough that the syscall overhead disappears
# into the network, small enough that progress moves and a cancel is felt.
CHUNK = 1 << 18          # 256 KiB
TIMEOUT = 30             # per read, not per download

# A real user agent. Some CDNs answer urllib's default with a 403.
UA = "mem-voice/0.1 (+https://github.com/)"


@dataclass(frozen=True)
class Asset:
    """One weight file.

    `name` is what tts.py/stt.py open. `remote` is what the host calls it --
    they differ for smart-turn, whose release is versioned in the filename and
    whose consumer is not.
    """
    name: str
    url: str
    sha256: str
    size: int
    what: str            # what it does, in words a person can act on
    breaks: str          # what stops working without it


# EVERY DIGEST BELOW IS OF A FILE FETCHED FROM THE URL BESIDE IT, not of the
# copy that happened to be on the machine this was written on. That distinction
# is not pedantry: the silero weights already in service here are byte-for-byte
# the same LENGTH as the ones at the pinned tag and a different build, so a
# size check would have passed and shipped a digest no fresh install could ever
# match. Re-derive these the same way if a URL ever moves -- download, hash,
# and load the result to confirm it still satisfies the interface its consumer
# in stt.py/tts.py expects.
ASSETS: tuple[Asset, ...] = (
    Asset(
        name="kokoro-v1.0.onnx",
        url="https://github.com/thewh1teagle/kokoro-onnx/releases/download/"
            "model-files-v1.0/kokoro-v1.0.onnx",
        sha256="7d5df8ecf7d4b1878015a32686053fd0eebe2bc377234608764cc0ef3636a6c5",
        size=325_532_387,
        what="the voice",
        breaks="It cannot speak.",
    ),
    Asset(
        name="voices-v1.0.bin",
        url="https://github.com/thewh1teagle/kokoro-onnx/releases/download/"
            "model-files-v1.0/voices-v1.0.bin",
        sha256="bca610b8308e8d99f32e6fe4197e7ec01679264efed0cac9140fe9c29f1fbf7d",
        size=28_214_398,
        what="the 54 voices",
        breaks="It cannot speak.",
    ),
    Asset(
        name="silero_vad.onnx",
        # Pinned to a tag, not master. `raw/master` is a moving target: the day
        # upstream lands a new model the digest here stops matching and every
        # fresh install fails verification at once.
        url="https://github.com/snakers4/silero-vad/raw/v5.1.2/"
            "src/silero_vad/data/silero_vad.onnx",
        # NOT the digest of the copy that was already on the development
        # machine. That file is the same LENGTH as this one and a different
        # build -- which is the whole argument for pinning a digest rather
        # than a size, and it was caught by this module failing its own
        # verification the first time it ran. Both satisfy the v5 interface
        # stt.py requires (inputs `input`/`state`/`sr`, state 2x1x128);
        # checked by loading each and running a frame through it.
        sha256="2623a2953f6ff3d2c1e61740c6cdb7168133479b267dfef114a4a3cc5bdd788f",
        size=2_327_524,
        what="hearing where speech starts and stops",
        breaks="It cannot tell you are talking.",
    ),
    Asset(
        name="smart-turn-v3.onnx",
        # Named `smart-turn-v3.0.onnx` upstream; stt.py opens the unversioned
        # name, so the version lives here and not in the consumer.
        url="https://huggingface.co/pipecat-ai/smart-turn-v3/resolve/main/"
            "smart-turn-v3.0.onnx",
        sha256="07a133aba31e2d0b523f17f8c2e4e65efe6d8f685efd12ca4fe21ebf4e798991",
        size=8_757_193,
        what="knowing when you have finished a sentence",
        breaks="It interrupts you mid-thought.",
    ),
)

TOTAL_BYTES = sum(a.size for a in ASSETS)

# Progress callback: (asset name, bytes done for this asset, its total).
Progress = Callable[[str, int, int], None]


class Cancelled(Exception):
    """Raised out of a fetch when the caller's `should_stop` returns True."""


# ---- what is here ---------------------------------------------------------

def path_for(asset: Asset, models_dir: Path | None = None) -> Path:
    return (Path(models_dir) if models_dir else MODELS) / asset.name


def _present(asset: Asset, models_dir: Path | None = None) -> bool:
    """Does a usable copy exist?

    Deliberately `exists()` and a size check rather than a digest: hashing 325
    MB on every health poll would make opening the Health tab take seconds.
    The digest is what gates a file INTO service (see `_verify`); this is only
    asking whether we already did that.

    `exists()` follows symlinks on purpose. A developer who has these linked in
    from somewhere else is correctly reported as having them, and correctly
    reported as not, the day the link dangles.
    """
    p = path_for(asset, models_dir)
    try:
        return p.is_file() and p.stat().st_size == asset.size
    except OSError:
        return False


def status(models_dir: Path | None = None) -> dict:
    """Everything the UI and the health check need, in one pass."""
    items = []
    for a in ASSETS:
        here = _present(a, models_dir)
        part = path_for(a, models_dir).with_suffix(path_for(a, models_dir).suffix + ".part")
        try:
            resume = part.stat().st_size if part.is_file() else 0
        except OSError:
            resume = 0
        items.append({
            "name": a.name, "what": a.what, "breaks": a.breaks,
            "size": a.size, "present": here,
            # So a resumed download can say "180 of 325 MB" rather than
            # starting the bar at zero and looking like no progress was kept.
            "resumeFrom": 0 if here else resume,
        })
    missing = [i for i in items if not i["present"]]
    return {
        "items": items,
        "dir": str(Path(models_dir) if models_dir else MODELS),
        "missing": len(missing),
        "missingBytes": sum(i["size"] - i["resumeFrom"] for i in missing),
        "totalBytes": TOTAL_BYTES,
        "ready": not missing,
    }


def missing(models_dir: Path | None = None) -> list[Asset]:
    return [a for a in ASSETS if not _present(a, models_dir)]


def free_space(models_dir: Path | None = None) -> int:
    """Bytes available where the weights would land.

    Checked before starting rather than discovered 300 MB in, which is the
    difference between "you need another 200 MB" and a disk that filled up
    while somebody was watching a progress bar.
    """
    d = Path(models_dir) if models_dir else MODELS
    probe = d
    while not probe.exists() and probe != probe.parent:
        probe = probe.parent
    try:
        return shutil.disk_usage(probe).free
    except OSError:
        return 0


# ---- getting them ---------------------------------------------------------

def _ssl_context():
    """A context that can actually verify a certificate.

    THE PYTHON.ORG INSTALLER SHIPS NO ROOT CERTIFICATES. It bundles its own
    OpenSSL, which then looks for a CA store the system does not put where it
    expects, and every https fetch dies with:

        CERTIFICATE_VERIFY_FAILED: unable to get local issuer certificate

    Apple's own python3 and Homebrew's are fine; python.org's is not until
    somebody runs its "Install Certificates.command" by hand, which nobody
    knows to do. A tester on 3.10 from python.org hit exactly this and all
    four model downloads failed at once, on a machine whose network was
    perfectly healthy.

    `certifi` carries the Mozilla CA bundle and arrives here anyway as a
    dependency of faster-whisper, so use it when it is there. Falling back to
    the default context is correct everywhere else -- and verification is
    NEVER disabled: these are 365 MB of executable model weights, and the
    digest check afterwards is not a substitute for knowing who you fetched
    them from.
    """
    import ssl
    try:
        import certifi
    except ImportError:
        return None                                    # urllib's default
    try:
        return ssl.create_default_context(cafile=certifi.where())
    except Exception:                                  # noqa: BLE001
        return None


def _verify(path: Path, sha256: str) -> bool:
    h = hashlib.sha256()
    try:
        with path.open("rb") as fh:
            for block in iter(lambda: fh.read(CHUNK), b""):
                h.update(block)
    except OSError:
        return False
    return h.hexdigest() == sha256


def fetch_one(asset: Asset, models_dir: Path | None = None,
              on_progress: Progress | None = None,
              should_stop: Callable[[], bool] | None = None) -> None:
    """Download one asset, resuming if there is a `.part` to resume.

    Raises on failure -- OSError, urllib's errors, `Cancelled`, or ValueError
    when the digest does not match. The caller turns those into something a
    person can read; this does not swallow them, because a silently skipped
    weight is the exact failure this module exists to end.
    """
    dest = path_for(asset, models_dir)
    dest.parent.mkdir(parents=True, exist_ok=True)
    part = dest.with_suffix(dest.suffix + ".part")

    have = 0
    if part.is_file():
        try:
            have = part.stat().st_size
        except OSError:
            have = 0
        # A `.part` longer than the finished file is not a resume point, it is
        # garbage from a changed URL. Start over rather than append to it.
        if have >= asset.size:
            part.unlink(missing_ok=True)
            have = 0

    req = urllib.request.Request(asset.url, headers={"User-Agent": UA})
    if have:
        req.add_header("Range", f"bytes={have}-")

    try:
        resp = urllib.request.urlopen(req, timeout=TIMEOUT, context=_ssl_context())
    except urllib.error.HTTPError as e:
        # 416 means our `.part` is at or past the end of what the server has:
        # the file changed under us. Throw it away and take the whole thing.
        if e.code == 416 and have:
            part.unlink(missing_ok=True)
            return fetch_one(asset, models_dir, on_progress, should_stop)
        raise

    with resp:
        # A server that ignores Range answers 200 with the whole file, and
        # appending that to a partial one produces a corrupt result that only
        # the digest would catch. Trust the status code, not the request.
        resuming = resp.status == 206 and have > 0
        if not resuming:
            have = 0
        mode = "ab" if resuming else "wb"
        done = have
        if on_progress:
            on_progress(asset.name, done, asset.size)

        with part.open(mode) as fh:
            while True:
                if should_stop and should_stop():
                    raise Cancelled(asset.name)
                block = resp.read(CHUNK)
                if not block:
                    break
                fh.write(block)
                done += len(block)
                if on_progress:
                    on_progress(asset.name, done, asset.size)

    if not _verify(part, asset.sha256):
        # Keep nothing. A file that failed its digest is not a resume point --
        # resuming it would append good bytes to bad ones forever.
        part.unlink(missing_ok=True)
        raise ValueError(f"{asset.name}: downloaded file did not match its checksum")

    # Atomic, and only now. Until this line no reader can see anything but the
    # `.part`, so tts.py can never open a half-written model.
    os.replace(part, dest)
    if on_progress:
        on_progress(asset.name, asset.size, asset.size)


def fetch(assets: Iterable[Asset] | None = None, models_dir: Path | None = None,
          on_progress: Progress | None = None,
          should_stop: Callable[[], bool] | None = None) -> dict:
    """Fetch what is missing. Returns a report rather than raising.

    One asset failing does not abandon the rest: three of the four are small,
    and a machine that got hearing and turn-detection but not the voice is in a
    better state than one that got nothing because the 325 MB download timed
    out.
    """
    todo = list(assets) if assets is not None else missing(models_dir)
    got, failed = [], []
    for a in todo:
        try:
            fetch_one(a, models_dir, on_progress, should_stop)
            got.append(a.name)
        except Cancelled:
            return {"ok": False, "cancelled": True, "got": got,
                    "failed": failed, "error": "Stopped."}
        except Exception as e:                          # noqa: BLE001
            failed.append({"name": a.name, "error": _human(e)})
    return {"ok": not failed, "cancelled": False, "got": got, "failed": failed,
            "error": failed[0]["error"] if failed else ""}


def _human(e: Exception) -> str:
    """An error somebody can act on, not a traceback."""
    if isinstance(e, urllib.error.HTTPError):
        return f"the download server answered {e.code}"
    if isinstance(e, urllib.error.URLError):
        reason = str(e.reason)
        if "CERTIFICATE_VERIFY_FAILED" in reason:
            # Name the actual cause. "could not reach the server" sent a
            # tester looking at their wifi for a problem that was a missing
            # CA bundle in their Python.
            return ("this Python has no CA certificates, so it cannot verify "
                    "any https server. Fix it once with:  pip install --upgrade "
                    "certifi   (or run 'Install Certificates.command' from your "
                    "Python 3.x folder in Applications)")
        return f"could not reach the download server ({reason})"
    if isinstance(e, ValueError):
        return str(e)
    if isinstance(e, OSError):
        if getattr(e, "errno", None) == 28:
            return "ran out of disk space"
        return f"could not write the file ({e.strerror or e})"
    return f"{type(e).__name__}: {e}"


# ---- whisper --------------------------------------------------------------

# faster-whisper's repos, so "is it already downloaded" can be answered without
# importing faster_whisper (which pulls in ctranslate2 and takes seconds).
WHISPER_REPO = {
    "tiny":   "Systran/faster-whisper-tiny",
    "base":   "Systran/faster-whisper-base",
    "small":  "Systran/faster-whisper-small",
    "medium": "Systran/faster-whisper-medium",
}
WHISPER_MB = {"tiny": 75, "base": 145, "small": 480, "medium": 1500}


def whisper_status(size: str = "small") -> dict:
    """Whether the transcriber's weights are already in the Hugging Face cache.

    Read off the filesystem rather than by importing faster_whisper, because
    this is called from the health check and from the setup panel, and neither
    should pay a multi-second import to answer "is it there".
    """
    repo = WHISPER_REPO.get(size)
    if not repo:
        return {"size": size, "present": False, "mb": 0, "known": False}
    home = Path(os.environ.get("HF_HOME") or (Path.home() / ".cache" / "huggingface"))
    # HF_HOME may or may not already end in `hub`; both layouts exist in the
    # wild depending on which version created the cache.
    roots = [home / "hub", home]
    folder = "models--" + repo.replace("/", "--")
    present = False
    for root in roots:
        snap = root / folder / "snapshots"
        try:
            present = snap.is_dir() and any(
                any(d.iterdir()) for d in snap.iterdir() if d.is_dir())
        except OSError:
            present = False
        if present:
            break
    return {"size": size, "present": present, "mb": WHISPER_MB.get(size, 0),
            "known": True, "repo": repo}


def fetch_whisper(size: str = "small",
                  on_progress: Progress | None = None) -> dict:
    """Pull the transcriber's weights now, so the first spoken word does not.

    Left to itself faster-whisper downloads on first use: several hundred
    megabytes, silently, inside the call that was supposed to transcribe a
    two-second utterance. The window looks frozen and the microphone looks
    broken. Doing it here, on purpose, with something to look at, is the whole
    point -- so this reports progress as an indeterminate step rather than
    pretending to a byte count huggingface_hub does not hand us.
    """
    repo = WHISPER_REPO.get(size)
    if not repo:
        return {"ok": False, "error": f"unknown model size {size!r}"}
    if on_progress:
        on_progress(f"whisper-{size}", 0, 1)
    try:
        from huggingface_hub import snapshot_download
        snapshot_download(repo_id=repo)
    except ImportError:
        # huggingface_hub arrives with faster-whisper; without the voice extra
        # there is nothing to prepare and nothing to apologise for.
        return {"ok": False, "error": "the voice extra is not installed"}
    except Exception as e:                              # noqa: BLE001
        return {"ok": False, "error": _human(e)}
    if on_progress:
        on_progress(f"whisper-{size}", 1, 1)
    return {"ok": True, "error": ""}


# ---- the download, as the window sees it ---------------------------------

class Downloader:
    """One fetch at a time, on a thread, reporting to the dashboard.

    Deliberately not a task per asset. These are large sequential downloads
    over one connection to two hosts; running four at once makes each slower,
    makes the progress bar meaningless, and turns a cancel into four races.

    Progress is throttled rather than emitted per chunk. At 256 KiB a chunk a
    325 MB file is 1,300 messages, and a websocket frame per chunk makes the
    UI thread the bottleneck in its own progress bar.
    """

    EMIT_EVERY = 0.25            # seconds

    def __init__(self, dash):
        import threading
        self.dash = dash
        self.running = False
        self._stop = False
        self._lock = threading.Lock()

    def start(self, include_whisper: bool = True) -> dict:
        import threading
        with self._lock:
            if self.running:
                return {"ok": False, "error": "already downloading"}
            need = missing()
            whisper_needed = include_whisper and not whisper_status().get("present")
            if not need and not whisper_needed:
                return {"ok": False, "error": "everything is already here"}
            # Checked before a byte is spent, so "you need another 200 MB" is
            # something you learn now rather than 300 MB into a progress bar.
            room = free_space()
            want = sum(a.size for a in need)
            if room and room < want * 1.1:
                return {"ok": False,
                        "error": f"not enough disk space — this needs about "
                                 f"{want/1e6:.0f} MB and there is "
                                 f"{room/1e6:.0f} MB free"}
            self.running = True
            self._stop = False
        threading.Thread(target=self._run, args=(whisper_needed,),
                         daemon=True).start()
        return {"ok": True, "error": ""}

    def cancel(self) -> None:
        self._stop = True

    def _run(self, whisper_needed: bool) -> None:
        import time
        last = [0.0]

        def progress(name: str, done: int, total: int) -> None:
            now = time.monotonic()
            if now - last[0] < self.EMIT_EVERY and done < total:
                return
            last[0] = now
            st = status()
            # Bytes already on disk, plus this file's progress. One bar for the
            # whole job: four bars that each reach 100% do not tell you how
            # much longer the thing takes, which is the only question.
            have = sum(i["size"] for i in st["items"] if i["present"])
            self.dash.emit_raw({
                "t": "models.progress", "file": name,
                "fileDone": done, "fileTotal": total,
                "allDone": have + done, "allTotal": TOTAL_BYTES,
            })

        try:
            report = fetch(on_progress=progress, should_stop=lambda: self._stop)
            if report["ok"] and whisper_needed and not self._stop:
                self.dash.emit_raw({"t": "models.progress",
                                    "file": "whisper", "fileDone": 0,
                                    "fileTotal": 1, "indeterminate": True,
                                    "allDone": TOTAL_BYTES,
                                    "allTotal": TOTAL_BYTES})
                w = fetch_whisper()
                if not w["ok"]:
                    # Not fatal. Whisper self-downloads on first use; the only
                    # thing lost is doing it now, where it can be watched.
                    report = dict(report, whisperError=w["error"])
            self.dash.emit_raw({"t": "models.done", **report,
                                "status": status(),
                                "whisper": whisper_status()})
        except Exception as e:                          # noqa: BLE001
            self.dash.emit_raw({"t": "models.done", "ok": False,
                                "cancelled": False, "got": [], "failed": [],
                                "error": _human(e), "status": status(),
                                "whisper": whisper_status()})
        finally:
            self.running = False
