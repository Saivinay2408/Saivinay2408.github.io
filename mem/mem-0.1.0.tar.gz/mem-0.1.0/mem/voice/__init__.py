"""mem-voice: a local voice-and-terminal convenience layer on top of a
`claude` CLI session and a mem memory vault.

Every submodule here is safe to `import` with none of the optional runtime
dependencies (sounddevice, onnxruntime, faster-whisper, kokoro-onnx,
pywebview) installed: heavy third-party imports are deferred to the function
or method that actually needs them, never done at module import time. That is
what lets `verify.py` prove there are no dead function references by
importing and exercising every module, on a machine with no microphone,
speakers, or model weights at all.
"""
