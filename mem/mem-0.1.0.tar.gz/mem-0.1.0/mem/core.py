"""Deterministic core of the vault: parsing, the reject gate, entity resolution,
and bi-temporal fact supersession.

Nothing in this module calls a model, touches the network, or makes a judgement
call. A language model may *propose* candidates; this file decides whether they
are allowed in and exactly how they are written. That separation is the reason
the system can survive a badly behaved extractor.

No third-party dependencies. The frontmatter dialect is intentionally flat
(scalars and one-line lists) so it parses with the small reader below, which
means the vault stays readable by any tool that can open a markdown file and
never breaks because a YAML library changed its mind about a corner case.
"""
from __future__ import annotations

import datetime
import re
from pathlib import Path

from .config import ENTITY_FOLDERS, folder_for, type_for

# --------------------------------------------------------------------------- #
# reject gate
# --------------------------------------------------------------------------- #

MIN_SALIENCE = 3
JUNK_CATEGORIES = {"mundane", "trivia", "smalltalk", "transient", "greeting", "chitchat"}
JUNK_PATTERNS = [
    r"\b(ate|eaten|eating|drank|drinking|coffee|tea|breakfast|lunch|dinner|snack|slept|nap|weather|raining)\b",
    r"\b(hi|hello|hey|thanks|thank you|good morning|good night|no worries)\b",
    r"\bas an ai\b",
]
IDENTITY_CORE_FILES = {"identity.md", "now.md"}
IDENTITY_CORE_TYPE = "identity-core"


def reject_gate(candidate: dict) -> tuple[bool, str]:
    """Return ``(keep, reason)``.

    Runs on every candidate regardless of what the extractor claimed about it.
    Defence in depth: the same rules live in the extraction prompt, but the
    prompt is advice and this is enforcement.
    """
    content = (candidate.get("content") or candidate.get("title") or "").strip()
    if not content:
        return False, "empty content"

    try:
        salience = int(candidate.get("salience", 0))
    except (TypeError, ValueError):
        salience = 0
    if salience < MIN_SALIENCE:
        return False, f"salience {salience} < {MIN_SALIENCE}"

    category = str(candidate.get("category") or "").lower()
    if category in JUNK_CATEGORIES:
        return False, f"junk category '{category}'"

    lowered = content.lower()
    for pattern in JUNK_PATTERNS:
        if re.search(pattern, lowered):
            return False, f"junk pattern /{pattern}/"

    kind = candidate.get("kind", "fact")
    if kind == "fact" and not candidate.get("entity"):
        return False, "fact with no entity subject"
    if kind == "event" and not (candidate.get("entities") or candidate.get("actors")):
        return False, "event with no linked entity"

    return True, "kept"


def normalize(text: str) -> str:
    """Whitespace- and case-insensitive form, used by the ground check."""
    return re.sub(r"\s+", " ", (text or "").lower()).strip()


def ground_check(candidates: list[dict], source: str) -> tuple[list[dict], list[dict]]:
    """Discard any candidate whose ``quote`` does not literally appear in the source.

    The reject gate blocks junk. This blocks fabrication, which is the more
    dangerous failure: a hallucinated fact carrying a provenance link looks
    *more* trustworthy than an honest gap.

    Returns ``(grounded, discarded)``; each discarded candidate gains a
    ``_reason`` key so a caller can report why.
    """
    src = normalize(source)
    grounded, discarded = [], []
    for cand in candidates:
        quote = normalize(cand.get("quote", ""))
        if not quote:
            discarded.append({**cand, "_reason": "no quote"})
        elif quote not in src:
            discarded.append({**cand, "_reason": "quote not found in source"})
        else:
            grounded.append(cand)
    return grounded, discarded


# --------------------------------------------------------------------------- #
# frontmatter I/O
# --------------------------------------------------------------------------- #


def _parse_scalar(raw: str):
    value = raw.strip()
    if value.startswith("[") and value.endswith("]"):
        inner = value[1:-1].strip()
        return [part.strip() for part in inner.split(",")] if inner else []
    if value in ("true", "True"):
        return True
    if value in ("false", "False"):
        return False
    if value in ("null", "~", ""):
        return None
    return value.strip("\"'")


def _dump_scalar(value) -> str:
    if isinstance(value, list):
        return "[" + ", ".join(str(v) for v in value) + "]"
    if isinstance(value, bool):
        return "true" if value else "false"
    if value is None:
        return "null"
    return str(value)


def read_note(path: str | Path) -> tuple[dict, str]:
    """Return ``(frontmatter, body)``. A note without frontmatter yields ``({}, text)``."""
    text = Path(path).read_text(encoding="utf-8")
    if not text.startswith("---"):
        return {}, text
    parts = text.split("---", 2)
    if len(parts) < 3:
        return {}, text
    frontmatter: dict = {}
    for line in parts[1].strip().splitlines():
        if ":" in line:
            key, _, value = line.partition(":")
            frontmatter[key.strip()] = _parse_scalar(value)
    return frontmatter, parts[2].lstrip("\n")


def write_note(path: str | Path, frontmatter: dict, body: str) -> Path:
    """Write a note, refusing to touch identity-core.

    The guard lives here rather than in each caller so that there is exactly one
    place to audit. A script cannot rewrite the user's self-description, even by
    accident, even if an extractor asks it to.
    """
    path = Path(path)
    if path.name in IDENTITY_CORE_FILES or frontmatter.get("type") == IDENTITY_CORE_TYPE:
        raise PermissionError(f"refusing automated write to identity-core file: {path.name}")
    path.parent.mkdir(parents=True, exist_ok=True)
    lines = ["---"]
    lines += [f"{k}: {_dump_scalar(v)}" for k, v in frontmatter.items()]
    lines += ["---", ""]
    path.write_text("\n".join(lines) + body.rstrip("\n") + "\n", encoding="utf-8")
    return path


def today() -> str:
    return datetime.date.today().isoformat()


# --------------------------------------------------------------------------- #
# sections
# --------------------------------------------------------------------------- #

FACT_RE = re.compile(r"^- (?P<key>[\w-]+):: (?P<rest>.*)$")


def section(body: str, header: str) -> tuple[list[str], int, int]:
    """Return ``(lines, start, end)`` for a ``## Header`` block.

    ``start``/``end`` are line indices into ``body.splitlines()`` so a caller can
    splice the block back without reformatting the rest of the note. Returns
    ``([], -1, -1)`` when the header is absent.
    """
    lines = body.splitlines()
    start = end = -1
    for i, line in enumerate(lines):
        if line.strip() == header:
            start = i + 1
        elif start != -1 and line.startswith("## "):
            end = i
            break
    if start == -1:
        return [], -1, -1
    if end == -1:
        end = len(lines)
    return lines[start:end], start, end


def _splice(body: str, start: int, end: int, new_lines: list[str]) -> str:
    lines = body.splitlines()
    return "\n".join(lines[:start] + [""] + new_lines + [""] + lines[end:])


# --------------------------------------------------------------------------- #
# entity resolution
# --------------------------------------------------------------------------- #

STOPWORDS = {"the", "a", "an", "of", "and", "my", "me", "for"}


def slugify(name: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", str(name).lower()).strip("-")


def tokens(text: str) -> set:
    return {t for t in re.findall(r"[a-z0-9]+", str(text).lower())} - STOPWORDS


def resolve_entity(vault: Path, name: str, entity_type: str) -> Path | None:
    """Find an existing entity file by id, title, alias, or token subset.

    The token-subset fallback is what stops an extractor from creating a second
    node every time it writes a person's full name where a short alias already
    exists. It requires at least two query tokens, because single-token subsets
    match far too much.
    """
    folder = Path(vault) / folder_for(entity_type)
    if not folder.exists():
        return None
    target = slugify(name)
    query_tokens = tokens(name)
    fuzzy: Path | None = None

    for path in sorted(folder.glob("*.md")):
        fm, body = read_note(path)
        node_id = str(fm.get("id", "")).lower()
        if node_id and (node_id.endswith(target) or node_id == f"{entity_type}-{target}"):
            return path
        aliases = [str(a) for a in (fm.get("aliases") or [])]
        alias_slugs = {slugify(a) for a in aliases}
        alias_slugs.add(slugify(node_id.replace(f"{entity_type}-", "")))
        title = body.splitlines()[0].lstrip("# ").strip() if body.strip() else ""
        if target in alias_slugs or slugify(title) == target or path.stem == target:
            return path
        if len(query_tokens) >= 2:
            combined = tokens(node_id) | tokens(title) | tokens(path.stem)
            for alias in aliases:
                combined |= tokens(alias)
            if query_tokens <= combined:
                fuzzy = path
    return fuzzy


def resolve_any(vault: Path, name: str) -> Path | None:
    """Resolve a name across every entity folder.

    Used for event-to-entity links, where the extractor usually knows the name
    but rarely knows whether it is a project, a concept, or a person.
    """
    for folder in ENTITY_FOLDERS:
        hit = resolve_entity(vault, name, type_for(folder))
        if hit:
            return hit
    return None


def link_target(path: str | Path) -> str:
    """Canonical wikilink target: the file stem, never the frontmatter id."""
    return Path(path).stem


def get_or_create_entity(
    vault: Path,
    name: str,
    entity_type: str,
    aliases: list | None = None,
    salience: int = 5,
) -> Path:
    existing = resolve_entity(vault, name, entity_type)
    if existing:
        return existing
    path = Path(vault) / folder_for(entity_type) / f"{slugify(name)}.md"
    frontmatter = {
        "id": f"{entity_type}-{slugify(name)}",
        "type": entity_type,
        "aliases": aliases or [name],
        "salience": salience,
        "created": today(),
        "updated": today(),
    }
    if entity_type == "project":
        frontmatter["status"] = "active"
    body = f"# {name}\n\n## Current facts\n\n## History\n\n## Links\n"
    write_note(path, frontmatter, body)
    return path


# --------------------------------------------------------------------------- #
# bi-temporal writes
# --------------------------------------------------------------------------- #


def apply_fact(vault: Path, candidate: dict) -> str:
    """Add a semantic fact, superseding any current fact sharing its key.

    The old bullet is not edited in place and not dropped. It gets a ``valid_to``
    stamp equal to the new fact's ``valid_from``, a ``[superseded]`` tag, and a
    new home under ``## History``. Reading the pair back tells you both what is
    true and when it stopped being true.
    """
    vault = Path(vault)
    name = candidate["entity"]
    entity_type = candidate.get("entity_type", "project")
    path = get_or_create_entity(
        vault, name, entity_type, candidate.get("aliases"), int(candidate.get("salience", 5))
    )
    frontmatter, body = read_note(path)

    key = candidate.get("key") or slugify(candidate["content"])[:20]
    valid_from = candidate.get("valid_from") or today()
    provenance = candidate.get("provenance", "")
    prov_suffix = f", provenance: [[{provenance}]]" if provenance else ""
    bullet = f"- {key}:: {candidate['content']} (valid_from: {valid_from}{prov_suffix})"

    current, cstart, cend = section(body, "## Current facts")
    if cstart == -1:
        body = body.rstrip("\n") + "\n\n## Current facts\n\n## History\n\n## Links\n"
        current, cstart, cend = section(body, "## Current facts")

    superseded = None
    kept = []
    for line in current:
        match = FACT_RE.match(line.strip())
        if match and match.group("key") == key and line.strip() != bullet:
            superseded = line.strip()
        elif line.strip():
            kept.append(line)

    body = _splice(body, cstart, cend, kept + [bullet])

    if superseded:
        closed = superseded.replace("(valid_from:", f"(valid_to: {valid_from}, valid_from:", 1)
        closed += " [superseded]"
        history, hstart, hend = section(body, "## History")
        if hstart == -1:
            body = body.rstrip("\n") + "\n\n## History\n\n" + closed + "\n"
        else:
            body = _splice(body, hstart, hend, [h for h in history if h.strip()] + [closed])

    frontmatter["updated"] = today()
    write_note(path, frontmatter, body)
    return f"fact[{key}] -> {path.name}" + (" (superseded prior)" if superseded else "")


def add_link(vault: Path, path: Path, link: str, relation: str = "relates_to") -> None:
    """Append a typed backlink to a note's ``## Links`` section, idempotently."""
    frontmatter, body = read_note(path)
    links, lstart, lend = section(body, "## Links")
    if any(link in line for line in links):
        return
    if lstart == -1:
        body = body.rstrip("\n") + f"\n\n## Links\n- {relation}:: {link}\n"
    else:
        body = _splice(body, lstart, lend, [l for l in links if l.strip()] + [f"- {relation}:: {link}"])
    write_note(path, frontmatter, body)


def apply_event(vault: Path, candidate: dict) -> str:
    """Write an immutable episodic note and backlink the entities it touches.

    Events are write-once. If the file already exists the call is a no-op, which
    makes re-running consolidation over the same inbox safe.
    """
    vault = Path(vault)
    date = candidate.get("date") or today()
    title = candidate.get("title") or candidate.get("content")
    slug = slugify(title)[:48]
    path = vault / "episodic" / date[:4] / f"{date}-{slug}.md"
    if path.exists():
        return f"event exists (immutable), skipped: {path.name}"

    rendered_links, resolved = [], []
    for entity in candidate.get("entities", []):
        hit = resolve_any(vault, entity)
        if hit:
            rendered_links.append(f"[[{link_target(hit)}]]")
            resolved.append(hit)
        else:
            # An unresolvable name stays plain text. A dead wikilink is worse
            # than no link: it pollutes the graph and every audit after it.
            rendered_links.append(str(entity))

    frontmatter = {
        "id": f"{date}-{slug}",
        "type": "event",
        "subtype": candidate.get("subtype", "note"),
        "date": date,
        "entities": rendered_links,
        "salience": int(candidate.get("salience", 5)),
        "provenance": f"[[{candidate.get('provenance', '')}]]",
    }
    body = f"# {title}\n"
    if candidate.get("rationale"):
        body += f"\nRationale: {candidate['rationale']}\n"
    if candidate.get("outcome"):
        body += f"\nOutcome: {candidate['outcome']}\n"
    write_note(path, frontmatter, body)

    for entity_path in resolved:
        add_link(vault, entity_path, f"[[{frontmatter['id']}]]", relation="decided")
    return f"event -> {path.name}"


def apply_candidates(vault: Path, candidates: list[dict]) -> dict:
    """Gate, then write. The only sanctioned path from a candidate to the vault."""
    report: dict = {"kept": [], "rejected": [], "log": []}
    for candidate in candidates:
        keep, reason = reject_gate(candidate)
        label = candidate.get("content") or candidate.get("title")
        if not keep:
            report["rejected"].append({"content": label, "reason": reason})
            continue
        report["kept"].append(label)
        if candidate.get("kind") == "event":
            report["log"].append(apply_event(vault, candidate))
        else:
            report["log"].append(apply_fact(vault, candidate))
    return report
