"""
`mem vault` — say which vault this machine uses, and see which one it is using.

    mem vault                 where am I reading and writing
    mem vault <path>          use this one from now on

WHY THIS EXISTS AS A COMMAND
----------------------------
A double-clicked app inherits nothing from your login shell. No PATH, no
MEM_DIR, none of it — so `export MEM_DIR=...` in a .zshrc reaches every
terminal you open and never reaches the window in your Dock. Without a way to
write the choice down, a GUI launch is permanently stuck on the default vault,
and the symptom is the worst kind: the app works perfectly and your memory is
simply not in it.

The setting is a pointer, so it lives outside the thing it points at
(`~/.mem/config.json`). MEM_DIR still wins when it is set, because a
throwaway vault for a test or a benchmark must not be overridable by whatever
this machine happens to prefer.
"""
from __future__ import annotations

import argparse
import os
from pathlib import Path

from .config import DEFAULT_VAULT, ENV_VAR, SETTINGS, saved_vault, set_vault, vault_path


def describe() -> str:
    here = vault_path()
    notes = 0
    try:
        notes = sum(1 for _ in here.rglob("*.md"))
    except OSError:
        pass

    env = os.environ.get(ENV_VAR)
    if env:
        why = f"{ENV_VAR} is set in this shell"
    elif saved_vault():
        why = f"chosen on this machine ({SETTINGS})"
    else:
        why = "the default; nothing has been chosen"

    lines = [f"{here}", f"  {notes} notes", f"  {why}"]
    if not here.is_dir():
        lines.append("  it does not exist yet — it is created on first write")
    if saved_vault() and env:
        lines.append(f"  (the chosen one, {saved_vault()}, is being overridden)")
    if not env and not saved_vault():
        lines.append(f"  default is {DEFAULT_VAULT}")
    return "\n".join(lines)


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(
        prog="mem vault",
        description="which vault this machine uses")
    parser.add_argument("path", nargs="?",
                        help="use this vault from now on, including for the app")
    args = parser.parse_args(argv)

    if not args.path:
        print(describe())
        return 0

    target = Path(args.path).expanduser()
    if not target.is_dir():
        # Not an error: pointing at a vault you are about to create is a normal
        # thing to do. It is worth saying out loud, though, because a typo'd
        # path looks exactly like an empty vault.
        print(f"note: {target} does not exist yet.")
    chosen = set_vault(target)
    print(f"Using {chosen}\n  written to {SETTINGS}")
    print("\nThe app reads this too, so a window opened from the Dock now "
          "sees the same vault as this terminal.")
    return 0
