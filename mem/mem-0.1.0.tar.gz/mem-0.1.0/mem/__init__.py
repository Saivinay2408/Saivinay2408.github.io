"""Mem: a typed, bi-temporal, file-backed memory graph for AI agents.

Markdown notes are the source of truth. Everything else, including the index, is
derived and disposable. A language model may propose what to remember; only
deterministic code decides what gets written.
"""

__version__ = "0.1.0"

from .config import vault_path  # noqa: F401
from .core import (  # noqa: F401
    apply_candidates,
    apply_event,
    apply_fact,
    ground_check,
    read_note,
    reject_gate,
    resolve_entity,
    write_note,
)
