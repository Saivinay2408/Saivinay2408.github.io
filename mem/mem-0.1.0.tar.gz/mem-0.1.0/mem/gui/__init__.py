"""Optional GUI setup wizard (``python3 -m mem setup-gui``).

Not imported by anything else in the package. `pywebview` is only required if
you actually run the wizard; the terminal path (`onboard` + `init-hooks`)
never touches this subpackage and stays dependency-free.
"""
