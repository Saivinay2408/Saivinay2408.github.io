"""setup-gui: a pywebview wizard over the existing onboarding path.

    python3 -m mem setup-gui

This is an *alternative front end*, not a new pipeline. Every action it takes
is a direct call into the same functions the terminal flow uses:

    welcome/prereqs   -> nothing (just inspection: sys.version, shutil.which)
    interview intake  -> native file picker (create_file_dialog), or the
                         bundled tools/example_answers.md
    run onboard       -> onboard.run(vault, answers, apply=True, fixture=...)
    review drafts     -> reads proposals/identity-*.md and now-*.md, the same
                         files onboard.draft_identity/draft_now write
    approve/reject    -> onboard._install(), the same sanctioned installer
                         onboard.approve_identity() calls; called per-draft
                         here because the CLI's approve_identity() only
                         supports "install the latest of both, unconditionally"
                         and the wizard needs independent approve/reject per file
    wire hooks        -> hooks.init_hooks(project, mem_home, vault)

Nothing here re-implements extraction, grounding, gating, or the identity
write guard. If those are wrong, they are wrong in the CLI too, and the fix
belongs in onboard.py/consolidate.py/core.py, not here.

**Threading law**: pywebview's cocoa/WKWebView backend on macOS SIGTRAPs if
`evaluate_js` is called concurrently from more than one thread. Background work
here (running onboard, running init-hooks) happens on worker threads; every one
of them talks to the window only by putting an event on `UI`'s queue, and a
single drain thread is the only thing that ever calls `evaluate_js`. Do not add
a second call site.
"""
from __future__ import annotations

import contextlib
import difflib
import io
import json
import queue
import shutil
import sys
import threading
from pathlib import Path

from .. import consolidate as cs
from .. import core
from .. import hooks as hk
from .. import onboard as ob
from ..config import REPO_ROOT, vault_path

try:
    import webview
except ImportError:  # pragma: no cover - exercised only when the extra isn't installed
    webview = None

HTML_PATH = Path(__file__).parent / "wizard.html"
DEFAULT_EXTRACTOR_CMD = "claude -p"


class UI:
    """Bridges background-thread events into the webview through one drain
    thread. See the module docstring for the crash this exists to avoid. Setup
    output is line-oriented rather than a token stream, so nothing here needs
    to be coalesced before it is drained."""

    def __init__(self):
        self.window = None
        self._q: "queue.Queue[tuple[str, object]]" = queue.Queue()
        threading.Thread(target=self._drain, daemon=True).start()

    def emit(self, fn: str, payload) -> None:
        self._q.put((fn, payload))

    def _drain(self) -> None:
        while True:
            fn, payload = self._q.get()
            if self.window is None:
                continue
            try:
                self.window.evaluate_js(f"window.ui.{fn}({json.dumps(payload)})")
            except Exception:  # noqa: BLE001 - a UI hiccup must never kill setup
                pass


class _StreamTee(io.TextIOBase):
    """Forwards writes to the real stream and, line by line, to the UI feed.

    onboard.run() and hooks.init_hooks() print progress with plain `print()`
    calls meant for a terminal. Redirecting stdout through this while they run
    is how the wizard shows real output instead of a spinner, without either
    module knowing a GUI exists.
    """

    def __init__(self, real, ui: UI):
        self.real, self.ui, self._buf = real, ui, ""

    def write(self, s: str) -> int:
        self.real.write(s)
        self._buf += s
        while "\n" in self._buf:
            line, self._buf = self._buf.split("\n", 1)
            if line.strip():
                self.ui.emit("log", line)
        return len(s)

    def flush(self) -> None:
        self.real.flush()


class Api:
    """The `js_api` object: every method here is callable from wizard.html as
    `window.pywebview.api.<name>(...)`, returning a promise."""

    def __init__(self, ui: UI, vault: Path, project: Path):
        self.ui = ui
        self.vault = Path(vault)
        self.project = Path(project)
        self._answers_path: Path | None = None

    # ------------------------------------------------------------------ #
    # screen 1: welcome / prereqs
    # ------------------------------------------------------------------ #

    def check_prereqs(self) -> dict:
        import os

        extractor_cmd = os.environ.get("MEM_EXTRACTOR_CMD", DEFAULT_EXTRACTOR_CMD)
        # consolidate.check_extractor() is the real preflight (it actually
        # invokes the extractor with a throwaway probe) -- the same one
        # `python3 -m mem check-extractor` runs. Prefer it; fall back to
        # a plain shutil.which guess only if this module predates that
        # function in whatever checkout this runs against.
        if hasattr(cs, "check_extractor"):
            # Shorter timeout than the CLI's default (240s): this runs
            # synchronously on the welcome screen and a hung extractor
            # shouldn't make the wizard look frozen. `check-extractor` on the
            # command line is still the authoritative, patient check.
            extractor_ok, extractor_message = cs.check_extractor(timeout=15)
        else:  # pragma: no cover - only on an older checkout
            exe = extractor_cmd.split()[0] if extractor_cmd.split() else extractor_cmd
            extractor_ok = shutil.which(exe) is not None
            extractor_message = "found on PATH" if extractor_ok else "not found on PATH"
        return {
            "python_version": sys.version.split()[0],
            "python_ok": sys.version_info >= (3, 10),
            "extractor_cmd": extractor_cmd,
            "extractor_found": extractor_ok,
            "extractor_message": extractor_message,
            "vault": str(self.vault),
            "project": str(self.project),
        }

    # ------------------------------------------------------------------ #
    # screen 2: interview intake
    # ------------------------------------------------------------------ #

    def pick_interview_file(self):
        if self.ui.window is None or webview is None:
            return None
        result = self.ui.window.create_file_dialog(
            webview.OPEN_DIALOG,
            file_types=("Markdown files (*.md)", "All files (*.*)"),
        )
        path = result[0] if result else None
        if path:
            self._answers_path = Path(path)
        return path

    def use_example(self) -> str:
        path = REPO_ROOT / "tools" / "example_answers.md"
        self._answers_path = path
        return str(path)

    # ------------------------------------------------------------------ #
    # screen 3: onboard --apply, streamed
    # ------------------------------------------------------------------ #

    def run_onboard(self, use_fixture: bool) -> dict:
        if not self._answers_path:
            return {"ok": False, "error": "no answers file selected"}
        threading.Thread(
            target=self._run_onboard_bg, args=(bool(use_fixture),), daemon=True
        ).start()
        return {"ok": True, "started": True}

    def _run_onboard_bg(self, use_fixture: bool) -> None:
        fixture = (
            REPO_ROOT / "tools" / "example_onboard_fixture.json" if use_fixture else None
        )
        self.ui.emit("log", f"onboarding from {self._answers_path.name} "
                     f"{'(fixture, no extractor call)' if use_fixture else ''}".rstrip())
        tee = _StreamTee(sys.stdout, self.ui)
        try:
            with contextlib.redirect_stdout(tee):
                result = ob.run(self.vault, self._answers_path, apply=True, fixture=fixture)
            s, report = result["stats"], result["report"]
            self.ui.emit(
                "log",
                f"parsed {s['sections']} sections, {s['answered']}/{s['questions']} "
                f"questions answered, {s['words']} words",
            )
            self.ui.emit(
                "log",
                f"captures filed: {len(result['captures'])} -- facts written: "
                f"{len(report['kept'])}, rejected: {len(report['rejected'])}, "
                f"ungrounded: {len(report.get('ungrounded', []))}",
            )
            for folder, names in sorted(result["seeded"].items()):
                self.ui.emit("log", f"seeded {folder}: {', '.join(names)}")
            self.ui.emit("log", f"eval golden cases: {len(result['cases'])}")
            self.ui.emit(
                "log",
                "identity.md and now.md are UNTOUCHED -- drafts are next, in the "
                "review step.",
            )
            self.ui.emit("onboardDone", {"ok": True})
        except Exception as e:  # noqa: BLE001
            self.ui.emit("log", f"! onboard failed: {e}")
            self.ui.emit("onboardDone", {"ok": False, "error": str(e)})

    # ------------------------------------------------------------------ #
    # screen 4: review identity.md / now.md drafts
    # ------------------------------------------------------------------ #

    def get_drafts(self) -> dict:
        return {
            "identity": self._draft_info("identity", "identity.md"),
            "now": self._draft_info("now", "now.md"),
        }

    def _latest_draft(self, which: str) -> Path | None:
        pattern = "identity-*.md" if which == "identity" else "now-*.md"
        drafts = sorted((self.vault / "proposals").glob(pattern))
        return drafts[-1] if drafts else None

    def _draft_info(self, which: str, target_name: str) -> dict:
        draft_path = self._latest_draft(which)
        if draft_path is None:
            return {"draft_path": None}
        _, draft_body = core.read_note(draft_path)
        target_path = self.vault / target_name
        target_body = (
            target_path.read_text(encoding="utf-8") if target_path.exists() else ""
        )
        diff = "\n".join(
            difflib.unified_diff(
                target_body.splitlines(),
                draft_body.splitlines(),
                fromfile=target_name if target_path.exists() else "(new file)",
                tofile=draft_path.name,
                lineterm="",
            )
        )
        return {
            "draft_path": str(draft_path),
            "draft_name": draft_path.name,
            "content": draft_body,
            "target_exists": target_path.exists(),
            "diff": diff or "(nothing to install -- draft is empty)",
        }

    def save_edited_draft(self, which: str, content: str) -> dict:
        draft_path = self._latest_draft(which)
        if draft_path is None:
            return {"ok": False, "error": "no draft"}
        frontmatter, _ = core.read_note(draft_path)
        core.write_note(draft_path, frontmatter, content)
        return {"ok": True}

    def approve_draft(self, which: str) -> dict:
        draft_path = self._latest_draft(which)
        if draft_path is None:
            return {"ok": False, "error": "no draft"}
        target = "identity.md" if which == "identity" else "now.md"
        # The sanctioned installer -- same one onboard.approve_identity() uses,
        # called per-draft here since that CLI entry point only knows how to
        # install "the latest of both, unconditionally" and the wizard needs
        # independent approve/reject per file.
        message = ob._install(self.vault, draft_path, target)
        self.ui.emit("log", message)
        return {"ok": True, "message": message}

    def reject_draft(self, which: str) -> dict:
        import datetime

        draft_path = self._latest_draft(which)
        if draft_path is None:
            return {"ok": False, "error": "no draft"}
        stamp = datetime.datetime.now().strftime("%Y%m%dT%H%M%S")
        rejected = draft_path.with_name(f"{draft_path.stem}.rejected-{stamp}.md")
        draft_path.rename(rejected)
        self.ui.emit("log", f"rejected: {draft_path.name} -> {rejected.name} (not installed)")
        return {"ok": True}

    # ------------------------------------------------------------------ #
    # screen 5: init-hooks, streamed
    # ------------------------------------------------------------------ #

    def run_init_hooks(self) -> dict:
        threading.Thread(target=self._run_init_hooks_bg, daemon=True).start()
        return {"ok": True, "started": True}

    def _run_init_hooks_bg(self) -> None:
        tee = _StreamTee(sys.stdout, self.ui)
        try:
            with contextlib.redirect_stdout(tee):
                result = hk.init_hooks(self.project, REPO_ROOT, self.vault, apply=True)
            self.ui.emit("log", f"settings: {result['path']}")
            self.ui.emit("log", f"command : {result['command']}")
            for line in result["changed"]:
                self.ui.emit("log", f"  {line}")
            if result["wrote"]:
                if result["backup"]:
                    self.ui.emit("log", f"backed up: {result['backup'].name}")
                self.ui.emit(
                    "log",
                    "wired: identity + now load at session start, recall is "
                    "injected per message, sessions are captured on stop.",
                )
            else:
                self.ui.emit("log", "already wired, nothing to change.")
            self.ui.emit("hooksDone", {"ok": True})
        except Exception as e:  # noqa: BLE001
            self.ui.emit("log", f"! init-hooks failed: {e}")
            self.ui.emit("hooksDone", {"ok": False, "error": str(e)})

    # ------------------------------------------------------------------ #
    # screen 6: done
    # ------------------------------------------------------------------ #

    def close_window(self) -> None:
        if self.ui.window is not None:
            self.ui.window.destroy()


def main(argv=None) -> int:
    import argparse

    parser = argparse.ArgumentParser(
        prog="mem setup-gui",
        description="pywebview onboarding wizard -- optional alternative to "
        "the terminal flow (interview -> onboard --apply -> "
        "--approve-identity -> init-hooks). The terminal path keeps working "
        "untouched either way.",
    )
    parser.add_argument("--vault", help="vault location (default: $MEM_DIR or ./vault)")
    parser.add_argument("--project", default=".", help="project dir to wire hooks into")
    args = parser.parse_args(list(sys.argv[1:] if argv is None else argv))

    if webview is None:
        print(
            "pywebview is not installed. Install it with:\n"
            "  pip install pywebview\n"
            "  (or: pip install 'mem[gui]' if you installed this as a package)\n"
            "then re-run: python3 -m mem setup-gui\n\n"
            "The terminal flow (onboard / init-hooks) needs none of this and "
            "still works without it.",
            file=sys.stderr,
        )
        return 1

    ui = UI()
    api = Api(ui, vault_path(args.vault), Path(args.project).expanduser().resolve())

    ui.window = webview.create_window(
        "Mem Setup",
        str(HTML_PATH),
        width=780,
        height=660,
        min_size=(620, 520),
        background_color="#0a0d14",
        js_api=api,
    )
    webview.start()
    return 0


if __name__ == "__main__":
    sys.exit(main())
