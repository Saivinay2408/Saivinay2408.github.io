"""Onboarding: turn a filled-in interview into a vault.

This is the real setup path. `docs/INTERVIEW.md` asks the questions; this module
takes the answers and turns them into memory, without inventing a single
sentence the user did not write.

    answers.md
      -> split into one capture per section, filed unconsolidated in the inbox
      -> the ordinary consolidation pipeline (extract, GROUND, REJECT, write)
      -> entity nodes in people/, projects/, goals/, concepts/, with provenance
      -> identity.md and now.md DRAFTS in proposals/, never installed by a script
      -> the decision-calibration section becomes eval golden cases

Two properties are load bearing.

**No parallel path.** Onboarding does not get its own extractor, its own gate, or
its own writer. It writes captures and then calls the same machinery any session
capture goes through, so a fact learned at onboarding is subject to exactly the
checks a fact learned in month six is. If the gates are wrong, they are wrong
everywhere, and the verifier catches it in one place.

**Identity stays human curated.** `core.write_note` physically refuses to write
identity-core, and this module does not work around that. It drafts into
`proposals/`, and installing a draft is a separate, explicit, human-invoked step
that backs up the previous file first. A setup wizard that silently writes the
user's self-description is the exact failure the guard exists to prevent.
"""
from __future__ import annotations

import argparse
import datetime
import json
import re
import shutil
import sys
from pathlib import Path

from . import consolidate as cs
from . import core
from .config import vault_path

INBOX_PREFIX = "interview"
IDENTITY_CORE_HEADER = (
    "<!-- Human curated. No script writes this file. Drafted by "
    "`mem onboard` from your own interview answers, then edited and "
    "installed by you. -->"
)

# `## 3. Autobiography, the part before this system (feeds: episodic/)`
SECTION_RE = re.compile(
    r"^##\s+(?P<num>\d+)[.)]\s+(?P<title>.+?)\s*(?:\(\s*feeds:\s*(?P<feeds>[^)]*)\))?\s*$"
)
# `101. A well paid role doing work you find boring ...`
QUESTION_RE = re.compile(r"^\s{0,4}(?P<num>\d{1,3})[.)]\s+(?P<text>\S.*)$")

SKIPPED_RE = re.compile(r"^\s*(n/?a|skip|skipped|-{1,3}|none)\s*\.?\s*$", re.I)


# --------------------------------------------------------------------------- #
# parsing
# --------------------------------------------------------------------------- #


def parse_answers(text: str) -> list[dict]:
    """Split a filled-in interview into sections, each holding question/answer pairs.

    Deliberately lenient. People delete questions they skipped, renumber, paste
    code blocks, and leave the template's prose in place. The only structure this
    relies on is `## <n>. <title>` for sections and a leading `<n>.` for
    questions.

    A numbered line opens a new question only if all of this holds:

    - its number is higher than the highest question number seen so far, and
    - a blank line precedes it, or the line ends in a question mark.

    Monotonicity alone is not enough, and the verifier proves it: an enumerated
    list inside an answer ("1. show up / 2. do not explain / 3. finish it")
    eventually numbers past the last real question and starts shredding the
    answer into fake questions. The template puts a blank line before every
    question and in-answer lists almost never have one, so that is the honest
    discriminator; the question-mark clause is there for the person who types
    their answers flush under each question with no blank lines at all.
    """
    sections: list[dict] = []
    current: dict | None = None
    question: dict | None = None
    highest = 0
    in_fence = False
    prev_blank = True

    for line in text.splitlines():
        was_blank, prev_blank = prev_blank, not line.strip()
        if line.lstrip().startswith("```"):
            in_fence = not in_fence
            if question is not None:
                question["answer_lines"].append(line)
            continue

        if not in_fence:
            match = SECTION_RE.match(line)
            if match:
                current = {
                    "num": int(match.group("num")),
                    "title": match.group("title").strip(),
                    "feeds": [f.strip().rstrip("/") for f in
                              (match.group("feeds") or "").split(",") if f.strip()],
                    "questions": [],
                }
                sections.append(current)
                question = None
                was_blank = True
                continue

            if current is not None:
                qmatch = QUESTION_RE.match(line)
                if (qmatch and int(qmatch.group("num")) > highest
                        and (was_blank or qmatch.group("text").rstrip().endswith("?"))):
                    highest = int(qmatch.group("num"))
                    question = {
                        "num": highest,
                        "question": qmatch.group("text").strip(),
                        "answer_lines": [],
                    }
                    current["questions"].append(question)
                    continue

        if question is not None:
            question["answer_lines"].append(line)

    for section in sections:
        for q in section["questions"]:
            q["answer"] = "\n".join(q.pop("answer_lines")).strip()
            q["answered"] = bool(q["answer"]) and not SKIPPED_RE.match(q["answer"])
    return sections


def feeds(section: dict, target: str) -> bool:
    return any(target in f for f in section["feeds"])


def stats(sections: list[dict]) -> dict:
    questions = [q for s in sections for q in s["questions"]]
    return {
        "sections": len(sections),
        "questions": len(questions),
        "answered": sum(1 for q in questions if q["answered"]),
        "words": sum(len(q["answer"].split()) for q in questions),
    }


# --------------------------------------------------------------------------- #
# captures
# --------------------------------------------------------------------------- #


def capture_body(section: dict) -> str:
    """The section rendered as a capture.

    Answers are reproduced character for character. The GROUND check searches
    this text for the extractor's quotes, so any cleanup here would silently
    start rejecting true facts.
    """
    lines = [f"# Interview section {section['num']}: {section['title']}", ""]
    for q in section["questions"]:
        if not q["answered"]:
            continue
        lines += [f"Q{q['num']}. {q['question']}", "", q["answer"], ""]
    return "\n".join(lines)


def write_captures(vault: Path, sections: list[dict], source: str) -> list[Path]:
    vault = Path(vault)
    today = core.today()
    written = []
    for section in sections:
        if not any(q["answered"] for q in section["questions"]):
            continue
        slug = core.slugify(section["title"])[:40]
        name = f"{INBOX_PREFIX}-{section['num']:02d}-{slug}"
        path = vault / "episodic" / "inbox" / f"{name}.md"
        core.write_note(path, {
            "id": name,
            "type": "capture",
            "subtype": "interview",
            "date": today,
            "source": source,
            "section": section["num"],
            "feeds": section["feeds"] or ["identity"],
            "consolidated": False,
        }, capture_body(section))
        written.append(path)
    return written


def consolidate_captures(vault: Path, paths: list[Path], fixture: Path | None = None) -> dict:
    """Run the interview captures through the ordinary pipeline, scoped to them.

    `consolidate.run` would sweep every pending capture in the vault. Onboarding
    should only be responsible for what it just filed, so this calls the same
    three pieces directly: the same extractor, the same ground check, the same
    gate and writer.
    """
    vault = Path(vault)
    if fixture is not None:
        report = cs.run(vault, fixture=fixture)
        for path in paths:
            cs.mark_consolidated(path)
        return report

    catalog = cs.build_catalog(vault)
    candidates: list[dict] = []
    discarded: list[dict] = []
    any_processed = False
    any_extractor_failure = False
    to_mark: list[Path] = []
    for path in paths:
        _, body = core.read_note(path)
        print(f"  extracting: {path.name}")
        raw, failed = cs.extract(body, path.stem, catalog)
        any_processed = True
        any_extractor_failure = any_extractor_failure or failed
        grounded, dropped = core.ground_check(raw, body)
        for item in dropped:
            print(f"    UNGROUNDED ({item['_reason']}): "
                  f"{str(item.get('content') or item.get('title'))[:70]!r}", file=sys.stderr)
        candidates += grounded
        discarded += dropped
        # As in `consolidate.run`: a source the extractor failed on stays
        # unconsolidated, so fixing the extractor and re-running consolidate
        # picks the interview section back up instead of losing it silently.
        if not failed:
            to_mark.append(path)

    report = core.apply_candidates(vault, candidates)
    report["ungrounded"] = discarded

    # Same loud-failure rule as `consolidate.run`: only trip when sources were
    # processed, the extractor itself failed at least once, and the whole pass
    # came back with nothing at all -- see the comment in consolidate.run for
    # why a legitimately empty session never reaches this branch.
    report["extractor_failed"] = False
    if any_processed and any_extractor_failure and not candidates and not discarded:
        _, message = cs.check_extractor()
        report["extractor_failed"] = True
        report["extractor_message"] = message

    for path in to_mark:
        cs.mark_consolidated(path)
    return report


# --------------------------------------------------------------------------- #
# identity drafts (never installed automatically)
# --------------------------------------------------------------------------- #


def _qa_block(section: dict) -> list[str]:
    out = [f"## {section['title']}", ""]
    for q in section["questions"]:
        if q["answered"]:
            out += [f"**{q['question']}**", "", q["answer"], ""]
    return out


def draft_identity(vault: Path, sections: list[dict], source: str) -> Path:
    """Assemble, do not generate.

    Every line below is the user's own text, regrouped under the sections that
    feed identity. Compressing this into a polished self-description is exactly
    the kind of generative call that should be made by the person it describes,
    so the draft says so at the top and leaves the editing to them.
    """
    vault = Path(vault)
    relevant = [s for s in sections
                if feeds(s, "identity") and any(q["answered"] for q in s["questions"])]
    lines = [
        "# Identity (DRAFT)",
        "",
        "Assembled verbatim from your interview answers on "
        f"{core.today()}, source `{source}`. Nothing here was written by a model.",
        "",
        "Edit this down into the self-description you actually want the system to "
        "load on every session, then install it with:",
        "",
        "```bash",
        "python3 -m mem onboard --approve-identity",
        "```",
        "",
        "Until you do, `identity.md` is untouched.",
        "",
    ]
    for section in relevant:
        lines += _qa_block(section)
    path = vault / "proposals" / f"identity-{core.today()}.md"
    core.write_note(path, {
        "id": f"identity-draft-{core.today()}",
        "type": "proposal",
        "target": "identity.md",
        "date": core.today(),
        "source": source,
        "sections": [s["num"] for s in relevant],
    }, "\n".join(lines))
    return path


def draft_now(vault: Path, sections: list[dict], source: str, seeded: dict) -> Path:
    """Draft of the current-state file: what is live right now.

    Fed by the sections about goals and present circumstances, plus an inventory
    of what the pipeline actually created, so the draft is checkable against the
    vault rather than being a second uncorroborated story.
    """
    vault = Path(vault)
    relevant = [s for s in sections
                if (feeds(s, "goal") or feeds(s, "procedure"))
                and any(q["answered"] for q in s["questions"])]
    lines = [
        "# Now (DRAFT)",
        "",
        f"Assembled from your interview answers on {core.today()}, source "
        f"`{source}`. Trim this to the handful of lines that are true *this week*: "
        "`now.md` is loaded on every session, so length here is a tax you pay "
        "constantly.",
        "",
        "## Seeded by this run",
        "",
    ]
    for folder in sorted(seeded):
        lines.append(f"- {folder}: " + ", ".join(sorted(seeded[folder])))
    lines.append("")
    for section in relevant:
        lines += _qa_block(section)
    path = vault / "proposals" / f"now-{core.today()}.md"
    core.write_note(path, {
        "id": f"now-draft-{core.today()}",
        "type": "proposal",
        "target": "now.md",
        "date": core.today(),
        "source": source,
        "sections": [s["num"] for s in relevant],
    }, "\n".join(lines))
    return path


def _install(vault: Path, draft: Path, target_name: str) -> str:
    """The one sanctioned way an identity-core file is ever written.

    `core.write_note` refuses these files by design and is not called here. This
    function runs only from `--approve-identity`, only on a draft a human has had
    the chance to read, and it copies the previous version into `archive/identity/`
    before replacing it, so approving a bad draft is recoverable.
    """
    vault = Path(vault)
    target = vault / target_name
    _, body = core.read_note(draft)
    body = body.replace(" (DRAFT)", "", 1)

    if target.exists():
        backup = vault / "archive" / "identity" / (
            f"{target.stem}-{datetime.datetime.now():%Y%m%d-%H%M%S}.md")
        backup.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(target, backup)

    frontmatter = {
        "id": target.stem,
        "type": core.IDENTITY_CORE_TYPE,
        "updated": core.today(),
        "curated_by": "human",
        "drafted_from": draft.stem,
    }
    text = ("---\n"
            + "\n".join(f"{k}: {core._dump_scalar(v)}" for k, v in frontmatter.items())
            + "\n---\n\n" + IDENTITY_CORE_HEADER + "\n\n" + body.rstrip("\n") + "\n")
    target.write_text(text, encoding="utf-8")
    return f"installed {target_name} from {draft.name}"


def approve_identity(vault: Path) -> list[str]:
    vault = Path(vault)
    out = []
    for target, pattern in (("identity.md", "identity-*.md"), ("now.md", "now-*.md")):
        drafts = sorted((vault / "proposals").glob(pattern))
        if not drafts:
            out.append(f"no draft found for {target}, nothing done")
            continue
        out.append(_install(vault, drafts[-1], target))
    return out


# --------------------------------------------------------------------------- #
# eval golden cases
# --------------------------------------------------------------------------- #


def write_eval_cases(vault: Path, sections: list[dict], source: str) -> list[Path]:
    """Decision-calibration answers become golden cases.

    A memory system that claims to represent a person needs a way to be wrong on
    the record. Each of these pairs a scenario with what the person said they
    would actually do, in their words, so a later evaluation has something to
    score against that nobody generated.
    """
    vault = Path(vault)
    written = []
    for section in sections:
        if not feeds(section, "eval"):
            continue
        capture_id = f"{INBOX_PREFIX}-{section['num']:02d}-{core.slugify(section['title'])[:40]}"
        for q in section["questions"]:
            if not q["answered"]:
                continue
            slug = core.slugify(q["question"])[:48]
            path = vault / "eval" / "cases" / f"{q['num']:03d}-{slug}.json"
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps({
                "id": f"case-{q['num']:03d}-{slug}",
                "kind": "decision-calibration",
                "section": f"{section['num']}. {section['title']}",
                "prompt": q["question"],
                "reference_behavior": q["answer"],
                "grader": "judge compares the system's answer to reference_behavior on "
                          "the decision made and the stated reason, not on wording",
                "provenance": capture_id,
                "source_file": source,
                "created": core.today(),
            }, indent=1, ensure_ascii=False) + "\n", encoding="utf-8")
            written.append(path)
    return written


# --------------------------------------------------------------------------- #
# driver
# --------------------------------------------------------------------------- #


def seeded_inventory(vault: Path, before: dict) -> dict:
    from .config import ENTITY_FOLDERS

    out: dict[str, list[str]] = {}
    for folder in ENTITY_FOLDERS:
        directory = Path(vault) / folder
        if not directory.exists():
            continue
        new = sorted({p.stem for p in directory.glob("*.md")} - set(before.get(folder, [])))
        if new:
            out[folder] = new
    return out


def snapshot(vault: Path) -> dict:
    from .config import ENTITY_FOLDERS

    return {folder: [p.stem for p in (Path(vault) / folder).glob("*.md")]
            for folder in ENTITY_FOLDERS if (Path(vault) / folder).exists()}


def run(vault: Path, answers_file: Path, apply: bool = False,
        fixture: Path | None = None) -> dict:
    vault = Path(vault)
    answers_file = Path(answers_file)
    text = answers_file.read_text(encoding="utf-8")
    sections = parse_answers(text)
    result: dict = {"stats": stats(sections), "sections": sections, "applied": apply}

    if not apply:
        return result

    before = snapshot(vault)
    captures = write_captures(vault, sections, answers_file.name)
    result["captures"] = captures
    report = consolidate_captures(vault, captures, fixture=fixture)
    result["report"] = report
    seeded = seeded_inventory(vault, before)
    result["seeded"] = seeded
    result["identity_draft"] = draft_identity(vault, sections, answers_file.name)
    result["now_draft"] = draft_now(vault, sections, answers_file.name, seeded)
    result["cases"] = write_eval_cases(vault, sections, answers_file.name)
    return result


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(
        prog="mem onboard",
        description="Turn a filled-in docs/INTERVIEW.md into a vault.")
    parser.add_argument("answers", nargs="?", help="your answered interview, markdown")
    parser.add_argument("--apply", action="store_true",
                        help="actually write captures, seed entities, draft identity")
    parser.add_argument("--fixture", help="JSON candidates instead of calling an extractor")
    parser.add_argument("--approve-identity", action="store_true",
                        help="install the latest identity/now drafts, backing up the old ones")
    args = parser.parse_args(argv)

    vault = vault_path()

    if args.approve_identity:
        for line in approve_identity(vault):
            print(line)
        return 0

    if not args.answers:
        parser.error("give an answers file, or --approve-identity")

    result = run(vault, Path(args.answers), apply=args.apply,
                 fixture=Path(args.fixture) if args.fixture else None)
    s = result["stats"]
    print(f"parsed {s['sections']} sections, {s['questions']} questions, "
          f"{s['answered']} answered, {s['words']} words")

    if not args.apply:
        for section in result["sections"]:
            answered = sum(1 for q in section["questions"] if q["answered"])
            flag = "" if answered else "   <- nothing answered"
            print(f"  {section['num']:>2}. {section['title'][:48]:<50} "
                  f"{answered}/{len(section['questions'])}{flag}")
        print("\ndry run. nothing written. re-run with --apply")
        return 0

    report = result["report"]
    print(f"\ncaptures filed: {len(result['captures'])}")
    print(f"facts written: {len(report['kept'])}, rejected: {len(report['rejected'])}, "
          f"ungrounded: {len(report.get('ungrounded', []))}")
    for folder, names in sorted(result["seeded"].items()):
        print(f"  seeded {folder}: {', '.join(names)}")
    print(f"eval golden cases: {len(result['cases'])}")
    print(f"\nidentity draft: {result['identity_draft'].relative_to(vault)}")
    print(f"now draft:      {result['now_draft'].relative_to(vault)}")
    print("identity.md and now.md are UNTOUCHED. read the drafts, edit them, then:")
    print("  python3 -m mem onboard --approve-identity")

    if report.get("extractor_failed"):
        print(f"\nFAIL: {report['extractor_message']}", file=sys.stderr)
        print("Captures were filed to episodic/inbox/ and are unconsolidated, so "
              "nothing is lost -- fix the extractor and re-run "
              "`python3 -m mem consolidate` to pick them up.", file=sys.stderr)
        return 1
    return 0
