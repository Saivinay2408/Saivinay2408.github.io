"""Builds ``index.json``: a derived, disposable projection of the markdown graph.

Markdown stays the source of truth. The index exists because markdown is bad at
the three things retrieval needs: structured queries, aggregates, and scoring
over a token vocabulary. It holds nothing that is not recoverable from the notes,
so deleting it is always safe.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

from .config import ENTITY_FOLDERS, REPO_ROOT, vault_path
from .core import read_note

WIKILINK = re.compile(r"\[\[([^\[\]|#]+?)(?:\|[^\[\]]*)?\]\]")

# A superseded bullet looks like:
#   - key:: value (valid_to: .., valid_from: .., provenance: [[..]]) [superseded]
# The metadata group must not be anchored to end-of-line, or that trailing tag
# makes the whole match fail and we silently lose valid_to and provenance on
# exactly the bi-temporal facts the design exists to preserve.
FACT = re.compile(
    r"^- (?P<key>[\w-]+):: (?P<val>.*?)"
    r"(?:\s*\((?P<meta>[^)]*(?:\[\[[^\]]*\]\])?[^)]*)\))?"
    r"(?:\s*\[(?P<tag>[^\]]*)\])?\s*$"
)

STOPWORDS = {
    "the", "a", "an", "of", "and", "to", "in", "is", "it", "for", "on", "with",
    "his", "her", "he", "she", "him", "they", "my", "me", "i", "at", "as",
    "that", "this", "was", "were", "not", "but", "so", "we", "you",
}

CAPTURE_FOLDERS = ("inbox", "sessions")


def tokenize(text: str) -> list[str]:
    return [t for t in re.findall(r"[a-z0-9]+", text.lower()) if t not in STOPWORDS and len(t) > 1]


def parse_facts(body: str, header: str) -> list[dict]:
    lines = body.splitlines()
    start = end = -1
    for i, line in enumerate(lines):
        if line.strip() == header:
            start = i + 1
        elif start != -1 and line.startswith("## "):
            end = i
            break
    if start == -1:
        return []
    if end == -1:
        end = len(lines)

    out = []
    for line in lines[start:end]:
        match = FACT.match(line.strip())
        if not match:
            continue
        meta = match.group("meta") or ""
        valid_from = re.search(r"valid_from: ([\d-]+)", meta)
        valid_to = re.search(r"valid_to: ([\d-]+)", meta)
        provenance = re.search(r"provenance: \[\[([^\]]+)\]\]", meta)
        out.append({
            "key": match.group("key"),
            "value": match.group("val").strip(),
            "valid_from": valid_from.group(1) if valid_from else None,
            "valid_to": valid_to.group(1) if valid_to else None,
            "provenance": provenance.group(1) if provenance else None,
            "superseded": "[superseded" in line,
        })
    return out


def external_targets(root: Path = REPO_ROOT) -> set:
    """Link targets that legitimately live outside the vault (repo docs).

    A wikilink to `[[SCHEMA]]` from a note is a real reference, not a broken
    edge. Keeping one definition of "external" means the indexer and the
    maintenance pass can never disagree about what counts as dangling.
    """
    ext = set()
    for path in list(Path(root).glob("*.md")) + list((Path(root) / "docs").glob("*.md")):
        ext.add(path.stem.lower())
    return ext


def node_type(path: Path, frontmatter: dict) -> str | None:
    folder = path.parent.name
    if path.name in ("identity.md", "now.md"):
        return "identity-core"
    if folder in ENTITY_FOLDERS:
        return str(frontmatter.get("type") or folder[:-1])
    if folder in CAPTURE_FOLDERS:
        return "capture"
    if "episodic" in path.parts:
        return "event"
    if folder == "proposals":
        return "proposal"
    return None


def build(vault: Path | None = None) -> dict:
    vault = Path(vault) if vault else vault_path()
    nodes, edges = [], []

    for path in sorted(vault.rglob("*.md")):
        if "archive" in path.parts:
            continue
        frontmatter, body = read_note(path)
        ntype = node_type(path, frontmatter)
        if ntype is None:
            continue

        title = body.splitlines()[0].lstrip("# ").strip() if body.strip() else path.stem
        current = parse_facts(body, "## Current facts")
        history = parse_facts(body, "## History")
        aliases = [str(a) for a in (frontmatter.get("aliases") or [])]
        searchable = f"{title} " + " ".join(f["key"] + " " + f["value"] for f in current) + " " + body[:1500]

        node = {
            "id": frontmatter.get("id") or path.stem,
            "stem": path.stem,
            "path": path.relative_to(vault).as_posix(),
            "type": ntype,
            "title": title,
            "aliases": aliases,
            "salience": int(frontmatter.get("salience", 5) or 5),
            "created": str(frontmatter.get("created") or frontmatter.get("date") or ""),
            "updated": str(frontmatter.get("updated") or frontmatter.get("date") or ""),
            "facts": current,
            "history": history,
            "n_facts": len(current),
            "tokens": sorted(set(tokenize(searchable))),
            # Name tokens are scored separately and weighted higher. A query that
            # hits a note's title is far stronger evidence than one that hits a
            # passing mention in its prose.
            "name_tokens": sorted(set(tokenize(
                title + " " + path.stem.replace("-", " ") + " " + " ".join(aliases)
            ))),
        }
        if ntype == "capture":
            # Raw transcripts would swamp relevance scoring, and they hold no
            # facts of their own: they are what facts point *at*.
            node.pop("tokens")
            node["facts"] = []
        nodes.append(node)

        raw = path.read_text(encoding="utf-8")
        if path.parent.name not in CAPTURE_FOLDERS:
            for target in sorted(set(WIKILINK.findall(raw))):
                edges.append({"src": path.stem, "dst": target.strip(), "rel": "links_to"})
        for fact in current:
            if fact.get("provenance"):
                edges.append({"src": path.stem, "dst": fact["provenance"], "rel": "provenance"})

    stems = {n["stem"] for n in nodes}
    ids = {n["id"] for n in nodes}
    ext = external_targets()
    for edge in edges:
        if edge["dst"] in stems or edge["dst"] in ids:
            edge["resolved"] = True
        elif edge["dst"].lower() in ext:
            edge["resolved"] = True
            edge["external"] = True
        else:
            edge["resolved"] = False

    dangling = [e for e in edges if not e["resolved"]]
    external = [e for e in edges if e.get("external")]
    return {
        "generated_by": "mem.indexer",
        "note": "DERIVED FILE. Safe to delete and rebuild. Markdown is the source of truth.",
        "counts": {
            "nodes": len(nodes),
            "edges": len(edges),
            "by_type": {t: sum(1 for n in nodes if n["type"] == t)
                        for t in sorted({n["type"] for n in nodes})},
            "facts": sum(n["n_facts"] for n in nodes),
            "external_edges": len(external),
            "dangling_edges": len(dangling),
        },
        "dangling": [f"{e['src']} -> {e['dst']}" for e in dangling][:50],
        "nodes": nodes,
        "edges": edges,
    }


def write_index(vault: Path | None = None) -> dict:
    vault = Path(vault) if vault else vault_path()
    index = build(vault)
    (vault / "index.json").write_text(
        json.dumps(index, indent=1, ensure_ascii=False), encoding="utf-8"
    )
    return index


def load_index(vault: Path | None = None) -> dict:
    vault = Path(vault) if vault else vault_path()
    path = vault / "index.json"
    if path.exists():
        return json.loads(path.read_text(encoding="utf-8"))
    return build(vault)


def main(argv=None) -> int:
    index = write_index()
    counts = index["counts"]
    print(f"index.json: {counts['nodes']} nodes, {counts['edges']} edges, {counts['facts']} facts")
    internal = counts["edges"] - counts["external_edges"] - counts["dangling_edges"]
    print(f"  edges: {internal} internal, {counts['external_edges']} external, "
          f"{counts['dangling_edges']} DANGLING")
    for line in index["dangling"][:10]:
        print(f"    DANGLING {line}")
    for ntype, n in counts["by_type"].items():
        print(f"  {ntype:<14} {n}")
    return 0
