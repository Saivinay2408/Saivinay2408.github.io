"""
mcp — the vault as an MCP server, so agents other than Claude Code can reach it.

WHY THIS EXISTS
---------------
`hooks.py` is the good path: three lifecycle events that fire on their own, so
the self-model is loaded involuntarily and recall happens per message whether or
not the model thinks to ask. Nothing has to cooperate.

Claude Code is currently the only one of the three major coding CLIs that
exposes those events. Codex and Gemini CLI do not have a SessionStart, a
UserPromptSubmit or a Stop. What all three *do* have is MCP. So this module is
the second-best mechanism, offered where the best one is unavailable, and the
difference is stated rather than papered over:

  Claude Code   hooks. Automatic. The model cannot forget to remember.
  Codex/Gemini  MCP tools + a seeded context file. Identity still arrives
                involuntarily (it is in AGENTS.md / GEMINI.md, which is read
                every session). Per-message recall becomes a tool the model
                chooses to call, prompted by an instruction in that same file.

That is a real downgrade and `agents.py` says so at install time. It is not a
reason to skip it: an agent that recalls when it thinks to is worth a great deal
more than one that cannot recall at all.

WHY THERE IS NO SDK HERE
------------------------
Mem has no dependencies and this does not change that. The stdio transport
is newline-delimited JSON-RPC 2.0 over stdin/stdout — three request types matter
(`initialize`, `tools/list`, `tools/call`) and the whole loop is under a hundred
lines. Taking a dependency to save those lines would cost every user of the
library an install, for a protocol surface that fits on one screen.

STDOUT IS THE WIRE. Nothing in this module may print. A stray debug line is a
protocol error that manifests as the agent silently losing the server, so
diagnostics go to stderr and only to stderr.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

from .config import vault_path

PROTOCOL_VERSION = "2025-06-18"
SERVER_NAME = "mem"
SERVER_VERSION = "1.0.0"

# Bigger than the hook path's budget on purpose. A hook fires on every single
# message and pays for itself every time; a tool call happens when the model
# decided it needed memory, which is a much stronger signal that the tokens
# are worth spending.
TOOL_BUDGET = 8000

TOOLS = [
    {
        "name": "recall",
        "description": (
            "Search the user's personal memory vault for what they have said, "
            "decided, preferred or built before. Call this whenever the answer "
            "depends on who this specific user is — their preferences, their "
            "projects, their past decisions, their people — rather than on "
            "general knowledge. Returns nothing when the vault holds nothing "
            "relevant, which is a normal and useful answer."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "What you want to know about the user. Use "
                                   "their own words where you have them.",
                },
            },
            "required": ["query"],
        },
    },
    {
        "name": "identity",
        "description": (
            "Load the user's self-model: who they are, how they think, and what "
            "they are working on right now. Call this once at the start of a "
            "session if it has not already been provided in your context."
        ),
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "remember",
        "description": (
            "Write something down about the user that should outlive this "
            "conversation — a stated preference, a decision, a correction to "
            "something the vault got wrong. Use their own words. Do not use "
            "this for facts about code, which the repository already records."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "text": {
                    "type": "string",
                    "description": "The thing to remember, in one or two sentences.",
                },
            },
            "required": ["text"],
        },
    },
]


def _log(message: str) -> None:
    """stderr, always. See the module docstring: stdout is the wire."""
    print(f"[mem-mcp] {message}", file=sys.stderr, flush=True)


# ------------------------------------------------------------------ the tools

def tool_recall(args: dict, vault: Path) -> str:
    from .recall import context_block
    query = str(args.get("query") or "").strip()
    if not query:
        return "No query given."
    # No session_id: the dedup ledger keys off a harness-provided session id,
    # and a tool call does not carry one. Dedup is therefore a Claude-Code-path
    # optimisation only. Passing a fabricated id here would be worse than
    # skipping it — it would suppress facts on their first delivery.
    block = context_block(vault=vault, query=query, budget=TOOL_BUDGET)
    return block or ("Nothing in the vault clears the relevance bar for that. "
                     "Answer from general knowledge, and do not invent a "
                     "personal detail to fill the gap.")


def tool_identity(_args: dict, vault: Path) -> str:
    from .hooks import session_start
    return session_start(vault) or "The vault has no identity notes yet."


def tool_remember(args: dict, vault: Path) -> str:
    """Append to the capture inbox, where consolidation will find it.

    Deliberately NOT a direct write into the graph. Everything else in this
    library earns its way in through the same reject gate, and a tool the model
    can call is the last thing that should get to bypass it — that is precisely
    the path by which a memory system fills up with things the model assumed.
    """
    text = str(args.get("text") or "").strip()
    if not text:
        return "Nothing to remember."
    from .capture import write_manual_summary
    try:
        path = write_manual_summary(vault, text)
    except Exception as e:                              # noqa: BLE001
        _log(f"remember failed: {e}")
        return f"Could not write that down: {e}"
    return (f"Noted. It goes through the same consolidation gate as everything "
            f"else, so it becomes lasting memory only if it holds up ({path.name}).")


HANDLERS = {"recall": tool_recall, "identity": tool_identity, "remember": tool_remember}


# ------------------------------------------------------------------- protocol

def handle(message: dict, vault: Path) -> dict | None:
    """One JSON-RPC message in, at most one response out.

    Returns None for notifications, which by the spec must not be answered.
    Answering one is the classic way to wedge a client that is strict about it.
    """
    method = message.get("method")
    msg_id = message.get("id")

    if method == "initialize":
        return _ok(msg_id, {
            "protocolVersion": PROTOCOL_VERSION,
            "capabilities": {"tools": {}},
            "serverInfo": {"name": SERVER_NAME, "version": SERVER_VERSION},
        })

    if method in ("notifications/initialized", "notifications/cancelled"):
        return None

    if method == "ping":
        return _ok(msg_id, {})

    if method == "tools/list":
        return _ok(msg_id, {"tools": TOOLS})

    if method == "tools/call":
        params = message.get("params") or {}
        name = params.get("name")
        handler = HANDLERS.get(name)
        if handler is None:
            return _err(msg_id, -32602, f"unknown tool: {name}")
        try:
            text = handler(params.get("arguments") or {}, vault)
        except Exception as e:                          # noqa: BLE001
            # A tool that raises must not take the server down with it. The
            # agent gets a readable failure and the session keeps working.
            _log(f"{name} raised {type(e).__name__}: {e}")
            return _ok(msg_id, {
                "content": [{"type": "text", "text": f"mem {name} failed: {e}"}],
                "isError": True,
            })
        return _ok(msg_id, {"content": [{"type": "text", "text": text}]})

    if msg_id is None:
        return None                                     # unknown notification
    return _err(msg_id, -32601, f"method not found: {method}")


def _ok(msg_id, result: dict) -> dict:
    return {"jsonrpc": "2.0", "id": msg_id, "result": result}


def _err(msg_id, code: int, message: str) -> dict:
    return {"jsonrpc": "2.0", "id": msg_id, "error": {"code": code, "message": message}}


def serve(vault: Path | None = None, stdin=None, stdout=None) -> int:
    """The stdio loop. Reads newline-delimited JSON-RPC, writes the same.

    `stdin`/`stdout` are injectable so the whole protocol can be exercised in a
    test without a subprocess or a real agent.
    """
    vault = Path(vault) if vault else vault_path()
    stdin = stdin or sys.stdin
    stdout = stdout or sys.stdout
    _log(f"serving vault {vault}")

    for line in stdin:
        line = line.strip()
        if not line:
            continue
        try:
            message = json.loads(line)
        except ValueError:
            # Malformed input is the client's problem, not a reason to exit —
            # a server that dies on one bad frame loses the whole session.
            _log("ignoring a line that was not JSON")
            continue
        if not isinstance(message, dict):
            continue
        try:
            response = handle(message, vault)
        except Exception as e:                          # noqa: BLE001
            _log(f"handler crashed: {type(e).__name__}: {e}")
            response = _err(message.get("id"), -32603, str(e))
        if response is None:
            continue
        stdout.write(json.dumps(response) + "\n")
        stdout.flush()
    return 0


def main(argv=None) -> int:
    import argparse
    parser = argparse.ArgumentParser(
        prog="mem mcp",
        description="serve the vault over MCP (stdio) for Codex, Gemini CLI, "
                    "or anything else that speaks the protocol")
    parser.add_argument("--vault", help="vault location (default: $MEM_DIR)")
    args = parser.parse_args(list(sys.argv[1:] if argv is None else argv))
    return serve(vault_path(args.vault))


if __name__ == "__main__":
    sys.exit(main())
