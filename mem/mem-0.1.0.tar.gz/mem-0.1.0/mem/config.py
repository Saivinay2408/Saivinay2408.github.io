"""Where the vault lives, and nothing else.

Every module imports `vault_path()` rather than hardcoding a directory, so a test
(or a benchmark harness driving a throwaway corpus) can point the whole system at
a temp directory with one environment variable.
"""
from __future__ import annotations

import os
from pathlib import Path

ENV_VAR = "MEM_DIR"
# Where a chosen vault location is remembered. A GUI launch inherits nothing
# from your login shell -- double-clicking the app runs with an empty
# environment -- so MEM_DIR in a .zshrc cannot reach it, and without somewhere
# to write the choice down the window is stuck on whatever the default is.
# Deliberately not in the vault: it is the pointer TO the vault.
SETTINGS = Path.home() / ".mem" / "config.json"
REPO_ROOT = Path(__file__).resolve().parent.parent

# True when the package is being run out of a git clone rather than out of
# site-packages. The repository is the supported way to run Mem (the
# verifier, the benchmarks and seed_persona.py all resolve `examples/` and
# `tools/` relative to REPO_ROOT), but the package still has to behave when it
# is merely installed: writing somebody's vault into site-packages, where the
# next `pip install --upgrade` silently deletes it, is not an option.
IS_SOURCE_CHECKOUT = (REPO_ROOT / "pyproject.toml").is_file() and (
    REPO_ROOT / "examples"
).is_dir()

DEFAULT_VAULT = (
    REPO_ROOT / "vault" if IS_SOURCE_CHECKOUT else Path.home() / ".mem" / "vault"
)


def saved_vault() -> Path | None:
    """The vault this machine was told to use, if it was told.

    Read with json, tolerant of anything: a broken settings file must degrade
    to the default rather than take down a hook that runs inside somebody's
    coding session.
    """
    try:
        import json
        data = json.loads(SETTINGS.read_text(encoding="utf-8"))
        chosen = data.get("vault")
    except (OSError, ValueError, AttributeError):
        return None
    return Path(chosen).expanduser().resolve() if chosen else None


def set_vault(path: str | Path) -> Path:
    """Remember which vault to use, for launches that have no shell."""
    import json
    resolved = Path(path).expanduser().resolve()
    SETTINGS.parent.mkdir(parents=True, exist_ok=True)
    try:
        data = json.loads(SETTINGS.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        data = {}
    data["vault"] = str(resolved)
    SETTINGS.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
    return resolved


def vault_path(override: str | Path | None = None) -> Path:
    """Most explicit wins: an argument, then the environment, then what this
    machine was told to use, then the default."""
    if override:
        return Path(override).expanduser().resolve()
    env = os.environ.get(ENV_VAR)
    if env:
        return Path(env).expanduser().resolve()
    return saved_vault() or DEFAULT_VAULT


# Folders that hold entity nodes. Order matters only for cross-type resolution,
# where the first plausible hit wins.
ENTITY_FOLDERS = [
    "people",
    "projects",
    "concepts",
    "artifacts",
    "skills",
    "goals",
    "organizations",
    "procedures",
]

# entity type -> folder. Only irregular plurals need an entry.
_IRREGULAR = {"person": "people"}


def folder_for(entity_type: str) -> str:
    return _IRREGULAR.get(entity_type, entity_type + "s")


def type_for(folder: str) -> str:
    for etype, f in _IRREGULAR.items():
        if f == folder:
            return etype
    return folder[:-1]
