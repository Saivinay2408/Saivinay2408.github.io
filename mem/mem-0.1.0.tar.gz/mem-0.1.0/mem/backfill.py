"""Learn from the conversations you have already had.

The best onboarding question is the one you don't have to ask. Anyone who has
used Claude Code has a folder of transcripts — months of real decisions, real
preferences, real corrections, in their own words. That is a better source than
an interview, because it is what someone actually did rather than what they
say they do when asked.

    python3 -m mem backfill                 # what's there, writes nothing
    python3 -m mem backfill --apply         # capture it
    python3 -m mem backfill --apply --days 90 --max 200

This only CAPTURES. Captures are inert markdown in `episodic/`; nothing enters
the vault as a fact until consolidation runs them through the same REJECT gate
as everything else, quote-grounded against the source. Backfilling a thousand
sessions cannot flood the vault with junk, because the gate is the same gate.

Deliberately not automatic. Reading your own history is a decision you should
make on purpose, and `--apply` is where you make it.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
from pathlib import Path

from .config import vault_path

# Claude Code's transcript layout: one directory per project cwd, one JSONL per
# session. Overridable the same way the CLI overrides it.
CLAUDE_HOME = Path(os.environ.get("CLAUDE_CONFIG_DIR", Path.home() / ".claude"))
PROJECTS = CLAUDE_HOME / "projects"

# Below this a transcript is a false start — one prompt, a typo, an accidental
# launch. There is nothing in it to learn and it costs a consolidation slot.
MIN_BYTES = 4_000
DEFAULT_DAYS = 180
DEFAULT_MAX = 150


def discover(days: int = DEFAULT_DAYS, min_bytes: int = MIN_BYTES,
             projects: Path | None = None) -> list[dict]:
    """Transcripts worth reading, newest first.

    Sorted by recency and capped by the caller because a long-time user has
    thousands, and the recent ones describe who they are *now* — which is the
    thing the identity core is supposed to hold.
    """
    root = projects or PROJECTS
    cutoff = time.time() - days * 86400
    found = []
    try:
        candidates = list(root.glob("*/*.jsonl"))
    except OSError:
        return []
    for path in candidates:
        try:
            stat = path.stat()
        except OSError:
            continue
        if stat.st_mtime < cutoff or stat.st_size < min_bytes:
            continue
        found.append({"path": path, "mtime": stat.st_mtime, "bytes": stat.st_size,
                      "project": _cwd_of(path) or path.parent.name})
    found.sort(key=lambda f: -f["mtime"])
    return found


def _cwd_of(path: Path) -> str:
    """The real working directory, read from inside the transcript.

    The directory name is NOT reversible: Claude Code builds it by replacing
    every "/" with "-", so `-Users-me-my-project` is as consistent with
    `my/project` as with `my-project`. Every record carries the true `cwd`, so
    read it instead of trying to undo the mangling.
    """
    try:
        with path.open("r", encoding="utf-8", errors="replace") as f:
            for _ in range(20):
                line = f.readline()
                if not line:
                    break
                try:
                    cwd = json.loads(line).get("cwd")
                except ValueError:
                    continue
                if cwd:
                    return Path(cwd).name
    except OSError:
        pass
    return ""


def run(vault: Path, days: int = DEFAULT_DAYS, limit: int = DEFAULT_MAX,
        apply: bool = False) -> dict:
    from . import capture

    found = discover(days)
    selected = found[:limit]
    written: list[Path] = []
    if apply:
        for item in selected:
            try:
                path = capture.write_session(
                    vault, str(item["path"]), project=item["project"],
                    session_id=item["path"].stem)
            except Exception:                       # noqa: BLE001
                continue                            # one bad transcript is not fatal
            if path:
                written.append(path)

    projects: dict[str, int] = {}
    for item in selected:
        projects[item["project"]] = projects.get(item["project"], 0) + 1
    return {"found": len(found), "selected": len(selected), "written": written,
            "projects": projects, "bytes": sum(i["bytes"] for i in selected)}


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(
        prog="mem backfill",
        description="seed the vault from your existing Claude Code transcripts")
    parser.add_argument("--apply", action="store_true", help="write the captures")
    parser.add_argument("--days", type=int, default=DEFAULT_DAYS,
                        help=f"how far back to look (default {DEFAULT_DAYS})")
    parser.add_argument("--max", type=int, default=DEFAULT_MAX, dest="limit",
                        help=f"most recent N transcripts (default {DEFAULT_MAX})")
    parser.add_argument("--vault")
    args = parser.parse_args(list(sys.argv[1:] if argv is None else argv))

    vault = vault_path(args.vault)
    if not PROJECTS.is_dir():
        print(f"No transcripts at {PROJECTS}.\n"
              "Nothing to backfill — answer docs/QUICKSTART.md instead, or just "
              "start working and let the Stop hook capture as you go.")
        return 0

    result = run(vault, days=args.days, limit=args.limit, apply=args.apply)
    if not result["selected"]:
        print(f"Found no transcripts over {MIN_BYTES:,} bytes in the last "
              f"{args.days} days.\nTry --days 365, or just start working.")
        return 0

    top = sorted(result["projects"].items(), key=lambda kv: -kv[1])[:8]
    print(f"{result['found']} transcripts in the last {args.days} days; "
          f"taking the {result['selected']} most recent "
          f"({result['bytes'] / 1e6:.1f} MB) across {len(result['projects'])} projects:\n")
    for name, count in top:
        print(f"  {count:>4}  {name}")
    if len(result["projects"]) > len(top):
        print(f"  {'…':>4}  and {len(result['projects']) - len(top)} more")

    if not args.apply:
        print("\nDry run, nothing written. Re-run with --apply to capture these.")
        print("Captures are inert: consolidation still gates every candidate "
              "against your own words before anything enters the vault.")
        return 0

    print(f"\ncaptured {len(result['written'])} sessions into episodic/")
    print("\nNext:")
    print("  python3 -m mem check-extractor   # confirm extraction can run")
    print("  python3 -m mem consolidate       # distil them into facts")
    print("  python3 -m mem verify            # check the graph is sound")
    return 0
