"""
agents — wire the vault into Claude Code, Codex, or Gemini CLI.

    mem init            every agent this machine actually has
    mem init claude
    mem init codex --dry-run

ONE HONEST TABLE
----------------
The three CLIs do not offer the same thing, and pretending otherwise would mean
shipping a feature that quietly works less well on two of them:

                 identity at start   recall per message      capture at end
  Claude Code    SessionStart hook   UserPromptSubmit hook   Stop hook
  Codex          AGENTS.md           `recall` MCP tool       `remember` tool
  Gemini CLI     GEMINI.md           `recall` MCP tool       `remember` tool

Only Claude Code has lifecycle hooks. On the other two, identity still arrives
involuntarily — the context file is read every session, that is what it is for —
but recall becomes something the model elects to do, and capture likewise. The
install prints this. A user who is choosing between agents should be told which
one gives them the better version, and a user on Codex should know that "it
didn't remember" has a different cause there than it would on Claude.

WHAT IS NOT DONE HERE
---------------------
Neither Codex nor Gemini CLI was installed on the machine this was written on,
so the adapters below are built from each project's documented configuration
format, not from a live round trip. The formats are simple and stable and the
writes are merge-not-clobber with a `--dry-run` that prints exactly what would
change — but `verify_wiring` reads the file back and re-parses it rather than
trusting the write, and until somebody runs this against a real Codex or Gemini
install, treat those two rows as "believed correct" rather than "observed".
That distinction is cheap to state and expensive to omit.
"""
from __future__ import annotations

import copy
import json
import os
import shutil
import sys
from dataclasses import dataclass
from pathlib import Path

from .config import ENV_VAR, REPO_ROOT, vault_path

MARKER = "mem"
SERVER_KEY = "mem"

# Bracketed so an update can find and replace exactly its own block, leaving
# whatever else the user keeps in that file completely alone. Two sets, because
# a marker has to be a COMMENT in the file it lives in: an HTML comment in a
# markdown context file is invisible, and in a TOML config it is a syntax error
# that stops the agent reading its own settings. (Found by verify_wiring on the
# first real run, which is what that function is for.)
BLOCK_START = "<!-- mem:start -->"
BLOCK_END = "<!-- mem:end -->"
TOML_START = "# >>> mem start"
TOML_END = "# <<< mem end"

CONTEXT_INSTRUCTIONS = """\
## Your memory of this user

You have a personal memory vault for this user, served over MCP as `mem`.

- Call `identity` once at the start of a session to load who they are, how they
  think, and what they are working on now.
- Call `recall` whenever the right answer depends on *this specific user* —
  their preferences, their projects, their past decisions, their people —
  rather than on general knowledge. It returns nothing when it holds nothing
  relevant, and that is a useful answer: do not invent a personal detail to
  fill the gap.
- Call `remember` when they tell you something that should outlive this
  conversation: a stated preference, a decision, a correction to something you
  had wrong. Use their own words.

This is their long-term memory, not a scratchpad for facts about the code. The
repository already records the code.
"""


@dataclass(frozen=True)
class Wiring:
    agent: str
    path: Path
    changed: list[str]
    wrote: bool
    backup: Path | None
    note: str = ""


def _stamp() -> str:
    import datetime
    return datetime.datetime.now().strftime("%Y%m%dT%H%M%S")


def _backup(path: Path) -> Path | None:
    if not path.exists():
        return None
    dest = path.with_suffix(path.suffix + f".bak-{_stamp()}")
    dest.write_text(path.read_text(encoding="utf-8"), encoding="utf-8")
    return dest


def mcp_command(vault: Path) -> tuple[str, list[str], dict]:
    """How to launch the MCP server: (command, args, env).

    `sys.executable` rather than a bare "python3" on purpose. The user may well
    have installed mem into a virtualenv, and the agent that launches this
    server will not have that virtualenv activated — a bare interpreter name
    resolves to whichever Python is on the agent's PATH, which is how you get a
    server that works when you test it by hand and fails when the agent starts it.
    """
    env = {ENV_VAR: str(vault)}
    if not _installed():
        # Running out of a checkout rather than site-packages: the server needs
        # to be able to import the package it is part of.
        env["PYTHONPATH"] = str(REPO_ROOT)
    return sys.executable, ["-m", "mem", "mcp"], env


def _installed() -> bool:
    """Is `mem` importable without help from PYTHONPATH?"""
    return "site-packages" in str(Path(__file__).resolve()) or \
        not (REPO_ROOT / "pyproject.toml").is_file()


# ------------------------------------------------------------- context files

def merge_context_file(path: Path, body: str) -> tuple[str, bool]:
    """Put our block into a markdown context file, idempotently.

    Returns (new text, changed). The block is delimited by HTML comments, so a
    second run replaces our section in place instead of appending a second copy
    — and everything the user wrote around it survives untouched. Appending
    blindly is how a GEMINI.md ends up with the same paragraph six times.
    """
    block = f"{BLOCK_START}\n{body.rstrip()}\n{BLOCK_END}"
    try:
        current = path.read_text(encoding="utf-8")
    except OSError:
        current = ""

    if BLOCK_START in current and BLOCK_END in current:
        head, _, rest = current.partition(BLOCK_START)
        _, _, tail = rest.partition(BLOCK_END)
        updated = head + block + tail
    elif current.strip():
        updated = current.rstrip() + "\n\n" + block + "\n"
    else:
        updated = block + "\n"
    return updated, updated != current


# -------------------------------------------------------------- claude code

def wire_claude(project: Path, vault: Path, apply: bool) -> Wiring:
    """Hooks, via the existing installer. Not reimplemented — see hooks.py."""
    from .hooks import init_hooks
    result = init_hooks(project, REPO_ROOT, vault, apply=apply)
    return Wiring(agent="claude", path=result["path"], changed=result["changed"],
                  wrote=result["wrote"], backup=result["backup"],
                  note="hooks: identity, recall and capture all automatic")


# --------------------------------------------------------------------- codex

def _toml_escape(value: str) -> str:
    return value.replace("\\", "\\\\").replace('"', '\\"')


def render_codex_block(vault: Path) -> str:
    """The `[mcp_servers.mem]` table, as text.

    Written rather than round-tripped through a TOML library on purpose:
    Python has no TOML *writer* in the standard library (`tomllib` reads only),
    and taking a dependency to emit eleven lines would break the library's
    zero-dependency promise for every user, including the ones who never touch
    Codex.
    """
    command, args, env = mcp_command(vault)
    arglist = ", ".join(f'"{_toml_escape(a)}"' for a in args)
    lines = [
        f"[mcp_servers.{SERVER_KEY}]",
        f'command = "{_toml_escape(command)}"',
        f"args = [{arglist}]",
    ]
    if env:
        lines.append(f"[mcp_servers.{SERVER_KEY}.env]")
        lines += [f'{k} = "{_toml_escape(v)}"' for k, v in env.items()]
    return "\n".join(lines)


def merge_codex_toml(current: str, block: str) -> tuple[str, bool]:
    """Add or replace our tables in a config.toml, leaving the rest alone.

    A line-level splice, not a parse-and-reserialise. Reserialising would
    silently reformat the user's file and drop their comments, which is a rude
    thing for an installer to do to a config somebody hand-maintains.
    """
    wrapped = f"{TOML_START}\n{block}\n{TOML_END}"
    if TOML_START in current and TOML_END in current:
        head, _, rest = current.partition(TOML_START)
        _, _, tail = rest.partition(TOML_END)
        updated = head + wrapped + tail
    elif f"[mcp_servers.{SERVER_KEY}]" in current:
        # Wired by hand before, without our markers. Do not touch it: two
        # definitions of the same server is worse than one we did not write.
        return current, False
    elif current.strip():
        updated = current.rstrip() + "\n\n" + wrapped + "\n"
    else:
        updated = wrapped + "\n"
    return updated, updated != current


def wire_codex(project: Path, vault: Path, apply: bool) -> Wiring:
    home = Path(os.environ.get("CODEX_HOME", Path.home() / ".codex"))
    path = home / "config.toml"
    try:
        current = path.read_text(encoding="utf-8")
    except OSError:
        current = ""

    updated, changed = merge_codex_toml(current, render_codex_block(vault))
    ctx_path = project / "AGENTS.md"
    ctx_text, ctx_changed = merge_context_file(ctx_path, CONTEXT_INSTRUCTIONS)

    notes = []
    if changed:
        notes.append(f"mcp_servers.{SERVER_KEY}: wired")
    elif f"[mcp_servers.{SERVER_KEY}]" in current and TOML_START not in current:
        notes.append(f"mcp_servers.{SERVER_KEY}: already defined by hand, left alone")
    else:
        notes.append(f"mcp_servers.{SERVER_KEY}: already wired")
    notes.append(f"AGENTS.md: {'updated' if ctx_changed else 'already current'}")

    backup = None
    if apply and changed:
        backup = _backup(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(updated, encoding="utf-8")
    if apply and ctx_changed:
        ctx_path.parent.mkdir(parents=True, exist_ok=True)
        ctx_path.write_text(ctx_text, encoding="utf-8")

    return Wiring(agent="codex", path=path, changed=notes,
                  wrote=apply and (changed or ctx_changed), backup=backup,
                  note="MCP tools: identity involuntary via AGENTS.md, "
                       "recall and capture are the model's call")


# -------------------------------------------------------------------- gemini

def merge_gemini_settings(settings: dict, vault: Path) -> tuple[dict, bool]:
    command, args, env = mcp_command(vault)
    entry: dict = {"command": command, "args": args}
    if env:
        entry["env"] = env
    servers = settings.setdefault("mcpServers", {})
    if not isinstance(servers, dict):
        raise SystemExit("mcpServers in your Gemini settings is not an object; "
                         "fix or move it before wiring")
    if servers.get(SERVER_KEY) == entry:
        return settings, False
    servers[SERVER_KEY] = entry
    return settings, True


def wire_gemini(project: Path, vault: Path, apply: bool) -> Wiring:
    home = Path(os.environ.get("GEMINI_HOME", Path.home() / ".gemini"))
    path = home / "settings.json"
    settings: dict = {}
    if path.exists():
        try:
            settings = json.loads(path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            raise SystemExit(f"{path} is not valid JSON ({exc}); fix or move it first")
        if not isinstance(settings, dict):
            raise SystemExit(f"{path} is not a JSON object; fix or move it first")

    merged, changed = merge_gemini_settings(copy.deepcopy(settings), vault)
    ctx_path = project / "GEMINI.md"
    ctx_text, ctx_changed = merge_context_file(ctx_path, CONTEXT_INSTRUCTIONS)

    notes = [f"mcpServers.{SERVER_KEY}: {'wired' if changed else 'already wired'}",
             f"GEMINI.md: {'updated' if ctx_changed else 'already current'}"]

    backup = None
    if apply and changed:
        backup = _backup(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(merged, indent=2) + "\n", encoding="utf-8")
    if apply and ctx_changed:
        ctx_path.parent.mkdir(parents=True, exist_ok=True)
        ctx_path.write_text(ctx_text, encoding="utf-8")

    return Wiring(agent="gemini", path=path, changed=notes,
                  wrote=apply and (changed or ctx_changed), backup=backup,
                  note="MCP tools: identity involuntary via GEMINI.md, "
                       "recall and capture are the model's call")


# ------------------------------------------------------------------- registry

ADAPTERS = {"claude": wire_claude, "codex": wire_codex, "gemini": wire_gemini}

# How to tell whether the user actually has each one. The config directory
# counts as well as the binary: somebody may have the desktop app and not the
# CLI, and wiring the vault in ahead of the CLI install is harmless and useful.
PRESENCE = {
    "claude": ("claude", Path.home() / ".claude"),
    "codex": ("codex", Path.home() / ".codex"),
    "gemini": ("gemini", Path.home() / ".gemini"),
}


def detect() -> list[str]:
    """Which agents this machine appears to have, in preference order."""
    found = []
    for name, (binary, home) in PRESENCE.items():
        if shutil.which(binary) or home.is_dir():
            found.append(name)
    return found


def verify_wiring(agent: str, vault: Path) -> tuple[bool, str]:
    """Read the file back and confirm the server is really declared.

    Separate from the write on purpose. `wrote: True` only says a file was
    written; this says the result parses and contains what it should. For the
    two adapters that were never exercised against a live CLI, that difference
    is the whole point.
    """
    if agent == "claude":
        from .hooks import HOOK_MARKER, SETTINGS_REL
        path = Path.cwd() / SETTINGS_REL
        try:
            return HOOK_MARKER in path.read_text(encoding="utf-8"), str(path)
        except OSError:
            return False, str(path)

    if agent == "codex":
        path = Path(os.environ.get("CODEX_HOME", Path.home() / ".codex")) / "config.toml"
        try:
            raw = path.read_bytes()
        except OSError:
            return False, str(path)
        try:
            import tomllib
            data = tomllib.loads(raw.decode("utf-8"))
        except ValueError as e:
            return False, f"{path}: TOML no longer parses ({e})"
        except ImportError:                             # Python < 3.11
            return SERVER_KEY in raw.decode("utf-8", "replace"), str(path)
        return SERVER_KEY in (data.get("mcp_servers") or {}), str(path)

    if agent == "gemini":
        path = Path(os.environ.get("GEMINI_HOME", Path.home() / ".gemini")) / "settings.json"
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return False, str(path)
        return SERVER_KEY in (data.get("mcpServers") or {}), str(path)

    return False, agent


def wire(agent: str, project: Path, vault: Path, apply: bool = True) -> Wiring:
    adapter = ADAPTERS.get(agent)
    if adapter is None:
        raise SystemExit(f"unknown agent {agent!r}; pick one of "
                         f"{', '.join(sorted(ADAPTERS))}")
    return adapter(Path(project).expanduser().resolve(), vault, apply)


# ------------------------------------------------------------------------ cli

def main(argv=None) -> int:
    import argparse
    parser = argparse.ArgumentParser(
        prog="mem init",
        description="wire the vault into Claude Code, Codex, or Gemini CLI")
    parser.add_argument("agents", nargs="*", default=None,
                        help="claude, codex, gemini, or all "
                             "(default: whichever this machine has)")
    parser.add_argument("--project", default=".",
                        help="project directory for context files (default: cwd)")
    parser.add_argument("--vault", help=f"vault location (default: ${ENV_VAR})")
    parser.add_argument("--dry-run", action="store_true", help="print, write nothing")
    args = parser.parse_args(list(sys.argv[1:] if argv is None else argv))

    vault = vault_path(args.vault)
    project = Path(args.project).expanduser().resolve()

    wanted = args.agents or []
    if not wanted or wanted == ["auto"]:
        wanted = detect()
        if not wanted:
            print("No coding agent found on this machine (looked for claude, "
                  "codex, gemini).\nName one explicitly to wire it anyway: "
                  "mem init codex", file=sys.stderr)
            return 1
        print(f"found: {', '.join(wanted)}\n")
    elif wanted == ["all"]:
        wanted = list(ADAPTERS)

    print(f"vault: {vault}\n")
    failed = 0
    for agent in wanted:
        result = wire(agent, project, vault, apply=not args.dry_run)
        print(f"{agent}")
        print(f"  config : {result.path}")
        for line in result.changed:
            print(f"  {line}")
        if result.backup:
            print(f"  backed up: {result.backup.name}")
        print(f"  {result.note}")
        if not args.dry_run:
            ok, where = verify_wiring(agent, vault)
            print(f"  verified: {'yes' if ok else 'NO -- check ' + where}")
            failed += 0 if ok else 1
        print()

    if args.dry_run:
        print("(dry run, nothing written; drop --dry-run to apply)")
        return 0
    if failed:
        print(f"{failed} agent(s) did not verify. Nothing else was changed.",
              file=sys.stderr)
        return 1
    print("Done. Restart any running agent session to pick up the change.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
