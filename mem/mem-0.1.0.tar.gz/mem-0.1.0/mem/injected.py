"""What this session has already been told.

The single largest avoidable cost in the whole system, measured on a real
vault: recall injects the same facts over and over.

Retrieval is per-message and stateless, so a conversation that stays on one
subject retrieves the same five notes on every single turn. Each block is
~1,200 tokens. Those tokens do not replace the previous block — they are
appended to the conversation and stay there — so a forty-turn session about
one project accumulates ~48,000 tokens of memory, most of it the same handful
of facts repeated dozens of times. That is a quarter of a 200k context window
spent restating what the model was told on turn one, and it is re-read as
cached input on every turn after that.

The fix is not cleverer retrieval. The model already read the fact; it is still
in the conversation. So this records what has been injected per session and
filters it out of later blocks. A fact is injected once, and after that only
notes with something NEW to say are worth spending tokens on.

Two properties worth stating, because both are load-bearing:

    it is per session, not global. A new conversation starts with an empty set,
    because a new conversation genuinely has not been told anything.

    a fact whose VALUE changes is injected again. The key is the pair, not the
    name — a superseded fact is new information, and suppressing it would be
    the one failure mode worse than repetition: the model confidently acting on
    something it was told before you changed it.

State lives outside the vault (``~/.mem/sessions/``) for the same reason
the switch does: it is per-machine scratch, not memory, and it must never end
up in a commit.
"""
from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path

STATE_DIR = Path.home() / ".mem" / "sessions"
MAX_AGE_S = 7 * 24 * 3600      # a session id nobody has touched in a week is over
MAX_FACTS = 4000               # a runaway session cannot grow this file forever


def fact_id(stem: str, key: str, value: str) -> str:
    """Identity of one injected fact.

    The value is hashed in on purpose: if a consolidation pass supersedes
    ``ships:: march`` with ``ships:: may``, that is a different fact and has to
    reach the model even though the note and key are unchanged.
    """
    digest = hashlib.sha1(str(value).encode("utf-8", "replace")).hexdigest()[:10]
    return f"{stem}:{key}:{digest}"


def _path(session_id: str) -> Path:
    safe = "".join(c for c in str(session_id) if c.isalnum() or c in "-_")[:64]
    return STATE_DIR / f"{safe or 'anon'}.json"


def load(session_id: str) -> set[str]:
    """Fact ids already sent to this session. Never raises."""
    if not session_id:
        return set()
    try:
        data = json.loads(_path(session_id).read_text(encoding="utf-8"))
        return set(data.get("facts") or [])
    except (OSError, ValueError):
        return set()


def record(session_id: str, ids) -> None:
    """Add fact ids to this session's set. Never raises."""
    if not session_id:
        return
    ids = list(ids)
    if not ids:
        return
    try:
        seen = load(session_id)
        seen.update(ids)
        if len(seen) > MAX_FACTS:
            # Losing the oldest entries only costs a repeat injection, which is
            # exactly the state we were in before this file existed.
            seen = set(list(seen)[-MAX_FACTS:])
        STATE_DIR.mkdir(parents=True, exist_ok=True)
        _path(session_id).write_text(
            json.dumps({"facts": sorted(seen), "at": time.time()}), encoding="utf-8")
    except OSError:
        pass                    # a failed write costs tokens, never correctness


def prune(max_age_s: float = MAX_AGE_S) -> int:
    """Drop state for sessions nobody has touched in a week. Returns the count."""
    cutoff = time.time() - max_age_s
    dropped = 0
    try:
        entries = list(STATE_DIR.glob("*.json"))
    except OSError:
        return 0
    for path in entries:
        try:
            if path.stat().st_mtime < cutoff:
                path.unlink()
                dropped += 1
        except OSError:
            continue
    return dropped
