"""The maintenance pass: janitorial work on the graph, run off the live path.

Five jobs, in the order they should run:

  1. repair_links   id-style wikilinks rewritten to file stems
  2. fix_key_drift  fact keys that look like the same slot on one entity
  3. dedup          entity files that are the same entity twice
  4. reinforce      salience bumps for notes that recall actually used
  5. propose_now    machine-drafted edits to the human-curated now.md

The governing rule for all of them: **no destructive operation on an ambiguous
signal.** Merging is irreversible in practice even when the file is archived,
because every downstream link has already been rewritten. So a merge happens
automatically only on an exact shared name or alias, which is precisely what
extractor fragmentation produces. Everything weaker gets reported for a human and
left alone. The same logic gates key-drift collapsing behind an explicit flag.
"""
from __future__ import annotations

import argparse
import datetime
import json
import re
import shutil
from pathlib import Path

from .config import ENTITY_FOLDERS, REPO_ROOT, vault_path
from .core import (
    FACT_RE, read_note, resolve_any, section, slugify, today, tokens, write_note,
)
from .indexer import WIKILINK, external_targets

PROTECTED = {"identity.md", "now.md"}
TYPE_PREFIXES = (
    "person-", "project-", "concept-", "artifact-", "skill-", "goal-",
    "organization-", "org-", "procedure-", "event-",
)
REINFORCE_THRESHOLD = 3
SALIENCE_CAP = 9          # 10 stays reserved for human assignment
NOW_STALE_DAYS = 14


def all_notes(vault: Path) -> list[Path]:
    return [p for p in sorted(Path(vault).rglob("*.md")) if "archive" not in p.parts]


def graph_notes(vault: Path) -> list[Path]:
    """Notes the maintenance pass is allowed to rewrite."""
    out = []
    for path in all_notes(vault):
        if path.name in PROTECTED:
            continue
        if path.parent.name in ("inbox", "sessions"):
            continue      # raw captures are immutable records, not graph nodes
        out.append(path)
    return out


def link_index(vault: Path) -> dict:
    """target string -> canonical file stem, covering stems, ids, and aliases.

    Protected files are indexed: they are valid link targets even though nothing
    is allowed to write them.
    """
    index: dict[str, str] = {}
    for path in all_notes(vault):
        frontmatter, _ = read_note(path)
        index.setdefault(path.stem.lower(), path.stem)
        if frontmatter.get("id"):
            index.setdefault(str(frontmatter["id"]).lower(), path.stem)
        for alias in (frontmatter.get("aliases") or []):
            index.setdefault(slugify(str(alias)), path.stem)
            index.setdefault(str(alias).lower(), path.stem)
    return index


def resolve_link(target: str, index: dict, external: set) -> tuple[str | None, str]:
    """Return ``(canonical_stem_or_None, status)`` where status is
    ``ok`` | ``fix`` | ``external`` | ``dead``."""
    lowered = target.lower()
    if lowered in external:
        return None, "external"
    canon = index.get(lowered) or index.get(slugify(target))
    if not canon and "/" in lowered:
        base = lowered.rsplit("/", 1)[-1].removesuffix(".md")
        canon = index.get(base) or index.get(slugify(base))
    if not canon:
        for prefix in TYPE_PREFIXES:
            if lowered.startswith(prefix):
                bare = lowered[len(prefix):]
                canon = index.get(bare) or index.get(slugify(bare))
                if canon:
                    break
    if not canon:
        return None, "dead"
    return canon, ("ok" if canon == target else "fix")


# --------------------------------------------------------------------------- #
# 1. link repair
# --------------------------------------------------------------------------- #

def repair_links(vault: Path, apply: bool = False) -> dict:
    vault = Path(vault)
    index = link_index(vault)
    external = external_targets(REPO_ROOT)
    fixed, broken, ext_hits = [], [], []

    for path in graph_notes(vault):
        text = path.read_text(encoding="utf-8")
        out = text
        for raw in sorted(set(WIKILINK.findall(text))):
            target = raw.strip()
            if not target:
                continue
            canon, status = resolve_link(target, index, external)
            if status == "fix":
                out = out.replace(f"[[{raw}]]", f"[[{canon}]]")
                fixed.append(f"{path.name}: [[{target}]] -> [[{canon}]]")
            elif status == "external":
                ext_hits.append(f"{path.name}: [[{target}]]")
            elif status == "dead":
                broken.append(f"{path.name}: [[{target}]]")
        if apply and out != text:
            path.write_text(out, encoding="utf-8")
    return {"fixed": fixed, "broken": broken, "external": ext_hits}


# --------------------------------------------------------------------------- #
# 2. key drift
# --------------------------------------------------------------------------- #

def key_slot(key: str) -> frozenset:
    """Represent a fact key by its token set, so ``target`` and ``launch_target``
    land in the same slot by containment."""
    return frozenset(tokens(key.replace("_", " ").replace("-", " ")))


def fix_key_drift(vault: Path, apply: bool = False, merge: bool = False) -> dict:
    """Find fact keys on one entity that look like the same slot.

    **Review-only by default.** Token containment is not proof of sameness:
    ``degree`` is a subset of ``degree_correction``, but one is a credential and
    the other is a note that a typo was fixed. Auto-merging on containment
    demotes the real fact and promotes the meta-fact. A human opts in with
    ``--merge-keys``.

    The real remedy is upstream: consolidation shows the extractor each entity's
    existing keys, and exact-key supersession then does the right thing without
    anyone having to guess.
    """
    vault = Path(vault)
    merged, review = [], []

    for folder in ENTITY_FOLDERS:
        directory = vault / folder
        if not directory.exists():
            continue
        for path in sorted(directory.glob("*.md")):
            frontmatter, body = read_note(path)
            current, cstart, cend = section(body, "## Current facts")
            if cstart == -1:
                continue

            facts = []          # (key, bullet, valid_from)
            for bullet in current:
                match = FACT_RE.match(bullet.strip())
                if not match:
                    continue
                vf = re.search(r"valid_from: ([\d-]+)", bullet)
                facts.append((match.group("key"), bullet.strip(), vf.group(1) if vf else ""))
            if len(facts) < 2:
                continue

            groups: list[list] = []
            for fact in facts:
                slot = key_slot(fact[0])
                placed = False
                for group in groups:
                    gslot = key_slot(group[0][0])
                    if slot and gslot and (slot <= gslot or gslot <= slot):
                        group.append(fact)
                        placed = True
                        break
                if not placed:
                    groups.append([fact])

            if not any(len(g) > 1 for g in groups):
                continue

            keep, demote = [], []
            for group in groups:
                if len(group) == 1:
                    keep.append(group[0][1])
                    continue
                ordered = sorted(group, key=lambda f: f[2])      # oldest first
                winner = ordered[-1]                             # newest wins the slot
                if not merge:
                    for loser in ordered[:-1]:
                        review.append(f"{path.name}: [{loser[0]}] ~ [{winner[0]}] "
                                      f"(same slot? not merged)")
                    keep.extend(f[1] for f in group)
                    continue
                keep.append(winner[1])
                for loser in ordered[:-1]:
                    demote.append(loser[1])
                    merged.append(f"{path.name}: [{loser[0]}] superseded by [{winner[0]}]")

            if not apply or not demote:
                continue

            lines = body.splitlines()
            body2 = "\n".join(lines[:cstart] + [""] + keep + [""] + lines[cend:])
            closed = [
                bullet.replace("(valid_from:", f"(valid_to: {today()}, valid_from:", 1)
                + " [superseded: key-drift]"
                for bullet in demote
            ]
            history, hstart, hend = section(body2, "## History")
            lines2 = body2.splitlines()
            if hstart != -1:
                body2 = "\n".join(
                    lines2[:hstart] + [""] + [h for h in history if h.strip()] + closed + [""] + lines2[hend:]
                )
            else:
                body2 = "\n".join(lines2 + ["", "## History", ""] + closed)
            frontmatter["updated"] = today()
            write_note(path, frontmatter, body2)

    return {"merged": merged, "review": review}


# --------------------------------------------------------------------------- #
# 3. duplicate entities
# --------------------------------------------------------------------------- #

def find_duplicates(vault: Path) -> tuple[list, list]:
    """Split candidate duplicates into ``(auto, review)``.

    ``auto`` requires an identical name, alias, or title between two files. That
    is the exact fingerprint of extractor fragmentation, where a full name gets
    written as a new node while an existing node already carries it as an alias.

    ``review`` holds token-subset overlaps, which are reported and never merged.
    A subset relation is genuinely common between two distinct entities that
    share a naming prefix, and merging them destroys real data.
    """
    vault = Path(vault)
    auto, review = [], []

    for folder in ENTITY_FOLDERS:
        directory = vault / folder
        if not directory.exists():
            continue
        notes = []
        for path in sorted(directory.glob("*.md")):
            frontmatter, body = read_note(path)
            names = {path.stem} | {str(a) for a in (frontmatter.get("aliases") or [])}
            if body.strip():
                names.add(body.splitlines()[0].lstrip("# ").strip())
            slugs = {slugify(n) for n in names if slugify(n)}
            toks: set = set()
            for name in names:
                toks |= tokens(name)
            n_facts = len(re.findall(r"^- [\w-]+::", body, re.M))
            notes.append((path, frontmatter, slugs, toks, n_facts))

        for i, (pa, fa, sa, ta, na) in enumerate(notes):
            for pb, fb, sb, tb, nb in notes[i + 1:]:
                # canonical = whichever holds more facts, tie broken by older created
                ka = (na, str(fa.get("created") or ""))
                kb = (nb, str(fb.get("created") or ""))
                canon, dup = (pa, pb) if ka >= kb else (pb, pa)
                if sa & sb:
                    auto.append((canon, dup))
                elif len(ta) >= 2 and len(tb) >= 2 and (ta < tb or tb < ta):
                    review.append((canon, dup))
    return auto, review


def merge_entities(vault: Path, canon: Path, dup: Path, apply: bool = False) -> str:
    vault = Path(vault)
    cfm, cbody = read_note(canon)
    dfm, dbody = read_note(dup)

    aliases = [str(a) for a in (cfm.get("aliases") or [])]
    for alias in [str(a) for a in (dfm.get("aliases") or [])] + [dup.stem]:
        if alias not in aliases:
            aliases.append(alias)
    cfm["aliases"] = aliases
    cfm["salience"] = max(int(cfm.get("salience", 5) or 5), int(dfm.get("salience", 5) or 5))
    cfm["updated"] = today()

    dup_facts, _, _ = section(dbody, "## Current facts")
    canon_facts, cstart, cend = section(cbody, "## Current facts")
    have = {b.strip() for b in canon_facts if b.strip()}
    extra = [b.strip() for b in dup_facts if b.strip() and b.strip() not in have]

    body = cbody
    if extra and cstart != -1:
        lines = cbody.splitlines()
        body = "\n".join(
            lines[:cstart] + [""] + [b for b in canon_facts if b.strip()] + extra + [""] + lines[cend:]
        )

    if not apply:
        return f"WOULD MERGE {dup.name} -> {canon.name} (+{len(extra)} facts)"

    write_note(canon, cfm, body)
    for path in all_notes(vault):
        text = path.read_text(encoding="utf-8")
        rewritten = text.replace(f"[[{dup.stem}]]", f"[[{canon.stem}]]")
        if rewritten != text:
            path.write_text(rewritten, encoding="utf-8")
    archive = vault / "archive" / "merged"
    archive.mkdir(parents=True, exist_ok=True)
    shutil.move(str(dup), str(archive / dup.name))
    return f"merged {dup.name} -> {canon.name} (+{len(extra)} facts, duplicate archived)"


# --------------------------------------------------------------------------- #
# 4. access reinforcement
# --------------------------------------------------------------------------- #

def reinforce(vault: Path, apply: bool = False) -> list[str]:
    """Memories that get used should strengthen: the mirror of salience decay.

    Recall logs every access. Here, at sleep time, a note touched at least
    ``REINFORCE_THRESHOLD`` times gains one point of salience up to the cap, and
    the log is consumed so the same accesses cannot be counted twice.
    """
    vault = Path(vault)
    log = vault / "access.jsonl"
    if not log.exists():
        return []

    counts: dict[str, int] = {}
    for line in log.read_text(encoding="utf-8").splitlines():
        try:
            for stem in json.loads(line).get("hits", []):
                counts[stem] = counts.get(stem, 0) + 1
        except json.JSONDecodeError:
            continue

    out = []
    for folder in ENTITY_FOLDERS:
        directory = vault / folder
        if not directory.exists():
            continue
        for path in sorted(directory.glob("*.md")):
            hits = counts.get(path.stem, 0)
            if hits < REINFORCE_THRESHOLD:
                continue
            frontmatter, body = read_note(path)
            before = int(frontmatter.get("salience", 5) or 5)
            after = min(SALIENCE_CAP, before + 1)
            out.append(f"{path.stem}: {hits} accesses, salience {before} -> {after}")
            if apply:
                frontmatter["salience"] = after
                frontmatter["last_accessed"] = today()
                write_note(path, frontmatter, body)
    if apply:
        log.unlink()
    return out


# --------------------------------------------------------------------------- #
# 5. orphans and now.md proposals
# --------------------------------------------------------------------------- #

def find_orphans(vault: Path) -> list[str]:
    vault = Path(vault)
    linked = set()
    for path in all_notes(vault):
        for target in WIKILINK.findall(path.read_text(encoding="utf-8")):
            linked.add(target.strip().lower())
    out = []
    for folder in ENTITY_FOLDERS:
        directory = vault / folder
        if not directory.exists():
            continue
        for path in sorted(directory.glob("*.md")):
            _, body = read_note(path)
            if path.stem.lower() in linked:
                continue
            if not re.search(r"^- [\w-]+::", body, re.M):
                out.append(f"{folder}/{path.name} (no inbound links, no facts)")
    return out


def _parse_date(value: str) -> datetime.date:
    try:
        return datetime.date.fromisoformat(str(value)[:10])
    except ValueError:
        return datetime.date(1970, 1, 1)


def propose_now(vault: Path, apply: bool = False) -> list[str]:
    """Draft updates to ``now.md`` without touching it.

    ``now.md`` is human-curated and locked, which means it drifts. This closes
    that loop the only safe way: for every entity ``now.md`` mentions, list the
    graph facts newer than its ``updated`` stamp, and write them to a proposal
    file. The system notices. The human applies.
    """
    vault = Path(vault)
    now_path = vault / "now.md"
    if not now_path.exists():
        return []

    frontmatter, body = read_note(now_path)
    stamp = str(frontmatter.get("updated") or "1970-01-01")
    index = link_index(vault)

    mentioned = {t.strip().lower() for t in WIKILINK.findall(body)}
    for bold in re.findall(r"\*\*([^*]+)\*\*", body):
        name = bold.strip()
        stem = index.get(name.lower()) or index.get(slugify(name))
        if not stem:
            hit = resolve_any(vault, name)
            stem = hit.stem if hit else None
        if stem:
            mentioned.add(stem.lower())

    stale: list[str] = []
    age = (datetime.date.today() - _parse_date(stamp)).days
    if age > NOW_STALE_DAYS:
        stale.append(f"- now.md itself is {age} days old (updated {stamp}); review the "
                     f"prose even if no fact below changed")

    for folder in ENTITY_FOLDERS:
        directory = vault / folder
        if not directory.exists():
            continue
        for path in sorted(directory.glob("*.md")):
            if path.stem.lower() not in mentioned:
                continue
            _, note_body = read_note(path)
            current, _, _ = section(note_body, "## Current facts")
            for bullet in current:
                vf = re.search(r"valid_from: ([\d-]+)", bullet)
                if vf and vf.group(1) > stamp:
                    stale.append(f"- **{path.stem}** has a newer fact than now.md "
                                 f"({vf.group(1)} > {stamp}): {bullet.strip()[:160]}")

    if not stale:
        return []
    if apply:
        out = vault / "proposals" / f"now-{today()}.md"
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(
            f"---\ntype: proposal\ndate: {today()}\ntarget: now.md\n---\n"
            f"# Proposed updates to now.md (auto-generated, apply by hand)\n\n"
            f"now.md was last updated {stamp}. The graph has moved since:\n\n"
            + "\n".join(stale)
            + "\n\nAfter updating now.md and bumping its `updated:` stamp, delete this file.\n",
            encoding="utf-8",
        )
    return stale


# --------------------------------------------------------------------------- #
# CLI
# --------------------------------------------------------------------------- #

def main(argv=None) -> int:
    parser = argparse.ArgumentParser(prog="mem maintain")
    parser.add_argument("--apply", action="store_true", help="write changes (default: dry run)")
    parser.add_argument("--merge-dupes", action="store_true",
                        help="merge entities that share an exact name or alias")
    parser.add_argument("--merge-keys", action="store_true",
                        help="collapse fact keys that look like the same slot (opt-in)")
    args = parser.parse_args(argv)

    vault = vault_path()
    print(f"vault: {vault}" + ("" if args.apply else "   (dry run, nothing written)"))

    links = repair_links(vault, apply=args.apply)
    print(f"\nlinks: {len(links['fixed'])} fixed, {len(links['broken'])} broken, "
          f"{len(links['external'])} external")
    for line in links["fixed"][:10]:
        print(f"  fix  {line}")
    for line in links["broken"][:10]:
        print(f"  DEAD {line}")

    drift = fix_key_drift(vault, apply=args.apply, merge=args.merge_keys)
    print(f"\nkey drift: {len(drift['merged'])} merged, {len(drift['review'])} to review")
    for line in drift["review"][:10] + drift["merged"][:10]:
        print(f"  {line}")

    auto, review = find_duplicates(vault)
    print(f"\nduplicates: {len(auto)} auto-mergeable, {len(review)} need a human")
    for canon, dup in auto:
        print("  " + merge_entities(vault, canon, dup, apply=args.apply and args.merge_dupes))
    for canon, dup in review:
        print(f"  REVIEW {dup.name} ~ {canon.name} (token subset; not merged)")

    strengthened = reinforce(vault, apply=args.apply)
    print(f"\nreinforcement: {len(strengthened)} note(s)")
    for line in strengthened[:10]:
        print(f"  {line}")

    orphans = find_orphans(vault)
    print(f"\norphans: {len(orphans)}")
    for line in orphans[:10]:
        print(f"  {line}")

    stale = propose_now(vault, apply=args.apply)
    print(f"\nnow.md drift: {len(stale)} line(s)"
          + (" -> proposals/" if args.apply and stale else ""))
    for line in stale[:10]:
        print(f"  {line}")
    return 0
