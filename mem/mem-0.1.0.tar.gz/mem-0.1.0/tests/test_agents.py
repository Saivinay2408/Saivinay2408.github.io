"""
Wiring the vault into agents that are not Claude Code.

These exist because neither Codex nor Gemini CLI was installed on the machine
the adapters were written on. The formats came from each project's docs, so the
one thing that must be nailed down in a test is that what we WRITE is what that
format actually accepts — a TOML file that no longer parses, or a settings.json
that lost the user's other servers, is the whole failure mode.

The TOML case is not hypothetical: the first implementation wrapped its block in
HTML comments, which is a syntax error in TOML, and the config became unreadable
to Codex. `verify_wiring` caught it on the first real run. This locks it down.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from mem import agents                                       # noqa: E402

tomllib = pytest.importorskip("tomllib")


@pytest.fixture
def wired(tmp_path, monkeypatch):
    """A machine with a Codex and a Gemini config the user already uses."""
    codex, gemini, project = (tmp_path / "codex", tmp_path / "gemini",
                              tmp_path / "project")
    for d in (codex, gemini, project):
        d.mkdir()
    monkeypatch.setenv("CODEX_HOME", str(codex))
    monkeypatch.setenv("GEMINI_HOME", str(gemini))
    (codex / "config.toml").write_text(
        'model = "gpt-5.5"\n\n[mcp_servers.other]\ncommand = "npx"\n'
        'args = ["thing"]\n', encoding="utf-8")
    (gemini / "settings.json").write_text(json.dumps({
        "security": {"auth": {"selectedType": "oauth-personal"}},
        "mcpServers": {"git": {"command": "uvx", "args": ["mcp-server-git"]}},
    }), encoding="utf-8")
    return project, codex, gemini


def test_codex_config_still_parses_as_toml(wired, tmp_path):
    """The bug that shipped for exactly one run. A config we cannot parse back
    is a config Codex cannot read, which is worse than not wiring at all."""
    project, codex, _ = wired
    agents.wire("codex", project, tmp_path / "vault", apply=True)

    data = tomllib.loads((codex / "config.toml").read_text(encoding="utf-8"))
    assert "mem" in data["mcp_servers"]
    assert data["mcp_servers"]["mem"]["args"] == ["-m", "mem", "mcp"]


def test_codex_keeps_what_the_user_already_had(wired, tmp_path):
    project, codex, _ = wired
    agents.wire("codex", project, tmp_path / "vault", apply=True)

    data = tomllib.loads((codex / "config.toml").read_text(encoding="utf-8"))
    assert data["model"] == "gpt-5.5", "clobbered a top-level setting"
    assert data["mcp_servers"]["other"]["command"] == "npx", "dropped their server"


def test_gemini_keeps_what_the_user_already_had(wired, tmp_path):
    project, _, gemini = wired
    agents.wire("gemini", project, tmp_path / "vault", apply=True)

    data = json.loads((gemini / "settings.json").read_text(encoding="utf-8"))
    assert data["security"]["auth"]["selectedType"] == "oauth-personal"
    assert data["mcpServers"]["git"]["command"] == "uvx"
    assert data["mcpServers"]["mem"]["command"] == sys.executable


@pytest.mark.parametrize("agent", ["codex", "gemini"])
def test_wiring_twice_changes_nothing_the_second_time(wired, tmp_path, agent):
    """Idempotence is the property that makes the command safe to put in a
    README, where people will paste it more than once."""
    project, codex, gemini = wired
    config = (codex / "config.toml") if agent == "codex" else (gemini / "settings.json")

    agents.wire(agent, project, tmp_path / "vault", apply=True)
    once = config.read_text(encoding="utf-8")
    second = agents.wire(agent, project, tmp_path / "vault", apply=True)

    assert config.read_text(encoding="utf-8") == once
    assert second.wrote is False
    assert second.backup is None, "backed up a file it did not change"


def test_a_hand_written_entry_is_left_alone(wired, tmp_path):
    """Somebody who wired this themselves gets to keep their version. Two
    definitions of one server is worse than one we did not write."""
    project, codex, _ = wired
    (codex / "config.toml").write_text(
        '[mcp_servers.mem]\ncommand = "my-own-thing"\n', encoding="utf-8")

    agents.wire("codex", project, tmp_path / "vault", apply=True)

    data = tomllib.loads((codex / "config.toml").read_text(encoding="utf-8"))
    assert data["mcp_servers"]["mem"]["command"] == "my-own-thing"


def test_context_file_wraps_rather_than_repeats(wired, tmp_path):
    """Appending blindly is how a GEMINI.md ends up with the same paragraph
    six times."""
    project, _, _ = wired
    (project / "AGENTS.md").write_text("# Mine\n\nBuild with make.\n", encoding="utf-8")

    for _ in range(3):
        agents.wire("codex", project, tmp_path / "vault", apply=True)

    text = (project / "AGENTS.md").read_text(encoding="utf-8")
    assert text.count(agents.BLOCK_START) == 1
    assert text.count("## Your memory of this user") == 1
    assert "Build with make." in text, "ate the user's own instructions"


def test_dry_run_writes_nothing(wired, tmp_path):
    project, codex, gemini = wired
    before = ((codex / "config.toml").read_text(encoding="utf-8"),
              (gemini / "settings.json").read_text(encoding="utf-8"))

    agents.wire("codex", project, tmp_path / "vault", apply=False)
    agents.wire("gemini", project, tmp_path / "vault", apply=False)

    assert ((codex / "config.toml").read_text(encoding="utf-8"),
            (gemini / "settings.json").read_text(encoding="utf-8")) == before
    assert not (project / "AGENTS.md").exists()
    assert not (project / "GEMINI.md").exists()


def test_broken_json_is_refused_not_overwritten(wired, tmp_path):
    """Their file is damaged; ours is not the hand that finishes it off."""
    project, _, gemini = wired
    (gemini / "settings.json").write_text("{ not json", encoding="utf-8")

    with pytest.raises(SystemExit):
        agents.wire("gemini", project, tmp_path / "vault", apply=True)
    assert (gemini / "settings.json").read_text(encoding="utf-8") == "{ not json"


def test_unknown_agent_is_a_clean_error(tmp_path):
    with pytest.raises(SystemExit):
        agents.wire("copilot", tmp_path, tmp_path / "vault", apply=False)
