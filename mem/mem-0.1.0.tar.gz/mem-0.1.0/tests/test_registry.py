"""
The projects registry.

The property that matters most here is the one a reasonable person would get
wrong: `remove` forgets a project and never touches the folder. There is a test
for that specifically, because the cost of being wrong is somebody's repository.
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from mem.voice import registry                                   # noqa: E402


@pytest.fixture(autouse=True)
def state(tmp_path, monkeypatch):
    """Point the registry at a throwaway state directory for every test."""
    home = tmp_path / "state"
    home.mkdir()
    monkeypatch.setenv("MEM_VOICE_HOME", str(home))
    monkeypatch.setattr(registry, "STATE", home)
    monkeypatch.setattr(registry, "FILE", home / "projects.json")
    return home


@pytest.fixture
def repo(tmp_path):
    d = tmp_path / "myrepo"
    (d / ".git").mkdir(parents=True)
    return d


def test_add_and_list(repo):
    assert registry.add(repo)["ok"]
    rows = registry.merged([])["projects"]
    assert [r["name"] for r in rows] == ["myrepo"]
    assert rows[0]["registered"] is True


def test_add_validates_before_writing_anything(tmp_path):
    assert registry.add("")["error"] == "no path given"
    assert "does not exist" in registry.add(tmp_path / "nope")["error"]
    f = tmp_path / "a-file"
    f.write_text("x")
    assert "not a folder" in registry.add(f)["error"]
    assert registry.merged([])["projects"] == []


def test_adding_twice_is_refused_not_duplicated(repo):
    registry.add(repo)
    assert registry.add(repo)["error"] == "already added"
    assert len(registry.merged([])["projects"]) == 1


def test_remove_forgets_the_project_and_keeps_the_folder(repo):
    """The one operation where a reasonable person might assume otherwise."""
    registry.add(repo)
    assert registry.remove(repo)["ok"]
    assert registry.merged([])["projects"] == []
    assert repo.is_dir(), "removing a project deleted the folder"
    assert (repo / ".git").is_dir()


def test_rename_survives_and_beats_discovery(repo):
    registry.add(repo)
    registry.rename(repo, "Nice Name")
    discovered = [{"cwd": str(repo.resolve()), "name": "myrepo", "parent": "x",
                   "sessions": 3, "lastActive": None, "lastActiveTs": 5.0,
                   "branch": "main", "live": False, "missing": False, "slug": "s"}]
    row = registry.merged(discovered)["projects"][0]
    assert row["name"] == "Nice Name"
    assert row["sessions"] == 3, "discovery data was thrown away"


def test_rename_needs_a_name(repo):
    registry.add(repo)
    assert registry.rename(repo, "   ")["ok"] is False


def test_pinned_projects_sort_first_whatever_the_mode(repo, tmp_path):
    other = tmp_path / "other"
    (other / ".git").mkdir(parents=True)
    registry.add(repo)
    registry.add(other)
    registry.pin(other)

    names = [r["name"] for r in registry.merged([])["projects"]]
    assert names[0] == "other"


def test_acting_on_a_discovered_project_registers_it(tmp_path):
    """Pinning something you can see must not silently do nothing just because
    it arrived from discovery rather than from Add."""
    d = tmp_path / "seen"
    d.mkdir()
    registry.pin(d)
    assert registry.merged([])["projects"][0]["pinned"] is True


def test_visits_are_counted_and_sortable(repo, tmp_path):
    other = tmp_path / "other"
    other.mkdir()
    registry.add(repo)
    registry.add(other)
    registry.visit(other)
    registry.visit(other)
    registry.set_sort("mostVisited")

    out = registry.merged([])
    assert out["sort"] == "mostVisited"
    assert out["projects"][0]["name"] == "other"


def test_an_unknown_sort_falls_back_rather_than_breaking(repo):
    assert registry.set_sort("nonsense") == registry.DEFAULT_SORT


def test_a_corrupt_registry_does_not_take_the_app_down(state, repo):
    (state / "projects.json").write_text("{ not json")
    assert registry.load()["projects"] == {}
    assert registry.add(repo)["ok"]


def test_scan_finds_repositories_and_marks_known_ones(tmp_path):
    ws = tmp_path / "code"
    for name in ("alpha", "beta"):
        (ws / name / ".git").mkdir(parents=True)
    (ws / "notarepo").mkdir()
    registry.add(ws / "alpha")

    res = registry.scan(ws)
    assert res["ok"]
    found = {f["name"]: f for f in res["found"]}
    assert set(found) == {"alpha", "beta"}
    assert found["alpha"]["registered"] is True
    assert found["beta"]["registered"] is False


def test_scan_does_not_descend_into_a_repository(tmp_path):
    """A vendored checkout inside a repo is not a project of its own, and
    offering every submodule turns one result into thirty."""
    ws = tmp_path / "code"
    (ws / "outer" / ".git").mkdir(parents=True)
    (ws / "outer" / "vendor" / "inner" / ".git").mkdir(parents=True)
    assert [f["name"] for f in registry.scan(ws)["found"]] == ["outer"]


def test_scan_reports_a_bad_path_rather_than_returning_nothing(tmp_path):
    assert registry.scan("")["error"] == "no path given"
    assert "not a folder" in registry.scan(tmp_path / "missing")["error"]


def test_import_reports_each_outcome_separately(tmp_path):
    """Partial success is the normal case, and collapsing it into one ok/failed
    hides which project did not make it."""
    good = tmp_path / "good"
    good.mkdir()
    res = registry.import_many([str(good), str(tmp_path / "gone")])
    assert res["ok"] is False
    assert len(res["added"]) == 1 and len(res["failed"]) == 1


def test_a_registered_project_lists_even_with_no_history(repo):
    """The point of Add: a repo you have not opened in the agent yet still
    belongs in the list."""
    registry.add(repo)
    row = registry.merged([])["projects"][0]
    assert row["sessions"] == 0 and row["registered"] is True


def test_forgetting_a_discovered_project_actually_forgets_it(tmp_path, monkeypatch):
    """Removal used to drop the registry entry and nothing else, so a project
    that came from a transcript on disk was rediscovered on the next read and
    reappeared where it was. The removal worked; the list was rebuilt from
    somewhere else."""
    monkeypatch.setattr(registry, "FILE", tmp_path / "projects.json")
    monkeypatch.setattr(registry, "STATE", tmp_path)
    (tmp_path / "a").mkdir()

    discovered = [{"cwd": str(tmp_path / "a"), "name": "a", "parent": str(tmp_path),
                   "slug": "a", "sessions": 3, "lastActive": None,
                   "lastActiveTs": 2.0, "branch": "", "live": False,
                   "missing": False}]

    assert [p["name"] for p in registry.merged(discovered)["projects"]] == ["a"]

    registry.remove(tmp_path / "a")
    assert registry.merged(discovered)["projects"] == []

    # and it is reversible, because "forget" is a preference and not a delete
    registry.add(tmp_path / "a")
    assert [p["name"] for p in registry.merged(discovered)["projects"]] == ["a"]


def test_forgetting_never_touches_the_folder(tmp_path, monkeypatch):
    monkeypatch.setattr(registry, "FILE", tmp_path / "projects.json")
    monkeypatch.setattr(registry, "STATE", tmp_path)
    project = tmp_path / "real"
    project.mkdir()
    (project / "keep.txt").write_text("still here", encoding="utf-8")

    registry.add(project)
    registry.remove(project)

    assert project.is_dir()
    assert (project / "keep.txt").read_text(encoding="utf-8") == "still here"
