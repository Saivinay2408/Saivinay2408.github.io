"""
Tests for the orb's state machine and push-to-talk.

Both bugs these cover were reported from actual use, and neither was caught by
the output tests because they live in the seam between the transcript (which
says a turn is over the moment the last token lands) and the speaker (which is
still playing that turn's audio for seconds afterwards).

  1. the orb stayed on "speaking" forever after a reply finished
  2. the voice went permanently silent after the first thing you said to it

    python -m pytest tests/test_voice_state.py -q
"""
from __future__ import annotations

import threading
import time

import pytest

from mem.voice.voice_loop import SPEECH_TAIL_S, VoiceLoop


class FakeSpeaker:
    """Reproduces the part of tts.Speaker that made the voice go mute: stop()
    latches a flag, and anything queued while it is set is DROPPED."""

    def __init__(self):
        self.stop_flag = False
        self.spoken: list[str] = []
        self.dropped: list[str] = []
        self._busy = False
        self.half_duplex = False
        self.ref = None

    def speak(self, text):
        if self.stop_flag:
            self.dropped.append(text)
            return
        self.spoken.append(text)
        self._busy = True

    def stop(self):
        self.stop_flag = True
        self._busy = False

    def resume(self):
        self.stop_flag = False

    def finish_playback(self):
        self._busy = False

    @property
    def busy(self):
        return self._busy


class FakeDash:
    def __init__(self):
        self.events: list[tuple] = []
        self.panes = None
        self.hub = self

    def emit(self, kind, payload):
        self.events.append((kind, payload))

    def send_threadsafe(self, msg):
        self.events.append(("raw", msg))

    def states(self):
        return [v for k, v in self.events if k == "state"]


@pytest.fixture
def vl():
    dash = FakeDash()
    loop = VoiceLoop(dash)
    loop.speaker = FakeSpeaker()
    loop._alive = True          # what start() sets; "idle" means it never started
    return loop


def _tick_until(loop, want, timeout=3.0):
    """Run the real tick loop in a thread until the state settles."""
    t = threading.Thread(target=loop._tick_run, daemon=True)
    t.start()
    deadline = time.time() + timeout
    while time.time() < deadline:
        if loop._state == want:
            loop._stop.set()
            return True
        time.sleep(0.02)
    loop._stop.set()
    return False


# ------------------------------------------------ bug 1: stuck on "speaking"

def test_speaking_ends_when_the_audio_does(vl):
    """The reported bug: reply finished, orb still said speaking."""
    vl._on_event("p", {"kind": "user", "text": "hello"})
    vl._say("all done.")
    assert vl._state == "speaking"

    # transcript says the turn is over while the audio is still playing
    vl._on_event("p", {"kind": "turn_end", "durationMs": 1200})
    assert vl._state == "speaking", "turn_end must not cut the orb off mid-sentence"

    vl.speaker.finish_playback()
    assert _tick_until(vl, "listening"), f"stuck on {vl._state!r} after playback ended"


def test_speaking_survives_the_gap_between_sentences(vl):
    """`busy` blinks false between queued sentences; that is not the end."""
    vl._on_event("p", {"kind": "user", "text": "hi"})
    vl._say("first sentence.")
    vl.speaker.finish_playback()          # gap while the next one synthesizes

    t = threading.Thread(target=vl._tick_run, daemon=True)
    t.start()
    time.sleep(SPEECH_TAIL_S * 0.5)
    assert vl._state == "speaking", "left speaking during a between-sentence gap"
    vl._stop.set()


def test_state_returns_to_working_if_the_turn_is_still_running(vl):
    vl._on_event("p", {"kind": "user", "text": "do a big thing"})
    vl._say("on it.")
    vl.speaker.finish_playback()
    assert _tick_until(vl, "working"), f"went to {vl._state!r} while still working"


# --------------------------------------------- bug 2: the voice going silent

def test_speaker_still_talks_after_the_first_submission(vl):
    """submit_text stops the speaker; without resume() everything after is dropped."""
    vl.speaker.stop()                      # what submit_text does
    vl._say("this must still be audible.")
    assert vl.speaker.spoken == ["this must still be audible."]
    assert vl.speaker.dropped == []


def test_narration_also_survives_a_stop(vl):
    vl.speaker.stop()
    vl._speak_progress("running the tests")
    assert vl.speaker.spoken == ["running the tests"]


# ------------------------------------------------------------ push to talk

def test_holding_the_key_silences_the_reply(vl):
    vl._say("a long answer that you want to interrupt.")
    assert vl.speaker.busy
    vl.set_ptt(True)
    assert not vl.speaker.busy, "pressing space did not silence it"
    assert vl._state == "hearing"


def test_release_ignores_a_stray_tap(vl):
    """A quick tap holds almost no audio and must not become a turn."""
    vl.set_ptt(True)
    vl._ptt_buf = [b"x"] * 2               # far below PTT_MIN_SAMPLES
    vl.set_ptt(False)
    assert vl._state == "listening"


def test_ptt_is_edge_triggered(vl):
    """Key auto-repeat fires keydown many times; only the first may count."""
    vl.set_ptt(True)
    vl._ptt_buf = ["frame"]
    vl.set_ptt(True)
    assert vl._ptt_buf == ["frame"], "a repeated keydown wiped the recording"


# ------------------------------------------------------------- submitting

class FakePty:
    alive = True

    def __init__(self):
        self.writes: list[bytes] = []

    def write(self, b):
        self.writes.append(b)


class FakePane:
    def __init__(self):
        self.pty = FakePty()


def test_submit_clears_the_input_before_typing(vl, monkeypatch):
    """Whatever is already in the box would otherwise be prepended to what you
    said. Measured against a real session with the line left dirty:
        submitted: 'GARBAGE_PREFILLreply with exactly: CLEAN'
    """
    pane = FakePane()
    vl.dash.panes = type("P", (), {"target_pane": staticmethod(lambda: pane)})()
    monkeypatch.setattr(vl, "_wait_for_turn", lambda before: True)

    assert vl.submit_text("commit it") is True
    joined = b"".join(pane.pty.writes)
    assert joined.startswith(b"\x15"), "input was not cleared before typing"
    assert b"commit it" in joined
    assert joined.endswith(b"\r"), "never submitted"


def test_submit_reports_failure_when_the_turn_never_starts(vl, monkeypatch):
    """The old loop typed, slept, sent Enter and had no idea when it didn't take."""
    pane = FakePane()
    vl.dash.panes = type("P", (), {"target_pane": staticmethod(lambda: pane)})()
    monkeypatch.setattr(vl, "_wait_for_turn", lambda before: False)

    assert vl.submit_text("this will not land") is False
    assert pane.pty.writes.count(b"\r") == 2, "Enter was not retried"
    errors = [m for k, m in vl.dash.events
              if k == "raw" and m.get("t") == "error"]
    assert errors, "a silent failure was not surfaced"


# ------------------------------------------------------ the nonstop-beep bug

def test_space_keydown_is_swallowed_before_the_repeat_check():
    """Ordering guard for a bug that has now shipped twice.

    Holding a key fires keydown ~15x/second. An unhandled space in a webview is
    a system beep, so every auto-repeat that reaches the OS is another tick —
    a continuous ticking noise for as long as you hold the key to talk.

    The fix is one line of ordering: preventDefault() must run for EVERY space
    we claim, and the `e.repeat` test must come after it, never as an early
    return instead of it. voice/retired/widget.html hit this and documented it;
    mem/voice/ui/app.js reintroduced it. There is no way to assert this from
    Python other than on the source, and a guard that has caught two
    regressions earns its keep.
    """
    from pathlib import Path

    # Resolved through the package, not relative to this file: the tests live
    # outside the package now, and a path that walks up from __file__ would
    # quietly follow the test suite wherever it moves next.
    import mem.voice
    src = (Path(mem.voice.__file__).parent / "ui" / "app.js").read_text()

    start = src.index('addEventListener("keydown"')
    handler = src[start:src.index("}, true);", start)]

    prevent = handler.index("e.preventDefault()")
    assert "e.repeat" in handler, "the repeat guard vanished entirely"
    assert handler.index("e.repeat") > prevent, (
        "the e.repeat check runs before preventDefault() — every auto-repeat "
        "will reach the OS and beep")

    # Bailing out before preventDefault is only correct for a space that is not
    # ours to consume (someone is typing); any other early return re-opens it.
    before = handler[:prevent]
    assert before.count("return") == 1 and "spaceIsOurs" in before, (
        "an early return other than the not-ours guard runs before "
        "preventDefault()")


def test_resting_state_is_listening_not_idle(vl):
    """There is no hands-free mode to be off, so at rest it is always ready —
    the orb breathes to say so. Idle is reserved for a voice loop that failed
    to start at all."""
    assert vl._derive_state() == "listening"
    vl._turns.add("p")
    assert vl._derive_state() == "working"
    vl._alive = False
    assert vl._derive_state() == "idle", "idle must mean the loop is not running"


# ------------------------------------------------- one place decides the state

def test_narration_does_not_steal_the_speaking_state(vl):
    """The reported bug, at its root.

    Progress narration goes through the same speaker as the answer, so any rule
    of the form "audio is playing -> speaking" fires for it. That made the orb
    change colour every few seconds during a long turn, and — because the
    client cleared the caption whenever the state changed — it wiped the very
    narration line that had just caused it. You would see "running the tests"
    for about one frame, then the word "speaking".
    """
    vl._on_event("p", {"kind": "user", "text": "run the tests"})
    assert vl._state == "working"

    vl._speak_progress("running the tests")
    assert vl.speaker.busy, "narration should still be audible"
    assert vl._derive_state() == "working", "narration took the orb off working"

    # and the answer, through the same speaker, DOES take it
    vl._say("all seventeen passed.")
    assert vl._derive_state() == "speaking"


def test_transcribing_is_thinking_not_working(vl):
    """Whisper decoding your speech is not the session working. No turn exists
    yet, and if the decode comes back empty none ever will."""
    vl._transcribing = True
    assert vl._derive_state() == "thinking"
    vl._transcribing = False
    assert vl._derive_state() == "listening"


def test_holding_the_key_outranks_everything(vl):
    vl._on_event("p", {"kind": "user", "text": "do a big thing"})
    vl._say("working on it.")
    vl.set_ptt(True)
    assert vl._derive_state() == "hearing", "your voice must outrank its own"


def test_blocked_fires_when_a_session_needs_you(vl):
    """`blocked` was in the orb's palette from the first version and nothing
    ever set it: the fact lives in the daemon's roster, which the voice loop
    had no path to."""
    vl.set_blocked(["auth-refactor"])
    assert vl._derive_state() == "blocked"
    assert any("needs you" in t for t in vl.speaker.spoken), \
        "a session waiting on you is worth saying once"

    # ...and once only, not on every two-second roster poll
    n = len(vl.speaker.spoken)
    vl.set_blocked(["auth-refactor"])
    assert len(vl.speaker.spoken) == n

    # a running turn outranks it: you are already being told what is happening
    vl._turns.add("p")
    assert vl._derive_state() == "working"


def test_turn_end_never_cuts_the_reply_off(vl):
    """The transcript marks a turn over as soon as the last token lands, while
    the audio for it is still seconds from finishing."""
    vl._on_event("p", {"kind": "user", "text": "hi"})
    vl._say("here is the answer, which takes a moment to say.")
    vl._on_event("p", {"kind": "turn_end", "durationMs": 900})
    assert vl._state == "speaking"


def test_hands_free_is_gone(vl):
    """Removed deliberately, not deferred.

    Voice-activity detection could not reliably tell the clone's own reply from
    yours — text-to-speech output IS speech — so it interrupted itself. Holding
    a key silences the speaker before a frame is captured, which deletes the
    problem rather than managing it. Anything that reintroduces an always-on
    listening mode brings the self-barge-in back with it."""
    assert not hasattr(vl, "enabled")
    assert not hasattr(vl, "set_enabled")
    import mem.voice.voice_loop as vlmod
    from pathlib import Path as _P
    assert not (_P(vlmod.__file__).parent / "echo.py").exists(), \
        "echo cancellation only existed to serve hands-free"
