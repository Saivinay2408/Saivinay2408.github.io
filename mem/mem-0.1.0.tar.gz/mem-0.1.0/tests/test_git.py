"""
The git layer.

Every test drives a real repository in a temp directory. There are no mocks
here on purpose: the whole value of this module is that it agrees with what git
actually does, and a fake `git` would only ever agree with my idea of it.

The two cases that earned their place by failing first are
`test_a_clean_tracked_file_has_no_diff` and
`test_filenames_that_break_line_parsers`.
"""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from mem.voice import git                                        # noqa: E402


def sh(*args, cwd):
    subprocess.run(["git", *args], cwd=str(cwd), check=True,
                   capture_output=True, text=True)


@pytest.fixture
def repo(tmp_path):
    sh("init", "-q", "-b", "main", cwd=tmp_path)
    sh("config", "user.email", "t@example.com", cwd=tmp_path)
    sh("config", "user.name", "Test", cwd=tmp_path)
    (tmp_path / "README.md").write_text("hello\n")
    sh("add", "-A", cwd=tmp_path)
    sh("commit", "-qm", "root", cwd=tmp_path)
    return tmp_path


def test_a_directory_with_no_repo_is_not_an_error(tmp_path):
    """`not a git repository` is a fact about the folder, not a failure. A
    dashboard that shows a red error for every non-repo is crying wolf."""
    st = git.status(tmp_path)
    assert st.repo is False
    assert st.error == ""
    assert st.label() == "not a repo"


def test_branch_and_cleanliness(repo):
    st = git.status(repo)
    assert st.repo and st.branch == "main"
    assert not st.dirty and st.label() == "main"


def test_filenames_that_break_line_parsers(repo):
    """A filename may legally contain a newline. A line-based status parser
    turns one such file into two entries, one of which does not exist — which
    is why this reads porcelain v2 with NUL delimiters."""
    (repo / "with\nnewline.txt").write_text("x\n")
    (repo / "with space.txt").write_text("x\n")
    (repo / 'with"quote.txt').write_text("x\n")

    paths = {f.path for f in git.status(repo).files}
    assert paths == {"with\nnewline.txt", "with space.txt", 'with"quote.txt'}


def test_untracked_then_staged(repo):
    (repo / "new.txt").write_text("a\n")
    assert git.status(repo).files[0].untracked is True

    assert git.stage(repo, ["new.txt"])["ok"]
    f = git.status(repo).files[0]
    assert f.staged == "A" and not f.untracked

    assert git.unstage(repo, ["new.txt"])["ok"]
    assert git.status(repo).files[0].untracked is True


def test_a_clean_tracked_file_has_no_diff(repo):
    """The first implementation fell back to "show the whole file as additions"
    whenever the diff was empty, so an unchanged tracked file rendered as if
    every line had just been written."""
    assert git.diff(repo, "README.md")["text"] == ""


def test_a_modified_file_diffs(repo):
    (repo / "README.md").write_text("hello\nworld\n")
    assert "+world" in git.diff(repo, "README.md")["text"]


def test_an_untracked_file_shows_as_additions(repo):
    """git says nothing about a file it has never seen, which reads as "no
    changes" for a file that is entirely new."""
    (repo / "new.txt").write_text("brand new\n")
    assert "+brand new" in git.diff(repo, "new.txt")["text"]


def test_a_huge_diff_is_capped(repo):
    (repo / "big.txt").write_text("x" * 50_000 + "\n")
    out = git.diff(repo, "big.txt", max_bytes=1000)
    assert out["truncated"] is True and len(out["text"]) <= 1000


def test_commit_needs_a_message(repo):
    (repo / "a.txt").write_text("a\n")
    git.stage(repo, ["a.txt"])
    assert git.commit(repo, "   ")["ok"] is False


def test_commit_with_nothing_staged_says_so(repo):
    res = git.commit(repo, "nothing here")
    assert res["ok"] is False and "nothing staged" in res["error"]


def test_commit_writes_history(repo):
    (repo / "a.txt").write_text("a\n")
    git.stage(repo, ["a.txt"])
    assert git.commit(repo, "add a")["ok"]
    assert git.log(repo, 1)[0]["subject"] == "add a"
    assert not git.status(repo).dirty


def test_switching_branches_refuses_to_carry_uncommitted_work(repo):
    """`git switch` would take the changes with it. That is occasionally what
    somebody wants and never what somebody wants when an agent has just edited
    files they have not read."""
    (repo / "a.txt").write_text("a\n")
    res = git.switch_branch(repo, "feature", create=True)
    assert res["ok"] is False and "uncommitted" in res["error"]
    assert git.status(repo).branch == "main"


def test_switching_branches_when_clean(repo):
    assert git.switch_branch(repo, "feature", create=True)["ok"]
    b = git.branches(repo)
    assert b["current"] == "feature" and set(b["branches"]) == {"main", "feature"}


def test_a_worktree_gives_a_second_agent_its_own_tree(repo):
    """The one git feature here that prevents damage rather than reporting it:
    two agents dispatched into one working tree interleave edits and the
    loser's work is simply gone."""
    res = git.add_worktree(repo, "parallel")
    assert res["ok"], res["error"]
    assert Path(res["path"]).is_dir()
    assert "parallel" in {t.get("branch") for t in git.worktrees(repo)}


def test_worktree_refuses_to_overwrite_an_existing_path(repo):
    git.add_worktree(repo, "parallel")
    assert git.add_worktree(repo, "parallel")["ok"] is False


def test_push_without_a_remote_fails_fast_and_says_why(repo):
    """With GIT_TERMINAL_PROMPT=0 this cannot sit waiting for a password. A
    hung subprocess is indistinguishable from a hung dashboard."""
    res = git.push(repo)
    assert res["ok"] is False and res["error"]


def test_line_counts_per_file(repo):
    (repo / "README.md").write_text("hello\nsecond\nthird\n")
    counts = {f["path"]: (f["add"], f["rem"]) for f in git.snapshot(repo)["files"]}
    assert counts["README.md"] == (2, 0)


def test_totals_sum_the_files(repo):
    (repo / "README.md").write_text("changed\n")
    (repo / "new.txt").write_text("a\nb\n")
    git.stage(repo, ["new.txt"])
    snap = git.snapshot(repo)
    assert snap["add"] == sum(f["add"] for f in snap["files"])
    assert snap["rem"] == sum(f["rem"] for f in snap["files"])


def test_a_binary_change_counts_as_zero_not_as_a_crash(repo):
    """`--numstat` reports `-` for a binary file. Parsing that as an int is the
    obvious bug, and it takes the whole panel down with it."""
    (repo / "blob.bin").write_bytes(bytes(range(256)) * 8)
    git.stage(repo, ["blob.bin"])
    git.commit(repo, "add a binary")
    (repo / "blob.bin").write_bytes(bytes(reversed(range(256))) * 8)
    counts = {f["path"]: (f["add"], f["rem"]) for f in git.snapshot(repo)["files"]}
    assert counts["blob.bin"] == (0, 0)


@pytest.fixture
def merged(repo):
    """main and a feature branch that diverge and rejoin."""
    (repo / "f.txt").write_text("A\n"); sh("add", "-A", cwd=repo)
    sh("commit", "-qm", "B", cwd=repo)
    sh("switch", "-qc", "feature", cwd=repo)
    (repo / "f.txt").write_text("A\nfeat\n"); sh("add", "-A", cwd=repo)
    sh("commit", "-qm", "feat 1", cwd=repo)
    sh("switch", "-q", "main", cwd=repo)
    (repo / "s.txt").write_text("side\n"); sh("add", "-A", cwd=repo)
    sh("commit", "-qm", "main C", cwd=repo)
    sh("merge", "-q", "--no-ff", "-m", "merge feature", "feature", cwd=repo)
    return repo


def test_the_graph_marks_the_merge_and_splits_the_lanes(merged):
    rows = {c["subject"]: c for c in git.graph(git.log(merged, 20))}
    assert rows["merge feature"]["merge"] is True
    assert rows["main C"]["lane"] != rows["feat 1"]["lane"], "branches share a lane"
    assert rows["feat 1"]["lane"] in rows["main C"]["through"], \
        "the feature lane should pass beside the commit it diverged from"


def test_lanes_converge_instead_of_running_on_forever(merged):
    """When a branch rejoins, two lanes wait on the same ancestor. Clearing
    only the first leaves the other reserved for good, and the graph draws a
    phantom vertical down past every older commit — which it did until this
    test existed."""
    rows = {c["subject"]: c for c in git.graph(git.log(merged, 20))}
    assert rows["B"]["through"] == [], f"phantom lane: {rows['B']['through']}"
    assert rows["root"]["through"] == []


def test_a_linear_history_uses_one_lane(repo):
    (repo / "a.txt").write_text("a\n"); sh("add", "-A", cwd=repo)
    sh("commit", "-qm", "second", cwd=repo)
    rows = git.graph(git.log(repo, 10))
    assert all(c["lane"] == 0 and not c["through"] for c in rows)


def test_session_branches_are_namespaced_and_slugged(repo):
    """`session/` so a glance at `git branch` separates what an agent made
    from what you made."""
    assert git.session_branch("Fix the flaky endpointer test!!") == \
        "session/fix-the-flaky-endpointer-test"
    assert git.session_branch("") == "session/task"


def test_worktrees_live_under_our_own_directory(repo, tmp_path, monkeypatch):
    """Not beside the repository. Git's docs show the sibling form and it
    scatters directories through whatever folder your projects sit in — it put
    a stray checkout on a real Desktop within an hour of shipping."""
    home = tmp_path / "managed"
    monkeypatch.setenv("MEM_WORKTREES", str(home))
    res = git.add_worktree(repo, git.session_branch("some task"))
    assert res["ok"], res["error"]
    assert Path(res["path"]).parent == home


def test_a_worktree_branch_keeps_its_namespace(repo, tmp_path, monkeypatch):
    """`refs/heads/session/x` must not be reported as `x`. Splitting on the
    last slash lost the namespace and silently broke every comparison against
    a session branch, including the duplicate check below."""
    monkeypatch.setenv("MEM_WORKTREES", str(tmp_path / "w"))
    git.add_worktree(repo, "session/keep-me")
    assert "session/keep-me" in {t.get("branch") for t in git.worktrees(repo)}


def test_the_same_branch_cannot_be_checked_out_twice(repo, tmp_path, monkeypatch):
    monkeypatch.setenv("MEM_WORKTREES", str(tmp_path / "w"))
    assert git.add_worktree(repo, "session/one")["ok"]
    again = git.add_worktree(repo, "session/one")
    assert again["ok"] is False
    assert "already checked out" in again["error"]


def test_a_worktree_can_be_removed_again(repo, tmp_path, monkeypatch):
    monkeypatch.setenv("MEM_WORKTREES", str(tmp_path / "w"))
    made = git.add_worktree(repo, "session/temp")
    assert git.remove_worktree(repo, made["path"], delete_branch=True)["ok"]
    assert "session/temp" not in {t.get("branch") for t in git.worktrees(repo)}
    assert "session/temp" not in git.branches(repo)["branches"]


def test_on_the_trunk_there_is_no_base_to_compare_against(repo):
    """The first version answered "what did this branch change" for `main` by
    picking an unrelated feature branch and diffing against it. Confidently,
    and backwards."""
    sh("switch", "-qc", "other", cwd=repo)
    sh("switch", "-q", "main", cwd=repo)
    assert git.base_branch(repo) == ""
    assert git.diff_vs_base(repo)["error"]


def test_a_branch_diffs_against_the_trunk(repo):
    sh("switch", "-qc", "feature", cwd=repo)
    (repo / "new.txt").write_text("one\ntwo\n")
    sh("add", "-A", cwd=repo)
    sh("commit", "-qm", "work", cwd=repo)

    d = git.diff_vs_base(repo)
    assert d["base"] == "main"
    assert [f["path"] for f in d["files"]] == ["new.txt"]
    assert d["add"] == 2 and d["rem"] == 0


def test_review_sees_committed_work_that_plain_diff_cannot(repo):
    """The whole reason this exists. An agent that ran for an hour and
    committed nine times shows NOTHING under `git diff`, and a panel that only
    knew about uncommitted work would report that as "no changes"."""
    sh("switch", "-qc", "feature", cwd=repo)
    (repo / "a.txt").write_text("a\n")
    sh("add", "-A", cwd=repo); sh("commit", "-qm", "one", cwd=repo)
    (repo / "b.txt").write_text("b\n")
    sh("add", "-A", cwd=repo); sh("commit", "-qm", "two", cwd=repo)

    assert git.status(repo).dirty is False          # nothing uncommitted
    assert git.diff(repo)["text"] == ""             # plain diff sees nothing
    review = git.diff_vs_base(repo)                 # the review sees both
    assert {f["path"] for f in review["files"]} == {"a.txt", "b.txt"}


def test_review_ignores_commits_that_landed_on_the_trunk_afterwards(repo):
    """Three dots, not two. With `main..HEAD` semantics a commit made on main
    after the fork would be attributed to this branch as a deletion."""
    sh("switch", "-qc", "feature", cwd=repo)
    (repo / "mine.txt").write_text("mine\n")
    sh("add", "-A", cwd=repo); sh("commit", "-qm", "mine", cwd=repo)
    sh("switch", "-q", "main", cwd=repo)
    (repo / "theirs.txt").write_text("theirs\n")
    sh("add", "-A", cwd=repo); sh("commit", "-qm", "theirs", cwd=repo)
    sh("switch", "-q", "feature", cwd=repo)

    assert {f["path"] for f in git.diff_vs_base(repo)["files"]} == {"mine.txt"}


def test_snapshot_is_one_call_for_the_whole_panel(repo):
    (repo / "a.txt").write_text("a\n")
    snap = git.snapshot(repo)
    assert snap["repo"] and snap["branch"] == "main" and snap["dirty"]
    assert "branches" in snap and "log" in snap and "worktrees" in snap
    assert snap["label"] == "main 1 changed"
