"""Hands: the clone's own cursor, and the levels that bound it.

The gate is the wall, so most of this is about the gate saying no when it
should, and never failing open."""
import asyncio
import io
import json
import subprocess
import sys

import pytest

from mem.voice import hands, supervisor
from mem.voice.hands_broker import Broker


@pytest.fixture(autouse=True)
def home(tmp_path, monkeypatch):
    monkeypatch.setenv("MEM_VOICE_HOME", str(tmp_path))
    monkeypatch.delenv("MEM_PORT", raising=False)
    return tmp_path


# ---- level ------------------------------------------------------------------

def test_default_level_is_ask():
    assert hands.level() == "ask"


def test_set_level_persists_and_validates():
    hands.set_level("watch")
    assert hands.level() == "watch"
    with pytest.raises(ValueError):
        hands.set_level("god")


# ---- classify ---------------------------------------------------------------

@pytest.mark.parametrize("tool,args,kind", [
    ("mcp__hands__get_window_state", {"pid": 1}, "read"),
    ("mcp__hands__list_apps", {}, "read"),
    ("mcp__hands__zoom", {}, "read"),
    ("mcp__hands__click", {"pid": 1, "element_token": "s00000001:3"}, "act"),
    ("mcp__hands__launch_app", {"bundle_id": "com.apple.TextEdit"}, "act"),
    ("mcp__hands__type_text", {"pid": 1, "text": "hello there"}, "act"),
    ("mcp__hands__type_text", {"pid": 1, "text": "my password is x"}, "risky"),
    ("mcp__hands__kill_app", {"pid": 1}, "risky"),
    ("mcp__hands__run_script", {"script": "1"}, "risky"),
    ("mcp__hands__clipboard_read", {}, "risky"),
    ("mcp__hands__hotkey", {"keys": ["cmd", "return"]}, "risky"),
    ("mcp__hands__hotkey", {"keys": ["cmd", "c"]}, "act"),
])
def test_classify(tool, args, kind):
    assert hands.classify(tool, args) == kind


def test_run_steps_takes_its_worst_step():
    read = {"steps": [{"tool": "get_window_state", "args": {"pid": 1}}]}
    act = {"steps": [{"click": {"role": "button", "name": "New"}}]}
    risky = {"steps": [{"click": {"role": "button", "name": "New"}},
                       {"click": {"role": "button", "name": "Send"}}]}
    assert hands.classify("mcp__hands__run_steps", read) == "read"
    assert hands.classify("mcp__hands__run_steps", act) == "act"
    assert hands.classify("mcp__hands__run_steps", risky) == "risky"


def test_tokens_are_not_read_as_words():
    # an element token or capture id that happens to contain letters must not
    # make an ordinary click "risky"
    args = {"pid": 1, "element_token": "s0000send:1", "capture_id": "delete_me"}
    assert hands.classify("mcp__hands__click", args) == "act"


# ---- decide -----------------------------------------------------------------

def test_watch_refuses_actions_but_allows_looking():
    assert hands.decide("mcp__hands__get_desktop_state", {}, "watch")[0] == "allow"
    v, why = hands.decide("mcp__hands__click", {"pid": 1, "x": 3, "y": 4}, "watch")
    assert v == "deny" and "WATCH" in why


def test_ask_asks_with_a_readable_question():
    v, what = hands.decide("mcp__hands__click",
                           {"pid": 1, "name": "Send", "app": "Mail"}, "ask")
    assert v == "ask" and what == 'click "Send" in Mail'


def test_free_acts_but_risky_still_asks():
    assert hands.decide("mcp__hands__launch_app", {"bundle_id": "x"}, "free")[0] == "allow"
    assert hands.decide("mcp__hands__click", {"pid": 1, "name": "Buy now"}, "free")[0] == "ask"
    assert hands.decide("mcp__hands__kill_app", {"pid": 1}, "free")[0] == "ask"


def test_bash_cannot_walk_around_the_gate():
    v, _ = hands.decide("Bash", {"command": "cua-driver call click '{\"pid\":1}'"}, "watch")
    assert v == "deny"
    v, _ = hands.decide("Bash", {"command": "~/.local/bin/cua-driver call click '{}'"}, "free")
    assert v == "deny"
    assert hands.decide("Bash", {"command": "cua-driver status"}, "watch")[0] == "allow"
    assert hands.decide("Bash", {"command": "git status"}, "watch")[0] == "allow"


def test_run_steps_question_lists_the_steps():
    args = {"app": "Mail", "steps": [{"click": {"role": "button", "name": "New"}},
                                     {"type_text": {"text": "hi"}}]}
    assert hands._what("mcp__hands__run_steps", args) == 'click "New", then type "hi"'


# ---- the hook ---------------------------------------------------------------

def _gate(payload) -> dict | None:
    out = io.StringIO()
    old = sys.stdout
    sys.stdout = out
    try:
        hands.gate(io.StringIO(json.dumps(payload)))
    finally:
        sys.stdout = old
    text = out.getvalue().strip()
    return json.loads(text) if text else None


def test_gate_denies_on_watch():
    hands.set_level("watch")
    out = _gate({"tool_name": "mcp__hands__click", "tool_input": {"pid": 1, "x": 1, "y": 1}})
    assert out["hookSpecificOutput"]["permissionDecision"] == "deny"


def test_gate_is_silent_when_allowed():
    hands.set_level("free")
    assert _gate({"tool_name": "mcp__hands__launch_app",
                  "tool_input": {"bundle_id": "com.apple.TextEdit"}}) is None


def test_gate_denies_when_nobody_can_be_asked():
    hands.set_level("ask")          # no MEM_PORT, no port file: Mem is not open
    out = _gate({"tool_name": "mcp__hands__click", "tool_input": {"pid": 1, "name": "OK"}})
    assert out["hookSpecificOutput"]["permissionDecision"] == "deny"
    assert "not open" in out["hookSpecificOutput"]["permissionDecisionReason"]


def test_a_broken_gate_fails_closed():
    """Claude Code treats a crashing hook as 'carry on'. The hands hook must
    turn a crash into a deny (found live: stale install, watch, TextEdit opened)."""
    cfg = hands.hook_settings("/nonexistent/python")
    cmd = cfg["hooks"]["PreToolUse"][0]["hooks"][0]["command"]
    p = subprocess.run(["/bin/sh", "-c", cmd], input='{"tool_name":"mcp__hands__click"}',
                       capture_output=True, text=True)
    out = json.loads(p.stdout.strip().splitlines()[-1])
    assert out["hookSpecificOutput"]["permissionDecision"] == "deny"
    assert cfg["hooks"]["PreToolUse"][0]["matcher"] == "mcp__hands__.*"
    # Bash fails open: a broken gate must not take the shell down with it.
    assert "||" not in cfg["hooks"]["PreToolUse"][1]["hooks"][0]["command"]


# ---- spoken answers ---------------------------------------------------------

@pytest.mark.parametrize("text,ans", [
    ("yes", True), ("Yeah, go ahead.", True), ("ok do it", True),
    ("no", False), ("No, wait", False), ("don't", False), ("stop", False),
    ("open safari instead", None), ("", None),
])
def test_spoken_answer(text, ans):
    assert hands.spoken_answer(text) is ans


# ---- the broker -------------------------------------------------------------

class Dash:
    def __init__(self):
        self.sent = []
        self.call = None
        self.voice = None

    def emit(self, kind, payload):
        self.sent.append((kind, payload))


def test_broker_ask_then_answer_yes():
    async def go():
        b = Broker(Dash())
        task = asyncio.create_task(b.ask('click "Send" in Mail', "click", risky=True))
        await asyncio.sleep(0.01)
        assert b.snapshot()["pending"][0]["what"] == 'click "Send" in Mail'
        assert b.answer(None, True)
        res = await task
        assert res["allow"] is True and not b.pending
    asyncio.run(go())


def test_broker_spoken_no():
    async def go():
        b = Broker(Dash())
        task = asyncio.create_task(b.ask("open Notes"))
        await asyncio.sleep(0.01)
        assert b.take_spoken("something else") is False      # not an answer
        assert b.take_spoken("no, don't") is True
        res = await task
        assert res["allow"] is False and "said no" in res["reason"]
    asyncio.run(go())


def test_broker_silence_is_no(monkeypatch):
    import mem.voice.hands_broker as hb
    monkeypatch.setattr(hb, "TIMEOUT_S", 0.05)

    async def go():
        res = await Broker(Dash()).ask("open Notes")
        assert res["allow"] is False
    asyncio.run(go())


def test_broker_trust_window_never_covers_risky():
    async def go():
        b = Broker(Dash())
        t = asyncio.create_task(b.ask("open Notes"))
        await asyncio.sleep(0.01)
        b.answer(None, True, minutes=10)
        await t
        assert (await b.ask("open Safari"))["by"] == "trusted"     # no question
        t2 = asyncio.create_task(b.ask('click "Delete"', risky=True))
        await asyncio.sleep(0.01)
        assert b.pending                                          # still asked
        b.answer(None, False)
        assert (await t2)["allow"] is False
    asyncio.run(go())


def test_no_spoken_answer_without_a_question():
    assert Broker(Dash()).take_spoken("yes") is False


# ---- wiring -----------------------------------------------------------------

def test_voice_session_gets_hands_and_the_gate(monkeypatch):
    monkeypatch.setattr(supervisor, "_HELP", "--effort --mcp-config --settings")
    monkeypatch.setattr(hands, "driver", lambda: "/Applications/x/cua-driver")
    cmd = supervisor.voice_pane_cmd("sid", "haiku")
    mcp = json.loads(cmd[cmd.index("--mcp-config") + 1])
    assert mcp["mcpServers"]["hands"]["args"] == ["mcp"]
    hooks = json.loads(cmd[cmd.index("--settings") + 1])["hooks"]["PreToolUse"]
    assert {h["matcher"] for h in hooks} == {"mcp__hands__.*", "Bash"}


def test_no_engine_no_hands(monkeypatch):
    monkeypatch.setattr(supervisor, "_HELP", "--mcp-config --settings")
    monkeypatch.setattr(hands, "driver", lambda: "")
    assert "--mcp-config" not in supervisor.voice_pane_cmd("sid", "haiku")


def test_hands_ask_endpoint_waits_for_the_answer():
    pytest.importorskip("aiohttp")
    from aiohttp.test_utils import TestClient, TestServer
    from unittest.mock import MagicMock
    from mem.voice.server import Dashboard

    async def go():
        dash = Dashboard.__new__(Dashboard)
        from aiohttp import web
        dash.app = web.Application()
        dash.hub = MagicMock()
        dash.call = None
        dash.voice = None
        dash.hands = Broker(dash)
        dash.emit = lambda k, v: None
        dash.app.router.add_post("/hands/ask", dash._hands_ask)
        async with TestClient(TestServer(dash.app)) as c:
            req = asyncio.create_task(c.post("/hands/ask", json={"what": "open Notes"}))
            for _ in range(50):
                await asyncio.sleep(0.01)
                if dash.hands.pending:
                    break
            dash.hands.answer(None, True)
            r = await req
            assert (await r.json())["allow"] is True
            # from the tunnel: refused
            r2 = await c.post("/hands/ask", json={"what": "x"},
                              headers={"X-Forwarded-For": "100.1.2.3"})
            assert r2.status == 403
    asyncio.run(go())
