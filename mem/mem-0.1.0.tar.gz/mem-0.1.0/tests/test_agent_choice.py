"""
The agent picker in the session header, and whether it actually picks anything.

It did not. The header offered claude / codex / gemini, the click handler set a
variable in the page, and every `pane.open` message left that variable behind —
so choosing Codex and pressing `+` opened Claude Code, every time. A control
that visibly changes state and changes nothing is worse than no control: it
teaches you the feature is broken rather than absent.

These tests pin the whole path: the command that gets built, the pane that
records which agent it is, and the fact that only Claude Code is handed the
flags that only Claude Code has.
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from mem.voice import supervisor                                 # noqa: E402
from mem.voice.panes import PaneManager                          # noqa: E402
from mem.voice.settings import AGENTS, DEFAULTS                  # noqa: E402


# ---- the command ---------------------------------------------------------

def test_claude_is_still_the_default():
    assert supervisor.plain_pane_cmd()[0] == "claude"
    assert DEFAULTS["agent"] == "claude"


def test_codex_runs_codex():
    assert supervisor.plain_pane_cmd(agent="codex") == ["codex"]


def test_gemini_runs_gemini():
    assert supervisor.plain_pane_cmd(agent="gemini") == ["gemini"]


@pytest.mark.parametrize("agent", ["codex", "gemini"])
def test_claude_only_flags_never_reach_another_agent(agent):
    """--session-id and --model are Anthropic's spellings.

    Codex has no --session-id at all and Gemini's takes a UUID for its own
    store; --model wants a name from each vendor's own list. Passing either
    across is not a degraded experience, it is a process that fails to launch.
    """
    cmd = supervisor.plain_pane_cmd(model="opus", session_id="abc", agent=agent)
    assert "--session-id" not in cmd
    assert "--model" not in cmd
    assert cmd == [agent]


def test_claude_still_gets_its_flags():
    cmd = supervisor.plain_pane_cmd(model="opus", session_id="abc")
    assert cmd == ["claude", "--session-id", "abc", "--model", "opus"]


# ---- the pane ------------------------------------------------------------

def _open(agent, tmp_path):
    mgr = PaneManager()
    pane = mgr.open_plain(tmp_path, agent=agent)
    try:
        yield_pane = pane.info()
    finally:
        pane.pty.close()
    return pane, yield_pane


def test_pane_records_which_agent_it_runs(tmp_path):
    """The header badge reads this, and so does the voice-target toast."""
    pane, info = _open("codex", tmp_path)
    assert pane.agent == "codex"
    assert info["agent"] == "codex"


def test_a_codex_pane_carries_no_session_id(tmp_path):
    """Rather than a made-up one that nothing will ever match.

    transcript_for() keys off this, and an id pointing at a Claude transcript
    path that will never exist is how you get a watcher tailing a file forever.
    """
    pane, _ = _open("codex", tmp_path)
    assert pane.session_id == ""
    assert PaneManager().transcript_for(pane) is None


def test_a_claude_pane_still_gets_one(tmp_path):
    pane, _ = _open("claude", tmp_path)
    assert pane.session_id
    assert PaneManager().transcript_for(pane) is not None


# ---- persistence ---------------------------------------------------------

def test_every_offered_agent_is_a_saveable_default():
    """The picker and the settings whitelist must agree.

    If they drift, choosing an agent silently fails to persist and the header
    springs back to Claude on the next launch -- the same class of bug as the
    one this file exists for, one layer down.
    """
    from mem.voice.agents_ui import AGENTS as OFFERED
    assert set(OFFERED) == set(AGENTS)
