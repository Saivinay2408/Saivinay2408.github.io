"""
Tests for the usage meters.

The reported bug was "the session limits are not properly live and updated".
That turned out to be four separate things, and none of them was the parser —
which works, and is covered here against a real captured screen:

  1. the first reading was emitted only AFTER the ~8s probe, so the meters sat
     blank on launch with nothing saying they were loading
  2. a failed probe was swallowed (`if got:`), leaving the last number on
     screen forever looking authoritative
  3. nothing recorded WHEN a reading was taken, so a stuck meter and a current
     one are the same pixels
  4. the probe ran on a fixed 10-minute timer, and never at the moment the
     number actually changes — when a turn ends

    python -m pytest tests/test_usage.py -q
"""
from __future__ import annotations

import time

import pytest

from mem.voice.usage import UsageMonitor, parse_usage_screen

# Captured from a real `/usage` screen, ANSI and box-drawing intact.
REAL_SCREEN = (
    "\x1b[2J\x1b[H\x1b[1m Usage\x1b[0m\r\n"
    "\r\n"
    " \x1b[1mCurrent session\x1b[0m\r\n"
    " \x1b[38;5;214m████████████▌\x1b[0m            51% used\r\n"
    " Resets 9:40pm (Asia/Calcutta)\r\n"
    "\r\n"
    " \x1b[1mCurrent week (all models)\x1b[0m\r\n"
    " \x1b[38;5;214m████████████████\x1b[0m         56% used\r\n"
    " Resets Aug 4 at 7:30pm (Asia/Calcutta)\r\n"
)


class FakeDash:
    def __init__(self):
        self.sent: list[dict] = []
        self.panes = type("P", (), {"all": staticmethod(lambda: [])})()

    def emit_raw(self, msg):
        self.sent.append(msg)

    def usages(self):
        return [m["v"] for m in self.sent if m.get("t") == "usage"]


@pytest.fixture
def mon(monkeypatch):
    m = UsageMonitor(FakeDash(), probe=True)
    # today_totals walks ~/.claude/projects; irrelevant here and slow
    monkeypatch.setattr("mem.voice.usage.today_totals",
                        lambda: {"output": 0, "cacheRead": 0,
                                 "sessions": 0, "projects": 0})
    return m


# ------------------------------------------------------------------ parsing

def test_parses_a_real_usage_screen():
    got = parse_usage_screen(REAL_SCREEN)
    assert got["sessionPct"] == 51
    assert got["weekPct"] == 56
    assert got["sessionResets"] == "9:40pm (Asia/Calcutta)"
    assert got["weekResets"] == "Aug 4 at 7:30pm (Asia/Calcutta)"


def test_a_redesigned_screen_degrades_instead_of_lying():
    """The parse is anchored on two headings. If Anthropic restyles the screen
    the right outcome is no numbers, not wrong ones."""
    assert parse_usage_screen("Some entirely new usage UI\n  you are fine\n") == {}


# ------------------------------------------------------------- liveness

def test_a_failed_probe_is_reported_not_swallowed(mon, monkeypatch):
    monkeypatch.setattr("mem.voice.usage.probe_limits", lambda: {"sessionPct": 40})
    mon._probe_once()
    assert mon.limits["sessionPct"] == 40
    first_read = mon.read_at
    assert first_read > 0

    monkeypatch.setattr("mem.voice.usage.probe_limits", lambda: {})   # probe fails
    mon._probe_once()
    payload = mon.dash.usages()[-1]
    assert payload["sessionPct"] == 40, "a failed read is not evidence it changed"
    assert payload["probeError"], "but the failure has to be visible"
    assert mon.read_at == first_read, "a failed read must not refresh the age"


def test_a_reading_carries_its_age(mon, monkeypatch):
    monkeypatch.setattr("mem.voice.usage.probe_limits", lambda: {"sessionPct": 7})
    mon._probe_once()
    p = mon.dash.usages()[-1]
    assert p["ageS"] == 0 and p["stale"] is False

    mon.read_at = time.time() - (mon.STALE_AFTER + 60)
    mon._emit()
    p = mon.dash.usages()[-1]
    assert p["stale"] is True, "an old reading must not look current"


def test_the_probe_announces_itself_before_it_blocks(mon, monkeypatch):
    """The probe drives a real terminal for several seconds. The UI has to know
    that is happening, or clicking refresh looks like it did nothing."""
    seen = []

    def slow_probe():
        seen.append(mon.dash.usages()[-1]["probing"])
        return {"sessionPct": 3}

    monkeypatch.setattr("mem.voice.usage.probe_limits", slow_probe)
    mon._probe_once()
    assert seen == [True], "no 'reading…' was emitted before the probe blocked"
    assert mon.dash.usages()[-1]["probing"] is False


def test_two_probes_do_not_run_at_once(mon, monkeypatch):
    """Each probe spawns a `claude` process. Overlapping them spawns two."""
    calls = []
    monkeypatch.setattr("mem.voice.usage.probe_limits",
                        lambda: (calls.append(1), mon._probe_once(), {})[-1])
    mon._probe_once()
    assert len(calls) == 1


def test_turn_end_refreshes_but_is_throttled(mon, monkeypatch):
    """A limit percentage moves when you spend tokens, so the end of a turn is
    when it is worth re-reading — but a run of one-line turns must not spawn a
    process every few seconds."""
    calls = []
    monkeypatch.setattr(mon, "refresh_limits_now", lambda: calls.append(1))

    mon.on_turn_end()
    assert len(calls) == 1

    mon._last_probe = time.time()
    mon.on_turn_end()
    assert len(calls) == 1, "a second turn straight after must not re-probe"

    mon._last_probe = time.time() - (mon.TURN_THROTTLE + 1)
    mon.on_turn_end()
    assert len(calls) == 2


def test_local_numbers_are_emitted_before_the_slow_probe(mon, monkeypatch):
    """Launch used to show empty meters for the whole ~8s of the first probe."""
    order = []
    monkeypatch.setattr("mem.voice.usage.probe_limits",
                        lambda: (order.append("probe"), {"sessionPct": 1})[-1])
    monkeypatch.setattr(mon, "_pane_context", lambda: order.append("emit") or {})
    mon._stop.set()          # one pass, no loop
    mon._run()
    assert order[0] == "emit", "the probe ran before anything was shown"
