"""
Which pane your voice goes to, and which pane you are merely looking at.

These are two different questions, and the whole point of this file is that
they have two different answers. They used to share one: clicking a terminal
moved the voice to it. That reads well in a design document and is wrong in
use — selecting a session is something you do constantly and mid-sentence, so
a click while the clone was thinking redirected the answer to a session nobody
was listening to, and the reply you were waiting for was never spoken.

So: selection follows your clicks, and the voice follows exactly one control.
The resting state of the voice is the clone, because the clone is the one that
knows everything.

Panes are faked rather than spawned. A real pane starts a `claude` process,
which needs the CLI installed, an account, and several seconds; none of that is
under test and all of it would make these tests unrunnable in CI.
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from mem.voice.panes import PaneManager                          # noqa: E402


class FakePty:
    def __init__(self, alive=True):
        self.alive = alive
        self.exit_code = None
        self.written = b""

    def write(self, data):
        self.written += data

    def close(self):
        self.alive = False


class FakePane:
    def __init__(self, pid, kind, cwd, alive=True):
        self.id = pid
        self.kind = kind
        self.cwd = cwd
        self.title = Path(cwd).name
        self.session_id = pid
        self.pty = FakePty(alive)

    # Mirrors Pane.project_cwd. Kept in step deliberately: the fake exists to
    # stand in for the real thing, not to be easier than it.
    @property
    def project_cwd(self):
        from mem.voice.paths import LAUNCH_CWD
        return str(LAUNCH_CWD) if self.kind == "voice" else self.cwd

    def info(self):
        return {"id": self.id, "kind": self.kind, "cwd": self.cwd,
                "title": self.title, "alive": self.pty.alive,
                "shortCwd": Path(self.cwd).name}


@pytest.fixture
def mgr():
    m = PaneManager()
    m._panes = {
        "v1": FakePane("v1", "voice", "/tmp/home"),
        "p1": FakePane("p1", "plain", "/tmp/api"),
        "p2": FakePane("p2", "plain", "/tmp/web"),
    }
    return m


# ---- the voice rests with the clone ------------------------------------

def test_the_clone_is_where_the_voice_starts(mgr):
    """On first launch nothing has been pressed yet, and the answer to "where
    does my voice go" must never be silence."""
    assert mgr.target_pane().id == "v1"


def test_selecting_a_pane_does_not_move_the_voice(mgr):
    """THE BUG THIS FILE EXISTS FOR. You click into a terminal to read it while
    your clone is mid-answer. The answer must still arrive."""
    assert mgr.focus("p1") is True
    assert mgr.focused_pane().id == "p1"
    assert mgr.target_pane().id == "v1"


def test_selecting_moves_the_rail_and_the_git_panel(mgr):
    """Selection still has to do its own job — this is what the left rail and
    the git panel read to decide which repo they are describing."""
    mgr.focus("p2")
    assert mgr.focused_pane().cwd == "/tmp/web"


# ---- and moves only when you say so ------------------------------------

def test_the_button_moves_the_voice(mgr):
    assert mgr.set_voice_target("p1").id == "p1"
    assert mgr.target_pane().id == "p1"
    assert mgr.target_pane().cwd == "/tmp/api"


def test_pressing_it_again_hands_the_voice_back(mgr):
    """One control, both directions. Otherwise "give it back to my clone" is a
    separate thing to go and find."""
    mgr.set_voice_target("p1")
    assert mgr.set_voice_target("p1").id == "v1"
    assert mgr.target_pane().id == "v1"


def test_pointing_at_another_session_just_moves_it(mgr):
    mgr.set_voice_target("p1")
    assert mgr.set_voice_target("p2").id == "p2"


def test_pointing_at_a_pane_that_is_gone_falls_back(mgr):
    """A click can race a pane closing. The honest answer to "talk to something
    that no longer exists" is the clone, not an exception on the UI thread."""
    assert mgr.set_voice_target("nope").id == "v1"


def test_selection_and_voice_can_disagree(mgr):
    """The state the whole redesign exists to allow: reading one session while
    talking to another."""
    mgr.set_voice_target("p1")
    mgr.focus("p2")
    assert mgr.focused_pane().id == "p2"
    assert mgr.target_pane().id == "p1"


# ---- and never points at a corpse --------------------------------------

def test_a_dead_target_hands_back_to_the_clone(mgr):
    """The session you were talking to exited. Your voice must not vanish into
    a process that is not there."""
    mgr.set_voice_target("p2")
    assert mgr.target_pane().id == "p2"
    mgr._panes["p2"].pty.alive = False
    assert mgr.target_pane().id == "v1"


def test_closing_the_target_hands_back_to_the_clone(mgr):
    mgr.set_voice_target("p1")
    mgr.close("p1")
    assert mgr._voice_target == ""
    assert mgr.target_pane().id == "v1"


def test_a_stopped_target_is_released_by_the_roster(mgr):
    """sync_roster is what notices a process died on its own."""
    mgr.set_voice_target("p2")
    mgr._panes["p2"].pty.alive = False
    mgr._panes["p2"].state = "idle"
    mgr.sync_roster([], auto_adopt=False)
    assert mgr._voice_target == ""


def test_no_clone_and_no_target_means_no_target(mgr):
    """Not an error. It is what an empty dashboard looks like, and the caller
    checks for None rather than being handed a pane it cannot write to."""
    mgr._panes.pop("v1")
    assert mgr.target_pane() is None


# ---- what the UI is told -----------------------------------------------

def test_info_marks_exactly_one_of_each(mgr):
    mgr.focus("p1")
    mgr.set_voice_target("p2")
    rows = mgr.info()
    assert sum(r["focused"] for r in rows) == 1
    assert sum(r["voice"] for r in rows) == 1
    assert next(r for r in rows if r["focused"])["id"] == "p1"
    assert next(r for r in rows if r["voice"])["id"] == "p2"


def test_info_marks_the_clone_when_nothing_has_been_pressed(mgr):
    """The rail should say "your clone" rather than nothing, because that is in
    fact where a held space bar would go."""
    assert next(r for r in mgr.info() if r["voice"])["id"] == "v1"


# ---- where the clone stands --------------------------------------------

def test_the_clone_opens_in_the_vault(tmp_path, monkeypatch):
    """It is the session that HAS the memory, so it stands in the memory. A
    clone launched inside one of your repositories is just a session with a
    system prompt."""
    from mem.voice import paths
    v = tmp_path / "vault"
    v.mkdir()
    monkeypatch.setattr(paths, "vault", lambda: v)
    assert paths.clone_cwd() == v


def test_no_vault_yet_falls_back_to_where_you_are(tmp_path, monkeypatch):
    """A fresh install before `mem init`. The honest answer is "wherever you
    are", not a directory that does not exist."""
    from mem.voice import paths
    monkeypatch.setattr(paths, "vault", lambda: tmp_path / "nope")
    assert paths.clone_cwd() == paths.LAUNCH_CWD


def test_the_rail_follows_your_code_not_the_notebook(mgr):
    """The clone's working directory is the vault, which is a folder of
    markdown. Pointing PROJECT at it makes the rail announce "no repo" while
    you are looking at real work."""
    from mem.voice.paths import LAUNCH_CWD
    assert mgr._panes["v1"].project_cwd == str(LAUNCH_CWD)
    assert mgr._panes["p1"].project_cwd == "/tmp/api"
