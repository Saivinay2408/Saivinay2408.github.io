"""The GPU speech path must never cost a word: every way it can fail lands on
the CPU path that was there before."""
import sys
import types

import pytest

from mem.voice import gpu, supervisor


@pytest.fixture(autouse=True)
def fresh(monkeypatch):
    monkeypatch.setattr(gpu, "_avail", None)
    monkeypatch.delenv("MEM_GPU", raising=False)


def test_switched_off_by_env(monkeypatch):
    monkeypatch.setenv("MEM_GPU", "0")
    assert gpu.available() is False


def test_not_apple_silicon(monkeypatch):
    monkeypatch.setattr(gpu.sys, "platform", "linux")
    assert gpu.available() is False


class FakeKokoro:
    def __init__(self):
        self.calls = 0
        self.voices = {"af_bella": None}

    def _infer(self, tokens, style, speed):
        self.calls += 1
        return "cpu-audio", None

    def create(self, *a, **kw):
        return self._infer([1], None, 1.0)


def test_kokoro_untouched_without_gpu(monkeypatch):
    monkeypatch.setattr(gpu, "available", lambda: False)
    k = FakeKokoro()
    orig = k._infer
    assert gpu.accelerate_kokoro(k, path="/nowhere") is False
    assert k._infer == orig


def test_kokoro_untouched_when_the_private_method_changed(monkeypatch):
    monkeypatch.setattr(gpu, "available", lambda: True)

    class Other(FakeKokoro):
        def _infer(self, ids, voice_style, rate):          # renamed upstream
            return "cpu-audio", None

    k = Other()
    orig = k._infer
    assert gpu.accelerate_kokoro(k, path="/nowhere") is False
    assert k._infer == orig


def test_kokoro_untouched_without_weights(monkeypatch):
    monkeypatch.setattr(gpu, "available", lambda: True)
    monkeypatch.setattr(gpu, "kokoro_path", lambda: "")
    k = FakeKokoro()
    orig = k._infer
    assert gpu.accelerate_kokoro(k) is False
    assert k._infer == orig


def test_kokoro_gpu_error_falls_back_for_good(monkeypatch):
    monkeypatch.setattr(gpu, "available", lambda: True)

    class Model:
        n = 0

        def __call__(self, *a, **kw):
            Model.n += 1
            raise RuntimeError("metal went away")

    monkeypatch.setattr(gpu, "_load_kokoro",
                        lambda p: (Model(), {"n_token": 4, "vocab": {}}))
    fake_mx = types.ModuleType("mlx.core")
    fake_mx.array = lambda x: types.SimpleNamespace(reshape=lambda *s: x)
    fake_mx.float32 = "f32"
    fake_mlx = types.ModuleType("mlx")
    fake_mlx.core = fake_mx
    monkeypatch.setitem(sys.modules, "mlx", fake_mlx)
    monkeypatch.setitem(sys.modules, "mlx.core", fake_mx)

    k = FakeKokoro()
    assert gpu.accelerate_kokoro(k, path="/x") is False   # warm-up already failed
    before = k.calls
    assert k._infer([1, 2], [0.0] * 256, 1.0)[0] == "cpu-audio"
    assert k._infer([1, 2], [0.0] * 256, 1.0)[0] == "cpu-audio"
    assert Model.n == 1                                   # never retried the GPU
    assert k.calls == before + 2


def test_transcriber_falls_back_to_cpu_on_gpu_error(monkeypatch):
    from mem.voice import stt

    class BadGPU:
        def transcribe(self, audio):
            raise RuntimeError("boom")

    class CPU:
        def transcribe(self, audio, **kw):
            return [types.SimpleNamespace(text=" hello there ")], None

    t = stt.Transcriber.__new__(stt.Transcriber)
    t.model_size, t.model, t._gpu, t._gpu_off = "small", CPU(), BadGPU(), False
    assert t.transcribe([0.0])[0] == "hello there"
    assert t.device == "cpu" and t._gpu_off


def test_voice_session_asks_for_low_effort(monkeypatch):
    monkeypatch.setattr(supervisor, "_HELP", "  --effort <level>  ...")
    monkeypatch.delenv("MEM_VOICE_EFFORT", raising=False)
    cmd = supervisor.voice_pane_cmd("sid", "sonnet")
    assert cmd[cmd.index("--effort") + 1] == "low"
    assert cmd[cmd.index("--model") + 1] == "sonnet"


def test_old_claude_gets_no_effort_flag(monkeypatch):
    monkeypatch.setattr(supervisor, "_HELP", "  --model <model> ...")
    assert "--effort" not in supervisor.voice_pane_cmd("sid", "sonnet")


def test_effort_can_be_overridden(monkeypatch):
    monkeypatch.setattr(supervisor, "_HELP", "--effort")
    monkeypatch.setenv("MEM_VOICE_EFFORT", "")
    assert "--effort" not in supervisor.voice_pane_cmd("sid", "sonnet")
