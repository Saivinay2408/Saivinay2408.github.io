"""
The MCP server, exercised over its actual wire format.

Everything here drives `serve` through string IO rather than calling handlers
directly, because the failures that matter in a stdio server are protocol
failures: answering a notification, dying on a malformed frame, or printing
something to stdout that was not a JSON-RPC message. None of those are visible
from the function level, and all of them look identical from the agent's side —
the server "just doesn't work".
"""
from __future__ import annotations

import io
import json
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from mem import mcp                                          # noqa: E402


def drive(lines: list[dict | str], vault: Path) -> list[dict]:
    """Feed frames in, collect responses out."""
    raw = "".join((json.dumps(m) if isinstance(m, dict) else m) + "\n" for m in lines)
    out = io.StringIO()
    mcp.serve(vault=vault, stdin=io.StringIO(raw), stdout=out)
    return [json.loads(line) for line in out.getvalue().splitlines() if line.strip()]


def req(msg_id, method, **params) -> dict:
    m = {"jsonrpc": "2.0", "id": msg_id, "method": method}
    if params:
        m["params"] = params
    return m


@pytest.fixture
def vault(tmp_path):
    (tmp_path / "episodic" / "inbox").mkdir(parents=True)
    return tmp_path


def test_initialize_reports_a_protocol_and_a_name(vault):
    [reply] = drive([req(1, "initialize")], vault)
    assert reply["result"]["protocolVersion"] == mcp.PROTOCOL_VERSION
    assert reply["result"]["serverInfo"]["name"] == "mem"
    assert "tools" in reply["result"]["capabilities"]


def test_notifications_are_never_answered(vault):
    """A notification has no id. Replying to one wedges a strict client, and
    'strict client' includes at least one of the three CLIs this targets."""
    replies = drive([{"jsonrpc": "2.0", "method": "notifications/initialized"}], vault)
    assert replies == []


def test_tools_are_listed_with_schemas(vault):
    [reply] = drive([req(1, "tools/list")], vault)
    tools = {t["name"]: t for t in reply["result"]["tools"]}
    assert set(tools) == {"recall", "identity", "remember"}
    for tool in tools.values():
        assert tool["description"].strip()
        assert tool["inputSchema"]["type"] == "object"


def test_a_bad_frame_does_not_end_the_session(vault):
    """One malformed line must not cost the user everything after it."""
    replies = drive(["{{{ not json", req(7, "tools/list")], vault)
    assert [r["id"] for r in replies] == [7]


def test_unknown_tool_is_an_error_not_a_crash(vault):
    [reply] = drive([req(2, "tools/call", name="nope", arguments={})], vault)
    assert reply["error"]["code"] == -32602


def test_unknown_method_is_an_error(vault):
    [reply] = drive([req(3, "resources/list")], vault)
    assert reply["error"]["code"] == -32601


def test_recall_on_an_empty_vault_says_so_rather_than_inventing(vault):
    """The instruction in this string is load-bearing. An empty result that
    reads like a failure invites the model to fill the gap from training data,
    which is exactly the hallucinated-personal-detail failure the whole gate
    exists to prevent."""
    [reply] = drive([req(4, "tools/call", name="recall",
                         arguments={"query": "what does this person prefer"})], vault)
    text = reply["result"]["content"][0]["text"]
    assert "do not invent" in text.lower()


def test_remember_goes_to_the_inbox_not_into_the_graph(vault):
    """A tool the model can call is the last thing that should be able to write
    straight into memory. It queues for the same reject gate as everything else."""
    [reply] = drive([req(5, "tools/call", name="remember",
                         arguments={"text": "prefers tabs over spaces"})], vault)
    assert reply["result"].get("isError") is not True

    written = list((vault / "episodic" / "inbox").glob("*.md"))
    assert len(written) == 1
    body = written[0].read_text(encoding="utf-8")
    assert "prefers tabs over spaces" in body
    assert "consolidated: false" in body, "skipped the consolidation gate"


def test_a_tool_that_raises_is_reported_not_fatal(vault, monkeypatch):
    def boom(*_a, **_k):
        raise RuntimeError("index is corrupt")
    monkeypatch.setitem(mcp.HANDLERS, "recall", boom)

    replies = drive([req(6, "tools/call", name="recall", arguments={"query": "x"}),
                     req(7, "tools/list")], vault)
    assert replies[0]["result"]["isError"] is True
    assert "index is corrupt" in replies[0]["result"]["content"][0]["text"]
    assert replies[1]["id"] == 7, "the server died instead of carrying on"


def test_nothing_but_json_rpc_reaches_stdout(vault):
    """stdout is the wire. One stray print is a protocol error that shows up as
    the agent silently losing the server."""
    out = io.StringIO()
    mcp.serve(vault=vault, stdout=out, stdin=io.StringIO(
        json.dumps(req(1, "initialize")) + "\n"
        + json.dumps(req(2, "tools/call", name="remember",
                         arguments={"text": "hello"})) + "\n"))
    for line in out.getvalue().splitlines():
        assert json.loads(line)["jsonrpc"] == "2.0"
