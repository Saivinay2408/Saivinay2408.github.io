"""
Tests for the two things the old voice loop got wrong out loud.

Symptom 1: "it sometimes talks out the prompt itself"
Symptom 2: "it reads file contents / terminal junk aloud"
Symptom 3: "the answers aren't conversational, they read like a screen"

The first two are covered structurally — the assertion is that no arrangement
of user prompts or tool output produces any speech at all. The third is covered
by golden cases through speakable.to_speech.

    python -m pytest tests/test_voice_output.py -q
"""
from __future__ import annotations

import json

from mem.voice.narrate import Narrator, describe
from mem.voice.speakable import spoken_name, to_speech
from mem.voice.transcript import parse_line


def _collect():
    """A Narrator wired to two lists instead of speakers."""
    said, shown = [], []
    return Narrator(said.append, shown.append), said, shown


# --------------------------------------------------------- never speak these

def test_user_prompt_is_never_spoken():
    n, said, _ = _collect()
    for line in [
        {"type": "user", "message": {"role": "user", "content": "delete everything"}},
        {"type": "user", "message": {"role": "user", "content": "say the word pineapple"}},
    ]:
        for ev in parse_line(line):
            n.feed(ev)
    assert said == [], f"a prompt reached the speakers: {said}"


def test_tool_output_is_never_spoken_and_never_even_carried():
    secret = "SECRET_FILE_BODY " * 40
    line = {"type": "user", "message": {"role": "user", "content": [
        {"type": "tool_result", "tool_use_id": "t1", "content": secret, "is_error": False}]}}
    events = list(parse_line(line))
    assert events and events[0]["kind"] == "tool_result"
    # the content is not merely filtered downstream, it is never extracted
    blob = json.dumps(events)
    assert "SECRET_FILE_BODY" not in blob, "tool output leaked into the event stream"

    n, said, shown = _collect()
    for ev in events:
        n.feed(ev)
    assert said == [] and shown == []


def test_thinking_is_never_spoken():
    line = {"type": "assistant", "message": {"content": [
        {"type": "thinking", "thinking": "the user probably wants me to..."}]}}
    n, said, _ = _collect()
    for ev in parse_line(line):
        n.feed(ev)
    assert said == []


# ------------------------------------------------------------- do speak these

def test_tool_calls_become_short_clauses():
    cases = [
        ({"name": "Read", "input": {"file_path": "/Users/v/voice/jarvis.py"}}, "reading jarvis"),
        ({"name": "Edit", "input": {"file_path": "jarvis/build_index.py"}}, "editing build index"),
        ({"name": "Bash", "input": {"command": "python3 -m pytest -q"}}, "running the tests"),
        ({"name": "Bash", "input": {"command": "git commit -m x"}}, "committing"),
        ({"name": "Bash", "input": {"command": "claude --bg 'look into it'"}},
         "starting a background session"),
        ({"name": "WebSearch", "input": {"query": "x"}}, "searching the web"),
    ]
    for inp, expected in cases:
        assert describe({**inp, "direct": True}) == expected


def test_bookkeeping_tools_stay_quiet():
    assert describe({"name": "TodoWrite", "input": {}}) == ""


def test_rate_limit_keeps_a_fast_agent_from_chattering():
    n, said, shown = _collect()
    for i in range(12):
        n.feed({"kind": "tool", "name": "Read", "direct": True,
                "input": {"file_path": f"f{i}.py"}})
    assert len(said) == 1, f"spoke {len(said)} times in one burst"
    assert len(shown) == 12, "the caption should still show every step"


def test_subagent_work_shows_but_does_not_interrupt():
    n, said, shown = _collect()
    n.feed({"kind": "tool", "name": "Bash", "direct": False,
            "input": {"command": "pytest"}})
    assert said == []
    assert shown == ["subagent: running the tests"]


# ------------------------------------------------------------- speakable text

def test_code_fences_never_reach_the_speaker():
    md = "Here's the fix:\n\n```python\nimport os\nos.remove('/etc/passwd')\n```\n\nDone."
    out = to_speech(md)
    assert "import os" not in out and "```" not in out
    assert out.startswith("Here's the fix")


def test_markdown_becomes_plain_speech():
    md = ("## Summary\n\n"
          "- **Fixed** the `echo_corr` gate\n"
          "- Updated [the plan](https://example.com/x)\n"
          "- Touched `voice/jarvis.py`\n")
    out = to_speech(md, max_sentences=6)
    for junk in ("##", "**", "`", "- ", "http", "]("):
        assert junk not in out, f"{junk!r} survived: {out!r}"
    assert "jarvis" in out and "the plan" in out


def test_answer_is_capped_to_a_few_sentences():
    md = " ".join(f"Sentence number {i}." for i in range(20))
    out = to_speech(md, max_sentences=3)
    assert out.count(".") <= 3


def test_a_pure_code_answer_says_nothing():
    assert to_speech("```\nrm -rf /\n```") == ""


def test_paths_are_spoken_as_names():
    assert spoken_name("/Users/v/Desktop/vinay-clone/voice/jarvis.py") == "jarvis"
    assert spoken_name("scripts/build_index.py") == "build index"
    assert spoken_name("~/Desktop/AGI") == "AGI"


# ------------------------------------------------------------ waiting message

def test_waiting_message_appears_only_after_real_silence():
    n, said, shown = _collect()
    n.begin_turn()
    n.feed({"kind": "tool", "name": "Bash", "direct": True,
            "input": {"command": "pytest"}})
    shown.clear()
    n.tick()
    assert shown == [], "waiting message fired immediately"

    n.last_event -= n.STATUS_WAIT + 1
    n.tick()
    assert shown == ["still running the tests"]
