"""
Which agents are here, and what rules govern them.

Both answers must come from the machine. An agent picker that offers Codex on
a machine without it makes a promise the app cannot keep, and a rules panel
that hides a missing CLAUDE.md answers "what governs this project?" with
silence when the true answer is "nothing, and here is where to put it".
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from mem.voice import agents_ui                                  # noqa: E402


def test_every_supported_agent_is_reported(monkeypatch):
    monkeypatch.setattr(agents_ui.shutil, "which", lambda b: None)
    names = {a["name"] for a in agents_ui.installed(probe_version=False)}
    assert names == {"claude", "codex", "gemini"}


def test_a_missing_agent_carries_the_command_that_fixes_it(monkeypatch):
    """Not a dead button and not a silent failure."""
    monkeypatch.setattr(agents_ui.shutil, "which", lambda b: None)
    for a in agents_ui.installed(probe_version=False):
        assert a["installed"] is False
        assert a["install"], f"{a['name']} offers no way to install it"
        assert a["version"] == ""


def test_an_installed_agent_reports_where_it_is(monkeypatch):
    monkeypatch.setattr(agents_ui.shutil, "which",
                        lambda b: "/usr/local/bin/" + b if b == "claude" else None)
    by = {a["name"]: a for a in agents_ui.installed(probe_version=False)}
    assert by["claude"]["installed"] is True
    assert by["claude"]["path"].endswith("claude")
    assert by["codex"]["installed"] is False


def test_the_version_probe_is_optional(monkeypatch):
    """It shells out once per agent. Fine on connect, wrong on a 2s timer."""
    calls = []
    monkeypatch.setattr(agents_ui.shutil, "which", lambda b: "/bin/" + b)
    monkeypatch.setattr(agents_ui, "_version", lambda b: calls.append(b) or "1.0")
    agents_ui.installed(probe_version=False)
    assert calls == []
    agents_ui.installed(probe_version=True)
    assert len(calls) == 3


def test_a_version_probe_that_fails_is_not_fatal(monkeypatch):
    monkeypatch.setattr(agents_ui.shutil, "which", lambda b: "/bin/" + b)
    assert agents_ui._version("definitely-not-a-real-binary-xyz") == ""


def test_missing_rules_files_are_listed_not_hidden(tmp_path, monkeypatch):
    """"There is no project CLAUDE.md here" is the answer to a real question.
    An empty list would look like the app had not checked."""
    monkeypatch.setattr(agents_ui, "GLOBAL_RULES", {"claude": tmp_path / "none.md"})
    rows = agents_ui.rules(tmp_path)
    assert any(r["scope"] == "global" and r["exists"] is False for r in rows)
    assert any(r["scope"] == "project" and r["exists"] is False for r in rows)


def test_an_existing_rules_file_reports_its_size(tmp_path, monkeypatch):
    g = tmp_path / "global.md"
    g.write_text("be terse\n")
    (tmp_path / "CLAUDE.md").write_text("project rules\n")
    monkeypatch.setattr(agents_ui, "GLOBAL_RULES", {"claude": g})

    rows = {r["name"]: r for r in agents_ui.rules(tmp_path)}
    assert rows["Global CLAUDE.md"]["exists"] and rows["Global CLAUDE.md"]["bytes"] == 9
    assert rows["Project CLAUDE.md"]["exists"] is True


def test_a_shared_rules_filename_is_listed_once(tmp_path, monkeypatch):
    """Codex and anything else reading AGENTS.md must not produce two identical
    project rows."""
    monkeypatch.setattr(agents_ui, "GLOBAL_RULES", {})
    names = [r["name"] for r in agents_ui.rules(tmp_path)]
    assert len(names) == len(set(names))


def test_rules_without_a_project_lists_only_globals(tmp_path, monkeypatch):
    monkeypatch.setattr(agents_ui, "GLOBAL_RULES", {"claude": tmp_path / "g.md"})
    assert all(r["scope"] == "global" for r in agents_ui.rules(None))


def test_reading_a_rules_file(tmp_path):
    f = tmp_path / "CLAUDE.md"
    f.write_text("never use em dashes\n")
    out = agents_ui.read_rules(f)
    assert out["ok"] and "em dashes" in out["text"]


def test_reading_a_missing_file_reports_rather_than_raises(tmp_path):
    out = agents_ui.read_rules(tmp_path / "nope.md")
    assert out["ok"] is False and out["error"]


def test_a_huge_rules_file_is_capped(tmp_path):
    f = tmp_path / "CLAUDE.md"
    f.write_text("x" * 5000)
    out = agents_ui.read_rules(f, max_bytes=100)
    assert out["truncated"] is True and len(out["text"]) == 100


def test_nothing_here_creates_a_file(tmp_path, monkeypatch):
    """Listing a rules file that does not exist tells you where to put one.
    Creating it silently would put words in the user's mouth."""
    monkeypatch.setattr(agents_ui, "GLOBAL_RULES", {"claude": tmp_path / "g.md"})
    agents_ui.snapshot(tmp_path, probe_version=False)
    agents_ui.read_rules(tmp_path / "CLAUDE.md")
    assert list(tmp_path.iterdir()) == []
