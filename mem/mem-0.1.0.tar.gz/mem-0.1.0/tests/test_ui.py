"""
The window is one HTML file, one stylesheet and one script, and they can
disagree. When they do, the failure is not subtle: `$("btn-rules")` returned
null after that button was deleted from the markup, the resulting TypeError
killed the whole IIFE, and the client rendered a dead page with no sessions,
no meters and no sockets. One missing id took out everything.

These are the three disagreements that are worth a test — they are mechanical,
they are silent at author time, and each has already happened here at least
once.
"""
from __future__ import annotations

import re
from pathlib import Path

UI = Path(__file__).resolve().parents[1] / "mem" / "voice" / "ui"
HTML = (UI / "index.html").read_text(encoding="utf-8")
JS = (UI / "app.js").read_text(encoding="utf-8")
CSS = (UI / "style.css").read_text(encoding="utf-8")

HTML_IDS = set(re.findall(r'\bid="([^"]+)"', HTML))


def test_every_id_the_script_reaches_for_exists():
    """`$("x")` on a deleted element throws, and one throw ends the client."""
    wanted = set(re.findall(r'\$\("([\w-]+)"\)', JS))
    missing = sorted(wanted - HTML_IDS)
    assert not missing, f"app.js reaches for ids that are not in index.html: {missing}"


def test_ids_are_unique():
    """Two elements with one id: `$()` silently returns whichever is first,
    so half the handlers bind to a control nobody can see."""
    all_ids = re.findall(r'\bid="([^"]+)"', HTML)
    dupes = sorted({i for i in all_ids if all_ids.count(i) > 1})
    assert not dupes, f"duplicate ids in index.html: {dupes}"


def test_every_css_variable_used_is_defined():
    """A misspelt custom property is not an error — the declaration is simply
    dropped, and the element renders with an inherited colour that is usually
    close enough to look intentional."""
    defined = set(re.findall(r'^\s*(--[\w-]+)\s*:', CSS, re.M))
    used = set(re.findall(r'var\((--[\w-]+)', CSS))
    # `var(--cols, 1)` and friends are set from JS at runtime.
    from_js = set(re.findall(r'setProperty\("(--[\w-]+)"', JS))
    missing = sorted(used - defined - from_js)
    assert not missing, f"style.css uses undefined variables: {missing}"


def test_the_vault_pointer_is_read_where_it_is_written(tmp_path, monkeypatch):
    """A double-clicked app inherits no environment, so the chosen vault has
    to live in a file. MEM_DIR still outranks it: a throwaway vault for a test
    must not be overridable by whatever this machine happens to prefer."""
    from mem import config

    monkeypatch.setattr(config, "SETTINGS", tmp_path / "config.json")
    monkeypatch.delenv(config.ENV_VAR, raising=False)
    assert config.saved_vault() is None
    assert config.vault_path() == config.DEFAULT_VAULT

    chosen = config.set_vault(tmp_path / "somewhere")
    assert config.vault_path() == chosen

    monkeypatch.setenv(config.ENV_VAR, str(tmp_path / "elsewhere"))
    assert config.vault_path() == (tmp_path / "elsewhere").resolve()

    # and a corrupt settings file degrades to the default rather than taking
    # down a hook that runs inside somebody's coding session
    monkeypatch.delenv(config.ENV_VAR, raising=False)
    (tmp_path / "config.json").write_text("{not json", encoding="utf-8")
    assert config.vault_path() == config.DEFAULT_VAULT
