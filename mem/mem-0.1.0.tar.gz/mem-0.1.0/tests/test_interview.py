"""
The interview asks questions in the window and writes a file the CLI already
knows how to read. Both halves of that sentence are testable, and both have a
way of quietly breaking:

  - the question set lives in Python (the wheel does not ship docs/), so it
    can drift from docs/QUICKSTART.md, which is what people are pointed at.
  - the file it writes has to survive `onboard.parse_answers`, whose rules
    about blank lines and monotonic numbering are strict enough that a
    plausible-looking file can parse into nothing at all.
"""
from __future__ import annotations

import re
from pathlib import Path

import pytest

from mem import onboard
from mem.voice import interview

ROOT = Path(__file__).resolve().parents[1]
QUICKSTART = ROOT / "docs" / "QUICKSTART.md"


def _norm(s: str) -> str:
    return re.sub(r"\s+", " ", s).strip().rstrip(".")


@pytest.mark.skipif(not QUICKSTART.is_file(), reason="docs are not in the wheel")
def test_questions_match_the_document_people_are_pointed_at():
    """One set of ten questions, not two that disagree."""
    # A question wrapped over several lines in the template parses as one
    # line of question plus the rest as "answer" -- the parser only ever sees
    # the first line as the question. Join them back to get the real text.
    doc = {q["num"]: _norm(q["question"] + " " + q["answer"])
           for s in onboard.parse_answers(QUICKSTART.read_text(encoding="utf-8"))
           for q in s["questions"]}
    ours = {q["num"]: _norm(q["question"]) for q in interview.QUESTIONS}
    assert set(doc) == set(ours), "question numbers differ from QUICKSTART.md"
    for num in sorted(doc):
        # `startswith`, not `==`: the last question of a section also absorbs
        # whatever prose follows it in the document, so ours has to be the
        # document's text and cannot be more than it.
        assert doc[num].startswith(ours[num]), (
            f"question {num} has drifted from the doc\n"
            f"doc:  {doc[num][:160]}\nours: {ours[num][:160]}")


@pytest.mark.skipif(not QUICKSTART.is_file(), reason="docs are not in the wheel")
def test_sections_and_their_feeds_match():
    """`feeds:` decides which part of the vault an answer becomes. A section
    that feeds nothing is answers collected and thrown away."""
    doc = {s["num"]: (s["title"], [f.rstrip("/") for f in s["feeds"]])
           for s in onboard.parse_answers(QUICKSTART.read_text(encoding="utf-8"))}
    for s in interview.SECTIONS:
        title, feeds = doc[s["num"]]
        assert s["title"] == title
        assert [f.rstrip("/") for f in s["feeds"]] == feeds


def test_spoken_form_is_shorter_than_the_written_one():
    """The written question is a checklist; read aloud it is a wall you have
    stopped listening to by the third comma."""
    for q in interview.QUESTIONS:
        assert len(q["ask"]) < len(q["question"])
        # One sentence, short enough to hold in your head while you answer it.
        assert len(q["ask"]) <= 130
        assert "\n" not in q["ask"]


def test_what_it_writes_is_what_onboard_reads(tmp_path, monkeypatch):
    monkeypatch.setattr(interview, "STATE", tmp_path)
    monkeypatch.setattr(interview, "STATE_FILE", tmp_path / "interview.json")

    class FakeDash:
        voice = None

        def emit_raw(self, msg):
            pass

    iv = interview.Interview(FakeDash())
    iv.start(0)
    iv.answer("Two things: the dashboard, and the vault behind it.")
    iv.answer("Shipping it, and having someone else run it.")
    iv.skip()                                   # question 3

    sections = onboard.parse_answers(iv.markdown())
    got = {q["num"]: q for s in sections for q in s["questions"]}

    # every question survives the round trip, with its number and its text
    assert sorted(got) == [q["num"] for q in interview.QUESTIONS]
    assert got[1]["answered"] and "dashboard" in got[1]["answer"]
    assert got[2]["answered"]
    # a skip is recorded as a skip, not as an answer that says "skip"
    assert not got[3]["answered"]
    # and an untouched question is not silently counted as answered
    assert not got[9]["answered"]


def test_answers_append_rather_than_replace(tmp_path, monkeypatch):
    """A spoken answer arrives in pieces. Overwriting on each utterance would
    leave you with the last sentence you said and nothing before it."""
    monkeypatch.setattr(interview, "STATE", tmp_path)
    monkeypatch.setattr(interview, "STATE_FILE", tmp_path / "interview.json")

    class FakeDash:
        voice = None

        def emit_raw(self, msg):
            pass

    iv = interview.Interview(FakeDash())
    iv.start(0)
    iv.answer("First sentence.", advance=False)
    iv.answer("Second sentence.", advance=False)
    assert iv.status()["at"] == 0                     # and it did not move on
    body = iv.answers["1"]
    assert "First sentence." in body and "Second sentence." in body


def test_it_survives_the_window_closing(tmp_path, monkeypatch):
    """These questions take real thought and some are personal. Losing them
    to a closed window is not a thing a person forgives twice."""
    monkeypatch.setattr(interview, "STATE", tmp_path)
    monkeypatch.setattr(interview, "STATE_FILE", tmp_path / "interview.json")

    class FakeDash:
        voice = None

        def emit_raw(self, msg):
            pass

    first = interview.Interview(FakeDash())
    first.start(0)
    first.answer("something I would hate to retype")

    again = interview.Interview(FakeDash())
    assert again.answers["1"] == "something I would hate to retype"
    assert again.at == 1
