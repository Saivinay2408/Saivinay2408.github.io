"""
When it is allowed to break the silence, and what it is allowed to say.

Reported: "a 'still working' voice keeps coming in at random intervals". It was
neither random nor working. Six separate faults, one policy behind all of them:

    A spoken line is only worth saying if it tells you something you do not
    already know.

"still working" fails that test absolutely — the orb is lit, so "something is
happening" was never in question. Repeating the same sentence on a 28-second
metronome fails it from the second time onward. Saying anything at all while a
session is BLOCKED fails it and is also false.

    python -m pytest tests/test_narrate_waiting_voice.py -q
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from mem.voice.narrate import Narrator                          # noqa: E402


class Ears:
    """A narrator plus everything it said, with time under test control."""

    def __init__(self, free=True):
        self.said: list[str] = []
        self.shown: list[str] = []
        self.free = free
        self.n = Narrator(say=self.said.append, status=self.shown.append,
                          allow=lambda: self.free)

    def wait(self, seconds: float) -> None:
        """Pretend that much silence has passed, and let the tick loop see it."""
        self.n.last_event -= seconds
        if self.n.said_waiting:
            self.n.said_waiting -= seconds
        self.n.tick()

    def tool(self, name="Bash", command="pytest", direct=True, **inp):
        """One tool call. Its own progress line is dropped, so the tests below
        are about the WAITING channel and not about announcing the step."""
        self.n.feed({"kind": "tool", "name": name, "direct": direct,
                     "input": {"command": command, **inp}})
        self.said.clear()


@pytest.fixture
def ears():
    e = Ears()
    e.n.begin_turn()
    return e


# ---- the sentence that started it --------------------------------------

def test_it_can_never_say_still_working(ears):
    """THE REPORTED BUG. Before the first tool call there is nothing to name,
    and "still working" names nothing. The orb already says that much, in a
    channel that does not interrupt the room."""
    for _ in range(6):
        ears.wait(120)
    assert ears.said == [], f"spoke with nothing to report: {ears.said}"


def test_the_caption_still_says_something(ears):
    """Silent is not the same as blank. What you glance at is free."""
    ears.wait(30)
    assert ears.shown[-1] == "still thinking"


def test_a_waiting_line_always_names_the_work(ears):
    ears.tool(command="pytest")
    ears.wait(40)
    assert ears.said == ["still running the tests"]


# ---- and how often ------------------------------------------------------

def test_the_gap_grows_instead_of_repeating(ears):
    """It used to say the identical sentence every 28 seconds for as long as a
    step lasted. A four-minute install said it eight times."""
    ears.tool(command="npm install")
    for _ in range(4):
        ears.wait(500)                 # far past every threshold
    assert len(ears.said) == 4
    gaps = ears.n.WAIT_STEPS
    assert gaps[0] < gaps[1] < gaps[2] < gaps[3], "the gap has to grow"


def test_a_long_job_is_not_narrated_to_death(ears):
    """Twelve minutes of one command. The old timer would have said it 25
    times; a person would say it two or three."""
    ears.tool(command="npm install")
    spoken = 0
    for _ in range(int(12 * 60 / 5)):      # 5-second ticks for twelve minutes
        before = len(ears.said)
        ears.wait(5)
        spoken += len(ears.said) - before
    assert spoken <= 4, f"said {spoken} things in twelve minutes"
    assert spoken >= 2, "twelve minutes of silence is its own kind of broken"


def test_later_lines_say_how_long_rather_than_repeat(ears):
    """The second reassurance has already made the first one's point. What it
    can add is the duration."""
    ears.tool(command="pytest")
    ears.wait(40)
    ears.wait(200)
    assert ears.said[0] == "still running the tests"
    assert ears.said[1] != ears.said[0]
    assert "minute" in ears.said[1]


def test_progress_resets_the_clock(ears):
    """Something happened, so the silence is over and the next one starts
    fresh — you are not owed a reassurance about work that is visibly moving."""
    ears.tool(command="pytest")
    ears.wait(40)
    assert ears.said == ["still running the tests"]
    ears.tool(command="git commit -m x")      # real progress
    assert ears.n.said_waiting == 0.0
    ears.n.tick()
    assert ears.said == [], "reassured about work that is visibly moving"


# ---- and when it must not speak at all ----------------------------------

def test_it_says_nothing_while_you_are_talking():
    """Holding the key outranks everything. This also used to un-latch the
    speaker's stop flag in the middle of a recording."""
    e = Ears(free=False)
    e.n.begin_turn()
    e.tool(command="pytest")
    e.wait(400)
    assert e.said == []


def test_it_speaks_once_the_room_is_free_again():
    """Deferred, not dropped. The work is still going and you still want to
    know."""
    e = Ears(free=False)
    e.n.begin_turn()
    e.tool(command="pytest")
    e.wait(400)
    assert e.said == []
    e.free = True
    e.n.tick()
    assert e.said == ["still running the tests"]


def test_a_blocked_session_is_never_narrated_as_working():
    """Not merely annoying — false. Something is waiting on YOU, and the loop
    has already said so."""
    e = Ears(free=False)          # what _room_is_free returns while blocked
    e.n.begin_turn()
    e.tool(command="pytest")
    for _ in range(5):
        e.wait(300)
    assert e.said == []


# ---- the same fault in the progress channel -----------------------------

def test_a_run_of_the_same_activity_is_announced_once(ears):
    """Nine files read is one activity, not nine pieces of news. The caption
    still names every file."""
    for i in range(9):
        ears.n.feed({"kind": "tool", "name": "Read", "direct": True,
                     "input": {"file_path": f"mod_{i}.py"}})
    assert len(ears.said) == 1, f"read nine files out loud: {ears.said}"
    assert len([s for s in ears.shown if s.startswith("reading")]) == 9


def test_changing_activity_is_news(ears):
    """Reading, then testing, is two facts. Only a RUN of the same verb is
    collapsed — this is the line that keeps the collapse from muting it."""
    ears.n.feed({"kind": "tool", "name": "Read", "direct": True,
                 "input": {"file_path": "narrate.py"}})
    ears.n.last_say -= Narrator.SAY_GAP + 1
    ears.n.feed({"kind": "tool", "name": "Bash", "direct": True,
                 "input": {"command": "pytest"}})
    assert ears.said == ["reading narrate", "running the tests"]


def test_a_streaming_answer_is_not_silence(ears):
    """The agent writing prose is working. Counting it as dead air let a
    progress line land on top of the reply."""
    ears.tool(command="pytest")
    ears.n.last_event -= 400          # long enough to earn a waiting line...
    ears.n.note_activity()            # ...but the agent is writing right now
    ears.n.tick()
    assert ears.said == []
