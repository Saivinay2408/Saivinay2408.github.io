"""
A terminal program is born at the size of the pane it is in, or it is wrong
forever.

A TUI reads its geometry once, at boot, and lays out against it. Claude Code
fixes the width of its banner and its tips panel there and never recomputes
them — so a session started at a guessed 80 columns and resized to 49 a moment
later draws a layout for a pane it is not in, permanently. That is the wrapped
box borders, the rule repeated down the side, the text broken at a column that
is not there. No later resize repairs it, because the resize re-runs the same
cached layout.

So PtyPane holds the process until a viewer says how big the pane is. These
tests run a real pty against `stty size`, which reports the kernel's idea of the
window — the same number the TUI would read — so they check the actual
mechanism and not our record of it.
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from mem.voice.pty_pane import PtyPane                           # noqa: E402

# Prints the size the kernel reports for this tty, then holds the pty open so
# the reader thread does not race the process exiting.
SAY_SIZE = ["/bin/sh", "-c", "stty size; sleep 5"]


def _read_size(pane, timeout=3.0):
    """Wait for `stty size` to come back through the pty."""
    deadline = time.time() + timeout
    while time.time() < deadline:
        out = pane.scrollback().decode(errors="replace")
        for line in out.replace("\r", "\n").split("\n"):
            parts = line.split()
            if len(parts) == 2 and all(p.isdigit() for p in parts):
                return int(parts[0]), int(parts[1])   # rows, cols
        time.sleep(0.02)
    raise AssertionError(f"no size reported; got {pane.scrollback()!r}")


def test_nothing_runs_until_a_size_arrives():
    pane = PtyPane(SAY_SIZE, label="deferred")
    try:
        assert not pane.started
        assert pane.proc is None
        # ...but it must not look dead. Everything that asks this question is
        # deciding whether to draw the pane, tail it, or let the voice point at
        # it, and the answer for a pane that is about to run is yes.
        assert pane.alive
        assert pane.exit_code is None
    finally:
        pane.close()


def test_the_program_boots_at_the_size_it_was_given():
    """The whole point: its FIRST frame is already the right shape."""
    pane = PtyPane(SAY_SIZE, label="sized")
    try:
        assert pane.start(101, 31)
        rows, cols = _read_size(pane)
        assert (rows, cols) == (31, 101)
    finally:
        pane.close()


def test_start_is_idempotent():
    """The viewer's first resize and the start deadline race by design."""
    pane = PtyPane(SAY_SIZE, label="raced")
    try:
        assert pane.start(90, 30) is True
        first = pane.proc
        assert pane.start(50, 20) is False      # loser changes nothing
        assert pane.proc is first
        rows, cols = _read_size(pane)
        assert (rows, cols) == (30, 90)
    finally:
        pane.close()


def test_a_pane_nobody_looks_at_still_runs(monkeypatch):
    """A dispatched background session nobody has scrolled to is still working.

    Deferring forever would mean the deferral had quietly become a way to not
    run things at all, so there is a deadline and it fires without a viewer.
    """
    monkeypatch.setattr(PtyPane, "START_DEADLINE", 0.15)
    pane = PtyPane(SAY_SIZE, label="unwatched")
    try:
        assert not pane.started
        deadline = time.time() + 3.0
        while time.time() < deadline and not pane.started:
            time.sleep(0.02)
        assert pane.started, "the deadline never fired"
        rows, cols = _read_size(pane)
        assert (rows, cols) == (PtyPane.START_ROWS, PtyPane.START_COLS)
    finally:
        pane.close()


def test_closing_before_it_starts_leaves_nothing_behind():
    pane = PtyPane(SAY_SIZE, label="stillborn")
    pane.close()
    assert pane.proc is None
    assert not pane.alive
    # And the deadline must not resurrect it.
    time.sleep(0.05)
    assert pane.start(80, 24) is False
    assert pane.proc is None


def test_explicit_start_skips_the_wait():
    """`defer=False` is for callers that already know the size."""
    pane = PtyPane(SAY_SIZE, cols=77, rows=21, label="eager", defer=False)
    try:
        assert pane.started
        rows, cols = _read_size(pane)
        assert (rows, cols) == (21, 77)
    finally:
        pane.close()


def test_typing_into_a_pending_pane_starts_it():
    """The voice loop can submit before any browser has measured anything."""
    pane = PtyPane(["/bin/cat"], label="typed")
    try:
        assert not pane.started
        pane.write(b"hello\n")
        assert pane.started
        deadline = time.time() + 3.0
        while time.time() < deadline and b"hello" not in pane.scrollback():
            time.sleep(0.02)
        assert b"hello" in pane.scrollback()
    finally:
        pane.close()


def test_resizing_a_pending_pane_is_harmless():
    """The viewer resizes before the process exists, every single time.

    The first resize is what starts it, and more arrive while it is still
    being debounced -- so this path runs on every pane that has ever opened.
    It used to raise ValueError out of ioctl on the not-yet-existing fd, which
    killed the pty socket handler and left the pane reading "[pane
    disconnected]" before it had drawn anything.
    """
    pane = PtyPane(SAY_SIZE, label="resized-early")
    try:
        pane.resize(120, 40)                 # must not raise
        assert (pane.cols, pane.rows) == (120, 40)
        assert not pane.started
        pane.start(pane.cols, pane.rows)
        rows, cols = _read_size(pane)
        assert (rows, cols) == (40, 120)     # the early resize is what it used
    finally:
        pane.close()
