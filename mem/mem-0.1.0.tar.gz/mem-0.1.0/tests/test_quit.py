"""
Closing the window has to end the process.

It did not, and the failure mode was worse than a stray process. macOS keeps an
app registered as running, so the NEXT launch is not a launch -- it is an
"activate" event sent to something with no window and no event loop left to
answer it. The user gets "Mem is not responding" and cannot reopen the app at
all without Activity Monitor. Reported from a Dock icon that had been working
minutes earlier.

The cause is ordinary: after `webview.start()` returns, the interpreter joins
every non-daemon thread before exiting, and this process has audio callbacks
and library threads that never finish. `sample` on the wedged process showed
the main thread parked in PyThread_acquire_lock -- blocked forever, by design,
on threads that were never going to end.
"""
from __future__ import annotations

import subprocess
import sys
import time
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

# A non-daemon thread that never finishes: exactly the shape of the real one.
STUCK = (
    "import threading, time, sys, os\n"
    "threading.Thread(target=lambda: time.sleep(9999), daemon=False).start()\n"
)


def _run(tail: str, timeout: float = 6.0) -> float | None:
    """Seconds until exit, or None if it wedged."""
    p = subprocess.Popen([sys.executable, "-c", STUCK + tail],
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    started = time.monotonic()
    try:
        p.wait(timeout=timeout)
        return time.monotonic() - started
    except subprocess.TimeoutExpired:
        p.kill()
        p.wait()
        return None


def test_a_lingering_thread_really_does_wedge_exit():
    """The bug is real, and this is what it looks like.

    Without this the fix below is a change nobody can justify keeping -- the
    next person to see a bare os._exit will tidy it into sys.exit and put the
    app straight back into "not responding".
    """
    assert _run("sys.exit(0)") is None, "expected sys.exit to hang on the join"


def test_the_quit_path_exits_anyway():
    took = _run("sys.stdout.flush(); os._exit(0)")
    assert took is not None, "os._exit must not be blocked by a live thread"
    assert took < 3.0


def test_cli_ends_the_process_rather_than_asking_it_to():
    """Guards the actual call site, not just the mechanism."""
    src = (ROOT / "mem" / "voice" / "cli.py").read_text(encoding="utf-8")
    assert "os._exit(0)" in src, "the window-close path must end the process"
    # And the panes must be closed FIRST -- os._exit runs no cleanup, and the
    # thing that matters is killing the child `claude` processes.
    quit_fn = src[src.index("def quit_now"):]
    assert quit_fn.index("shutdown()") < quit_fn.index("os._exit(0)")


def test_window_close_is_wired_to_the_quitting_one():
    """`shutdown` alone closed the panes and left the process alive. The event
    has to be bound to the function that also exits."""
    src = (ROOT / "mem" / "voice" / "cli.py").read_text(encoding="utf-8")
    assert "window.events.closed += quit_now" in src
    assert "window.events.closed += shutdown" not in src


# ---- the watchdog ---------------------------------------------------------
#
# The `closed` event is the tidy path and it is not reliable: a real run ended
# with zero windows on screen, webview.start() never returning, and no thread
# anywhere in the shutdown path -- the event had simply not fired. `sample`
# showed a healthy Cocoa event loop with nothing left to draw. From the Dock
# that is an app that cannot be opened, because macOS will not start a second
# instance and the first has no window to activate.
#
# And the launcher cannot rescue it: clicking the icon while an instance runs
# does not execute the launcher at all. Measured. So the app has to notice by
# itself, which means observing a condition rather than subscribing to a
# callback.

def _watchdog_decision(counts):
    """The watchdog's rule, in isolation: exit once a window has existed and
    then stopped existing. Never before -- windows take a moment to appear,
    and exiting during startup would make the app unlaunchable instead."""
    had_one = False
    for n in counts:
        if n:
            had_one = True
        elif had_one:
            return "exit"
    return "keep running"


def test_it_waits_for_a_window_before_arming():
    """Zero windows at startup is normal, not a reason to quit."""
    assert _watchdog_decision([0, 0, 0]) == "keep running"


def test_it_exits_once_the_last_window_goes():
    assert _watchdog_decision([0, 1, 1, 0]) == "exit"


def test_it_survives_a_window_that_is_still_open():
    assert _watchdog_decision([0, 1, 1, 1]) == "keep running"


def test_the_watchdog_is_actually_wired_up():
    src = (ROOT / "mem" / "voice" / "cli.py").read_text(encoding="utf-8")
    assert "webview.windows" in src, "the watchdog must observe pywebview's own registry"
    assert "threading.Thread(target=watchdog, daemon=True).start()" in src


# ---- a bundle copied to another machine ------------------------------------
#
# How this actually reached a tester: the .app was copied across, not
# installed. The bundle is a launcher pointing at an interpreter in the
# BUILDING machine's home directory, so on theirs "$PY" does not exist.
#
# That used to end at `osascript display alert`, which is worse than nothing:
# it asks macOS for permission to send Apple Events, and if the person
# dismisses that prompt the alert never appears. The icon bounces once and the
# app is silently dead -- reported, accurately, as "it asked for a bunch of
# allows and nothing opened".

def _run_launcher(python_path: str):
    """Run a generated launcher with a stubbed `open` and an isolated HOME."""
    import os
    import tempfile
    from mem.voice import appbundle

    d = Path(tempfile.mkdtemp())
    launcher = d / "Mem"
    launcher.write_text(appbundle.LAUNCHER.format(
        app=appbundle.APP_NAME, python=python_path, site=appbundle.SITE_URL))
    launcher.chmod(0o755)

    stub = d / "bin"
    stub.mkdir()
    (stub / "open").write_text('#!/bin/sh\necho "OPENED $*"\n')
    (stub / "open").chmod(0o755)

    env = dict(os.environ, HOME=str(d), PATH=f"{stub}:{os.environ['PATH']}")
    r = subprocess.run([str(launcher)], capture_output=True, text=True, env=env)
    return r, d / "Library" / "Logs" / "Mem.log"


@pytest.mark.skipif(sys.platform != "darwin", reason="macOS launcher")
def test_a_copied_bundle_sends_you_to_the_install_page():
    """`open <url>` needs no permission, so this cannot be dismissed away."""
    from mem.voice import appbundle
    r, _ = _run_launcher("/nonexistent/python")
    assert r.returncode == 1
    assert appbundle.SITE_URL in r.stdout


@pytest.mark.skipif(sys.platform != "darwin", reason="macOS launcher")
def test_it_says_why_in_the_log():
    """A GUI launch has no terminal, so the log is the only place a reason can
    survive. It has to name the path, or nobody can tell what went wrong."""
    r, log = _run_launcher("/nonexistent/python")
    assert log.is_file()
    body = log.read_text()
    assert "/nonexistent/python" in body
    assert "not on this machine" in body


def test_the_launcher_never_depends_on_osascript_to_report_failure():
    """The failure path must not need a permission the user can decline."""
    from mem.voice import appbundle
    assert "osascript" not in appbundle.LAUNCHER.replace(
        "`osascript display alert`", "")   # the comment explaining why may stay
