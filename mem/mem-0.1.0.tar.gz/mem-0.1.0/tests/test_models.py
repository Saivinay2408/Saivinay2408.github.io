"""
Getting the speech weights, and refusing to be fooled by a partial one.

This is the code path that decides whether a stranger's install can hear and
speak, and it runs once, unattended, over 365 MB of somebody else's bandwidth.
The failure modes that matter are all about *stopping in the middle*: a dropped
connection, a quit app, a mirror that answers with something else. So these
tests are about resumption and verification rather than about the happy path.

They serve the fixtures over a real HTTP server on localhost, because the two
behaviours most worth pinning -- Range resumption and what happens when a
server IGNORES Range -- exist only in the protocol. A mocked urlopen would
assert that the code does what the code does.
"""
from __future__ import annotations

import hashlib
import http.server
import sys
import threading
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from mem.voice import models                                     # noqa: E402
from mem.voice.models import Asset, Cancelled                     # noqa: E402

BODY = bytes(range(256)) * 400          # 102,400 bytes, not compressible away
DIGEST = hashlib.sha256(BODY).hexdigest()


class _Handler(http.server.BaseHTTPRequestHandler):
    """Serves BODY, honours Range, and can be told to ignore Range."""

    ignore_range = False

    def log_message(self, *a):           # silence: pytest output is not a log
        pass

    def _send(self, head_only=False):
        rng = self.headers.get("Range")
        start = 0
        if rng and rng.startswith("bytes=") and not self.ignore_range:
            try:
                start = int(rng.split("=", 1)[1].split("-", 1)[0])
            except ValueError:
                start = 0
        if start >= len(BODY):
            self.send_response(416)
            self.send_header("Content-Range", f"bytes */{len(BODY)}")
            self.end_headers()
            return
        chunk = BODY[start:]
        self.send_response(206 if start else 200)
        self.send_header("Content-Length", str(len(chunk)))
        if start:
            self.send_header("Content-Range",
                             f"bytes {start}-{len(BODY)-1}/{len(BODY)}")
        self.end_headers()
        if not head_only:
            self.wfile.write(chunk)

    def do_GET(self):
        self._send()

    def do_HEAD(self):
        self._send(head_only=True)


@pytest.fixture
def server():
    _Handler.ignore_range = False
    srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), _Handler)
    t = threading.Thread(target=srv.serve_forever, daemon=True)
    t.start()
    yield f"http://127.0.0.1:{srv.server_port}/w.bin"
    srv.shutdown()


@pytest.fixture
def asset(server):
    return Asset(name="w.bin", url=server, sha256=DIGEST, size=len(BODY),
                 what="a test weight", breaks="Nothing.")


# ---- the happy path, and what it leaves behind ---------------------------

def test_downloads_and_verifies(tmp_path, asset):
    models.fetch_one(asset, tmp_path)
    assert (tmp_path / "w.bin").read_bytes() == BODY


def test_no_part_file_survives_success(tmp_path, asset):
    """A leftover `.part` beside a finished file would be resumed next time."""
    models.fetch_one(asset, tmp_path)
    assert list(tmp_path.glob("*.part")) == []


def test_progress_reaches_the_total(tmp_path, asset):
    seen = []
    models.fetch_one(asset, tmp_path, on_progress=lambda n, d, t: seen.append((d, t)))
    assert seen[-1] == (len(BODY), len(BODY))
    assert [d for d, _ in seen] == sorted(d for d, _ in seen)   # never goes backwards


# ---- stopping in the middle ----------------------------------------------

def test_resumes_from_a_part_file(tmp_path, asset):
    """The point of the whole exercise: 300 MB in, the wifi drops."""
    part = tmp_path / "w.bin.part"
    part.write_bytes(BODY[:40_000])

    first = []
    models.fetch_one(asset, tmp_path, on_progress=lambda n, d, t: first.append(d))

    assert (tmp_path / "w.bin").read_bytes() == BODY
    # It started where the part left off rather than at zero -- which is the
    # difference between resuming and re-downloading while claiming to resume.
    assert first[0] == 40_000


def test_a_server_that_ignores_range_starts_over(tmp_path, asset):
    """Some CDNs answer 200 with the whole body regardless of Range.

    Appending that to a partial file produces a corrupt result that only the
    digest would catch -- and by then 325 MB has been spent. So resumption is
    decided by the response status, never by the fact that we asked.
    """
    _Handler.ignore_range = True
    (tmp_path / "w.bin.part").write_bytes(BODY[:40_000])

    models.fetch_one(asset, tmp_path)
    assert (tmp_path / "w.bin").read_bytes() == BODY   # not 40k longer


def test_a_part_longer_than_the_file_is_discarded(tmp_path, asset):
    """A stale `.part` from a different, larger release."""
    (tmp_path / "w.bin.part").write_bytes(BODY + b"junk")
    models.fetch_one(asset, tmp_path)
    assert (tmp_path / "w.bin").read_bytes() == BODY


def test_cancel_stops_and_keeps_the_part(tmp_path, asset):
    """Quitting mid-download must not throw away what was already fetched."""
    calls = {"n": 0}

    def stop():
        calls["n"] += 1
        return calls["n"] > 1

    with pytest.raises(Cancelled):
        models.fetch_one(asset, tmp_path, should_stop=stop)

    assert not (tmp_path / "w.bin").exists()      # nothing entered service
    assert (tmp_path / "w.bin.part").exists()     # and nothing was wasted


# ---- being lied to --------------------------------------------------------

def test_a_wrong_digest_is_refused(tmp_path, server):
    bad = Asset(name="w.bin", url=server, sha256="0" * 64, size=len(BODY),
                what="x", breaks="x")
    with pytest.raises(ValueError):
        models.fetch_one(bad, tmp_path)
    assert not (tmp_path / "w.bin").exists()


def test_a_failed_digest_leaves_no_part_to_resume(tmp_path, server):
    """Otherwise the next attempt appends good bytes to bad ones, forever."""
    bad = Asset(name="w.bin", url=server, sha256="0" * 64, size=len(BODY),
                what="x", breaks="x")
    with pytest.raises(ValueError):
        models.fetch_one(bad, tmp_path)
    assert list(tmp_path.glob("*.part")) == []


# ---- the batch ------------------------------------------------------------

def test_one_failure_does_not_abandon_the_rest(tmp_path, server):
    """Three of the four weights are small. A machine that got hearing and
    turn-detection but not the 325 MB voice is in a better state than one that
    got nothing because the big download timed out."""
    good = Asset("a.bin", server, DIGEST, len(BODY), "x", "x")
    bad = Asset("b.bin", server, "0" * 64, len(BODY), "x", "x")
    report = models.fetch([bad, good], tmp_path)

    assert report["ok"] is False
    assert report["got"] == ["a.bin"]
    assert [f["name"] for f in report["failed"]] == ["b.bin"]
    assert "checksum" in report["failed"][0]["error"]


def test_errors_are_readable(tmp_path, server):
    """A person reads these. `URLError(ConnectionRefusedError(61, ...))` is
    not something anybody can act on."""
    dead = Asset("z.bin", "http://127.0.0.1:9/z.bin", DIGEST, 1, "x", "x")
    report = models.fetch([dead], tmp_path)
    assert "could not reach" in report["error"]
    assert "Traceback" not in report["error"]


# ---- status ---------------------------------------------------------------

def test_status_counts_what_is_missing(tmp_path):
    st = models.status(tmp_path)
    assert st["ready"] is False
    assert st["missing"] == len(models.ASSETS)
    assert st["missingBytes"] == models.TOTAL_BYTES


def test_status_reports_a_resume_point(tmp_path):
    """So a resumed download opens at "180 of 325 MB" instead of at zero,
    which reads as though the earlier attempt was thrown away."""
    a = models.ASSETS[0]
    (tmp_path / (a.name + ".part")).write_bytes(b"x" * 1000)
    item = next(i for i in models.status(tmp_path)["items"] if i["name"] == a.name)
    assert item["resumeFrom"] == 1000
    assert models.status(tmp_path)["missingBytes"] == models.TOTAL_BYTES - 1000


def test_a_wrong_sized_file_is_not_present(tmp_path):
    """Truncated by a full disk, say. It must not count as done."""
    a = models.ASSETS[0]
    (tmp_path / a.name).write_bytes(b"x" * 10)
    item = next(i for i in models.status(tmp_path)["items"] if i["name"] == a.name)
    assert item["present"] is False


# ---- the pinned table itself ---------------------------------------------

def test_every_asset_is_fully_pinned():
    """A url without a digest is a download nobody is checking."""
    for a in models.ASSETS:
        assert a.url.startswith("https://"), a.name
        assert len(a.sha256) == 64 and a.sha256 != "0" * 64, a.name
        assert a.size > 0, a.name
        assert a.what and a.breaks, a.name


def test_no_moving_targets():
    """`raw/master` and `resolve/main` on a mutable branch mean the digest
    stops matching the day upstream ships anything -- and then EVERY fresh
    install fails verification at once, which looks like our bug."""
    for a in models.ASSETS:
        assert "/raw/master/" not in a.url, f"{a.name} is pinned to a branch"
        assert "/raw/main/" not in a.url, f"{a.name} is pinned to a branch"


def test_names_match_what_the_consumers_open():
    """stt.py and tts.py open these by literal name; a rename here is a
    silently missing model there."""
    names = {a.name for a in models.ASSETS}
    assert names == {"kokoro-v1.0.onnx", "voices-v1.0.bin",
                     "silero_vad.onnx", "smart-turn-v3.onnx"}


# ---- where the icon goes --------------------------------------------------
#
# A tester ran the installer, ran `mem app`, and could not find the
# application. It was installed correctly the whole time -- into
# ~/Applications, which is NOT the folder behind Finder's "Applications"
# sidebar item, is not created by macOS, and had never been indexed by
# Launchpad. An install nobody can find has not installed anything.

def test_the_icon_goes_where_finder_looks(monkeypatch):
    """/Applications when writable, which is the common case: it is
    group-writable by `admin` and the first account on a Mac is an admin."""
    import os as _os
    from mem.voice import appbundle
    monkeypatch.setattr(_os, "access", lambda p, m: True)
    assert appbundle.default_dest() == Path("/Applications")


def test_it_falls_back_rather_than_failing(monkeypatch):
    """A managed machine or a standard user cannot write there. That is what
    ~/Applications is for -- as a fallback, never as the default."""
    import os as _os
    real = _os.access
    monkeypatch.setattr(
        _os, "access",
        lambda p, m: False if str(p) == "/Applications" else real(p, m))
    from mem.voice import appbundle
    assert appbundle.default_dest() == Path.home() / "Applications"
