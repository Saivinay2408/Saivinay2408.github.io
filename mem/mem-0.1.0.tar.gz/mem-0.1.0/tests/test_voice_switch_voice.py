"""
Switching sessions must not swallow the answer you are waiting for.

The reported bug, in full: you say something to a session, and while it is
working you click another one to see what it is doing. The voice goes quiet —
not "answers late", quiet. It never speaks that turn at all.

The cause was one line in attach_target_pane: moving the voice unwatched the
old pane's transcript. Every assistant event still to come from the session you
had just spoken to was written to a file nobody was reading, and _turn_active
was forced false on the way out, so the orb dropped back to resting as if the
turn had completed.

Two things fix it, and both are tested here:

  1. selecting a pane no longer moves the voice at all (tests/test_focus.py)
  2. when the voice DOES move, a session that is mid-turn keeps being listened
     to until its turn ends

    python -m pytest tests/test_voice_switch_voice.py -q
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from mem.voice.voice_loop import VoiceLoop                       # noqa: E402


class FakeSpeaker:
    def __init__(self):
        self.spoken: list[str] = []
        self.busy = False
        self.ref = None

    def speak(self, text):
        self.spoken.append(text)

    def stop(self):
        pass

    def resume(self):
        pass


class FakePty:
    def __init__(self):
        self.alive = True
        self.written = b""

    def write(self, data):
        self.written += data


class FakePane:
    def __init__(self, pid, kind, cwd):
        self.id = pid
        self.kind = kind
        self.cwd = cwd
        self.title = Path(cwd).name
        self.session_id = pid
        self.pty = FakePty()


class FakePanes:
    """Just enough PaneManager for the loop: a target, and transcript paths."""

    def __init__(self, tmp):
        self.tmp = tmp
        self.panes = {
            "v1": FakePane("v1", "voice", "/tmp/home"),
            "p1": FakePane("p1", "plain", "/tmp/api"),
        }
        self.target = "v1"

    def get(self, pane_id):
        return self.panes.get(pane_id)

    def target_pane(self):
        return self.panes.get(self.target)

    def transcript_for(self, pane):
        p = self.tmp / f"{pane.id}.jsonl"
        p.touch()
        return p


class FakeDash:
    def __init__(self, panes):
        self.panes = panes
        self.events: list[tuple] = []
        self.hub = self

    def emit(self, kind, payload):
        self.events.append((kind, payload))

    def send_threadsafe(self, msg):
        self.events.append(("raw", msg))


@pytest.fixture
def vl(tmp_path):
    panes = FakePanes(tmp_path)
    loop = VoiceLoop(FakeDash(panes))
    loop.speaker = FakeSpeaker()
    loop._alive = True
    loop.attach_target_pane()               # starts on the clone
    return loop


def _watched(loop):
    return set(loop.watcher._tails)


# ---- the reported bug --------------------------------------------------

def test_a_turn_in_flight_survives_the_voice_moving(vl):
    """You asked the clone something, then pointed the voice at a session while
    it was still working. The clone's answer still has to arrive."""
    vl._on_event("v1", {"kind": "user", "text": "what did I break yesterday"})
    assert vl._state == "working"

    vl.dash.panes.target = "p1"
    vl.attach_target_pane()

    assert "v1" in _watched(vl), "stopped listening to the session mid-answer"
    vl._on_event("v1", {"kind": "assistant", "text": "The migration test."})
    assert vl.speaker.spoken == ["The migration test."]


def test_the_finished_session_is_let_go(vl):
    """It lingers to finish, not forever. Otherwise every session you ever
    spoke to is still being tailed an hour later."""
    vl._on_event("v1", {"kind": "user", "text": "go"})
    vl.dash.panes.target = "p1"
    vl.attach_target_pane()
    assert "v1" in _watched(vl)

    vl._on_event("v1", {"kind": "turn_end", "durationMs": 900})
    assert "v1" not in _watched(vl)
    assert vl._lingering == set()


def test_an_idle_session_is_dropped_immediately(vl):
    """Nothing was running, so there is nothing to wait for."""
    vl.dash.panes.target = "p1"
    vl.attach_target_pane()
    assert _watched(vl) == {"p1"}


# ---- the state machine, now that turns are per pane --------------------

def test_two_sessions_can_be_working_at_once(vl):
    vl._on_event("v1", {"kind": "user", "text": "one"})
    vl.dash.panes.target = "p1"
    vl.attach_target_pane()
    vl._on_event("p1", {"kind": "user", "text": "two"})
    assert vl._turns == {"v1", "p1"}
    assert vl._state == "working"

    vl._on_event("v1", {"kind": "turn_end"})
    assert vl._state == "working", "one session finishing does not end the other"
    vl._on_event("p1", {"kind": "turn_end"})
    assert vl._state == "listening"


def test_the_same_sentence_from_two_sessions_is_spoken_twice(vl):
    """Dedupe is per session. Two agents both saying "Done." are two facts, and
    a shared set would silently drop the second one."""
    vl._on_event("v1", {"kind": "user", "text": "one"})
    vl.dash.panes.target = "p1"
    vl.attach_target_pane()
    vl._on_event("p1", {"kind": "user", "text": "two"})

    vl._on_event("v1", {"kind": "assistant", "text": "Done."})
    vl._on_event("p1", {"kind": "assistant", "text": "Done."})
    assert vl.speaker.spoken == ["Done.", "Done."]

    vl._on_event("p1", {"kind": "assistant", "text": "Done."})
    assert len(vl.speaker.spoken) == 2, "the same session repeating itself is not new"


def test_barge_in_stops_every_running_turn(vl):
    """You pressed space. You meant stop — including the session you have
    already moved the voice away from."""
    vl._on_event("v1", {"kind": "user", "text": "one"})
    vl.dash.panes.target = "p1"
    vl.attach_target_pane()
    vl._on_event("p1", {"kind": "user", "text": "two"})

    vl._interrupt_turns()
    assert vl.dash.panes.get("v1").pty.written == b"\x1b"
    assert vl.dash.panes.get("p1").pty.written == b"\x1b"
