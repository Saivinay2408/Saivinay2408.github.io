"""
The prompt the voice session is launched with.

This exists because the version that shipped named its author, addressed every
user as him, and listed his Desktop folders. Correct for one person, quietly
wrong for everybody else, and the kind of thing nobody notices in review because
it reads perfectly to the person who wrote it.

The rule these tests enforce: the prompt says a name only when the vault
actually supplies one, and it is a name rather than a fragment of a document.

    python -m pytest tests/test_voice_prompt.py -q
"""
from __future__ import annotations

import pytest

from mem.voice import voice_prompt as vp


@pytest.fixture
def vault(tmp_path):
    return tmp_path


def write_identity(vault, text):
    (vault / "identity.md").write_text(text, encoding="utf-8")
    return vault


def test_an_explicit_name_field_wins(vault):
    write_identity(vault, "---\ntype: identity\n---\n\nname:: Ada Lovelace\n")
    assert vp.vault_name(vault) == "Ada Lovelace"


def test_the_h1_is_stripped_of_its_label(vault):
    """Identity notes conventionally open "Identity core — Someone". Taking the
    whole heading produces "Identity core — Ada Lovelace's clone", which is
    worse than being unnamed."""
    write_identity(vault, "---\n---\n\n# Identity core — Ada Lovelace\n\nStuff.\n")
    assert vp.vault_name(vault) == "Ada Lovelace"


@pytest.mark.parametrize("heading", [
    "# Ada Lovelace",
    "# Identity core: Ada Lovelace",
    "# Identity core | Ada Lovelace",
])
def test_common_heading_shapes(vault, heading):
    write_identity(vault, f"---\n---\n\n{heading}\n")
    assert vp.vault_name(vault) == "Ada Lovelace"


def test_prose_is_not_a_name(vault):
    """Anything long enough to be a sentence is not a name, and using one makes
    the clone open every session by misquoting the vault at you."""
    write_identity(vault, "---\n---\n\n# " + "a rambling heading " * 6 + "\n")
    assert vp.vault_name(vault) == ""


def test_a_missing_or_unreadable_vault_is_not_an_error(tmp_path):
    """A fresh install has no identity note. That is normal, not a failure, and
    guessing here means calling someone by the wrong name every session."""
    assert vp.vault_name(tmp_path) == ""
    assert vp.vault_name(tmp_path / "nope") == ""


def test_the_unnamed_prompt_claims_no_identity():
    prompt = vp.build("")
    assert "clone" not in prompt.lower()
    assert "{name}" not in prompt
    assert "direct, capable assistant" in prompt


def test_the_named_prompt_uses_they_them():
    """The vault yields a name. A name is not a statement of pronouns, and
    guessing from one misgenders a real person in every single session."""
    prompt = vp.build("Ada Lovelace")
    assert "Ada Lovelace's clone" in prompt
    for gendered in (" his ", " her ", " him ", " she ", " he "):
        assert gendered not in f" {prompt.lower()} "


@pytest.mark.parametrize("name", ["", "Ada Lovelace"])
def test_no_placeholder_ever_survives_into_the_prompt(name):
    prompt = vp.build(name)
    assert "{" not in prompt and "}" not in prompt


def test_nothing_personal_to_the_author_is_left_in_the_template():
    """The original failure, asserted directly."""
    blob = (vp._SPEECH + vp._CLONE + vp._PLAIN + vp._SELF
            + vp._ORCHESTRATOR + vp._NAVIGATOR).lower()
    for token in ("vinay", "saivinay", "/users/", "desktop/agi", "jarvis/"):
        assert token not in blob, f"{token!r} is baked into the shipped prompt"


def test_the_voice_config_path_is_the_one_that_hot_reloads():
    """"talk faster" only works if the path in the prompt is the file the
    engine actually watches."""
    from mem.voice.paths import VOICE_CONFIG
    assert str(VOICE_CONFIG) in vp.build("Ada Lovelace")
