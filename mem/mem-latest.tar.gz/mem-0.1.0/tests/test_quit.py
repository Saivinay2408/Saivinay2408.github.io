"""
Closing the window has to end the process.

It did not, and the failure mode was worse than a stray process. macOS keeps an
app registered as running, so the NEXT launch is not a launch -- it is an
"activate" event sent to something with no window and no event loop left to
answer it. The user gets "Mem is not responding" and cannot reopen the app at
all without Activity Monitor. Reported from a Dock icon that had been working
minutes earlier.

The cause is ordinary: after `webview.start()` returns, the interpreter joins
every non-daemon thread before exiting, and this process has audio callbacks
and library threads that never finish. `sample` on the wedged process showed
the main thread parked in PyThread_acquire_lock -- blocked forever, by design,
on threads that were never going to end.
"""
from __future__ import annotations

import subprocess
import sys
import time
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

# A non-daemon thread that never finishes: exactly the shape of the real one.
STUCK = (
    "import threading, time, sys, os\n"
    "threading.Thread(target=lambda: time.sleep(9999), daemon=False).start()\n"
)


def _run(tail: str, timeout: float = 6.0) -> float | None:
    """Seconds until exit, or None if it wedged."""
    p = subprocess.Popen([sys.executable, "-c", STUCK + tail],
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    started = time.monotonic()
    try:
        p.wait(timeout=timeout)
        return time.monotonic() - started
    except subprocess.TimeoutExpired:
        p.kill()
        p.wait()
        return None


def test_a_lingering_thread_really_does_wedge_exit():
    """The bug is real, and this is what it looks like.

    Without this the fix below is a change nobody can justify keeping -- the
    next person to see a bare os._exit will tidy it into sys.exit and put the
    app straight back into "not responding".
    """
    assert _run("sys.exit(0)") is None, "expected sys.exit to hang on the join"


def test_the_quit_path_exits_anyway():
    took = _run("sys.stdout.flush(); os._exit(0)")
    assert took is not None, "os._exit must not be blocked by a live thread"
    assert took < 3.0


def test_cli_ends_the_process_rather_than_asking_it_to():
    """Guards the actual call site, not just the mechanism."""
    src = (ROOT / "mem" / "voice" / "cli.py").read_text(encoding="utf-8")
    assert "os._exit(0)" in src, "the window-close path must end the process"
    # And the panes must be closed FIRST -- os._exit runs no cleanup, and the
    # thing that matters is killing the child `claude` processes.
    quit_fn = src[src.index("def quit_now"):]
    assert quit_fn.index("shutdown()") < quit_fn.index("os._exit(0)")


def test_window_close_is_wired_to_the_quitting_one():
    """`shutdown` alone closed the panes and left the process alive. The event
    has to be bound to the function that also exits."""
    src = (ROOT / "mem" / "voice" / "cli.py").read_text(encoding="utf-8")
    assert "window.events.closed += quit_now" in src
    assert "window.events.closed += shutdown" not in src
