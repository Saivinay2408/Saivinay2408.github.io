"""One command in front of every subsystem: ``mem <cmd>``.

Dispatch is a table rather than an argparse tree on purpose. Every subcommand
owns its own parser and its own `--help`, and the table imports the module only
when that command is actually run — so `mem recall` does not pay for importing
the dashboard, and `mem voice` is the only path that needs aiohttp installed.
That is what lets the voice half be an optional extra rather than a dependency
everybody carries.
"""
from __future__ import annotations

import sys

# command -> "module" or "module:function"
COMMANDS = {
    "backfill": "mem.backfill",
    "capture": "mem.capture",
    "check-extractor": "mem.consolidate:main_check_extractor",
    "consolidate": "mem.consolidate",
    "doctor": "mem.voice.cli:main_doctor",
    "hook": "mem.hooks",
    "index": "mem.indexer",
    "init": "mem.agents",
    "init-hooks": "mem.hooks:main_init",
    "lint": "mem.lint",
    "maintain": "mem.maintain",
    "app": "mem.voice.app_cli",
    "mcp": "mem.mcp",
    "memory": "mem.switch",
    "models": "mem.voice.models_cli",
    "onboard": "mem.onboard",
    "recall": "mem.recall",
    "tokens": "mem.tokens",
    "vault": "mem.vault_cmd",
    "verify": "mem.verify",
    "voice": "mem.voice.cli",
    "setup-gui": "mem.gui.wizard",
}

# Commands that live in the optional half. Naming them lets a missing extra
# produce one clear sentence instead of a traceback about aiohttp, which tells
# the user nothing about what they should install.
NEEDS_VOICE = {"voice", "doctor"}

USAGE = """usage: mem <command> [args]

start here
  backfill      seed the vault from coding sessions you have already had
                 (asks you nothing -- start here)
  onboard       build a vault from an answered interview
  init          wire the vault into every coding agent you have: Claude Code
                 (hooks), Codex and Gemini CLI (MCP)
  models        download the speech models (365 MB, once) -- without them
                 the microphone opens and holding space does nothing
  voice         open the dashboard -- one window, live sessions, hold space
                 to talk
  app           put a Mem icon in ~/Applications (macOS)
  doctor        what is wired, what is broken, and the command that fixes it
  vault         which vault this machine uses, and how to point it elsewhere

day to day
  memory        turn the clone on or off. `off` is a plain agent: nothing
                 injected, nothing recorded
  recall        query the vault
  consolidate   run the sleep pass: extract, gate, write, commit
  lint          check a draft against how you actually write
  tokens        measure what the live path costs against your own vault

plumbing
  hook          live-path handler (SessionStart, UserPromptSubmit, Stop)
  mcp           serve the vault over MCP on stdio, for agents without hooks
  capture       ingest a session transcript (stop-hook entry point)
  index         rebuild index.json from the markdown
  maintain      link repair, dedup, key drift, reinforcement, proposals
  verify        run the numbered checks
  check-extractor  preflight: does MEM_EXTRACTOR_CMD actually run?
  init-hooks    just Claude Code's settings.json (what `init claude` calls)
  setup-gui     optional pywebview wizard over onboard + init-hooks

  MEM_DIR overrides the vault location for one shell; `mem vault <path>`
  sets it for this machine, including for the app in your Dock, which
  inherits no environment at all.
"""


def main() -> int:
    if len(sys.argv) < 2 or sys.argv[1] in ("-h", "--help", "help"):
        print(USAGE)
        return 0
    command = sys.argv[1]
    if command not in COMMANDS:
        print(f"unknown command: {command}\n\n{USAGE}", file=sys.stderr)
        return 2
    target, _, func = COMMANDS[command].partition(":")
    try:
        module = __import__(target, fromlist=["main"])
    except ImportError as e:
        if command in NEEDS_VOICE:
            print(f"`mem {command}` needs the voice extra, which is not "
                  f"installed:\n\n    pip install \"mem[voice]\"\n\n({e})",
                  file=sys.stderr)
            return 2
        raise
    return getattr(module, func or "main")(sys.argv[2:]) or 0


if __name__ == "__main__":
    sys.exit(main())
