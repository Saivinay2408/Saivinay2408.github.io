"""
mem voice — one window over your agents, with your memory in them.

    mem voice                 the dashboard
    mem voice --browser       serve only; open the URL yourself
    mem voice --no-voice      dashboard without the mic (typing still works)

Its siblings live at the top level, because they are not voice features:
`mem doctor` (defined here, since it reports on this half) and `mem init`.

Hold space to talk. There is no listening mode to turn on — see voice_loop.

The stack this replaces opened two windows that fought each other: a frameless
always-on-top HUD, plus a Terminal.app window AppleScript'd into existence next
to it, with a regex scraper reading the terminal to find out what the agent had
said. This opens one window, the sessions live inside it, and nothing is
scraped — the agent's own transcript is the event stream.
"""
from __future__ import annotations

import argparse
import signal
import sys
import threading

WHISPER_SIZES = ("tiny", "base", "small", "medium")


def _settle_launch_dir() -> None:
    """Pick a working directory when the launcher did not give us one.

    macOS starts a double-clicked app in "/", and the first session then opens
    there. Home was the first fix and it was not enough: Claude Code asks "do
    you trust this folder?" the first time it runs anywhere new, and while
    that prompt is up the session ignores everything you type. Landing in a
    folder nobody has approved turns the app's first impression into a
    terminal that appears to be broken.

    So the fallback is the project you used most recently — already trusted,
    already where you work — and only then home. Run before the Dashboard is
    built, because panes take this as their default.
    """
    import os
    from pathlib import Path

    from . import paths

    if Path.cwd() != Path("/"):
        return
    best = None
    try:
        from . import registry
        from .projects import list_projects
        rows = registry.merged(list_projects()).get("projects") or []
        best = next((r["cwd"] for r in rows
                     if not r.get("missing") and Path(r["cwd"]).is_dir()), None)
    except Exception:                                       # noqa: BLE001
        best = None
    chosen = Path(best) if best else Path.home()
    try:
        os.chdir(chosen)
    except OSError:
        chosen = Path.home()
        os.chdir(chosen)
    # LAUNCH_CWD is captured at import; this runs after it, so it is corrected
    # here rather than left describing a directory we have just left.
    paths.LAUNCH_CWD = chosen.resolve()


def _run_dashboard(a) -> int:
    # aiohttp is reached HERE, not at module import, so the dispatcher in
    # __main__ cannot catch it: `import mem.voice.cli` succeeds perfectly well
    # without it. A bare `pip install mem` therefore used to answer `mem voice`
    # with a traceback about a package the user has never heard of. The extra
    # is the answer, so the extra is what the error names.
    try:
        from aiohttp import web
    except ImportError:
        print('`mem voice` needs the window extra:\n\n'
              '    pip install "mem[voice]"     # with the microphone\n'
              '    pip install "mem[window]"    # typing only\n',
              file=sys.stderr)
        return 2

    from .server import Dashboard, free_port
    from .settings import load_defaults

    _settle_launch_dir()

    saved = load_defaults()
    model = a.model or saved["model"]
    whisper = a.whisper or saved["whisper"]
    permission_mode = "acceptEdits" if a.safe else saved["permissionMode"]

    dash = Dashboard(model=model, permission_mode=permission_mode)
    port = a.port or free_port()
    url = f"http://127.0.0.1:{port}/"

    # The session you talk to exists before the window does, so the first pane
    # is already painting its TUI by the time you can look at it.
    dash.panes.open_voice(model, dash.permission_mode)

    # THE ONE PROMPT WE CANNOT ANSWER FOR YOU.
    #
    # The clone opens in your vault, and the first time `claude` runs in any
    # new folder it asks whether you trust the files in it. Until that is
    # answered the session ignores the keyboard — which looks exactly like a
    # terminal that does not work, and has been reported as one every time it
    # has happened. So say what it is, before it is seen rather than after.
    #
    # Deliberately NOT answered on your behalf: it is a security question
    # about a folder, and marking folders trusted without being asked is not
    # a thing this app should do quietly, even for a folder it created.
    from . import supervisor as _sup
    from .paths import clone_cwd as _clone_cwd
    if _sup.folder_is_trusted(_clone_cwd()) is False:
        # "may", not "will": Claude Code also trusts a folder whose parent it
        # already trusts, so this check is deliberately pessimistic. A note
        # that turns out to be unnecessary costs a sentence; a session that
        # silently ignores the keyboard costs an afternoon.
        dash.first_run_note = (
            f"Your clone is opening in {_clone_cwd()} for the first time. "
            "Claude Code may ask whether you trust that folder — answer it in "
            "the pane and it will not ask again.")

    if not a.no_voice:
        try:
            from .voice_loop import VoiceLoop
            dash.voice = VoiceLoop(dash, whisper=whisper)
            dash.voice.start()
        except Exception as e:                             # noqa: BLE001
            # A missing mic or model weight must not cost you the dashboard —
            # typing into the prompt drives the same session either way.
            print(f"[voice] disabled: {type(e).__name__}: {e}", file=sys.stderr)

    from .memory_ctl import MemoryMonitor
    from .usage import UsageMonitor
    dash.usage = UsageMonitor(dash, probe=not a.no_usage_probe)
    dash.memory = MemoryMonitor(dash)
    dash.usage.start()
    dash.memory.start()

    runner = web.AppRunner(dash.app, access_log=None)

    def serve() -> None:
        import asyncio
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.run_until_complete(runner.setup())
        site = web.TCPSite(runner, "127.0.0.1", port)
        loop.run_until_complete(site.start())
        loop.run_forever()

    if a.browser:
        print(f"mem-voice on {url}")
        try:
            serve()
        except KeyboardInterrupt:
            pass
        finally:
            dash.panes.close_all()
        return 0

    threading.Thread(target=serve, daemon=True).start()

    try:
        import webview
    except ImportError:
        # Not an error worth dying over: the whole UI is a local web page, and
        # a browser is a perfectly good window for it. But WHERE that message
        # goes decides whether this is a graceful fallback or a crash.
        #
        # From a terminal, printing the URL is exactly right. From the Dock it
        # is a disaster: stdout is a log file, so the icon bounces, macOS asks
        # for the microphone -- the process really did start -- and then
        # nothing ever appears. A tester hit precisely this and reported the
        # app as broken, which from where they sat it was.
        #
        # So when nobody can read stdout, open the page instead of describing
        # it. A GUI launch has no controlling terminal; that is the test.
        print(f"mem-voice on {url}\n"
              f"(no desktop window: pip install pywebview — or just open that URL)")
        if not sys.stdout.isatty():
            try:
                import webbrowser
                webbrowser.open(url)
            except Exception:                          # noqa: BLE001
                pass
        try:
            serve()
        except KeyboardInterrupt:
            pass
        finally:
            dash.panes.close_all()
        return 0

    window = webview.create_window(
        "mem-voice", url,
        width=1180, height=860, min_size=(880, 620),
        background_color="#08090b",
        text_select=True,
    )

    def shutdown() -> None:
        dash.panes.close_all()

    window.events.closed += shutdown
    signal.signal(signal.SIGINT, lambda *_: (shutdown(), sys.exit(0)))
    webview.start()
    shutdown()
    return 0


def main_doctor(argv=None) -> int:
    """`mem doctor`. Every check, printed.

    The same data the Health tab shows, for people who have not got a window
    open yet — which includes anyone whose window will not open, i.e. exactly
    the people who need it most. It must therefore never require the window,
    the vault, or an agent to be present.
    """
    argparse.ArgumentParser(
        prog="mem doctor",
        description="what is wired, what is broken, and the command that fixes it"
    ).parse_args(argv or [])

    from .health import run_all
    report = run_all()
    mark = {True: "ok  ", False: "FAIL", None: "?   "}
    for c in report["checks"]:
        print(f"  {mark[c['ok']]} {c['name']:<16} {c['detail']}")
        if c["fix"] and c["ok"] is not True:
            print(f"       -> {c['fix']}")
    n = report["failing"]
    print(f"\n{n} failing" if n else "\nall clear")
    return 1 if n else 0


def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(
        prog="mem voice",
        description="one window over your coding agents, with your memory in them")

    # No argparse defaults on these two. With `default="sonnet"`, an unpassed
    # flag was indistinguishable from an explicit one, so the model and whisper
    # size picked in Defaults were written to disk and then overruled on every
    # launch — a settings screen that silently did nothing.
    ap.add_argument("--model", default=None, help="model for the voice session")
    ap.add_argument("--whisper", default=None, choices=WHISPER_SIZES,
                    help="speech-recognition model size")
    ap.add_argument("--safe", action="store_true",
                    help="run sessions gated (acceptEdits) instead of full permissions")
    ap.add_argument("--browser", action="store_true",
                    help="don't open a window; just serve and print the URL")
    ap.add_argument("--no-voice", action="store_true",
                    help="skip the mic loop (the typed prompt still drives the session)")
    ap.add_argument("--no-usage-probe", action="store_true",
                    help="skip the periodic /usage read (local token counts only)")
    ap.add_argument("--port", type=int, default=0)
    return ap


def main(argv=None) -> int:
    return _run_dashboard(build_parser().parse_args(argv))


if __name__ == "__main__":
    sys.exit(main())
