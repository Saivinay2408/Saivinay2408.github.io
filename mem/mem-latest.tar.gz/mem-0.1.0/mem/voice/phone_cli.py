"""
mem phone — set up and control reaching Mem from your phone.

    mem phone setup     store your bot token (asked privately, kept in the Keychain)
    mem phone pair      a one-tap link that pairs your Telegram account
    mem phone tunnel    publish the phone app over Tailscale (private to your devices)
    mem phone link      the phone app's address, with its login token
    mem phone status    what is set up, who is paired, whether the app is reachable
    mem phone on|off    allow or block all phone access, right now
    mem phone forget    remove the token and every pairing

Telegram and the phone app talk to the Mem window, so Mem has to be open on
the Mac for either to answer.
"""
from __future__ import annotations

import getpass
import sys

from . import phone, tunnel


def _verify(token: str) -> tuple[bool, str]:
    from .telegram import TelegramBridge
    b = TelegramBridge(dash=None, token=token)
    try:
        me = b.call("getMe")
    except RuntimeError as e:
        return False, str(e)
    return True, me.get("username", "")


def setup(argv: list[str]) -> int:
    print("Create a bot first: in Telegram, message @BotFather, send /newbot, and copy")
    print("the token it gives you. Use a NEW bot just for Mem: a bot already used by")
    print("another assistant would stop working for it.\n")
    token = getpass.getpass("bot token (hidden): ").strip()
    if not phone.looks_like_token(token):
        print("That does not look like a bot token (it is digits, a colon, then ~35 characters).")
        return 2
    ok, who = _verify(token)
    if not ok:
        print(f"Telegram rejected it: {who}")
        return 1
    if not phone.set_token(token):
        print("Could not save it to the Keychain. Set MEM_TELEGRAM_TOKEN instead.")
        return 1
    phone.update(bot=who, enabled=True)
    print(f"\nSaved. Your bot is @{who}.")
    return pair([])


def pair(argv: list[str]) -> int:
    cfg = phone.load()
    if not phone.get_token():
        print("No bot yet. Run: mem phone setup")
        return 1
    code = phone.new_pair_code()
    link = phone.pair_link(code)
    print("\nOn your phone, open this link and press Start (valid for 10 minutes):\n")
    print(f"    {link}" if link else f"    send /start {code} to your bot")
    print("\nThen restart Mem on the Mac if it is open, so it picks up the bot.")
    if cfg["allowed"]:
        print(f"(already paired: {', '.join(cfg['names'].get(str(u), str(u)) for u in cfg['allowed'])})")
    return 0


def status(argv: list[str]) -> int:
    cfg = phone.load()
    tok = phone.get_token()
    print(f"phone access : {'on' if cfg['enabled'] else 'off'}")
    print(f"telegram bot : {'@' + cfg['bot'] if tok and cfg['bot'] else ('token stored' if tok else 'not set up (mem phone setup)')}")
    names = [cfg["names"].get(str(u), str(u)) for u in cfg["allowed"]]
    print(f"paired       : {', '.join(names) if names else 'nobody yet (mem phone pair)'}")
    st = tunnel.status()
    url = tunnel.public_url(cfg["port"]) if st["running"] else ""
    if not st["installed"]:
        ts = "Tailscale not installed"
    elif not st["running"]:
        ts = "Tailscale installed, not connected"
    else:
        ts = url or f"connected as {st['host']}, not serving (mem phone tunnel)"
    print(f"phone app    : {ts}")
    print(f"answers on Mac: {'spoken' if cfg['speak_on_mac'] else 'quiet'}")
    return 0


def do_tunnel(argv: list[str]) -> int:
    port = phone.load()["port"]
    ok, msg = tunnel.serve(port)
    print(msg)
    if ok:
        print(f"\nOpen it on your phone (also from your bot with /app):\n\n    {msg}/phone?k={phone.web_token()}")
        print("\nYour phone needs the Tailscale app, signed into the same account.")
    return 0 if ok else 1


def link(argv: list[str]) -> int:
    url = tunnel.public_url(phone.load()["port"])
    if not url:
        print("Not being served. Run: mem phone tunnel")
        return 1
    print(f"{url}/phone?k={phone.web_token()}")
    return 0


def main(argv: list[str] | None = None) -> int:
    argv = list(argv or [])
    cmd = argv[0] if argv else "status"
    rest = argv[1:]
    if cmd in ("-h", "--help", "help"):
        print(__doc__.strip())
        return 0
    if cmd == "setup":
        return setup(rest)
    if cmd == "pair":
        return pair(rest)
    if cmd == "status":
        return status(rest)
    if cmd == "tunnel":
        return do_tunnel(rest)
    if cmd == "link":
        return link(rest)
    if cmd == "on":
        phone.update(enabled=True)
        print("Phone access is on.")
        return 0
    if cmd == "off":
        phone.lock()
        print("Phone access is off. Open phone app sessions are logged out.")
        return 0
    if cmd == "forget":
        phone.delete_token()
        phone.update(allowed=[], names={}, enabled=False, bot="")
        phone.rotate_web_token()
        tunnel.unserve(phone.load()["port"])
        print("Forgotten: token, pairings, and the phone app link.")
        return 0
    print(f"unknown: mem phone {cmd}\n\n{__doc__.strip()}", file=sys.stderr)
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
