"""
mem voice — one window over your agents, with your memory in them.

    mem voice                 the dashboard
    mem voice --browser       serve only; open the URL yourself
    mem voice --no-voice      dashboard without the mic (typing still works)

Its siblings live at the top level, because they are not voice features:
`mem doctor` (defined here, since it reports on this half) and `mem init`.

Hold space to talk. There is no listening mode to turn on — see voice_loop.

The stack this replaces opened two windows that fought each other: a frameless
always-on-top HUD, plus a Terminal.app window AppleScript'd into existence next
to it, with a regex scraper reading the terminal to find out what the agent had
said. This opens one window, the sessions live inside it, and nothing is
scraped — the agent's own transcript is the event stream.
"""
from __future__ import annotations

import argparse
import os
import signal
import sys
import threading
import time

WHISPER_SIZES = ("tiny", "base", "small", "medium")


def _settle_launch_dir() -> None:
    """Pick a working directory when the launcher did not give us one.

    macOS starts a double-clicked app in "/", and the first session then opens
    there. Home was the first fix and it was not enough: Claude Code asks "do
    you trust this folder?" the first time it runs anywhere new, and while
    that prompt is up the session ignores everything you type. Landing in a
    folder nobody has approved turns the app's first impression into a
    terminal that appears to be broken.

    So the fallback is the project you used most recently — already trusted,
    already where you work — and only then home. Run before the Dashboard is
    built, because panes take this as their default.
    """
    import os
    from pathlib import Path

    from . import paths

    if Path.cwd() != Path("/"):
        return
    best = None
    try:
        from . import registry
        from .projects import list_projects
        rows = registry.merged(list_projects()).get("projects") or []
        best = next((r["cwd"] for r in rows
                     if not r.get("missing") and Path(r["cwd"]).is_dir()), None)
    except Exception:                                       # noqa: BLE001
        best = None
    chosen = Path(best) if best else Path.home()
    try:
        os.chdir(chosen)
    except OSError:
        chosen = Path.home()
        os.chdir(chosen)
    # LAUNCH_CWD is captured at import; this runs after it, so it is corrected
    # here rather than left describing a directory we have just left.
    paths.LAUNCH_CWD = chosen.resolve()


def _run_dashboard(a) -> int:
    # aiohttp is reached HERE, not at module import, so the dispatcher in
    # __main__ cannot catch it: `import mem.voice.cli` succeeds perfectly well
    # without it. A bare `pip install mem` therefore used to answer `mem voice`
    # with a traceback about a package the user has never heard of. The extra
    # is the answer, so the extra is what the error names.
    try:
        from aiohttp import web
    except ImportError:
        print('`mem voice` needs the window extra:\n\n'
              '    pip install "mem[voice]"     # with the microphone\n'
              '    pip install "mem[window]"    # typing only\n',
              file=sys.stderr)
        return 2

    from .server import Dashboard, free_port
    from .settings import load_defaults

    _settle_launch_dir()

    saved = load_defaults()
    model = a.model or saved["model"]
    whisper = a.whisper or saved["whisper"]
    permission_mode = "acceptEdits" if a.safe else saved["permissionMode"]

    dash = Dashboard(model=model, permission_mode=permission_mode)
    port = a.port or free_port()
    url = f"http://127.0.0.1:{port}/"

    # The session you talk to exists before the window does, so the first pane
    # is already painting its TUI by the time you can look at it.
    dash.panes.open_voice(model, dash.permission_mode)

    # THE ONE PROMPT WE CANNOT ANSWER FOR YOU.
    #
    # The clone opens in your vault, and the first time `claude` runs in any
    # new folder it asks whether you trust the files in it. Until that is
    # answered the session ignores the keyboard — which looks exactly like a
    # terminal that does not work, and has been reported as one every time it
    # has happened. So say what it is, before it is seen rather than after.
    #
    # Deliberately NOT answered on your behalf: it is a security question
    # about a folder, and marking folders trusted without being asked is not
    # a thing this app should do quietly, even for a folder it created.
    from . import supervisor as _sup
    from .paths import clone_cwd as _clone_cwd
    if _sup.folder_is_trusted(_clone_cwd()) is False:
        # "may", not "will": Claude Code also trusts a folder whose parent it
        # already trusts, so this check is deliberately pessimistic. A note
        # that turns out to be unnecessary costs a sentence; a session that
        # silently ignores the keyboard costs an afternoon.
        dash.first_run_note = (
            f"Your clone is opening in {_clone_cwd()} for the first time. "
            "Claude Code may ask whether you trust that folder — answer it in "
            "the pane and it will not ask again.")

    if not a.no_voice:
        try:
            from .voice_loop import VoiceLoop
            dash.voice = VoiceLoop(dash, whisper=whisper)
            dash.voice.start()
        except Exception as e:                             # noqa: BLE001
            # A missing mic or model weight must not cost you the dashboard —
            # typing into the prompt drives the same session either way.
            print(f"[voice] disabled: {type(e).__name__}: {e}", file=sys.stderr)

    from .memory_ctl import MemoryMonitor
    from .usage import UsageMonitor
    dash.usage = UsageMonitor(dash, probe=not a.no_usage_probe)
    dash.memory = MemoryMonitor(dash)
    dash.usage.start()
    dash.memory.start()

    runner = web.AppRunner(dash.app, access_log=None)

    def serve() -> None:
        import asyncio
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.run_until_complete(runner.setup())
        site = web.TCPSite(runner, "127.0.0.1", port)
        loop.run_until_complete(site.start())
        loop.run_forever()

    if a.browser:
        print(f"mem-voice on {url}")
        try:
            serve()
        except KeyboardInterrupt:
            pass
        finally:
            dash.panes.close_all()
        return 0

    threading.Thread(target=serve, daemon=True).start()

    try:
        import webview
    except ImportError:
        # Not an error worth dying over: the whole UI is a local web page, and
        # a browser is a perfectly good window for it. But WHERE that message
        # goes decides whether this is a graceful fallback or a crash.
        #
        # From a terminal, printing the URL is exactly right. From the Dock it
        # is a disaster: stdout is a log file, so the icon bounces, macOS asks
        # for the microphone -- the process really did start -- and then
        # nothing ever appears. A tester hit precisely this and reported the
        # app as broken, which from where they sat it was.
        #
        # So when nobody can read stdout, open the page instead of describing
        # it. A GUI launch has no controlling terminal; that is the test.
        print(f"mem-voice on {url}\n"
              f"(no desktop window: pip install pywebview — or just open that URL)")
        if not sys.stdout.isatty():
            try:
                import webbrowser
                webbrowser.open(url)
            except Exception:                          # noqa: BLE001
                pass
        try:
            serve()
        except KeyboardInterrupt:
            pass
        finally:
            dash.panes.close_all()
        return 0

    window = webview.create_window(
        "mem-voice", url,
        width=1180, height=860, min_size=(880, 620),
        background_color="#08090b",
        text_select=True,
    )

    def shutdown() -> None:
        dash.panes.close_all()

    def quit_now() -> None:
        """CLOSING THE WINDOW HAS TO END THE PROCESS. Hard.

        It did not, and the consequence was worse than a stray process: macOS
        keeps the app registered as running, so the next launch is not a launch
        at all -- it is an "activate" Apple Event sent to something with no
        window and no event loop left to answer it. The user gets "Mem is not
        responding" and CANNOT REOPEN THE APP AT ALL until they find it in
        Activity Monitor. Reported from a Dock icon that had been working
        minutes earlier.

        The cause is ordinary and worth naming: after webview.start() returns,
        the interpreter tries to join every non-daemon thread before exiting,
        and this process has audio callbacks and library threads that never
        finish. `sample` on the wedged process showed the main thread parked in
        PyThread_acquire_lock -- shutdown blocked forever, by design, on
        threads that are never going to end.

        sys.exit() cannot help: it raises on this thread and then waits for the
        same joins. So the panes are closed properly first -- that is the part
        that matters, it kills the child `claude` processes -- and then the
        process is ended outright rather than asked politely.
        """
        shutdown()
        sys.stdout.flush()
        sys.stderr.flush()
        os._exit(0)

    # NOT bound to a pywebview event. Neither `shown` nor `closed` fires in
    # this build -- measured both ways -- so anything that depends on them
    # silently never happens. The watchdog below does the scheduling instead,
    # from a condition it can see.
    window.events.closed += quit_now
    signal.signal(signal.SIGINT, lambda *_: quit_now())

    def watchdog() -> None:
        """Exit when the last window is gone, whatever pywebview did about it.

        BELT AND BRACES, AND THE BRACES ARE LOAD-BEARING. The `closed` event
        above is the tidy path and it is not reliable here: a real run ended
        with zero windows on screen, `webview.start()` never returning, and no
        thread anywhere in the shutdown path -- the event simply had not fired.
        `sample` showed a perfectly healthy Cocoa event loop with nothing left
        to draw. From the Dock that is an app that will not open, because macOS
        will not start a second instance and the first one has no window to
        activate: "Mem is not responding".

        So the condition that actually matters is observed rather than
        subscribed to. `webview.windows` is pywebview's own registry; once it
        has held a window and then empties, this process has no reason to
        exist. Polling a list once a second costs nothing and does not depend
        on any callback being delivered.
        """
        had_one = False
        fronted = False
        while True:
            time.sleep(1.0)
            try:
                n = len(webview.windows)
            except Exception:                          # noqa: BLE001
                return                                 # teardown already running
            if n:
                if not had_one:
                    had_one = True
                if not fronted:
                    fronted = _bring_to_front()
            elif had_one:
                quit_now()
                return

    # Which build is actually running. Printed before anything can go wrong,
    # so a log from a confused machine always carries it.
    try:
        from .._build import BUILD as _BUILD
    except ImportError:
        _BUILD = "unknown"
    print(f"[mem] build {_BUILD}", flush=True)

    threading.Thread(target=watchdog, daemon=True).start()
    webview.start()
    quit_now()
    return 0



def _bring_to_front() -> bool:
    """Show the window, in front, wearing the app's own icon.

    THE WINDOW IS CREATED AND NEVER DISPLAYED WITHOUT THIS. Measured, on a
    clean install: CGWindowList reports a 1180x860 window at (145,48) that is
    simply not `onscreen`. From the user's side that is an icon that bounces
    and an app that never opens -- which is exactly the report.

    The cause is that a framework Python re-execs into
    Python.framework/.../Python.app, so this process belongs to that bundle
    rather than to Mem.app, and nothing ever makes it the active application.
    Setting the activation policy to Regular gives it a Dock presence;
    activating brings its window up; the icon is loaded from the bundle the
    launcher points at, so the Dock shows Mem rather than a Python rocket.

    TIMING IS THE WHOLE TRICK, and both obvious placements are wrong:

      before webview.start()  -- touching NSApplication first pre-empts
                                 pywebview's own Cocoa setup and the window is
                                 then never created at all. Measured: zero
                                 windows every time.

      on the `shown` event    -- that event does not fire in this build. Nor
                                 does `closed`. Anything hung on them silently
                                 never runs.

    So it is called from the watchdog thread once pywebview's own registry
    reports a window, and the AppKit work is handed to the main run loop --
    which is where AppKit calls belong, and where nothing else is waiting.

    Returns True once it has been done, so the caller stops trying.
    """
    if sys.platform != "darwin":
        return True
    try:
        from AppKit import (NSApplication, NSApplicationActivationPolicyRegular,
                            NSImage)
        from PyObjCTools import AppHelper
    except ImportError:
        return True                                    # nothing to do, stop asking
    from pathlib import Path

    def on_main() -> None:
        try:
            app = NSApplication.sharedApplication()
            app.setActivationPolicy_(NSApplicationActivationPolicyRegular)
            bundle = os.environ.get("MEM_APP_BUNDLE", "")
            if bundle:
                icon = Path(bundle) / "Contents" / "Resources" / "icon.icns"
                if icon.is_file():
                    image = NSImage.alloc().initWithContentsOfFile_(str(icon))
                    if image:
                        app.setApplicationIconImage_(image)
            app.activateIgnoringOtherApps_(True)
        except Exception:                              # noqa: BLE001
            pass                                       # presentation only

    try:
        AppHelper.callAfter(on_main)
    except Exception:                                  # noqa: BLE001
        return True
    # A LINE IN THE LOG, because this is the step whose silence cost the most.
    # "the window did not open" and "the window opened behind everything" look
    # identical from the outside and have different fixes, and a GUI launch has
    # no terminal to say which. Now the log does.
    print(f"[mem] window shown; brought to front (bundle="
          f"{os.environ.get('MEM_APP_BUNDLE', 'none')})", flush=True)
    return True


def main_doctor(argv=None) -> int:
    """`mem doctor`. Every check, printed.

    The same data the Health tab shows, for people who have not got a window
    open yet — which includes anyone whose window will not open, i.e. exactly
    the people who need it most. It must therefore never require the window,
    the vault, or an agent to be present.
    """
    argparse.ArgumentParser(
        prog="mem doctor",
        description="what is wired, what is broken, and the command that fixes it"
    ).parse_args(argv or [])

    from .health import run_all
    report = run_all()
    mark = {True: "ok  ", False: "FAIL", None: "?   "}
    for c in report["checks"]:
        print(f"  {mark[c['ok']]} {c['name']:<16} {c['detail']}")
        if c["fix"] and c["ok"] is not True:
            print(f"       -> {c['fix']}")
    n = report["failing"]
    print(f"\n{n} failing" if n else "\nall clear")
    return 1 if n else 0


def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(
        prog="mem voice",
        description="one window over your coding agents, with your memory in them")

    # No argparse defaults on these two. With `default="sonnet"`, an unpassed
    # flag was indistinguishable from an explicit one, so the model and whisper
    # size picked in Defaults were written to disk and then overruled on every
    # launch — a settings screen that silently did nothing.
    ap.add_argument("--model", default=None, help="model for the voice session")
    ap.add_argument("--whisper", default=None, choices=WHISPER_SIZES,
                    help="speech-recognition model size")
    ap.add_argument("--safe", action="store_true",
                    help="run sessions gated (acceptEdits) instead of full permissions")
    ap.add_argument("--browser", action="store_true",
                    help="don't open a window; just serve and print the URL")
    ap.add_argument("--no-voice", action="store_true",
                    help="skip the mic loop (the typed prompt still drives the session)")
    ap.add_argument("--no-usage-probe", action="store_true",
                    help="skip the periodic /usage read (local token counts only)")
    ap.add_argument("--port", type=int, default=0)
    # Set by the .app launcher. It marks THIS instance as the one the icon
    # started, so a relaunch can clear it without touching a `mem voice`
    # somebody is running in a terminal -- the launcher cannot match on the
    # interpreter path, because a framework Python re-execs into Python.app
    # and the path is gone from the command line by the time it is running.
    ap.add_argument("--launched-from-app", action="store_true",
                    help=argparse.SUPPRESS)
    return ap


def main(argv=None) -> int:
    return _run_dashboard(build_parser().parse_args(argv))


if __name__ == "__main__":
    sys.exit(main())
