"""
A stamp identifying exactly which build this is.

WHY THIS EXISTS. Three separate times, a fix was published, installed, and
still appeared broken -- and each time the only way to tell whether the running
code was new was to infer it from the wording of an error message. That is not
a diagnosis, it is a guess, and twice it was the wrong one.

`release_site.py` rewrites this when it builds the tarball. "dev" means a
checkout, not a release.
"""
BUILD = "20260820-225912-261739d"
